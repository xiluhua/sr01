package test;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import net.sf.json.JSON;

import com.taiping.dianshang.outer.service.impl.giftScore.model.GiftScoreReturn;
import com.taiping.facility.tool.AesUtil;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.Md5EncryptTool;

public class Test_gift {

	public static void main(String[] args) throws UnsupportedEncodingException, Exception {
		 String md5key = "MD5KEY_YXFZPFFXT";
        String ASEKEY = "y9i61rnjsech8cmr";   //加密解密秘钥
       // String memberId = "9f92cd8023c6e3468fe2bee22ecdf0db"; //会员Id
            //礼包生产接口
        String memberId = "4d8784a7ddb7fc67624d43626817568b";//
        String phone = "13521700005";
        String email = "";
        String ruleType = "2";
        String childType = "1";
        String channel = "1";
        String requestId = "001133490418311";
        String blueId = "50000729";
        String paymentMethod = "2";
        String policyNo = "001133490418311";
        String premium = "1100.0";
        String actionId = "";
        String memo = "";
        String innercome = "";
        String waitingPeriod = "";
        String companySource = "1";

        /* String memo = "购买孝心宝50元";
        String innercome = "2000";
        String waitingPeriod = "0";
        String companySource = "TCSF";
*/
        // String token = MD5.MD5Encode(md5key + "|" + memberId+"|"+ruleType+"|"+channel);
        String token = Md5EncryptTool.getMd5(md5key + "|" + memberId+"|"+ruleType+"|"+channel+"|"+companySource+"|"+requestId);
        // String token2 = MD5.MD5Encode(md5key + "|" + memberId+"|"+phone);
        memberId = URLEncoder.encode(AesUtil.Encrypt(memberId,ASEKEY),"UTF-8");
        System.out.print("---------------memberId--------"+memberId);
        phone =URLEncoder.encode(AesUtil.Encrypt(phone,ASEKEY),"UTF-8");
        System.out.print("---------------phone--------"+phone);
        email =URLEncoder.encode(AesUtil.Encrypt(email,ASEKEY),"UTF-8");
        ruleType =URLEncoder.encode(AesUtil.Encrypt(ruleType,ASEKEY),"UTF-8");
        childType =URLEncoder.encode(AesUtil.Encrypt(childType,ASEKEY),"UTF-8");
        channel =URLEncoder.encode(AesUtil.Encrypt(channel,ASEKEY),"UTF-8");
        requestId = URLEncoder.encode(AesUtil.Encrypt(requestId,ASEKEY),"UTF-8");
        blueId = URLEncoder.encode(AesUtil.Encrypt(blueId,ASEKEY),"UTF-8");
        paymentMethod = URLEncoder.encode(AesUtil.Encrypt(paymentMethod,ASEKEY),"UTF-8");
        policyNo = URLEncoder.encode(AesUtil.Encrypt(policyNo,ASEKEY),"UTF-8");
        premium = URLEncoder.encode(AesUtil.Encrypt(premium,ASEKEY),"UTF-8");
        actionId = URLEncoder.encode(AesUtil.Encrypt(actionId,ASEKEY),"UTF-8");
        memo = URLEncoder.encode(AesUtil.Encrypt(memo,ASEKEY),"UTF-8");
        innercome = URLEncoder.encode(AesUtil.Encrypt(innercome,ASEKEY),"UTF-8");
        waitingPeriod = URLEncoder.encode(AesUtil.Encrypt(waitingPeriod,ASEKEY),"UTF-8");
        companySource = URLEncoder.encode(AesUtil.Encrypt(companySource,ASEKEY),"UTF-8");

        token =  URLEncoder.encode(AesUtil.Encrypt(token,ASEKEY),"UTF-8");
        System.out.print("---------------token--------"+token);
        //拼接url字符串
        String url="http://10.1.117.34:8001/b2b2eM2/ws/addGifts/"+memberId+"/"+phone+"/"+email+"/"+ruleType+"/"+childType+"/"+channel+"/"+requestId+"/"+blueId+"/"+paymentMethod+"/"+policyNo+"/"+premium+"/"+actionId+"/"+memo+"/"+innercome+"/"+waitingPeriod+"/"+companySource+"/"+token;

        System.out.println(url);
        String responseStrDetails = HttpclientTool.post(url, "", "utf-8");
        System.out.println(responseStrDetails);
        Map mapDetails = JsonTool.toObject(responseStrDetails, Map.class, DateTool.DATE_TIME_MASK);
        //接口返回信息
        String resTokenDetails = AesUtil.Decrypt((String) mapDetails.get("token"),ASEKEY);
        String resResultDetails = (String) mapDetails.get("result");
        String resMemberIdDetails = (String) mapDetails.get("memberId");

	}
}

package com.taiping.dianshang.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * @ClassName ISP_PAY_CALLBACK
 * @Description
 * @Version
 */
@Entity
@Table(name = "ISP_PAY_CALLBACK")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspPayCallback implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -725309447202996976L;
	@Id
	@Column(name = "ID")
	private Long id;
	@Column(name = "PARTNER_ID")
	private Long partnerId; 				// 方案ID
	@Column(name = "ACTUAL_URL")
	private String actualUrl;				// 实际URL
	@Column(name = "PROXY_URL")
	private String proxyUrl; 				// 代理URL
	@Column(name = "STATUS")
	private String status; 	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;				// 创建时间
	@Column(name="SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name="TYPE")
	private Integer type;
	
	public Integer getSellChannel() {
		return sellChannel;
	}
	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public String getActualUrl() {
		return actualUrl;
	}
	public void setActualUrl(String actualUrl) {
		this.actualUrl = actualUrl;
	}
	public String getProxyUrl() {
		return proxyUrl;
	}
	public void setProxyUrl(String proxyUrl) {
		this.proxyUrl = proxyUrl;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public IspPayCallback() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	
	
}

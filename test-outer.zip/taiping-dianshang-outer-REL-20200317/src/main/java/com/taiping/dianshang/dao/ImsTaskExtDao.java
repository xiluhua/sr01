package com.taiping.dianshang.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.ImsTaskExt;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class ImsTaskExtDao extends BaseWriteDao<ImsTaskExt, Long>{
	
	@Resource
	private IspSequenceDao ispSequenceDao;
	
	@Transactional
	public Long save(ImsTaskExt taskExt){
		Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IMS_TASK_EXT);
		taskExt.setTaskExtId(seq);
		return super.save(taskExt);
	}
	
	@Transactional
	public void update(ImsTaskExt taskExt){
		super.update(taskExt);
	}
}

package com.taiping.dianshang.outer.service.impl;

import java.io.IOException;
import java.util.Date;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.outer.DTO.request.RequestCancelDTO;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.service.CancelService;
import com.taiping.dianshang.outer.service3.url.UrlService;
import com.taiping.dianshang.service.httpclient.HttpclientService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.LogTool;

@Service
public class CancelImpl implements CancelService{
	@Resource
	BusinesslogService businesslogService;
	@Resource
	UrlService urlService;
	@Resource
	HttpclientService httpclientService;
	
	public Integer exec(String partnerApplyId,Long partnerId){
		Integer operateStatus = 2;
		ResponseDTO responseDTO = null; 
			
		RequestCancelDTO cancelDTO = new RequestCancelDTO();
		cancelDTO.getBusiness().setBusiId(partnerApplyId);
		cancelDTO.getBusiness().setPartnerId(String.valueOf(partnerId));
		cancelDTO.getBusiness().setServiceCode(ConstantTool.CANCEL);
		cancelDTO.getBusiness().setTransTime(new Date());
		
		IspApply apply = new IspApply();
		apply.setPartnerApplyId(partnerApplyId);
		apply.setPartnerId(partnerId);
		try {
			String requestXml = JAXBTool.marshal(cancelDTO);
			LogTool.debug(this.getClass(),"cancel requestXml:"+requestXml);
			System.err.println();
			businesslogService.postBusinessOpelog_1(apply, requestXml, ConstantTool.CANCEL, 1, 3);
			IspHttpclientParams httpclientParams = CacheContainer.getByIdFromCache(32l, IspHttpclientParams.class);
			
			String url = urlService.dsCoreUrl();
			LogTool.warn(this.getClass(),"cancel url:"+url);
			
			String responseXml = httpclientService.post(url, requestXml, httpclientParams);
			LogTool.debug(this.getClass(),"cancel responseXml:"+responseXml);
			
			responseXml = Base64Tool.decode(responseXml, ConstantTool.UTF8);
			LogTool.warn(this.getClass(),"responseXml:"+responseXml);
			responseDTO = (ResponseDTO) JAXBTool.unmarshal(responseXml, ResponseDTO.class);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally {
			String responseXml = null;
			try {
				if (responseDTO != null) {
					responseXml = JAXBTool.marshal(responseDTO);
					if (responseDTO.getBusiness().isSuccess()) {
						operateStatus = 1;
					}
				}
				LogTool.debug(this.getClass(),"check requestXml:"+responseXml);
			} catch (JAXBException e) {
				LogTool.error(this.getClass(), e);
			} catch (IOException e) {
				LogTool.error(this.getClass(), e);
			}
			businesslogService.postBusinessOpelog_2(apply, StringUtils.defaultString(responseXml), ConstantTool.CANCEL, operateStatus, 3);
		}
		
		return operateStatus;
	}
}

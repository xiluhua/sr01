package com.taiping.dianshang.outer.service.impl.giftScore.model;

import java.net.URLEncoder;

import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.facility.tool.AesUtil;

/**
 * added by xiluhua 20170227 投保礼接口更新，新增字段childType
 * 添加字段：childType
 * @author xilh
 * @since 20170227
 */
public class GiftScoreRequestV2 extends GiftScoreRequest {

	private String childType = "1"; 	// 1：单增。2：批增
	private String companySource = "1";	// 1代表太平电商，2太财上分，3太平车险团队
	private String memo = "";
	private String innercome = "";
	private String waitingPeriod = "";
	
	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	public String getInnercome() {
		return innercome;
	}

	public void setInnercome(String innercome) {
		this.innercome = innercome;
	}

	public String getWaitingPeriod() {
		return waitingPeriod;
	}

	public void setWaitingPeriod(String waitingPeriod) {
		this.waitingPeriod = waitingPeriod;
	}

	public String getCompanySource() {
		return companySource;
	}

	public void setCompanySource(String companySource) {
		this.companySource = companySource;
	}

	public String getChildType() {
		return childType;
	}

	public void setChildType(String childType) {
		this.childType = childType;
	}

	@Override
	public String getJSONObject(String simpleName){
		
		String jsonString = "{#jsonString}";
		try {
			JSONObject jobj = new JSONObject(); 
			jobj.put("memberId", this.getMemberId());
			
			if (simpleName.toLowerCase().indexOf("mobile") > -1) {
				jobj.put("phone", this.getPhone());
			}else {
				jobj.put("email", this.getEmail());
			}
			
			jobj.put("ruleType", this.getRuleType());
			jobj.put("channel", this.getChannel());
			jobj.put("requestId", this.getRequestId());
			
			if (this.getBlueId() != null) {
				jobj.put("blueId", this.getBlueId());
			}
			if (this.getPaymentMethod() != null) {
				jobj.put("paymentMethod", this.getPaymentMethod());
			}
			if (this.getPremium() != null) {
				jobj.put("premium", this.getPremium());
			}
			if (this.getActionId() != null) {
				jobj.put("actionId", this.getActionId());
			}
			
			jobj.put("token", this.getToken());
			// added by xiluhua 20170227 投保礼接口更新，新增字段childType
			jobj.put("childType", this.getChildType());
			
			StringBuffer sb = new StringBuffer();   
			for(Object key:jobj.keySet()){  
	            sb.append("\""+key+"\":\""+jobj.get(key)+"\",");  
	        }  
	        String temp = sb.toString().substring(0, sb.toString().length()-1);
	        jsonString = jsonString.replaceAll("#jsonString", temp);
		} catch (Exception e) {
			e.printStackTrace();
			jsonString = null;
		}
		
		return jsonString;
	}
	
	@Override
	public String getUrl(IspApply apply,String url,String aesKey)throws Exception{
		String demoUrl = new String(url);
		System.out.println(ToStringBuilder.reflectionToString(this));
		System.out.println("=============================================================");
		try {
			// 字段次序不可变
			String memberId = AesUtil.Encrypt(StringUtils.defaultString(this.getMemberId(),""), aesKey);
			String phone = AesUtil.Encrypt(StringUtils.defaultString(this.getPhone(),""), aesKey);
			String email = AesUtil.Encrypt(StringUtils.defaultString(this.getEmail(), ""), aesKey);
			String channel = AesUtil.Encrypt(StringUtils.defaultString(this.getChannel(), ""), aesKey);
			String ruleType = AesUtil.Encrypt(StringUtils.defaultString(this.getRuleType()+"", ""), aesKey);
			// added by xiluhua 20170227 投保礼接口更新，新增字段childType
			String childType = AesUtil.Encrypt(StringUtils.defaultString(this.getChildType(),""), aesKey);
			String requestId = AesUtil.Encrypt(StringUtils.defaultString(this.getRequestId()), aesKey);
			String blueId = AesUtil.Encrypt(StringUtils.defaultString(String.valueOf(this.getBlueId()), ""), aesKey);
			String paymentMethod = AesUtil.Encrypt(StringUtils.defaultString(String.valueOf(this.getPaymentMethod()), ""), aesKey);
			String policyNo = AesUtil.Encrypt(StringUtils.defaultString(this.getPolicyNo(),""), aesKey);
			String premium = AesUtil.Encrypt(StringUtils.defaultString(String.valueOf(this.getPremium()),""), aesKey);
			String actionId = AesUtil.Encrypt(StringUtils.defaultString(this.getActionId(), ""), aesKey);
			
			String memo = AesUtil.Encrypt(StringUtils.defaultString(this.getMemo(), ""), aesKey);
			String innercome = AesUtil.Encrypt(StringUtils.defaultString(this.getInnercome(), ""), aesKey);
			String waitingPeriod = AesUtil.Encrypt(StringUtils.defaultString(this.getWaitingPeriod(), ""), aesKey);
			String companySource = AesUtil.Encrypt(StringUtils.defaultString(this.getCompanySource(), ""), aesKey);
			String token = AesUtil.Encrypt(StringUtils.defaultString(this.getToken(),""), aesKey);
			
			//http://10.1.117.34:8001/b2b2eM2/ws/addGifts
			///#memberId/#phone/#email/#ruleType/#channel/#requestId/#blueId/#paymentMethod/#policyNo/#premium/#actionId/#token

			demoUrl = demoUrl.replaceAll("#memberId", URLEncoder.encode(memberId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#phone", URLEncoder.encode(phone,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#email", URLEncoder.encode(email,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#ruleType", URLEncoder.encode(ruleType,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#channel", URLEncoder.encode(channel,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#requestId", URLEncoder.encode(requestId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#blueId", URLEncoder.encode(blueId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#paymentMethod", URLEncoder.encode(paymentMethod,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#policyNo", URLEncoder.encode(policyNo,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#premium", URLEncoder.encode(premium,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#actionId", URLEncoder.encode(actionId,"UTF-8"));
			
			demoUrl = demoUrl.replaceAll("#memo", URLEncoder.encode(memo,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#innercome", URLEncoder.encode(innercome,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#waitingPeriod", URLEncoder.encode(waitingPeriod,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#companySource", URLEncoder.encode(companySource,"UTF-8"));
			
			demoUrl = demoUrl.replaceAll("#token", URLEncoder.encode(token,"UTF-8"));
			// added by xiluhua 20170227 投保礼接口更新，新增字段childType
			demoUrl = demoUrl.replaceAll("#childType", URLEncoder.encode(childType,"UTF-8"));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new Exception("fail to build url,applyId:"+apply.getApplyId());
		}
		
		return demoUrl;
	}
	
}

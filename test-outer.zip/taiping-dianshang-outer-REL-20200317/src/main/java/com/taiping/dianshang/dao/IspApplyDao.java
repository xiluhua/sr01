package com.taiping.dianshang.dao;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBeneficiary;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.model.Busi;
import com.taiping.facility.tool.DateTool;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspApplyDao extends BaseWriteDao<IspApply, Long>{
	@Resource
	private CommonDao commonDao;
	@Resource
	private IspCustomerDao ispCustomerDao;
	@Resource
	private IspBeneficiaryDao ispBeneficiaryDao;
	
	public IspApply getApply(String partnerApplyId,String policyNo,String appno,Long applyId){
		if (!StringUtils.isEmpty(partnerApplyId)) {
			return super.get("partnerApplyId", partnerApplyId);	
		}else if (!StringUtils.isEmpty(policyNo)) {
			return super.get("policyNo", policyNo);	
		}else if (!StringUtils.isEmpty(appno)) {
			return super.get("appno", appno);	
		}else {
			return super.get("applyId", applyId);	
		}
	}

	public Long save(IspApply apply){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_APPLY);
		apply.setApplyId(seq);
		
		return super.save(apply);
	}
	
	public IspApply loadApply(String partnerApplyId){
		IspApply apply = this.getApply(partnerApplyId,null,null,null);
		if (apply == null) {
			return null;
		}
		Long applyId = apply.getApplyId();
		// 1,投保人
		IspCustomer holder  = ispCustomerDao.getCusotmerByApplyId(applyId, 1);
		// 2,
		IspCustomer insured = ispCustomerDao.getCusotmerByApplyId(applyId, 2);
		
		apply.setHolder(holder);
		apply.setInsured(insured);
		// 3,
		List<IspBeneficiary> beneficiaryList = ispBeneficiaryDao.getBeneficiayListByApplyId(applyId);
		if (!beneficiaryList.isEmpty()) {
			apply.setBeneficiaryList(beneficiaryList);
		}
		
		// 4,
//		if (apply.getSellChannel() == 2) {
//			IspYangLaoTrans yanglaoTrans = ispYangLaoTransDao.getIspYangLaoTransByApplyId(applyId);
//			if (yanglaoTrans!= null) {
//				apply.setYangLaoTrans(yanglaoTrans);
//			}
//		}
		return apply;
	}
	
	public IspApply loadApply(String partnerApplyId,String policyNo,String appno,Long applyId){
		IspApply apply = this.getApply(partnerApplyId,policyNo,appno,applyId);
		if (apply == null) {
			return null;
		}
		applyId = apply.getApplyId();
		// 1,投保人
		IspCustomer holder  = ispCustomerDao.getCusotmerByApplyId(applyId, 1);
		// 2,
		IspCustomer insured = ispCustomerDao.getCusotmerByApplyId(applyId, 2);
		
		apply.setHolder(holder);
		apply.setInsured(insured);
		// 3,
		List<IspBeneficiary> beneficiaryList = ispBeneficiaryDao.getBeneficiayListByApplyId(applyId);
		if (!beneficiaryList.isEmpty()) {
			apply.setBeneficiaryList(beneficiaryList);
		}
		
		// 4,
//		if (apply.getSellChannel() == 2) {
//			IspYangLaoTrans yanglaoTrans = ispYangLaoTransDao.getIspYangLaoTransByApplyId(applyId);
//			if (yanglaoTrans!= null) {
//				apply.setYangLaoTrans(yanglaoTrans);
//			}
//		}
		
		return apply;
	}
	
	public Busi loadApplyBusi(String partnerApplyId){
		Busi busi = new Busi();
		IspApply apply = this.loadApply(partnerApplyId);
		if (apply == null) {
			return null;
		}
		Long applyId = apply.getApplyId();
		busi.setApply(apply);
		
		// 4,
//		IpayRenew payRenew = ipayRenewDao.getPayRenewByApplyId(applyId);
//		if (payRenew!= null) {
//			busi.setPayRenew(payRenew);
//		}
//		// 5,
//		IpayPay pay = null;
//		if (apply.getPayId() != null) {
//			pay = ipayPayDao.getPayById(apply.getPayId());
//			if (pay != null) {
//				busi.setPay(pay);
//			}	
//		}
//		// 7,
//		IpayRegister payRegister = ipayRegisterDao.getPayRegisterByApplyId(applyId);
//		if (payRegister != null) {
//			busi.setPayRegister(payRegister);
//		}
		return busi;
	}
	
	/**
	 * 
	 * @param partnerApplyId
	 * @param policyNo
	 * @param applyId
	 * @param isLoadAll 是否加载所有外键对象,true.是|false.否(仅加载投被保人+受益人对象)
	 * @return
	 */
	public Busi loadApplyBusi(String partnerApplyId,String policyNo,String appno,Long applyId,boolean isLoadAll ){
		Busi busi = new Busi();
		IspApply apply = this.getApply(partnerApplyId,policyNo,appno,applyId);
		if (apply == null) {
			return null;
		}
		
		applyId = apply.getApplyId();
		// 1,投保人
		IspCustomer holder  = ispCustomerDao.getCusotmerByApplyId(applyId, 1);
		// 2,
		IspCustomer insured = ispCustomerDao.getCusotmerByApplyId(applyId, 2);
		
		apply.setHolder(holder);
		apply.setInsured(insured);
		// 3,
		List<IspBeneficiary> beneficiaryList = ispBeneficiaryDao.getBeneficiayListByApplyId(applyId);
		if (!beneficiaryList.isEmpty()) {
			apply.setBeneficiaryList(beneficiaryList);
		}
		// 4,
//		if (apply.getSellChannel() == 2) {
//			IspYangLaoTrans yanglaoTrans = ispYangLaoTransDao.getIspYangLaoTransByApplyId(applyId);
//			if (yanglaoTrans!= null) {
//				apply.setYangLaoTrans(yanglaoTrans);
//			}
//		}
		busi.setApply(apply);
		
//		if (isLoadAll) {
//			// 5,
//			IpayRenew payRenew = ipayRenewDao.getPayRenewByApplyId(applyId);
//			if (payRenew!= null) {
//				busi.setPayRenew(payRenew);
//			}
//			// 6,
//			IpayPay pay = null;
//			if (apply.getPayId() != null) {
//				pay = ipayPayDao.getPayById(apply.getPayId());
//				if (pay != null) {
//					busi.setPay(pay);
//				}
//			}
//		
//			// 7,
//			IpayRegister payRegister = ipayRegisterDao.getPayRegisterByApplyId(applyId);
//			if (payRegister != null) {
//				busi.setPayRegister(payRegister);
//			}
//		}
		
		return busi;
	}
	
	/**
	 * 创建养老险订单号
	 * @param channelNo
	 * 渠道代码 (01商城,02集团自保,03联通,04淘宝)
	 * @return
	 */
	public String getYangLaoTrans(Long partnerId)throws Exception{
		String channelNo = this.getYangLaoChannelNo(partnerId);
		
		StringBuffer yangLaoOrderNo = new StringBuffer();

		// 养老订单号(机构号[5]+渠道代码[2]+年月日(yyyymmdd)[8]+流水号[10])
		String organNo = "00201"; // 上分
		String dateString = DateTool.getFormatDate("yyyyMMdd", new Date());

		// 获取序列号
		Long serialNo = commonDao.getSequnce(ConstantTool.SEQ_YL_DDH);

		yangLaoOrderNo.append(organNo);
		yangLaoOrderNo.append(channelNo);
		yangLaoOrderNo.append(dateString);
		yangLaoOrderNo.append(String.valueOf(serialNo));

		return yangLaoOrderNo.toString();		
	}
	
	/**
	 * 取得对应的网易客户证件类型
	 * @param neteaseCardType
	 * @return
	 */
	private String getYangLaoChannelNo(Long partnerId) {
		String ChannelNo = ConstantTool.YANGLAO_CHANNELNO_MALL;  // 默认为：01. 商城
		
		if (partnerId == ConstantTool.TAOBAO_ID) {
			ChannelNo = ConstantTool.YANGLAO_CHANNELNO_TAOBAO;
		}else if(partnerId == ConstantTool.SHANG_CHENG || partnerId == ConstantTool.GUAN_WANG ) {
			ChannelNo = ConstantTool.YANGLAO_CHANNELNO_MALL;
		}
		
		return ChannelNo;
	}
	
	public void updatePreCore(IspApply apply){
		String sql = "update SC_ISP_APPLY t set t.BANK_CODE = ? where t.PARTNER_APPLY_ID = ?";
		SQLQuery query = super.getSession().createSQLQuery(sql);
		query.setString(0, apply.getBankCode());
		query.setString(1, apply.getPartnerApplyId());
		query.executeUpdate();
	}
	
	public String generatePolicyNo(String prefix){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_APPLY);
		int length = 10 - String.valueOf(seq).length();
		String zero = "";
		if (length > 0) {
			zero = StringUtils.repeat("0",  length);
		}
		
		return prefix + zero + seq;
	} 
	@Transactional
	public void update(IspApply apply){
		super.update(apply);
	}
}

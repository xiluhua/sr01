package com.taiping.dianshang.outer.service.impl.autoRegister.ws.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity.AccountResponse;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.util.MyAESUtil;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.SsoHttpService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;

/**
 * http请求工具
 * @author bruce(liwenlong)  2016年9月9日 上午11:53:31
 * @author xilh update 2017-12-04
 */
@Component
public class SsoHttpImpl implements SsoHttpService {
	@Resource
	BusinesslogService businesslogService;
	
	public Map<String,String> before(IspApply apply) {
    	Map<String, String> headers = new HashMap<String, String>();
        headers.put("Content-Type", "text/html");
        headers.put("--uid--", "10008"); // 客户端ID 必填,否则出现505错误
        headers.put("--requestId--", apply.getPolicyNo()); // 可选,每次请求参数值应该不一样,由客户端自由随机生成
        return headers;
    }
	
	/**
	 * Post方式请求网络数据,
	 * 
	 * @param strUrl          网络地址
	 * @param body            发送的请求体
	 * @param headers         发送的请求头
	 * @param encoding        请求编码方式,默认 UTF-8
	 */
	public AccountResponse httpdoPostBodyHeader(IspApply apply, String strUrl, String body,String busiType) {
		AccountResponse ac = null;
		HttpURLConnection httpURLConn = null;
		String responseaMsg = "";
		String encoding = ConstantTool.UTF8;
		
		try {
			Map<String, String> headers = this.before(apply);
			LogTool.debug(this.getClass(), "strUrl: "+strUrl);
			// String aesKey = "iwowopeoeksksjss"; UAT
			String aesKey = CacheContainer.getSystemParameterValueNoThrows("uniformUserIdentity.aesKey.v2");
			LogTool.debug(this.getClass(), "aesKey: "+aesKey);
			String ciphertext = MyAESUtil.encrypt(body, aesKey);
			LogTool.debug(this.getClass(), "ciphertext: "+ciphertext);
			URL url = new URL(strUrl);
			httpURLConn = (HttpURLConnection) url.openConnection();
			// 设置编码方式
			httpURLConn.addRequestProperty("encoding", encoding);
			httpURLConn.setDoInput(true); // 使httpURLConn可以从网络获取数据
			httpURLConn.setDoOutput(true); // 使httpURLConn可以向互联网传输数据
			httpURLConn.setRequestMethod("POST"); // 设置POST请求方式
			if (!LogTool.isFormal) {
				httpURLConn.setChunkedStreamingMode(0);//请求超时时会导致自动重发。设置为 0 不重发
				httpURLConn.setConnectTimeout(1000);
				httpURLConn.setReadTimeout(1000);
			}
			if (headers != null) {
				Iterator<String> iteHeaders = headers.keySet().iterator();
				while (iteHeaders.hasNext()) {
					String header = iteHeaders.next();
					//设置请求头
					httpURLConn.addRequestProperty(header, headers.get(header));
				}
			}

			if (body != null) {
				// 获取输出流
				OutputStream outStream = httpURLConn.getOutputStream();
				this.writeStrToOutputStream(ciphertext, outStream,encoding);
			}
			
			int responseCode = httpURLConn.getResponseCode();
			if(responseCode == 200){
				// 获取输入流
				InputStream inStream = httpURLConn.getInputStream();
				StringBuilder builder = readStrFromInputStream(inStream, encoding);
				String responseText = MyAESUtil.decrypt(builder.toString().trim(), aesKey);
				LogTool.debug(this.getClass(),busiType+ ","+apply.getPartnerApplyId()+", responseText:" + responseText);
				// 日志
		        businesslogService.postBusinessOpelog_2(apply, strUrl+System.getProperty("line.separator")+responseText, busiType, 1, 1);
		        
				ac = JSON.parseObject(responseText, AccountResponse.class);
				responseaMsg = JSON.toJSONString(ac);
			} else {
				String responseMessage = httpURLConn.getResponseMessage();
				LogTool.debug(this.getClass(), "responseCode: " + responseCode + ", message: " + responseMessage);
				ac = new AccountResponse();
				ac.setReturnCode(responseCode + "");
				ac.setReturnFlag(false);
				ac.setReturnMessage(responseMessage);
				responseaMsg = JSON.toJSONString(ac);
			}

		} catch (MalformedURLException e) {
			LogTool.error(this.getClass(), e);
			ac = new AccountResponse();
			ac.setReturnFlag(false);
			ac.setReturnMessage("统一身份管理中心接口异常");
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
			ac = new AccountResponse();
			ac.setReturnFlag(false);
			ac.setReturnMessage("统一身份管理中心接口异常");
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			ac = new AccountResponse();
			ac.setReturnFlag(false);
			ac.setReturnMessage("自动注册接口发生异常");
		} finally {
			if (ac != null && ac.getAccountInfoList() != null
					&& ac.getAccountInfoList().size() > 0) {
				ac.setReturnFlag(true);
			}
			
			if (httpURLConn != null) {
				httpURLConn.disconnect();
			}
			LogTool.info(this.getClass(),"accountResponseaStr:"+responseaMsg);
		}
		ac.setResponseaMsg(responseaMsg);
		return ac;
	}

	/**
	 * 输出字符串到输出流
	 */
	private void writeStrToOutputStream(String body, OutputStream outStream,String encoding){
		OutputStreamWriter outWriter = null;
		BufferedWriter bufWriter = null;
		try {
		    outWriter = new OutputStreamWriter(outStream,encoding);
		    bufWriter = new BufferedWriter(outWriter);
			// 输出请求体
			bufWriter.write(body);
			bufWriter.flush();
			// 关闭输出流
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
		}finally{
			try {
				bufWriter.close();
				outWriter.close();
				outStream.close();
			} catch (Exception e2) {
				LogTool.error(this.getClass(), e2);
			}
		}
	}
	
    /**
     * 从输入流中读取字符串
     */
	private StringBuilder readStrFromInputStream(InputStream inStream,String encoding) {
		StringBuilder builder = new StringBuilder();
		InputStreamReader inReader = null;
		BufferedReader bufReader = null;
		try {
			 inReader = new InputStreamReader(inStream, encoding);
			 bufReader = new BufferedReader(inReader);
			 String line;
			 while ((line = bufReader.readLine()) != null) {
				builder.append(line + "\n");
			 }
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally {
			try {
				if(bufReader!=null) bufReader.close();
				if(inReader!=null) inReader.close();
				if(inStream!=null) inStream.close();
			} catch (IOException e2) {
				LogTool.error(this.getClass(), e2);
			}
		}
		return builder;
	}

}

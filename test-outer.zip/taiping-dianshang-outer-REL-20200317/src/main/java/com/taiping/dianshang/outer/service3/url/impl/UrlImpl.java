package com.taiping.dianshang.outer.service3.url.impl;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.outer.service3.url.UrlService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * @author xilh
 * @since 20161018
 * @category 获取网销核心请求地址接口 
 * @version 3.0
 */
@Component
public class UrlImpl implements UrlService{

	@Override
	public String dsCoreUrl() {
		String url = PropertyFileTool.get(ConstantTool.DIANSHANG_CORE_REST_SERVICE_URL);
		if (StringUtils.isEmpty(url)) {
			// modified by xiluhua 20170218 为支持热部署
			// PRODUCT
			url = CacheContainer.getSystemParameterValueNoThrows(ConstantTool.DIANSHANG_CORE_REST_SERVICE_URL+ConstantTool.UNDERLINE+LogTool.localIp);
			
			// LOCAL & UAT
			if (StringUtils.isEmpty(url)) {
				 url = CacheContainer.getSystemParameterValue(ConstantTool.DIANSHANG_CORE_REST_SERVICE_URL);
			}
		}
		LogTool.warn(this.getClass(),ConstantTool.DIANSHANG_CORE_REST_SERVICE_URL+":"+url);
		return url;
	}

}

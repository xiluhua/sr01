package com.taiping.dianshang.outer.service.impl.policyPdf;

import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.exception.DownloadInvoicePdfException;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.ResponsePolicyPdfUrlDTO;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.dianshang.outer.service3.policyPdfUrl.impl.PolicyPdfUrlCoreImpl;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PdfDownloadTool;
import com.taiping.facility.tool.PropertyFileTool;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;


/**
 * @author Liwei 2019/9/3 10:42 AM
 * 亚太产品电子保单下载
 */
@Service
@Transactional
public class DownloadPolicyPdfImpl_12 implements DownloadPolicyPdfService {
    @Resource
    private IspApplyDao ispApplyDao;
    @Resource
    private PolicyPdfUrlCoreImpl policyPdfUrlCoreImpl;

    @Override
    public String download(String policyNo, String idNo) {
        LogTool.info(this.getClass(), "亚太电子保单下载: "+policyNo+", "+idNo);
        String policyUrl;
        String path;
        try {
            //1. 保单号相关信息校验
            IspApply apply = ispApplyDao.loadApply(null, policyNo, null, null);

            //2. 调用核心获取电子保单地址
            Busi busi = new Busi();
            ResponsePolicyPdfUrlDTO responseDTO = new ResponsePolicyPdfUrlDTO(busi);
            busi.setApply(apply);
            busi.setResponseDTO(responseDTO);
            policyPdfUrlCoreImpl.handleCore(busi);
            if (!responseDTO.getBusiness().isSuccess()) {
                throw new DownloadInvoicePdfException("电子保单下载异常！");
            }else{
                policyUrl = responseDTO.getMain().getPolicyUrl();      //返回  http://testqcar.apiins.com/h5img/app/ImgView/getImgFile
                if (!LogTool.isLocal){
                    String [] replaceUrl = CacheContainer.getSystemParameterValue("outer.policy.url.replace").split(",");
                    if (replaceUrl.length == 0 || replaceUrl.length == 1){
                        throw new RuntimeException("电子保单代理地址未配置");
                    }else{
                        policyUrl = policyUrl.replace(replaceUrl[0],replaceUrl[1]);     //地址保单地址替换 http://testqcar.apiins.com:8808/h5img/app/ImgView/getImgFile
                        LogTool.info(this.getClass(),"policyUrl地址替换为:"+policyUrl);
                    }
                }
            }

            //3. 电子保单生成
            String dir = PropertyFileTool.get("policy.pdf.dir");
            path = dir+policyNo+".pdf";
            PdfDownloadTool httpClient = new PdfDownloadTool();
            httpClient.persistentPDF(policyUrl,path);
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
            throw new DownloadPolicyPdfSysException();
        }
        return path;
    }
}

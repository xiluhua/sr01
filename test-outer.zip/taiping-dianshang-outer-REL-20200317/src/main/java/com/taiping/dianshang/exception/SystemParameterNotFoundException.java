package com.taiping.dianshang.exception;


public class SystemParameterNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public SystemParameterNotFoundException(String msg){
		super(msg);
	}
}


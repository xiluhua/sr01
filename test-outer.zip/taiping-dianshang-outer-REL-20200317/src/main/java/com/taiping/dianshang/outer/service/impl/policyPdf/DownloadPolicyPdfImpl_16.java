package com.taiping.dianshang.outer.service.impl.policyPdf;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.annotation.Resource;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.FileStreamTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * @author xilh
 * @since 20200206
 * 京东安联电子保单下载
 */
@Service
@Transactional
public class DownloadPolicyPdfImpl_16 implements DownloadPolicyPdfService {
    @Resource
    private IspApplyDao ispApplyDao;

    @Override
    public String download(String policyNo, String idNo) {
        LogTool.info(this.getClass(), "京东安联电子保单下载: "+policyNo+", "+idNo);
        String path = null;
        IspHttpclientParams httpclientParams = null;
        try {
            //1. 保单号相关信息校验
            IspApply apply = ispApplyDao.loadApply(null, policyNo, null, null);
            
            IspRmi rmi = CacheContainer.getIspRmiByIdFromCache(apply.getBlueId(), apply.getSellChannel(), "policyPdf", IspRmi.class);
            LogTool.debug(this.getClass(), policyNo +", "+JSON.toJSONString(rmi));
            String requestXml = this.objectToXml(apply, rmi);
            if (rmi.getHttpclientParamsId() != null) {
    			httpclientParams = CacheContainer.getByIdFromCache(rmi.getHttpclientParamsId(), IspHttpclientParams.class);
    		}
            
        	byte[] bytes = this.post(rmi.getUrl(), requestXml, httpclientParams);      //返回  http://testqcar.apiins.com/h5img/app/ImgView/getImgFile
            if (bytes == null || bytes.length < 1){
                throw new RuntimeException("电子保单获取失败");
            }
            LogTool.info(this.getClass(),"policyByteString, policyNo: "+bytes.length);
            //3. 电子保单生成
            String dir = PropertyFileTool.get("policy.pdf.dir");
            path = dir+policyNo+".pdf";
            FileStreamTool.write(path, bytes);
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
            throw new DownloadPolicyPdfSysException();
        }
        return path;
    }
    
	public String objectToXml(IspApply apply, IspRmi rmi) throws Exception {
		String requestXml = null; // 核心请求报文
		// 定义局部变量
		String templateFileName = rmi.getRequestXmlTemplateFile(); // 报文模板文件名
		String encryptPassword = CacheContainer.getSysParamValueNoThrows("16.EncryptPassword");
		// 定义局部变量
		// 构建请求报文，并转换成报文字符串
		VelocityContext context = new VelocityContext();
		context.put("apply", apply);
		context.put("encryptPassword", encryptPassword);
		requestXml = TemplateToolV1218.fill(context, rmi.getRequestXmlTemplate());
		LogTool.info(this.getClass(), apply.getPartnerApplyId()+", requestXml: "+requestXml);
		if (StringUtils.isEmpty(requestXml)) {
			throw new Exception("填充模板出错，模板路径：" + templateFileName);
		}
		// 返回报文字符串
		return requestXml;
	}
    
    /**
	 * @category 京东安联冠状病毒险
	 * @author xilh 
	 * @since 20200206
	 * @return
	 */
	@SuppressWarnings({ "deprecation", "unchecked" })
	public byte[] post(String url, String requestXml, IspHttpclientParams httpclientParams) throws Exception {
		HttpPost httpost 	= null;
		HttpHost proxy 		= null; 
		byte  buffer[] 		= null;
		DefaultHttpClient httpclient = new DefaultHttpClient();
        
		try {
			// 代理的设置
			String value = CacheContainer.getSystemParameterValue(ConstantTool.INTERNET_PROXY_1);
			if (LogTool.isLocal) {
				value = PropertyFileTool.get(ConstantTool.INTERNET_PROXY_1);
			}
			String[] arr = value.split(":");
			proxy = new HttpHost(arr[0], Integer.valueOf(arr[1]));
			httpclient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
			// Secure Protocol implementation.
			SSLContext ctx = SSLContext.getInstance("TLS");
			// Implementation of a trust manager for X509 certificates
			X509TrustManager tm = new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			ClientConnectionManager ccm = httpclient.getConnectionManager();
			// register https protocol in httpclient's scheme registry
			SchemeRegistry sr = ccm.getSchemeRegistry();
			sr.register(new Scheme("https", 443, ssf));
			httpclient = new DefaultHttpClient(ccm, httpclient.getParams());
			//请求超时
		    httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, httpclientParams.getConnectionTimeout());
		    //读取超时
		    httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, httpclientParams.getSoTimeout());
			httpost = new HttpPost(url);
	
			StringEntity entityParams = new StringEntity(requestXml,"utf-8");
			httpost.setEntity(entityParams);
			HttpResponse response = httpclient.execute(httpost);
			buffer = FileStreamTool.read(response.getEntity().getContent());
			return buffer;
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally {
			// 关闭请求
			if (httpost != null) {
				httpost.releaseConnection();
			}
		}
		return null;
	}

}

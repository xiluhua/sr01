package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "ISP_SHORTMSG_TEMPLATE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspShortmsgTemplate implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;                             
	private String tempId;
	private Integer type;
	private Integer status;                         
	private String requestXmlTemplate;
	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "REQUEST_XML_TEMPLATE")
	public String getRequestXmlTemplate() {
		return requestXmlTemplate;
	}
	
	public void setRequestXmlTemplate(String requestXmlTemplate) {
		this.requestXmlTemplate = requestXmlTemplate;
	}
	
	@Column(name = "TEMP_ID")
	public String getTempId() {
		return tempId;
	}
	public void setTempId(String tempId) {
		this.tempId = tempId;
	}
	
	@Column(name = "TYPE")
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "IspShortmsgTemplate [id=" + id + ", tempId=" + tempId
				+ ", type=" + type + ", status=" + status
				+ ", requestXmlTemplate=" + requestXmlTemplate + "]";
	}
	
	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	} 
	
	
}

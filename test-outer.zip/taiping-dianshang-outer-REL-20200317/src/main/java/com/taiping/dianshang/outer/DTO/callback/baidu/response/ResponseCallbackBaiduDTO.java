package com.taiping.dianshang.outer.DTO.callback.baidu.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author xiluhua 
 * @since 2017-12-18
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"head"
})
@XmlRootElement(name = "Message")
public class ResponseCallbackBaiduDTO extends ReponseDTOBaidu{
	@XmlElement(name = "Head")
	ResponseHeadDTO head = new ResponseHeadDTO();

	public ResponseHeadDTO getHead() {
		return head;
	}

	public void setHead(ResponseHeadDTO head) {
		this.head = head;
	}

	@Override
	public String toString() {
		return "ResponseCallbackBaiduDTO [head=" + head + "]";
	}

	
}

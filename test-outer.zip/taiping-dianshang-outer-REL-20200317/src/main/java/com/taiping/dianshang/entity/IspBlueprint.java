package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspBlueprint entity. 
 */
@Entity
@Table(name = "CP_ISP_BLUEPRINT")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspBlueprint implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	
	// Fields

	private Long blueId;
	private String blueCode;
	private String blueCoreName;
	private String blueInnerName;
	private String bluePinyin;
	private Integer blueType;
	private Integer blueFeeType;
	private Integer blueSaleType;
	private String memo;
	private Integer status;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private Integer partnerApplyFlag;
	private Double defaultDiscount;
	private Double discount;
	private Integer isImallSell;
	private Integer sellChannel;
	private Integer insuranceType;
	private String imagePath;
	private Long coreBlueId;
	// Constructors

	/** default constructor */
	public IspBlueprint() {
	}

	/** minimal constructor */
	public IspBlueprint(Long blueId) {
		this.blueId = blueId;
	}

	/** full constructor */
	public IspBlueprint(Long blueId, String blueCode, String blueCoreName,
			String blueInnerName, String bluePinyin, Integer blueType,
			Integer blueFeeType, Integer blueSaleType, String memo, Integer status,
			Date createTime, Date updateTime, String createAid,
			String updateAid, Integer partnerApplyFlag, Double defaultDiscount,
			Double discount, Integer isImallSell, Integer sellChannel,
			Integer insuranceType) {
		this.blueId = blueId;
		this.blueCode = blueCode;
		this.blueCoreName = blueCoreName;
		this.blueInnerName = blueInnerName;
		this.bluePinyin = bluePinyin;
		this.blueType = blueType;
		this.blueFeeType = blueFeeType;
		this.blueSaleType = blueSaleType;
		this.memo = memo;
		this.status = status;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
		this.partnerApplyFlag = partnerApplyFlag;
		this.defaultDiscount = defaultDiscount;
		this.discount = discount;
		this.isImallSell = isImallSell;
		this.sellChannel = sellChannel;
		this.insuranceType = insuranceType;
	}

	@Transient
	public Long getCoreBlueId() {
		return coreBlueId;
	}

	public void setCoreBlueId(Long coreBlueId) {
		this.coreBlueId = coreBlueId;
	}

	// Property accessors
	@Id
	@Column(name = "BLUE_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Column(name = "BLUE_CODE", length = 20)
	public String getBlueCode() {
		return this.blueCode;
	}

	public void setBlueCode(String blueCode) {
		this.blueCode = blueCode;
	}

	@Column(name = "BLUE_CORE_NAME", length = 200)
	public String getBlueCoreName() {
		return this.blueCoreName;
	}

	public void setBlueCoreName(String blueCoreName) {
		this.blueCoreName = blueCoreName;
	}

	@Column(name = "BLUE_INNER_NAME", length = 200)
	public String getBlueInnerName() {
		return this.blueInnerName;
	}

	public void setBlueInnerName(String blueInnerName) {
		this.blueInnerName = blueInnerName;
	}

	@Column(name = "BLUE_PINYIN", length = 25)
	public String getBluePinyin() {
		return this.bluePinyin;
	}

	public void setBluePinyin(String bluePinyin) {
		this.bluePinyin = bluePinyin;
	}

	@Column(name = "BLUE_TYPE", precision = 3, scale = 0)
	public Integer getBlueType() {
		return this.blueType;
	}

	public void setBlueType(Integer blueType) {
		this.blueType = blueType;
	}

	@Column(name = "BLUE_FEE_TYPE", precision = 3, scale = 0)
	public Integer getBlueFeeType() {
		return this.blueFeeType;
	}

	public void setBlueFeeType(Integer blueFeeType) {
		this.blueFeeType = blueFeeType;
	}

	@Column(name = "BLUE_SALE_TYPE", precision = 3, scale = 0)
	public Integer getBlueSaleType() {
		return this.blueSaleType;
	}

	public void setBlueSaleType(Integer blueSaleType) {
		this.blueSaleType = blueSaleType;
	}

	@Column(name = "MEMO", length = 2000)
	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Column(name = "PARTNER_APPLY_FLAG", precision = 3, scale = 0)
	public Integer getPartnerApplyFlag() {
		return this.partnerApplyFlag;
	}

	public void setPartnerApplyFlag(Integer partnerApplyFlag) {
		this.partnerApplyFlag = partnerApplyFlag;
	}

	@Column(name = "DEFAULT_DISCOUNT", precision = 7, scale = 6)
	public Double getDefaultDiscount() {
		return this.defaultDiscount;
	}

	public void setDefaultDiscount(Double defaultDiscount) {
		this.defaultDiscount = defaultDiscount;
	}

	@Column(name = "DISCOUNT", precision = 7, scale = 6)
	public Double getDiscount() {
		return this.discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	@Column(name = "IS_IMALL_SELL", precision = 3, scale = 0)
	public Integer getIsImallSell() {
		return this.isImallSell;
	}

	public void setIsImallSell(Integer isImallSell) {
		this.isImallSell = isImallSell;
	}

	@Column(name = "SELL_CHANNEL", precision = 3, scale = 0)
	public Integer getSellChannel() {
		return this.sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}

	@Column(name = "INSURANCE_TYPE", precision = 3, scale = 0)
	public Integer getInsuranceType() {
		return this.insuranceType;
	}

	public void setInsuranceType(Integer insuranceType) {
		this.insuranceType = insuranceType;
	}

	@Column(name = "IMAGE_PATH", length = 200)
	public String getImagePath() {
		return this.imagePath;
	}

	public void setImagePath(String imagePath) {
		this.imagePath = imagePath;
	}

}
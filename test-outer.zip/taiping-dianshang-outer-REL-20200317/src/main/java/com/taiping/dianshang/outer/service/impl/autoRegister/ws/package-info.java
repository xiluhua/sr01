@javax.xml.bind.annotation.XmlSchema(namespace = "http://cntp.com/")
package com.taiping.dianshang.outer.service.impl.autoRegister.ws;


package com.taiping.dianshang.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspBale entity. 
 */
@Entity
@Table(name = "CP_ISP_BALE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspBale implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long baleId;
	private Integer baleNo;
	private String blueCode;
	private String baleName;
	private Integer baleOrder;
	private Integer status;
	private Integer amount;
	private String pts;
	private Long chargeYear;
	private String memo;
	private Long blueId;
	private Double standardPremium;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private Double discount;
	private BigDecimal activityPrice;
	private BigDecimal salesPrice;

	public Long coreBlueId;      	//核心方案ID	
	public Long coreBaleId;  		//核心方案ID
	public Integer coreAnnounceId; 	//核心健康告知ID
	public String chargeTypeList; 	//交费类型列表 试算用
	// Constructors

	/** default constructor */
	public IspBale() {
	}

	/** minimal constructor */
	public IspBale(Long baleId) {
		this.baleId = baleId;
	}

	/** full constructor */
	public IspBale(Long baleId, Integer baleNo, String blueCode,
			String baleName, Integer baleOrder, Integer status, Integer amount,
			String pts, Long chargeYear, String memo, Long blueId,
			Double standardPremium, Date createTime, Date updateTime,
			String createAid, String updateAid, Double discount,
			BigDecimal activityPrice, BigDecimal salesPrice) {
		this.baleId = baleId;
		this.baleNo = baleNo;
		this.blueCode = blueCode;
		this.baleName = baleName;
		this.baleOrder = baleOrder;
		this.status = status;
		this.amount = amount;
		this.pts = pts;
		this.chargeYear = chargeYear;
		this.memo = memo;
		this.blueId = blueId;
		this.standardPremium = standardPremium;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
		this.discount = discount;
		this.activityPrice = activityPrice;
		this.salesPrice = salesPrice;
	}

	// Property accessors
	@Id
	@Column(name = "BALE_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getBaleId() {
		return this.baleId;
	}

	public void setBaleId(Long baleId) {
		this.baleId = baleId;
	}

	@Column(name = "BALE_NO", precision = 3, scale = 0)
	public Integer getBaleNo() {
		return this.baleNo;
	}

	public void setBaleNo(Integer baleNo) {
		this.baleNo = baleNo;
	}

	@Column(name = "BLUE_CODE", length = 20)
	public String getBlueCode() {
		return this.blueCode;
	}

	public void setBlueCode(String blueCode) {
		this.blueCode = blueCode;
	}

	@Column(name = "BALE_NAME", length = 200)
	public String getBaleName() {
		return this.baleName;
	}

	public void setBaleName(String baleName) {
		this.baleName = baleName;
	}

	@Column(name = "BALE_ORDER", precision = 4, scale = 0)
	public Integer getBaleOrder() {
		return this.baleOrder;
	}

	public void setBaleOrder(Integer baleOrder) {
		this.baleOrder = baleOrder;
	}

	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "AMOUNT", precision = 10)
	public Integer getAmount() {
		return this.amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	@Column(name = "PTS", length = 2000)
	public String getPts() {
		return this.pts;
	}

	public void setPts(String pts) {
		this.pts = pts;
	}

	@Column(name = "CHARGE_YEAR", precision = 10, scale = 0)
	public Long getChargeYear() {
		return this.chargeYear;
	}

	public void setChargeYear(Long chargeYear) {
		this.chargeYear = chargeYear;
	}

	@Column(name = "MEMO", length = 2000)
	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Column(name = "STANDARD_PREMIUM", precision = 12)
	public Double getStandardPremium() {
		return this.standardPremium;
	}

	public void setStandardPremium(Double standardPremium) {
		this.standardPremium = standardPremium;
	}

	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Column(name = "DISCOUNT", precision = 5)
	public Double getDiscount() {
		return this.discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	@Column(name = "ACTIVITY_PRICE", precision = 10)
	public BigDecimal getActivityPrice() {
		return this.activityPrice;
	}

	public void setActivityPrice(BigDecimal activityPrice) {
		this.activityPrice = activityPrice;
	}

	@Column(name = "SALES_PRICE", precision = 10)
	public BigDecimal getSalesPrice() {
		return this.salesPrice;
	}

	public void setSalesPrice(BigDecimal salesPrice) {
		this.salesPrice = salesPrice;
	}
	
	@Transient
	public Long getCoreBlueId() {
		return coreBlueId;
	}

	public void setCoreBlueId(Long coreBlueId) {
		this.coreBlueId = coreBlueId;
	}
	@Transient
	public Long getCoreBaleId() {
		return coreBaleId;
	}

	public void setCoreBaleId(Long coreBaleId) {
		this.coreBaleId = coreBaleId;
	}
	@Transient
	public Integer getCoreAnnounceId() {
		return coreAnnounceId;
	}

	public void setCoreAnnounceId(Integer coreAnnounceId) {
		this.coreAnnounceId = coreAnnounceId;
	}
	@Transient
	public String getChargeTypeList() {
		return chargeTypeList;
	}

	public void setChargeTypeList(String chargeTypeList) {
		this.chargeTypeList = chargeTypeList;
	}

}
package com.taiping.dianshang.outer.action;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.compass.core.util.concurrent.ConcurrentHashSet;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.outer.service.OuterService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.SpringTool;
import com.taiping.framework.action.BaseAction;

/**
 * 触发产生支付回调守护线程
 * @author xilh
 * @since 20171120
 */
@ParentPackage("struts-default")
@Namespace("/payCallback")
public class PayCallbackSupportAction  extends BaseAction {
	
	public static ConcurrentHashSet<Long> set = new ConcurrentHashSet<Long>();
	private static final long serialVersionUID = 5849260213064898322L;
	
	/**
	 * 触发产生支付回调守护线程
	 * 场景：当 StartUpListener 处理支付回调队列的线程因不明原因终止运行时，通过作业平台的监控启动新的线程 
	 * @author xilh
	 * @since 20171120
	 */
	@Action(value = "support")
	public void support() throws IOException {
		final String queueName = getRequest().getParameter("queueName");
		
		if (StringUtils.isEmpty(queueName)) {
			LogTool.warn(this.getClass(), "queueName is null");
			return;
		}
		
		synchronized (set) {
			// 最多可执行60 次
			if (set.size() > 60) {
				ajaxText("switchOff");
				return;
			}
			set.add(System.currentTimeMillis());
		}
		
		new Thread() {
			@SuppressWarnings("unchecked")
			public void run() {
				int index = 1;
				while(true){
					try {
						// 0. 作业总开关
						while(true){
							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_PAYNOTIFY_START_END_TIME);
							// 在任务暂停时间内，sleep 5 minute a time
							if (isInTime(startEnd)) {
								LogTool.debug(this.getClass(), "sleeping ... ");
								Thread.sleep(5*1000);
								continue;
							}else {
								break;
							}
						}
						
						long length = JedisClient_outer2.llen(queueName);
						LogTool.info(this.getClass(), queueName+",support length: "+String.valueOf(length));
						
						// 告知客户端（TASK工程）正常启动了 ,此代码块只走一次
						if (index == 1) {
							JedisClient_outer2.set("TASK_"+queueName, ConstantTool.STR_1);
							JedisClient_outer2.expire("TASK_"+queueName, 30);
							index--;
						}
						
						// 队列长度为零的话，休眠
						if (length == 0) {
							Thread.sleep(2000);
						}else {
							// 对队列长度不为零的，进行处理
							String json = JedisClient_outer2.lpop(queueName);
							if (!StringUtils.isEmpty(json)) {
								LogTool.info(this.getClass(), "payCallback: "+String.valueOf(json));
								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
								
								String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
								if (!service.endsWith("Impl")) {
									service = service.concat("Impl");
								}
								OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
								if (sendService != null) {
									sendService.handle(map);
								}
							}
						}
					} catch (InterruptedException e1) {
						LogTool.error(this.getClass(), e1);
						try {
							Thread.sleep(1*1000);
						} catch (InterruptedException e2) {
							LogTool.error(this.getClass(), e2);
						}
					} catch (ParseException e) {
						LogTool.error(this.getClass(), e);
						try {
							Thread.sleep(1*1000);
						} catch (InterruptedException e1) {
							LogTool.error(this.getClass(), e1);
						}
					} 
				}
				// while over
			}
		}.start();
		
		ajaxText(SUCCESS);
	}
	
	public boolean isInTime(String startEnd) throws ParseException{
		if (!StringUtils.isEmpty(startEnd) && startEnd.indexOf(";") > -1) {
			String start = startEnd.split(";")[0];
			String end   = startEnd.split(";")[1];
			Date date1 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, start);
			Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, end);
			Date now = new Date();
			
			if (now.before(date2) && now.after(date1)) {
				LogTool.debug(this.getClass(), "now: "+DateTool.convertDataToString(now, DateTool.DATE_TIME_MASK));
				LogTool.debug(this.getClass(), "task service pause date1: "+date1);
				LogTool.debug(this.getClass(), "task service pause date2: "+date2);
				return true;
			}
		}
		return false;
	}
}
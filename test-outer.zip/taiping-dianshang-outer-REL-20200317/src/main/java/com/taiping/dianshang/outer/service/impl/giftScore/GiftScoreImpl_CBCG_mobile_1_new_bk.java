package com.taiping.dianshang.outer.service.impl.giftScore;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.outer.DTO.response.GiftResponseDTO;
import com.taiping.dianshang.outer.service.GiftScoreService;
import com.taiping.dianshang.outer.service.impl.autoRegister.UniformUserIdentityService;
import com.taiping.dianshang.outer.service.impl.giftScore.model.GiftScoreRequestV2;
import com.taiping.dianshang.outer.service.impl.giftScore.model.GiftScoreReturnV2;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.model.DictItems;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.Md5EncryptTool;
import com.taiping.facility.tool.StringTool;

/**
 * 业务场景:承保后根据投保人手机号赠送积分,一个交易号赠送一次
 * @author xilh
 *
 */
@Component
public class GiftScoreImpl_CBCG_mobile_1_new_bk extends GiftScoreImpl implements GiftScoreService{
	@Resource
	private BusinesslogService businesslogService;
	@Resource(name="uniformUserIdentityImpl")
	private UniformUserIdentityService uniformUserIdentityService;
	@Resource
	private IspApplyDao ispApplyDao;
	@Resource
	private IspPolicyDao ispPolicyDao;
	@Resource
	private IspSendHistoryDao ispSendHistoryDao;
	
	@Transactional
	public void handle(Map<String, Object> paramsMap){
		String userId = "";
		String partnerApplyId = "";
		try {
			// 保单号
			partnerApplyId = StringTool.nullToEmpty(paramsMap.get("operateNo"));
	        
			LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
			LogTool.error(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
			
	        IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply == null) {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			userId = apply.getUserId();
			// 是否已送过积分
			IspSendHistory ispSendHistory = ispSendHistoryDao.load(apply.getApplyId());
			if (ispSendHistory != null && ispSendHistory.getIsGiftScoreSend() == 1) {
				LogTool.error(this.getClass(),"score already gived,applyId:"+apply.getApplyId());
				return;
			}
			// 送积分策略一：partnerId+blueId
			// 20171011 REMOVE SCORE STRATEGY
			// IspGiftStrategy ispGiftStrategy = CacheContainer.getByIdFromCache(apply.getPartnerId()+ConstantTool.UNDERLINE+apply.getBlueId(), IspGiftStrategy.class);
			// 有送积分策略
			//if (ispGiftStrategy != null) {
			// 是否在活动时间内
			// 永远在活动期内
			boolean isInTime = true;//this.isInTime(ispGiftStrategy);
			// 避免已有userId还自动注册, modified by xiluhua 20170417 
			LogTool.debug(this.getClass(), "userId_partnerApplyId: "+partnerApplyId+",userId: "+userId);
			if (isInTime && StringUtils.isEmpty(userId)) {
				LogTool.error(this.getClass(),"InTime:"+isInTime);
				userId = uniformUserIdentityService.autoRegister(apply,apply.getHolder().getMobile());
				apply.setUserId(userId);
			}
			
			if (!StringUtils.isEmpty(userId)) {
				GiftResponseDTO responseDTO = this.sendGift(apply, this.getClass().getSimpleName());
				if (responseDTO.isSuccess()) {
					ispSendHistory.setIsGiftScoreSend(1);
					ispSendHistoryDao.update(ispSendHistory);
				}
				
				// 更新 userId 到 IspApply
				ispApplyDao.update(apply);
				// 更新 userId 到 IspPolicy
				IspPolicy policy = ispPolicyDao.load(apply.getPolicyNo());
				if (policy != null && StringUtils.isEmpty(policy.getUserId())) {
					policy.setUserId(userId);
					ispPolicyDao.update(policy);
				}
			}
			
			// 20171011 REMOVE SCORE STRATEGY
			//}
			
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	public GiftResponseDTO sendGift(IspApply apply,String simpleName){

		GiftResponseDTO responseDTO = new GiftResponseDTO();
		responseDTO.setSuccess(false);
		String responseMsg = null;
		String giftScoreUrl = "";
		String giftScoreAesKey = "";
		try {
			giftScoreUrl = CacheContainer.getSystemParameterValue(ConstantTool.GIFTSCORE_URL);
			giftScoreAesKey = CacheContainer.getSystemParameterValue(ConstantTool.GIFTSCORE_AESKEY);
			
			GiftScoreRequestV2 giftScoreRequest = this.getGiftScoreRequest_1(apply, null, simpleName);
			String url = giftScoreRequest.getUrl(apply, giftScoreUrl,giftScoreAesKey);
			
			String requestXml = url+"\r\n"+ToStringBuilder.reflectionToString(giftScoreRequest);
			businesslogService.postBusinessOpelog_1(apply, requestXml, ConstantTool.INTERFACE_G_106_GIFT_SCORE, 1, 1);
			
			LogTool.error(this.getClass(),"applyId:"+apply.getApplyId()+",url:"+url);
			responseMsg = this.send(url);
			
			if (StringUtils.isEmpty(responseMsg)) {
				responseDTO.setReturnInfo("积分系统返回为空");
			}else {
				GiftScoreReturnV2 giftScoreReturn = JsonTool.toObject(responseMsg, GiftScoreReturnV2.class, DateTool.DATE_TIME_MASK);
				if (giftScoreReturn.getResult().equals("0000")) {
					responseDTO.setSuccess(true);
				}
				LogTool.error(this.getClass(),"=============================================================");
				LogTool.error(this.getClass(),"applyId:"+apply.getApplyId()+",giftScoreReturn:"+ToStringBuilder.reflectionToString(giftScoreReturn));
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			if (StringUtils.isEmpty(e.getMessage())) {
				responseDTO.setReturnInfo("积分系统连接失败 ...");
			}else {
				responseDTO.setReturnInfo(e.getMessage());
			}
		}
		
		int operateStatus = 2;
		if (responseDTO.isSuccess()) {
			operateStatus = 1;
		}
		
		businesslogService.postBusinessOpelog_2(apply, responseMsg, ConstantTool.INTERFACE_G_106_GIFT_SCORE, operateStatus, 1);
		
		return responseDTO;
	}
	
	@Override
	public GiftScoreRequestV2 getGiftScoreRequest_1(IspApply apply,String actionId,String simpleName)throws Exception{
		GiftScoreRequestV2 giftScoreRequest = new GiftScoreRequestV2();
		
		try {
			giftScoreRequest.setActionId(actionId);
			giftScoreRequest.setPolicyNo(apply.getPolicyNo());
			giftScoreRequest.setBlueId(apply.getBlueId());	
			DictItems dictItems = CacheContainer.getDictionary("gift.score.channel");
			String channel = dictItems.getItemByCode(String.valueOf(apply.getPartnerId())).getValue();
			
			LogTool.debug(this.getClass(), "partnerApplyId:"+apply.getPartnerApplyId()+",gift.score.channel:"+channel);
			giftScoreRequest.setChannel(channel);
			
			if (simpleName.toLowerCase().indexOf("mobile") > -1) {
				giftScoreRequest.setPhone(apply.getHolder().getMobile());
			}else {
				giftScoreRequest.setEmail(apply.getHolder().getEmail());
			}
			giftScoreRequest.setMemberId(apply.getUserId());
			
			int paymentMethod = 0;
			if (apply.getChargeType() == 5) {
				paymentMethod = 1;//1--趸缴
			}else if (apply.getChargeType() == 1) {
				paymentMethod = 2;//2—-年缴
			}else if (apply.getChargeType() == 4) {
				paymentMethod = 3;//3—-月缴
			}
			giftScoreRequest.setPaymentMethod(paymentMethod);
			giftScoreRequest.setPremium(apply.getPremium());
			// added by xiluhua 20170227 投保礼接口更新，新增字段childType
//			giftScoreRequest.setRequestId(String.valueOf(seq));
			giftScoreRequest.setRequestId(apply.getPolicyNo());
			giftScoreRequest.setRuleType(2);
			
			giftScoreRequest.setToken(this.getToken(apply,giftScoreRequest));
		} catch (Exception e) {
			String errorMsg = "get GiftScoreRequest failed,partnerApplyId:"+apply.getPartnerApplyId();
			LogTool.error(this.getClass(), e);
			LogTool.error(this.getClass(), errorMsg);
			throw new Exception(errorMsg);
		}
		
		return giftScoreRequest;
	}
	
	public String getToken(IspApply apply,GiftScoreRequestV2 giftScoreRequest)throws Exception{
		StringBuffer buffer = new StringBuffer();
		String token = null;
		String md5Key = "";
		
		try {
			md5Key = CacheContainer.getSystemParameterValue(ConstantTool.GIFTSCORE_MD5KEY);
		
			buffer.append(md5Key+"|");	
			buffer.append(giftScoreRequest.getMemberId()+"|");	
			buffer.append(giftScoreRequest.getRuleType()+"|");
			buffer.append(giftScoreRequest.getChannel()+"|");
			buffer.append(giftScoreRequest.getCompanySource()+"|");
			buffer.append(giftScoreRequest.getRequestId());
			token = Md5EncryptTool.getMd5(buffer.toString());
			LogTool.error(this.getClass(),buffer.toString());
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new Exception("getToken sign error,partnerApplyId:"+apply.getPartnerApplyId());
		}
		
		return token;
	}

}

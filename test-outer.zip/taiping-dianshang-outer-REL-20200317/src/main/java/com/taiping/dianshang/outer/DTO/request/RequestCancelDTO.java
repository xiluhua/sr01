package com.taiping.dianshang.outer.DTO.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.taiping.dianshang.outer.DTO.request.element.BusinessDTO;

/**
 * @author: xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"business"
})
@XmlRootElement(name = "REQUEST")
public class RequestCancelDTO implements RequestDTO {
	@XmlElement(name = "BUSINESS")
	protected BusinessDTO business = new BusinessDTO();

	public BusinessDTO getBusiness() {
		return business;
	}

	public void setBusiness(BusinessDTO business) {
		this.business = business;
	}

}

package com.taiping.dianshang.outer.DTO.request;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;
/**
 * @author xiluhua by 20181121
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
	    "ad",
	    "channel",
	    "cid",
	    "wi",
	    "target"
})
@JsonIgnoreProperties(ignoreUnknown = true) 
public class RequestMediumDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	@XmlElement(name = "AD")
	private String ad;
	@XmlElement(name = "CHANNEL")
	private String channel;
	@XmlElement(name = "CID")
	private String cid;
	@XmlElement(name = "WI")
	private String wi;
	@XmlElement(name = "TARGET")
	private String target;

	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getWi() {
		return wi;
	}
	public void setWi(String wi) {
		this.wi = wi;
	}
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	
}

package com.taiping.dianshang.outer.DTO.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.taiping.dianshang.outer.DTO.request.element.BusinessDTO;
import com.taiping.dianshang.outer.DTO.request.element.PayCallbackDTO;

/**
 * @author: xiluhua by 20170629
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"business",
		"callback"
})
@XmlRootElement(name = "REQUEST")
public class RequestPayCallbackDTO implements RequestDTO {
	@XmlElement(name = "BUSINESS")
	protected BusinessDTO business = new BusinessDTO();
	@XmlElement(name = "CALLBACK")
	protected PayCallbackDTO callback = new PayCallbackDTO();
	
	public BusinessDTO getBusiness() {
		return business;
	}
	public void setBusiness(BusinessDTO business) {
		this.business = business;
	}
	public PayCallbackDTO getCallback() {
		return callback;
	}
	public void setCallback(PayCallbackDTO callback) {
		this.callback = callback;
	}
	public RequestPayCallbackDTO() {
		super();
	}
	
	


}

package com.taiping.dianshang.outer.service.impl.policyPdf;

import java.io.DataOutputStream;
import java.io.File;
import java.io.OutputStream;
import java.net.URLDecoder;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PdfDownloadHttpsTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * 易安下载电子保单
 * @author xilh
 * @since 20200229
 */
@Service
public class DownloadPolicyPdfImpl_4 implements DownloadPolicyPdfService{
	@Autowired
	IspPolicyDao ispPolicyDao;
	
	/**
	 * 
	 * @author xilh
	 * @since 20200229
	 */
	@SuppressWarnings("deprecation")
	@Transactional
	public String download(String policyNo,String idNo) {
		String path = null;
		OutputStream outputStream = null;
		DataOutputStream dout = null;
		try {
			IspPolicy policy = ispPolicyDao.getIspPolicy(policyNo);
			if (policy == null || StringUtils.isEmpty(policy.getDownloadRes())) {
				return null;
			}
			String dir = PropertyFileTool.get("policy.pdf.dir");
			if (!new File(dir).exists()) {
				new File(dir).mkdirs();
			}
			path = dir+policyNo+".pdf";
			LogTool.debug(this.getClass(),"download.pdf.dir.path：" + path);
			LogTool.debug(this.getClass(),"policy.download.url: " + policy.getDownloadRes());
			
			String policyUrl = policy.getDownloadRes();
			if (policyUrl.indexOf("%") > -1) {
				policyUrl = URLDecoder.decode(policyUrl);
				LogTool.info(this.getClass(), "policyNo: " + policyNo + " , policyUrl:" + policyUrl);
			}
			// 代理的设置  
			String proxy = CacheContainer.getSystemParameterValue(ConstantTool.INTERNET_PROXY_1);
			if (LogTool.isLocal) {
				proxy = PropertyFileTool.get(ConstantTool.INTERNET_PROXY_1);
			}
            //3. 电子保单生成
            PdfDownloadHttpsTool tool = new PdfDownloadHttpsTool();
            tool.persistentPDF(policyNo, proxy, path, policyUrl);
		} catch (Exception e) {
			path = null;
			LogTool.error(this.getClass(), e);
			throw new DownloadPolicyPdfSysException();
		} finally {
			try {
				if (outputStream!= null) {
					outputStream.close();
				}
				if (dout != null) {
					dout.close();
				}
			} catch (Exception e2) {
				LogTool.error(this.getClass(), e2);
			}
		}
		
		return path;
	}
	
	public static void main(String[] args) {
		String url = "http://ebiz.tpi.cntaiping.com";
		String domainIp = "ectp.tpi.cntaiping.com,10.12.41.1;ebiz.tpi.cntaiping.com,10.12.41.1";
		String[] arr = domainIp.split(";");
		System.out.println(arr.length);
		for (int i = 0; i < arr.length; i++) {
			String[] tmp = arr[i].split(",");
			for (int j = 0; j < tmp[i].length(); j++) {
				url = url.replaceAll(tmp[0], tmp[1]);
			}
		}
		
		System.err.println(url);
	}
}

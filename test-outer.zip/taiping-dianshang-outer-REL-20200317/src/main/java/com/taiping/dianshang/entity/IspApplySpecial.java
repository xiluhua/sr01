package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**   
 * @ClassName ISP_APPLY_SPECIAL   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_APPLY_SPECIAL")
public class IspApplySpecial {

	@Id
	@Column(name="APPLY_ID")
	private Long applyId;
	@Column(name="SPECIAL1")
	private String special1;
	@Column(name="SPECIAL2")
	private String special2;
	
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getSpecial1() {
		return special1;
	}
	public void setSpecial1(String special1) {
		this.special1 = special1;
	}
	public String getSpecial2() {
		return special2;
	}
	public void setSpecial2(String special2) {
		this.special2 = special2;
	}
	
	
}





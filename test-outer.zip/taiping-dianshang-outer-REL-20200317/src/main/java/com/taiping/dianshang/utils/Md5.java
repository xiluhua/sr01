package com.taiping.dianshang.utils;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * <b>Title: </b>
 * <p>Description: </p>
 * 
 * @author H.Yang
 * @email xhaimail@163.com
 * @date 2019/04/25
 */
public class Md5 {

	/**
	* 利用MD5进行加密
		 * 
	* @param str
	*            待加密的字符串
	* @return 加密后的字符串
	* @throws NoSuchAlgorithmException
	*             没有这种产生消息摘要的算法
	* @throws UnsupportedEncodingException
	*/
	public static String EncoderByMd5(String str) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		String strMD5Ret = "";
		// 确定计算方法
		MessageDigest md5 = MessageDigest.getInstance("MD5");
		byte[] inputByteArray = str.getBytes();
		md5.update(inputByteArray);
		byte[] resultByteArray = md5.digest();
		strMD5Ret = byteArrayToHex(resultByteArray);
		return strMD5Ret;
	}

	private static String byteArrayToHex(byte[] byteArray) {
		// 首先初始化一个字符数组，用来存放每个16进制字符
		char[] hexDigits = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
		// new一个字符数组，这个就是用来组成结果字符串的（解释一下：一个byte是八位二进制，也就是2位十六进制字符（2的8次方等于16的2次方））
		char[] resultCharArray = new char[byteArray.length * 2];
		// 遍历字节数组，通过位运算（位运算效率高），转换成字符放到字符数组中去
		int index = 0;
		for (byte b : byteArray) {
			resultCharArray[index++] = hexDigits[b >>> 4 & 0xf];
			resultCharArray[index++] = hexDigits[b & 0xf];
		}
		// 字符数组组合成字符串返回
		return new String(resultCharArray);
	}

	public static void main(String[] args) {
		Md5 md = new Md5();
		try {
			String ee = md.EncoderByMd5("d15fdd6fef4943e0968edc2b63a97aff" + "6303130114206190000006");
			System.out.println(ee);
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
	}

}

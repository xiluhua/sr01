package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;

/**
 * @category 反欺诈
 * @author xilh
 * @since 20181122
 * from 王丽军
 */
@Service
public class ShortMsgAndGiftImpl_CBCG_1_FQZ_tmall extends ShortMsgImpl_COMMON_1 {

	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		shortMsgParamMap.put(ConstantTool.TEMPLATE_ID, "1.blue.tmall.fqz");
		shortMsgParamMap.put(ConstantTool.TYPE, ConstantTool.STR_2);
		super.handle(shortMsgParamMap);
	}
}

package com.taiping.dianshang.service.httpclient;

import com.taiping.dianshang.entity.IspHttpclientParams;

public interface HttpclientService {
	/**
	 * post 方法
	 * @param  url
	 * @param httpclientParams
	 * @return
	 */
	public String get(String url, IspHttpclientParams httpclientParams,String trans) throws Exception;
	
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content, String encode) throws Exception;
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content, String encode, String contextType, boolean needProxy) throws Exception;
	
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content,String contentType, String encode,int connectionTimeout,int soTimeout,int retryTime) throws Exception;
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object obj, IspHttpclientParams httpclientParams) throws Exception;
}

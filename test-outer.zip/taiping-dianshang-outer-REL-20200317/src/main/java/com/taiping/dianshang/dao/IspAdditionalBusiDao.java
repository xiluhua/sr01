package com.taiping.dianshang.dao;

import java.math.BigDecimal;
import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.ScOverseasSecurityProject;
import com.taiping.framework.dao.CommonDao;
import com.taiping.framework.dao.DaoUtil;

@Repository
public class IspAdditionalBusiDao extends CommonDao  {

    /**
	 * 根据productArea,destination,planType获得境外游保额
	 * @param productArea
	 * @param destination
	 * @param planType
	 * @return
	 */
	public Double getAmount_jwy(String productArea,String destination,String planType){
		Double amount = null;
		StringBuffer sql = new StringBuffer();
	    sql.append(" select sum(osp.security_amount) from SC_OVERSEAS_SECURITY_PROJECT osp ");
	    sql.append(" where 1=1 ");
	    sql.append(" and osp.product_area=? ");
	    sql.append(" and osp.destination=? ");
	    sql.append(" and osp.plan_type=?");
	   
		SQLQuery query = this.getSessionRead().createSQLQuery(sql.toString());
		query.setParameter(0,productArea);
		query.setParameter(1, destination);
		query.setParameter(2, planType);
		amount = ((BigDecimal) query.uniqueResult()).doubleValue(); 
	    return amount;
	}
	
	/**
	 * 根据productArea,destination,planType获得SC_OVERSEAS_SECURITY_PROJECT
	 * @param productArea
	 * @param destination
	 * @param planType
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public List<ScOverseasSecurityProject> getOverseasSecurityProjectList(String productArea, String destination, String planType){
		List<ScOverseasSecurityProject> list = null;
		StringBuffer sql = new StringBuffer();
	    sql.append("select osp.id, ");
	    sql.append("  osp.product_area, ");
	    sql.append("  osp.destination, ");
	    sql.append("  osp.plan_type, ");
	    sql.append("  osp.security_project, ");
	    sql.append("  osp.security_payments, ");
	    sql.append("  osp.security_amount, ");
	    sql.append("  osp.insurance, ");
	    sql.append("  osp.insurance_code, ");
	    sql.append("  osp.limit_name, ");
	    sql.append("  osp.limit_code, ");
	    sql.append("  osp.limit_description, ");
	    sql.append("  osp.limit_amount ");
	    sql.append("  from SC_OVERSEAS_SECURITY_PROJECT osp ");
	    sql.append("where osp.product_area=? ");
	    sql.append("and osp.destination=? ");
	    sql.append("and osp.plan_type=?");
	    
	    SQLQuery query = this.getSessionRead().createSQLQuery(sql.toString());
	    query.addEntity(ScOverseasSecurityProject.class);
	    query.setString(0, productArea);
	    query.setString(1, destination);
	    query.setString(2, planType);
	    list = query.list();
//	    list = daoUtil.queryForEntityListByParam(sql.toString(),ScOverseasSecurityProject.class,new Object[]{productArea,destination,planType});
	    
	    return list;
	}
}

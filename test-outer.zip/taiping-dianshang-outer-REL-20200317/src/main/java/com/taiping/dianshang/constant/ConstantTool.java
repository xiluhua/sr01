package com.taiping.dianshang.constant;



/**
 * 常量定义工具
 * @author xilh by 20160119
 *
 */
public class ConstantTool {
	
	public static final String GBK = "GBK";
	public static final String UTF8 = "UTF-8";
	public static final String TEXT_XML = "text/xml";
	//核心返回
	public static final String CoreReturnSuccess 	= "1001"; //核心返回成功
	public static final String CoreReturnFailed 	= "1002"; //核心返回失败
	public static final String ErrorDocParse 		= "1104";          // 报文解析出错

	//合作方ID Long 类型
	public static final Long ISP_ID 				= Long.parseLong("301");   // ISP平台ID
	public static final Long CAIXIAN_CORE_ID 		= Long.parseLong("600");  // 太财核心平台ID
	public static final Long YANGLAO_CORE_ID 		= Long.parseLong("500");  // 养老核心平台ID
	public static final Long SHOUXIAN_CORE_ID 		= Long.parseLong("400");  // 核心平台ID
	public static final Long IPAY_ID 				= Long.parseLong("300");  // 支付平台ID
	public static final Long SHANG_CHENG 			= Long.parseLong("200");  	// 网上商城ID
	public static final Long GUAN_WANG 				= Long.parseLong("199");  	// 太平官网ID
	public static final Long ALIPAY_ID 				= Long.parseLong("205");  // 支付宝ID
	public static final Long TAOBAO_ID 				= Long.parseLong("34");  // 淘宝ID
	public static final Long PRODUCT_CENTER 		= Long.parseLong("186");   // 产品中心
	public static final Long SCORE_ID 				= Long.parseLong("350");  // 积分系统ID
	public static final Long WO_WALLAT_ID            =Long.parseLong("321");    // 沃钱包
	// 自动注册
	public static String WX_WZZCCG 					= "WX_WZZCCG"; 	//注册成功
	public static String WX_ZZKGMCG 				= "WX_ZZKGMCG"; //自助卡购买成功
	public static String WX_YJQRMM 					= "WX_YJQRMM"; 	//邮件确认密码
	public static String WSFW_QHMM 					= "WSFW_QHMM"; 	//密码找回
	public static String WX_YCTX 					= "WX_YCTX"; 		//异常提醒
	public static String WX_KDQTX 					= "WX_KDQTX"; 	//快到期提醒(用户购买的保单即将到期,提醒用户及时续保)   
	public static String WX_HD 						= "WX_HD"; 			//活动
	public static String WX_ZF 						= "WX_ZF"; 			//祝福
	public static String WX_YJ 						= "WX_YJ"; 			//预警(太平人寿网销平台预警)   
	public static String WX_TZ 						= "WX_TZ"; 			//通知
	public static String WX_MMCZ					= "WX_MMCZ";			//密码重置邮件
	public static String WX_CBCG					= "WX_CBCG";			//承保通知
	public static String WX_DSRW					= "WX_DSRW";		//定时任务失败邮件
	public static String WX_WTJ						= "WX_WTJ";		//定时任务失败邮件
	public static String WX_XQTX                    = "WX_XQTX";       //续期提醒
	// 承保成功短信
	public static String DSWX_TBCBDX 				= "DSWX_TBCBDX";
	//发送邮件
	public static String SHORTMSG_TEMPLATE_PATH 	= "";//短信模板根目录路径
	public static String EMAIL_TEMPLATE_PATH 		= "";//邮件模板根目录路径
	public static String SERVICE_ID 				= "serviceId";
	public static String PAY_REGISTER 				= "payRegister";
	public static String PREM_ID 					= "PREM_ID";
	public static String BILL_ID 					= "BILL_ID";
	public static String BUSI_TYPE 					= "BUSI_TYPE";
	public static String TEMPLATE_ID 				= "templateId";	// added by xiluhua 20170926
	public static String TYPE 						= "type";		// added by xiluhua 20170926
	public static String OPERATE_NO 				= "operateNo";
	public static String SHORTMSG_TEMP_ID 			= "shortmsgTempId";
	public static String PARTNER_ID 				= "partnerId";
	public static String ADMIN_TYPE 				= "adminType";
	public static String COUNT 						= "count";
	public static String NEXT_CALLBACK_TIME 		= "next.callback.time";
	public static String EMAIL_REGISTER 			= "email_register";					//注册
	public static String EMAIL_BACKPASSWORD 		= "email_backPassword";			//找回密码
	public static String EMAIL_CARD 				= "email_card";							//自助卡激活
	public static String EMAIL_EXPIRATIONPOLICY 	= "email_expirationPolicy";	//快到期保单
	public static String EMAIL_PREVIEW 				= "email_preview";					//承保
	public static String EMAIL_TASK 				= "email_task";							//定时任务失败
	public static String EMAIL_PROBLEM 				= "email_problem";					//问题件
	
	public static String ZZKGMCGHTML 				= "ZZKGMCG.html";		//自助卡购买成功邮件内容html
	public static String WZZCCGHTML 				= "WZZCCG.html";		//自动注册成功邮件内容html
	public static String QHMMHTML 					= "QHMM.html";			//密码找回邮件内容html
	public static String KDQTXHTML 					= "KDQTX.html";			//快到期邮件内容html
	public static String CBCG						= "CBCG.html";					//承保成功
	public static String DSRW 						= "DSRW.html";					//承保成功
	public static String CBSB_WTJ					= "CBSB_WTJ.html";					//问题件发送
	
	public static String SUCCESS					= "SUCCESS";		//操作成功
	public static String FAILURE 					= "FAILURE";		//操作失败
	public static String EXCEPTION 					= "EXCEPTION";	//操作过程中发生异常
	
	//add by xiluhua 2013-03-14
	public static String SHORT_MSG_XYHCBHTML		= "XYHCB.html";			//新用户承保短信内容
	public static String SHORT_MSG_LYHCBHTML 		= "LYHCB.html";			//老用户承保短信内容
	public static String SHORT_MSG_ZXTBYZMHTML 		= "ZXTBYZM.html";		//在线退保验证码短信内容
	public static String SHORT_MSG_TFCGTZHTML 		= "TFCGTZ.html";		//退费成功通知短信内容
	public static String SHORT_MSG_DQX 				= "LYHCB_DQX.html";		//老用户承保短信内容
	public static String SHORT_MSG_CQX 				= "LYHCB_CQX.html";
	public static String SHORT_MSG_CBSB 			= "CBSB_CQX.html";		//承保失败短信内容
	public static String SHORT_MSG_XBSB 			= "XBSB_CQX.html";		//续保失败短信内容
	public static String WX_XYHCB 					= "WX_XYHCB";
	public static String WX_LYHCB 					= "WX_LYHCB";
	public static String WX_ZXTBYZM 				= "WX_ZXTBYZM";
	public static String WX_TFCGTZ 					= "WX_TFCGTZ";
	public static String SHORT_CB_FAIL 				= "SHORT_CB_FAIL.html";	//承保失败短信内容
	public static String SHORT_CB_LTDH				= "LTDH_CB.html";		//联调导航承保短信内容
	
	//add by xiluhua 2013-03-14
	public static String SHOR_MSG_SEND_SUCCESS 		= "OK";//请求短信提交成功，纳入接口队列等待处理：SMS has been queued for processing.
	
	public static String SEQ_LOG_INDEX 				= "seq_log_index";//报文日志ID
	
	//add by xiluhua 2014-09-04    养老险渠道代码 (01商城,02集团自保,03联通,04淘宝)
	public static String YANGLAO_CHANNELNO_MALL 	= "01";
	public static String YANGLAO_CHANNELNO_GROUP 	= "02";
	public static String YANGLAO_CHANNELNO_LIANTONG = "03";
	public static String YANGLAO_CHANNELNO_TAOBAO 	= "04";
	public static String YANGLAO_CHANNELNO_NETEASE 	= "0X";	//待定
	
	public static String BANKCODE 	= "BANKCODE_";
	public static String UNDERLINE 	= "_";
	public static String POLICYPDF 	= "POLICYPDF";
	public static String INVOICEPDF = "INVOICEPDF";
	// 通过
	public static String PASS 		= "0000";
	// 不通过
	public static String NOT_PASS 	= "9999";
	public static String CX_XML_TEMPLATE_FILE_PATH 	= "/template/cx/"; // 报文模板路径
	public static String SEQ_TRIAL_TRANS 			= "SEQ_ISP_TRIAL_TRANS";
	public static String SEQ_APPLY 					= "SEQ_ISP_APPLYID";
	public static String SEQ_CUSTOMER 				= "SEQ_ISP_APPCUSTOMERID";
	public static String SEQ_BENEFICIARY 			= "SEQ_ISP_APPBENEFICIARYID";
	public static String SEQ_IPAY_RENEW 			= "SEQ_IPAY_RENEW";
	public static String SEQ_IPAY_PAY 				= "SEQ_DS_IPAY_PAYID";
	public static String SEQ_IPAY_BILL 				= "SEQ_DS_IPAY_BILLID";
	public static String SEQ_IPAY_BILL_GOODS 		= "SEQ_DS_IPAY_BILL_GOODSID";
	public static String SEQ_YL_DDH 				= "SEQ_YL_DDH";
	public static String SEQ_YANGLAO_TRANS 			= "SEQ_ISP_YANGLAO_TRANS";
	public static String SEQ_CX_MERS_POLICYNO 		= "SEQ_CX_MERS_POLICYNO";	// 财险保单号生成SEQUENCE
	public static String SEQ_CX_ISP_BLUEPRINT_FEE 	= "SEQ_CX_ISP_BLUEPRINT_FEE";
	public static String SEQ_ISP_BLUEPRINT 			= "SEQ_ISP_BLUEPRINT";
	public static String SEQ_ISP_BALE 				= "SEQ_ISP_BALE";
	public static String SEQ_ISP_PRODUCT_EXT 		= "SEQ_ISP_PRODUCT_EXT";
	public static String SEQ_ISP_BALE_COVER 		= "SEQ_ISP_BALE_COVER";
	public static String SEQ_ISP_BALE_PRODUCT_EXT 	= "SEQ_ISP_BALE_PRODUCT_EXT";
	public static String SEQ_ISP_BLUE_ANNOUNCE 		= "SEQ_ISP_BLUE_ANNOUNCE";
	public static String SEQ_ISP_BLUEPRINT_PROPERTY = "SEQ_ISP_BLUEPRINT_PROPERTY";
	public static String SEQ_IMS_TASK_EXT 			= "SEQ_IMS_TASK_EXT_ID";
	public static String SEQ_DS_IPAY_REGISTER 		= "SEQ_DS_IPAY_REGISTER";
	public static String SEQ_TRANS 					= "SEQ_ISP_TRANS";
	public static String SEQ_IIP_SM_SEND_LIST 		= "SEQ_IIP_SM_SEND_LIST";
	public static String SEQ_ISP_ERROR_BUSINESS		= "SEQ_ISP_ERROR_BUSINESS";
	public static String SEQ_ISP_RETRY_RECORED		= "SEQ_ISP_RETRY_RECORED";
	// 核保业务
	public static final String INTERFACE_A1_CHECK			= "check";
	// 规则库业务
	public static final String INTERFACE_A2_CHECKRULE 		= "checkRule";
	// 出单业务
	public static final String INTERFACE_A3_CHECKBILL 		= "checkBill";
	// 承保业务(核保+出单)
	public static final String INTERFACE_A4_ACCEPT 			= "accept";
	// 保单状态查询
	public static final String INTERFACE_A5_POLICY_STATUS_QUERY 	= "policyStatusQuery";
	// 退保业务
	public static final String INTERFACE_A6_REFUND 			= "refund";
	// 支付登记 
	public static final String INTERFACE_A7_PAY_REGISTER 	= "payRegister";
	// 投保单号同步
	public static final String INTERFACE_A8_SYNAPPNO 		= "synAppno";
	// 方案导入业务
	public static final String INTERFACE_A9_SYN_BLUEPRINT	= "synBlueprint";
	// 试算业务
	public static final String INTERFACE_A10_TRIAL 			= "trial";
	// 订单查询业务
	public static final String INTERFACE_A11_ORDER_QUERY	= "orderQuery";
	// 保单续保状态查询业务
	public static final String INTERFACE_A15_RENEW_QUERY	= "renewQuery";
	// 保单续保业务
	public static final String INTERFACE_A16_RENEW_CHECKBILL= "renewCheckBill";
	// 短信业务
	public static final String INTERFACE_E_510_SHORTMSG 	= "shortMsg";
	// 注册查询
	public static final String INTERFACE_R_104_AUTO_REGI_QUERY 	= "autoRegiQuery";
	// 自动注册
	public static final String INTERFACE_R_105_AUTO_REGI 	= "autoRegi";
	// 积分赠送
	public static final String INTERFACE_G_106_GIFT_SCORE	= "giftScore";
	// 短信业务
	public static final String INTERFACE_F_108_SENDEMAIL 	= "sendEmail";
	public static final String PAY_NOTIFY					= "payNotify";
	public static final String PAY_NOTIFY_MULTI				= "payNotifyMulti";
	public static final String PAY_CALLBACK					= "payCallback";
	public static final String PAY_CALLBACK_MULTI			= "payCallbackMulti";
	public static final String CHECKBILL_CALLBACK			= "checkBillCallback";
	public static final String CANCEL 						= "cancel";	// added by xiluhua 20171026

	
	public static String STR_0 = "0";
	public static String STR_1 = "1";
	public static String STR_2 = "2";
	public static String STR_3 = "3";
	public static String STR_4 = "4";
	public static String STR_5 = "5";
	public static String STR_6 = "6";
	public static String STR_7 = "7";
	public static String STR_8 = "8";
	public static String STR_9 = "9";
	
	// 系统变量
	public static String SYS_IS_CHECK_18_YEARS_OLDER 	= "is.check.18.years.older";
	public static String SYS_SYN_APPNO_PER_BATCH_AMOUNT = "syn.appno.per.batch.amount";
	public static String UNIFORMUSERIDENTITY_SERVICEID 	= "uniformUserIdentity.serviceId";
	public static String UNIFORMUSERIDENTITY_SOURCE 	= "uniformUserIdentity.source";
	public static String GIFTSCORE_URL					= "giftScore.url";
	public static String GIFTSCORE_AESKEY				= "giftScore.aesKey";
	public static String GIFTSCORE_MD5KEY				= "giftScore.md5Key";
	public static String SYSTEM_TIMEOUT_1 				= "system.timeout.1";
	public static String POLICY_DOWNLOAD_URL_NEW 		= "policy.download.url.new";
	public static String WXHOME 						= "wxhome";
	public static String POLICY_PDF_DOWNLOAD_SIGN		= ".policy.pdf.download.sign";
	public static String LIFEPOLPATH 					= "lifePolPath";
	public static String ENDOWMENTPOLPATH				= "endowmentPolPath";
	public static String TPLIFE_POLICY_PDF_DOWNLOAD_URL = "tplife.policy.pdf.download.url";
	public static String SYS_TPI_DOMAIN_IP 				= "tpi.domain.ip";
	public static String SYS_CBCG_SEND_EMAIL_SLEEP_SECONDS 	= "CBCG.send.email.sleep.senconds";
	public static String SYS_KEY_1				 		= "sys.key.1";
	public static String SYS_GIFTSCORE_STOP_TIME		= "giftScore.stop.time";
	public static String SYS_GIFTSCORE_STOP_END_TIME	= "giftScore.stop.end.time";
	// 代理IP by-qby 2019-03-15
	public static String SYS_TPI_AGENT_IP 				= "tpi.agent.ip";
	// 服务暂停开关
	public static String SYS_GIFTSCORE_START_END_TIME	= "giftScore.start.end.time";
	public static String SYS_PAYNOTIFY_START_END_TIME	= "payNotify.start.end.time";
	public static String SYS_SHORTMSG_START_END_TIME	= "shortmsg.start.end.time";
	public static String SYS_EMAIL_START_END_TIME		= "email.start.end.time";
	public static String SYS_CANCEL_START_END_TIME		= "cancel.start.end.time";
	public static String SYS_CHECKBILL_START_END_TIME	= "checkBill.start.end.time";
	
	public static String SYS_GIFTSCORE_START_END_TIMEOLD	= "giftScore.start.end.time.old";
	public static String SYS_PAYNOTIFY_START_END_TIMEOLD	= "payNotify.start.end.time.old";
	public static String SYS_SHORTMSG_START_END_TIMEOLD		= "shortmsg.start.end.time.old";
	public static String SYS_EMAIL_START_END_TIMEOLD		= "email.start.end.time.old";
	public static String SYS_CANCEL_START_END_TIMEOLD		= "cancel.start.end.time.old";
	public static String SYS_CHECKBILL_START_END_TIMEOLD	= "checkBill.start.end.time.old";
	
	public static String SYS_NO_SIGN_PARTNERS			= "no.sign.partners";
	public static String SYS_PAY_RECALL_RETRY_TIME		= "pay.recall.retry.time";
	public static String SYS_PAY_CALLBACKS_WITH_PARTNER_PROTOCOL = "pay.callbacks.with.partner.protocol";
	
	public static String QUEUE_EMAIL 					= "QUEUE_EMAIL";
	public static String QUEUE_SHORTMSG 				= "QUEUE_SHORTMSG";
	public static String QUEUE_GIFTSCORE 				= "QUEUE_GIFTSCORE";
	public static String QUEUE_AUTO_REGI 				= "QUEUE_AUTO_REGI";
	public static String QUEUE_PAY_NOTIRY 				= "QUEUE_PAY_NOTIRY";
	public static String QUEUE_PAY_CALLBACK				= "QUEUE_PAY_CALLBACK";
	public static String QUEUE_PAY_CALLBACK_RETRY		= "QUEUE_PAY_CALLBACK_RETRY";
	public static String QUEUE_PAY_CALLBACK_LOCAL		= "QUEUE_PAY_CALLBACK_LOCAL";
	public static String QUEUE_PAY_CALLBACK_RETRY_LOCAL	= "QUEUE_PAY_CALLBACK_RETRY_LOCAL";
	public static String QUEUE_DS_BUSI_LOG 				= "QUEUE_DS_BUSI_LOG";
	public static String QUEUE_CHECKBILL_CALLBACK		= "QUEUE_CHECKBILL_CALLBACK";
	public static String QUEUE_CHECKBILL_CALLBACK_RETRY	= "QUEUE_CHECKBILL_CALLBACK_RETRY";
	public static String QUEUE_CHECKBILL_CALLBACK_LOCAL		= "QUEUE_CHECKBILL_CALLBACK_LOCAL";
	public static String QUEUE_CHECKBILL_CALLBACK_RETRY_LOCAL	= "QUEUE_CHECKBILL_CALLBACK_RETRY_LOCAL";
	
	public static String DIANSHANG_CORE_REST_SERVICE_URL= "dianshang.core.rest.service.url";
	
	public static String PAY_BANK_FOSUN = "foSun";
	public static String FOSUN_DOWNLOAD_POLICY_PDF_RMI  ="200000147_download_policyPDF"; // add by liwei  2019/5/8 5:42 PM  description:RMI对应常量
	// add by liuhe 20190819 续期邮件编码
	public static String EMAIL_CODE_RENEW               = "renewNotify";
	public static final String INTERNET_PROXY_1         = "internet.proxy";		// add by xiluhua 20200206
}

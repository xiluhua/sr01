package com.taiping.dianshang.outer.service;

public interface DownloadPolicyPdfService {

	/**
	 * 从核心系统下载电子保单
	 * @param policyNo
	 * @param idNo
	 * @return
	 */
	public String download(String policyNo,String idNo);
	
	
}

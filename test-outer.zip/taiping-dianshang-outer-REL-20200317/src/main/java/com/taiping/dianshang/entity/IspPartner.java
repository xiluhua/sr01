package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspPartner entity. 
 */
@Entity
@Table(name = "ISP_PARTNER")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspPartner implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long partnerId;
	private String partnerName;
	private String partnerCode;
	private String payerCode;
	private String merCode;
	private String partnerUrl;
	private String keyPassword;
	private String certificationFilePath;
	private Integer partnerType;
	private String accountLoginPage;
	private String payLoginPage;
	private Integer status;
	private String address;
	private String communicationMemo;
	private String bankCode;
	private String ipList;
	private String memo;
	private Date createTime;
	private Date updateTime;
	private Long createAid;
	private Long updateAid;
	private Integer cooperateType;
	private Integer feeType;
	private Integer organType;
	private Long payerDisplaySeq;
	private String partnerQlReqUrl;
	private String partnerQlResUrl;
	private String partnerQlApplyClass;

	// Constructors

	/** default constructor */
	public IspPartner() {
	}

	/** minimal constructor */
	public IspPartner(Long partnerId) {
		this.partnerId = partnerId;
	}

	/** full constructor */
	public IspPartner(Long partnerId, String partnerName, String partnerCode,
			String payerCode, String merCode, String partnerUrl,
			String keyPassword, String certificationFilePath,
			Integer partnerType, String accountLoginPage, String payLoginPage,
			Integer status, String address, String communicationMemo,
			String bankCode, String ipList, String memo, Date createTime,
			Date updateTime, Long createAid, Long updateAid,
			Integer cooperateType, Integer feeType, Integer organType,
			Long payerDisplaySeq, String partnerQlReqUrl,
			String partnerQlResUrl, String partnerQlApplyClass) {
		this.partnerId = partnerId;
		this.partnerName = partnerName;
		this.partnerCode = partnerCode;
		this.payerCode = payerCode;
		this.merCode = merCode;
		this.partnerUrl = partnerUrl;
		this.keyPassword = keyPassword;
		this.certificationFilePath = certificationFilePath;
		this.partnerType = partnerType;
		this.accountLoginPage = accountLoginPage;
		this.payLoginPage = payLoginPage;
		this.status = status;
		this.address = address;
		this.communicationMemo = communicationMemo;
		this.bankCode = bankCode;
		this.ipList = ipList;
		this.memo = memo;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
		this.cooperateType = cooperateType;
		this.feeType = feeType;
		this.organType = organType;
		this.payerDisplaySeq = payerDisplaySeq;
		this.partnerQlReqUrl = partnerQlReqUrl;
		this.partnerQlResUrl = partnerQlResUrl;
		this.partnerQlApplyClass = partnerQlApplyClass;
	}

	// Property accessors
	@Id
	@Column(name = "PARTNER_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getPartnerId() {
		return this.partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	@Column(name = "PARTNER_NAME", length = 150)
	public String getPartnerName() {
		return this.partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	@Column(name = "PARTNER_CODE", length = 50)
	public String getPartnerCode() {
		return this.partnerCode;
	}

	public void setPartnerCode(String partnerCode) {
		this.partnerCode = partnerCode;
	}

	@Column(name = "PAYER_CODE", length = 50)
	public String getPayerCode() {
		return this.payerCode;
	}

	public void setPayerCode(String payerCode) {
		this.payerCode = payerCode;
	}

	@Column(name = "MER_CODE", length = 20)
	public String getMerCode() {
		return this.merCode;
	}

	public void setMerCode(String merCode) {
		this.merCode = merCode;
	}

	@Column(name = "PARTNER_URL", length = 1000)
	public String getPartnerUrl() {
		return this.partnerUrl;
	}

	public void setPartnerUrl(String partnerUrl) {
		this.partnerUrl = partnerUrl;
	}

	@Column(name = "KEY_PASSWORD", length = 12)
	public String getKeyPassword() {
		return this.keyPassword;
	}

	public void setKeyPassword(String keyPassword) {
		this.keyPassword = keyPassword;
	}

	@Column(name = "CERTIFICATION_FILE_PATH", length = 200)
	public String getCertificationFilePath() {
		return this.certificationFilePath;
	}

	public void setCertificationFilePath(String certificationFilePath) {
		this.certificationFilePath = certificationFilePath;
	}

	@Column(name = "PARTNER_TYPE", precision = 3, scale = 0)
	public Integer getPartnerType() {
		return this.partnerType;
	}

	public void setPartnerType(Integer partnerType) {
		this.partnerType = partnerType;
	}

	@Column(name = "ACCOUNT_LOGIN_PAGE", length = 500)
	public String getAccountLoginPage() {
		return this.accountLoginPage;
	}

	public void setAccountLoginPage(String accountLoginPage) {
		this.accountLoginPage = accountLoginPage;
	}

	@Column(name = "PAY_LOGIN_PAGE", length = 500)
	public String getPayLoginPage() {
		return this.payLoginPage;
	}

	public void setPayLoginPage(String payLoginPage) {
		this.payLoginPage = payLoginPage;
	}

	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "ADDRESS", length = 100)
	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "COMMUNICATION_MEMO", length = 1000)
	public String getCommunicationMemo() {
		return this.communicationMemo;
	}

	public void setCommunicationMemo(String communicationMemo) {
		this.communicationMemo = communicationMemo;
	}

	@Column(name = "BANK_CODE", length = 20)
	public String getBankCode() {
		return this.bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	@Column(name = "IP_LIST", length = 1000)
	public String getIpList() {
		return this.ipList;
	}

	public void setIpList(String ipList) {
		this.ipList = ipList;
	}

	@Column(name = "MEMO", length = 1000)
	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", precision = 10, scale = 0)
	public Long getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(Long createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", precision = 10, scale = 0)
	public Long getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(Long updateAid) {
		this.updateAid = updateAid;
	}

	@Column(name = "COOPERATE_TYPE", precision = 3, scale = 0)
	public Integer getCooperateType() {
		return this.cooperateType;
	}

	public void setCooperateType(Integer cooperateType) {
		this.cooperateType = cooperateType;
	}

	@Column(name = "FEE_TYPE", precision = 3, scale = 0)
	public Integer getFeeType() {
		return this.feeType;
	}

	public void setFeeType(Integer feeType) {
		this.feeType = feeType;
	}

	@Column(name = "ORGAN_TYPE", precision = 3, scale = 0)
	public Integer getOrganType() {
		return this.organType;
	}

	public void setOrganType(Integer organType) {
		this.organType = organType;
	}

	@Column(name = "PAYER_DISPLAY_SEQ", precision = 10, scale = 0)
	public Long getPayerDisplaySeq() {
		return this.payerDisplaySeq;
	}

	public void setPayerDisplaySeq(Long payerDisplaySeq) {
		this.payerDisplaySeq = payerDisplaySeq;
	}

	@Column(name = "PARTNER_QL_REQ_URL", length = 2000)
	public String getPartnerQlReqUrl() {
		return this.partnerQlReqUrl;
	}

	public void setPartnerQlReqUrl(String partnerQlReqUrl) {
		this.partnerQlReqUrl = partnerQlReqUrl;
	}

	@Column(name = "PARTNER_QL_RES_URL", length = 2000)
	public String getPartnerQlResUrl() {
		return this.partnerQlResUrl;
	}

	public void setPartnerQlResUrl(String partnerQlResUrl) {
		this.partnerQlResUrl = partnerQlResUrl;
	}

	@Column(name = "PARTNER_QL_APPLY_CLASS", length = 200)
	public String getPartnerQlApplyClass() {
		return this.partnerQlApplyClass;
	}

	public void setPartnerQlApplyClass(String partnerQlApplyClass) {
		this.partnerQlApplyClass = partnerQlApplyClass;
	}

}
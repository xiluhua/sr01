package com.taiping.dianshang.outer.service.impl.giftScore;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspGiftStrategy;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.outer.DTO.response.GiftResponseDTO;
import com.taiping.dianshang.outer.service.GiftScoreService;
import com.taiping.dianshang.outer.service.impl.autoRegister.UniformUserIdentityService;
import com.taiping.dianshang.outer.service.impl.giftScore.model.GiftScoreRequest;
import com.taiping.dianshang.outer.service.impl.giftScore.model.GiftScoreReturn;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.StringTool;

/**
 * 业务场景:承保后根据投保人手机号赠送积分,一个交易号赠送一次
 * @author xilh
 *
 */
@Deprecated
@Component
public class GiftScoreImpl_CBCG_mobile_1 extends GiftScoreImpl implements GiftScoreService{
	@Resource
	private BusinesslogService businesslogService;
	@Resource(name="uniformUserIdentityImpl")
	private UniformUserIdentityService uniformUserIdentityService;
	@Resource
	private IspApplyDao ispApplyDao;
	@Resource
	private IspPolicyDao ispPolicyDao;
	@Resource
	private IspSendHistoryDao ispSendHistoryDao;
	
	@Transactional
	public void handle(Map<String, Object> paramsMap){
		String userId = "";
		String partnerApplyId = "";
		try {
			// 保单号
			partnerApplyId = StringTool.nullToEmpty(paramsMap.get("operateNo"));
	        
			LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
			
	        IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply == null) {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			
			// 是否已送过积分
			IspSendHistory ispSendHistory = ispSendHistoryDao.load(apply.getApplyId());
			if (ispSendHistory != null && ispSendHistory.getIsGiftScoreSend() == 1) {
				LogTool.error(this.getClass(),"score already gived,applyId:"+apply.getApplyId());
				return;
			}
			// 送积分策略一：partnerId+blueId
			IspGiftStrategy ispGiftStrategy = CacheContainer.getByIdFromCache(apply.getPartnerId()+ConstantTool.UNDERLINE+apply.getBlueId(), IspGiftStrategy.class);
			//有送积分策略
			if (ispGiftStrategy != null) {
				// 是否在活动时间内
				boolean isInTime = this.isInTime(ispGiftStrategy);
				if (isInTime) {
					LogTool.error(this.getClass(),"InTime:"+isInTime);
					userId = uniformUserIdentityService.autoRegister(apply,apply.getHolder().getMobile());
				}
			}
			
			if (!StringUtils.isEmpty(userId)) {
				apply.setUserId(userId);
				GiftResponseDTO responseDTO = this.sendGift(apply, this.getClass().getSimpleName());
				if (responseDTO.isSuccess()) {
					ispSendHistory.setIsGiftScoreSend(1);
					ispSendHistoryDao.update(ispSendHistory);
					// 更新 userId 到 IspApply
					ispApplyDao.update(apply);
					// 更新 userId 到 IspPolicy
					IspPolicy policy = ispPolicyDao.load(apply.getPolicyNo());
					if (policy != null) {
						policy.setUserId(userId);
						ispPolicyDao.update(policy);
					}
				}
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	public GiftResponseDTO sendGift(IspApply apply,String simpleName){

		GiftResponseDTO responseDTO = new GiftResponseDTO();
		responseDTO.setSuccess(false);
		String responseMsg = null;
		String giftScoreUrl = "";
		String giftScoreAesKey = "";
		try {
			giftScoreUrl = CacheContainer.getSystemParameterValue(ConstantTool.GIFTSCORE_URL);
			giftScoreAesKey = CacheContainer.getSystemParameterValue(ConstantTool.GIFTSCORE_AESKEY);
			
			GiftScoreRequest giftScoreRequest = super.getGiftScoreRequest_1(apply, null, simpleName);
			String url = giftScoreRequest.getUrl(apply, giftScoreUrl,giftScoreAesKey);
			
			String requestXml = url+"\r\n"+ToStringBuilder.reflectionToString(giftScoreRequest);
			businesslogService.postBusinessOpelog_1(apply, requestXml, ConstantTool.INTERFACE_G_106_GIFT_SCORE, 1, 1);
			
			LogTool.error(this.getClass(),"applyId:"+apply.getApplyId()+",url:"+url);
			responseMsg = this.send(url);
			if (StringUtils.isEmpty(responseMsg)) {
				responseDTO.setReturnInfo("积分系统返回为空");
			}else {
				GiftScoreReturn giftScoreReturn = JsonTool.toObject(responseMsg, GiftScoreReturn.class, DateTool.DATE_TIME_MASK);
				if (giftScoreReturn.getResult().equals("0000")) {
					responseDTO.setSuccess(true);
				}
				LogTool.error(this.getClass(),"=============================================================");
				LogTool.error(this.getClass(),"applyId:"+apply.getApplyId()+",giftScoreReturn:"+ToStringBuilder.reflectionToString(giftScoreReturn));
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			if (StringUtils.isEmpty(e.getMessage())) {
				responseDTO.setReturnInfo("积分系统连接失败 ...");
			}else {
				responseDTO.setReturnInfo(e.getMessage());
			}
		}
		
		int operateStatus = 2;
		if (responseDTO.isSuccess()) {
			operateStatus = 1;
		}
		
		businesslogService.postBusinessOpelog_2(apply, responseMsg, ConstantTool.INTERFACE_G_106_GIFT_SCORE, operateStatus, 1);
		
		return responseDTO;
	}
	
	

}

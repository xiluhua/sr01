package com.taiping.dianshang.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.text.ParseException;

import javax.xml.bind.JAXBException;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.taiping.dianshang.utils.CreateDTOTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.IOTool;

public class HttpXmlSender_Concurrent
{
	
	public static void main(String[] args) throws ParseException, JAXBException
	{
		int threadNum = 150;
		final int concurrentNum = 100;
		
//		String file = "test-199-query.xml";//"test-199-yiNianQiZJ-accept-multi.xml"; //"test-199-hkyw-accept-multi.xml";//"test-199-yiNianQiZJ-accept-single-3000.xml";//"test-199-yiNianQiZJ-accept-single-test.xml";  //
//		final String template = IOTool.readFile(HttpXmlSender_199_Concurrent.class.getResource("/template/test/"+file).getPath(), "gbk");
		String file = "test_check.xml";
		String path = HttpclientTool.class.getResource("/template/test/"+file).getPath();
		System.out.println("path : "+path);
		String xml = IOTool.readFile(path, "utf-8");  //请确认编码方式
		System.out.println(xml);
		
		
		// 刷新缓存
//		String url = "http://localhost:7788/taiping-dianshang-core/rest/core/business/cacheRefresh";
//		String response = HttpClientTool.get(url, map, encode);
//		System.out.println("response:"+response);
		
		// 核保
		final String content = CreateDTOTool.create(1,"178_LOCAL201602211",false,1);
		
		
		// localhost本地
//		String url = "http://localhost:8000/taiping-sol-mall/partner/partnerEntrance.action";
		
		for (int i = 0; i < threadNum; i++) {
			new Thread(){
				public void run(){
					// UAT环境
//					String url = "http://baoxian.itaiping.com/partner/partnerEntrance.action";
//					String url = "http://10.1.17.96:7002/partner/partnerEntrance.action";
					String url = "http://localhost:7788/taiping-dianshang-core/services/rest/core/business/entrance";
					// 请确认编码方式
					String encode = "GBK";
					String key = "tplife";
					
					for (int j = 0; j < concurrentNum; j++) {
						String response = "";
						try {
							response = HttpclientTool.post(url, content, encode);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						System.out.println("response:"+response);
					}
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}.start();
		}
		
	}
	
	public static String getRandom(int length){
		String random = String.valueOf(Math.random() + 1).replace(".", "")+String.valueOf(Math.random() + 1).replace(".", "");
		return random.substring(0,length);
	}
	
	private static Log log = LogFactory.getLog(HttpXmlSender_Concurrent.class);

	/**
	 * 发送报文方法
	 * @param url  发送URL地址
	 * @param xml  报文消息体
	 * @param md5key 机构验证码
	 * @return   合作方应答报文
	 * 
	 * 发送时要对明文进行md5签名，md5(key+xml明文)，发送时xml报文要进行GBK编码后发送
	 */
	public static String sendRequest(String url, String requestXml, String md5key,String comId,String encode)
	{
		String result = null;
		
		if (StringUtils.isBlank(url))
		{
			System.out.println("[发送报文接口出错] 参数url为空");
			return null;
		}
		else if (StringUtils.isBlank(requestXml))
		{
			System.out.println("[发送报文接口出错] 参数xml为空");
			return null;
		}
		else if (StringUtils.isBlank(md5key))
		{
			System.out.println("[发送报文接口出错] 参数md5key为空");
			//return null;
		}

//		System.out.println("[发送报文接口]参数xml=" + requestXml + "，" + "url=" + url);

		HttpClient client = new HttpClient();
		
		
		//设置代理
//        client.getHostConfiguration().setProxy("10.4.233.50", 31151);
//        client.getParams().setAuthenticationPreemptive(true);
//        //设置密码
//        client.getState().setProxyCredentials(AuthScope.ANY, new UsernamePasswordCredentials("xilh", "Itaiping123"));
        
        
		//设置连接超时时间(单位毫秒)    	 
		client.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
		//设置读数据超时时间(单位毫秒)    	
		client.getHttpConnectionManager().getParams().setSoTimeout(60000);
		PostMethod method = null;
		try
		{
			String source = (md5key == null ? "" : md5key) + requestXml;
//			System.out.println(source);
			String sign = DigestUtils.md5Hex(source.getBytes("GBK"));

			String handledUrl = null;
			if (url.contains("?"))
			{
				handledUrl = url + "&sign=" + sign + "&comId=" + comId;
			}
			else
			{
				handledUrl = url + "?sign=" + sign + "&comId=" + comId;
			}
			
//			log.info("[发送目标URL:]\n" + handledUrl);
			method = new PostMethod(handledUrl);
			method.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
			method.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");
			NameValuePair[] data ={ new NameValuePair("data", URLEncoder.encode(requestXml, "GBK")) };//{ new NameValuePair("data", xml) };
			
			method.setRequestBody(data);
			requestXml = requestXml.replaceAll("\\n", "");
			requestXml = requestXml.replaceAll("\\r", "");
			System.out.println("[requestXml]=" + requestXml.replaceAll(" ", ""));
			int statusCode = client.executeMethod(method);
			
			if (statusCode == 200)// 返回成功
			{
				InputStream resStream = method.getResponseBodyAsStream();
				BufferedReader br = new BufferedReader(new InputStreamReader(resStream, "gbk"));
				StringBuffer resBuffer = new StringBuffer();
				String resTemp = "";
				while ((resTemp = br.readLine()) != null)
				{
					resBuffer.append(resTemp);
				}
				result = resBuffer.toString();
				System.out.println("=============================================================");
				System.out.println("=============================================================");
				System.out.println("=============================================================");
//				System.out.println(result);
				if (StringUtils.isNotBlank(result))
				{
					System.out.println("[responseXml=" + result + "]");
				}
			}
			else
			{
				System.out.println("[发送报文接口][接口状态异常][status=" + statusCode + "][reason="
						+ method.getStatusLine().getReasonPhrase() + "]");
			}
		}
		catch (IOException e)
		{
			System.out.println("[发送报文接口][网络IO异常][" + "][url=" + url + "]");
			e.printStackTrace();
		}
		finally
		{
			if (method != null)
			{
				method.releaseConnection();
			}
		}

		return result;
	}
	
	
	
	/**
	 * 发送报文方法
	 * @param url  发送URL地址
	 * @param xml  报文消息体
	 * @param md5key 机构验证码
	 * @return   合作方应答报文
	 * 
	 * 发送时要对明文进行md5签名，md5(key+xml明文)，发送时xml报文要进行GBK编码后发送
	 */
//	public static String sendRequest(String url, String xml, String md5key,String file,String comId,String encode)
//	{
//		String result = null;
//		String path = HttpXmlSender_199_Concurrent.class.getResource("/template/test/"+file).getPath();
//		System.out.println("path : "+path);
//		xml = IOTool.readFile(path, encode);  //请确认编码方式
//		
//		if (StringUtils.isBlank(url))
//		{
//			System.out.println("[发送报文接口出错] 参数url为空");
//			return null;
//		}
//		else if (StringUtils.isBlank(xml))
//		{
//			System.out.println("[发送报文接口出错] 参数xml为空");
//			return null;
//		}
//		else if (StringUtils.isBlank(md5key))
//		{
//			System.out.println("[发送报文接口出错] 参数md5key为空");
//			//return null;
//		}
//
//		System.out.println("[发送报文接口]参数xml=" + xml + "，" + "url=" + url);
//
//		HttpClient client = new HttpClient();
//		
//		
//		//设置代理
////        client.getHostConfiguration().setProxy("10.4.233.50", 31151);
////        client.getParams().setAuthenticationPreemptive(true);
////        //设置密码
////        client.getState().setProxyCredentials(AuthScope.ANY, new UsernamePasswordCredentials("xilh", "Itaiping123"));
//        
//        
//		//设置连接超时时间(单位毫秒)    	 
//		client.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
//		//设置读数据超时时间(单位毫秒)    	
//		client.getHttpConnectionManager().getParams().setSoTimeout(60000);
//		PostMethod method = null;
//		try
//		{
//			String source = (md5key == null ? "" : md5key) + xml;
//			System.out.println(source);
//			String sign = DigestUtils.md5Hex(source.getBytes("GBK"));
//
//			String handledUrl = null;
//			if (url.contains("?"))
//			{
//				handledUrl = url + "&sign=" + sign + "&comId=" + comId;
//			}
//			else
//			{
//				handledUrl = url + "?sign=" + sign + "&comId=" + comId;
//			}
//			
////			String timestamp = DateTool.getDateTime("yyyyMMddHHmmss", new Date());
////			String source = (md5key == null ? "" : md5key) + trans + timestamp;
////	        System.out.println(source);
////	        String sign = DigestUtils.md5Hex(source.getBytes("GBK"));
////	 
////	        String handledUrl = null;
////	        if (url.contains("?"))
////	        {
////	           handledUrl = url + "&sign=" + sign + "&timestamp=" + timestamp + "&trans=" + trans;
////	        }
////	        else
////	        {
////	           handledUrl = url + "?sign=" + sign + "&timestamp=" + timestamp + "&trans=" + trans;
////	        }
//			log.info("[发送目标URL:]\n" + handledUrl);
//			method = new PostMethod(handledUrl);
//			method.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
//			method.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");
//			//method.addRequestHeader("Content-Type", "text/html;charset=GBK");
//			//method.setRequestEntity(new StringRequestEntity(xml, "text/xml", "GBK"));
//			NameValuePair[] data ={ new NameValuePair("data", URLEncoder.encode(xml, "GBK")) };//{ new NameValuePair("data", xml) };
//			System.out.println(xml);
////			{ new NameValuePair("data", URLEncoder.encode(xml, "GBK")) };
//			method.setRequestBody(data);
//			
//			int statusCode = client.executeMethod(method);
//			if (statusCode == 200)// 返回成功
//			{
//				InputStream resStream = method.getResponseBodyAsStream();
//				BufferedReader br = new BufferedReader(new InputStreamReader(resStream, "gbk"));
//				StringBuffer resBuffer = new StringBuffer();
//				String resTemp = "";
//				while ((resTemp = br.readLine()) != null)
//				{
//					resBuffer.append(resTemp);
//				}
//				result = resBuffer.toString();
//				System.out.println("=============================================================");
//				System.out.println("=============================================================");
//				System.out.println("=============================================================");
////				System.out.println(result);
//				if (StringUtils.isNotBlank(result))
//				{
//					log.info("[发送报文接口][responseXml=" + result + "]");
//				}
//			}
//			else
//			{
//				System.out.println("[发送报文接口][接口状态异常][status=" + statusCode + "][reason="
//						+ method.getStatusLine().getReasonPhrase() + "]");
//			}
//		}
//		catch (IOException e)
//		{
//			System.out.println("[发送报文接口][网络IO异常][" + "][url=" + url + "]");
//			e.printStackTrace();
//		}
//		finally
//		{
//			if (method != null)
//			{
//				method.releaseConnection();
//			}
//		}
//
//		return result;
//	}



}

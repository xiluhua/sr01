package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 问题业务对象
 * @author xilh
 */
@Entity
@Table(name = "SC_ISP_ERROR_BUSINESS")
public class IspErrorBusiness {
	
	@Id
	@Column(name = "ERROR_BUSINESS_ID", length = 10)
	private Long errorBusinessId;   //问题业务ID 
	@Column(name = "BUSINESS_TYPE")
	private Integer businessType;   //业务类型
	@Column(name = "BUSINESS_APPLY_ID")
	private Long businessApplyId;  	//业务请求ID 
	@Column(name = "APP_NO")
	private String appNo;     		//投保单号/卡号
	@Column(name = "POLICY_NO")
	private String policyNo;  		//保单号
	@Column(name = "STATUS")
	private Integer status;   		//状态
	@Column(name = "ERROR_TYPE")
	private Integer errorType;     	//问题类型
	@Column(name = "REGISTER_TYPE")
	private Integer registerType;  	//登记类型 ?
	@Column(name = "DISPOSE_TYPE")
	private Integer disposeType;   	//处理类型?
	@Column(name = "APP_CUST_ID")
	private String appCustId;   		//投保客户ID
	@Column(name = "CUST_NAME")
	private String custName;  		//客户姓名
	@Column(name = "BLUE_ID")
	private Long blueId;      		//方案ID 
	@Column(name = "BLUE_INNER_NAME")
	private String blueInnerName;  	//方案名称
	@Column(name = "REGISTER_MEMO")
	private String registerMemo;   	//登记备注 
	@Column(name = "DISPOSE_MEMO")
	private String disposeMemo;    	//处理备注
	@Column(name = "BUSINEUSS_TIME")
	private Date businessTime;     	//业务时间
	@Column(name = "REGISTER_TIME")
	private Date registerTime;     	//登记时间 
	@Column(name = "DISPOSE_TIME")
	private Date disposeTime;      	//处理结束时间
	@Column(name = "CREATE_TIME")
	private Date createTime;       	//创建时间
	@Column(name = "UPDATE_TIME")
	private Date updateTime;       	//更新时间
	@Column(name = "CREATE_AID")
	private String createAid;        	//创建帐号ID 
	@Column(name = "UPDATE_AID")
	private String updateAid;        	//更新帐号ID
	@Column(name = "BILL_ID")
	private String billId;        	//创建帐号ID 
	@Column(name = "PAY_ID")
	private String payId;        	//更新帐号ID
	
	
	public Long getErrorBusinessId() {
		return errorBusinessId;
	}
	public void setErrorBusinessId(Long errorBusinessId) {
		this.errorBusinessId = errorBusinessId;
	}
	public Integer getBusinessType() {
		return businessType;
	}
	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}
	public Long getBusinessApplyId() {
		return businessApplyId;
	}
	public void setBusinessApplyId(Long businessApplyId) {
		this.businessApplyId = businessApplyId;
	}
	public String getAppNo() {
		return appNo;
	}
	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getErrorType() {
		return errorType;
	}
	public void setErrorType(Integer errorType) {
		this.errorType = errorType;
	}
	public Integer getRegisterType() {
		return registerType;
	}
	public void setRegisterType(Integer registerType) {
		this.registerType = registerType;
	}
	public Integer getDisposeType() {
		return disposeType;
	}
	public void setDisposeType(Integer disposeType) {
		this.disposeType = disposeType;
	}
	public String getAppCustId() {
		return appCustId;
	}
	public void setAppCustId(String appCustId) {
		this.appCustId = appCustId;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	public String getBlueInnerName() {
		return blueInnerName;
	}
	public void setBlueInnerName(String blueInnerName) {
		this.blueInnerName = blueInnerName;
	}
	public String getRegisterMemo() {
		return registerMemo;
	}
	public void setRegisterMemo(String registerMemo) {
		this.registerMemo = registerMemo;
	}
	public String getDisposeMemo() {
		return disposeMemo;
	}
	public void setDisposeMemo(String disposeMemo) {
		this.disposeMemo = disposeMemo;
	}
	public Date getBusinessTime() {
		return businessTime;
	}
	public void setBusinessTime(Date businessTime) {
		this.businessTime = businessTime;
	}
	public Date getRegisterTime() {
		return registerTime;
	}
	public void setRegisterTime(Date registerTime) {
		this.registerTime = registerTime;
	}
	public Date getDisposeTime() {
		return disposeTime;
	}
	public void setDisposeTime(Date disposeTime) {
		this.disposeTime = disposeTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getCreateAid() {
		return createAid;
	}
	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}
	public String getUpdateAid() {
		return updateAid;
	}
	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}
	@Override
	public String toString() {
		return "IspErrorBusiness [errorBusinessId=" + errorBusinessId
				+ ", businessType=" + businessType + ", businessApplyId="
				+ businessApplyId + ", appNo=" + appNo + ", policyNo="
				+ policyNo + ", status=" + status + ", errorType=" + errorType
				+ ", registerType=" + registerType + ", disposeType="
				+ disposeType + ", appCustId=" + appCustId + ", custName="
				+ custName + ", blueId=" + blueId + ", blueInnerName="
				+ blueInnerName + ", registerMemo=" + registerMemo
				+ ", disposeMemo=" + disposeMemo + ", businessTime="
				+ businessTime + ", registerTime=" + registerTime
				+ ", disposeTime=" + disposeTime + ", createTime=" + createTime
				+ ", updateTime=" + updateTime + ", createAid=" + createAid
				+ ", updateAid=" + updateAid + "]";
	}
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public String getPayId() {
		return payId;
	}
	public void setPayId(String payId) {
		this.payId = payId;
	}
	
	
	

}

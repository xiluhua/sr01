package com.taiping.dianshang.outer.DTO.response.element.info;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspArea;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTimeAdapter;

/**
 * @author xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"partnerApplyId",
		"applyId",
		"appNo",
		"policyNo",
		"checkStatus",
		"payStatus",
		"checkBillStatus",
		"applyStatus",
		"blueName",
	    "blueId",
	    "baleId",
	    "premium",
	    "amount",
	    "bonusMode",
	    "discount",
	    "organId",
	    "lv1Area",
	    "lv2Area",
	    "lv1AreaId",
	    "lv2AreaId",
	    "chargeType",
	    "chargeYear",
	    "rHolderInst",
	    "checkTime",
	    "validateDate",
	    "expirationDate",
	    "beneficiaryType",
	    "sellChannel",
	    "partnerId",
	    "createTime",
	    "userId",
	    "unit",
	    "acceptTime",
	    "billId",
	    "isPaperPdfSent",
	    "isCancel"
	   
})
public class ApplyResponseDTO {
	@XmlElement(name = "PARTNER_APPLY_ID")
	private String partnerApplyId; 		// 合作方请求ID
	@XmlElement(name = "APPLY_ID")
	protected Long applyId; 
	@XmlElement(name = "APP_NO")
	private String appNo; 
	@XmlElement(name = "POLICY_NO")
	private String policyNo; 			// 合作方请求ID
	@XmlElement(name = "CHECK_STATUS")
	private int checkStatus = 0; 		// 订单状态: 1(核保成功)
	@XmlElement(name = "PAY_STATUS")
	private int payStatus = 0; 			// 支付状态: 1(支付成功)
	@XmlElement(name = "CHECK_BILL_STATUS")
	private int checkBillStatus = 0; 	// 出单状态: 1(出单成功)
	@XmlElement(name = "APPLY_STATUS")
	private int applyStatus = 0; 		// 订单状态: 1待支付(核保成功)|6支付成功、承保成功返回支付成功|4承保失败
	@XmlElement(name = "BLUE_NAME")
	private String blueName;
    @XmlElement(name = "BLUE_ID")
 	protected Long blueId;  
    @XmlElement(name = "BALE_ID")
    protected Long baleId;  			// 计划ID
    @XmlElement(name = "PREMIUM")
    private double premium;				// 保费
    @XmlElement(name = "AMOUNT")
    protected Integer amount; 			// 保额
    @XmlElement(name = "BONUS_MODE")
    private Integer bonusMode;			// 红利领取方式
    @XmlElement(name = "DISCOUNT")
    protected Double discount;   
    @XmlElement(name = "ORGAN_ID")
    protected Long organId;         	// 机构ID// 折扣率
    @XmlElement(name = "LV1_AREA")
    protected String lv1Area;    		// 投保地区(省)
    @XmlElement(name = "LV2_AREA")
    protected String lv2Area; 			// 投保城市(市)
    @XmlElement(name = "LV1_AREA_ID")
    protected Long lv1AreaId;    		// 投保地区(省)
    @XmlElement(name = "LV2_AREA_ID")
    protected Long lv2AreaId; 			// 投保城市(市)
    @XmlElement(name = "CHARGE_TYPE")
    protected Integer chargeType;  		// 缴费方式
    @XmlElement(name = "CHARGE_YEAR")
    protected Integer chargeYear;  		// 缴费年限
    @XmlElement(name = "R_HOLDER_INST")
    protected Integer rHolderInst;  	// 被保人是投保人的关系
    @XmlElement(name = "CHECK_TIME")
    @XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    private Date checkTime;				// 投保时间
    @XmlElement(name = "VALIDATE_DATE")
    @XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    protected Date validateDate;    	// 保单生效日期
    @XmlElement(name = "EXPIRATION_DATE")
    @XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    protected Date expirationDate;  	// 终止日期
    @XmlElement(name = "BENEFICIARY_TYPE")
    protected Integer beneficiaryType = 0;  // 受益人类型 0.法定,1.指定,缺省0
    @XmlElement(name = "SELL_CHANNEL")
    private Integer sellChannel;		// 专业公司渠道
    @XmlElement(name = "PARTNER_ID")
    protected Long partnerId;			//合作方伙伴
    @XmlElement(name = "USER_ID")
    protected String userId;  			// 当前用户
    @XmlElement(name = "CREATE_TIME")
    @XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    private Date createTime = null;	
    @XmlElement(name = "UNIT")
    private Integer unit = 1;			// 投保份数，默认1份
    @XmlElement(name = "ACCEPT_TIME")
    @XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    private Date acceptTime = null;	
    @XmlElement(name = "BILL_ID")
    private String billId = null;	
    @XmlElement(name = "IS_PAPER_PDF_SENT")
    private Long isPaperPdfSent;
    @XmlElement(name = "IS_CANCEL")
    private Integer isCancel;
    @XmlTransient
    private Integer policyStatus;
    
	public Integer getPolicyStatus() {
		return policyStatus;
	}

	public void setPolicyStatus(Integer policyStatus) {
		this.policyStatus = policyStatus;
	}

	public String getBillId() {
		return billId;
	}

	public void setBillId(String billId) {
		this.billId = billId;
	}

	public Date getAcceptTime() {
		return acceptTime;
	}

	public void setAcceptTime(Date acceptTime) {
		this.acceptTime = acceptTime;
	}

	public String getAppNo() {
		return appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public int getApplyStatus() {
		return applyStatus;
	}

	public void setApplyStatus(int applyStatus) {
		this.applyStatus = applyStatus;
	}

	public Long getOrganId() {
		return organId;
	}

	public void setOrganId(Long organId) {
		this.organId = organId;
	}

	public Integer getSellChannel() {
		if (sellChannel == null) {
			sellChannel = 0;
		}
		return sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}

	public String getPartnerApplyId() {
		return partnerApplyId;
	}
	
	public String getLv1Area() {
		return lv1Area;
	}

	public void setLv1Area(String lv1Area) {
		this.lv1Area = lv1Area;
	}

	public String getLv2Area() {
		return lv2Area;
	}

	public void setLv2Area(String lv2Area) {
		this.lv2Area = lv2Area;
	}

	public void setPartnerApplyId(String partnerApplyId) {
		this.partnerApplyId = partnerApplyId;
	}
	
    public Long getApplyId() {
        return applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Long getBaleId() {
        return baleId;
    }

    public void setBaleId(Long baleId) {
        this.baleId = baleId;
    }

    
    public Double getDiscount() {
        return discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    public Integer getChargeType() {
        return chargeType;
    }

    public void setChargeType(Integer chargeType) {
        this.chargeType = chargeType;
    }

    public Integer getChargeYear() {
        return chargeYear;
    }

    public void setChargeYear(Integer chargeYear) {
        this.chargeYear = chargeYear;
    }
    
    public Integer getrHolderInst() {
        return rHolderInst;
    }

    public void setrHolderInst(Integer rHolderInst) {
        this.rHolderInst = rHolderInst;
    }

    
    public Date getValidateDate() {
        return validateDate;
    }

    public void setValidateDate(Date validateDate) {
        this.validateDate = validateDate;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

	public Integer getBonusMode() {
		return bonusMode;
	}

	public void setBonusMode(Integer bonusMode) {
		this.bonusMode = bonusMode;
	}

	public Date getCheckTime() {
		return checkTime;
	}

	public void setCheckTime(Date checkTime) {
		this.checkTime = checkTime;
	}

	public double getPremium() {
		return premium;
	}

	public void setPremium(double premium) {
		this.premium = premium;
	}

	public Integer getAmount() {
		return amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	public Integer getBeneficiaryType() {
		return beneficiaryType;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setBeneficiaryType(Integer beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}

	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Long getBlueId() {
		return blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	public Integer getUnit() {
		return unit;
	}

	public void setUnit(Integer unit) {
		if (unit == null) {
			unit = 1;
		}
		this.unit = unit;
	}

	public int getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(int checkStatus) {
		this.checkStatus = checkStatus;
	}

	public int getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(int payStatus) {
		this.payStatus = payStatus;
	}

	public int getCheckBillStatus() {
		return checkBillStatus;
	}

	public void setCheckBillStatus(int checkBillStatus) {
		this.checkBillStatus = checkBillStatus;
	}

	public Long getLv1AreaId() {
		return lv1AreaId;
	}

	public void setLv1AreaId(Long lv1AreaId) {
		this.lv1AreaId = lv1AreaId;
	}

	public Long getLv2AreaId() {
		return lv2AreaId;
	}

	public void setLv2AreaId(Long lv2AreaId) {
		this.lv2AreaId = lv2AreaId;
	}
	
	public String getBlueName() {
		return blueName;
	}

	public void setBlueName(String blueName) {
		this.blueName = blueName;
	}

	public Long getIsPaperPdfSent() {
		return isPaperPdfSent;
	}

	public void setIsPaperPdfSent(Long isPaperPdfSent) {
		this.isPaperPdfSent = isPaperPdfSent;
	}
	
	public Integer getIsCancel() {
		return isCancel;
	}

	public void setIsCancel(Integer isCancel) {
		this.isCancel = isCancel;
	}

	public ApplyResponseDTO(IspApply apply) {
		super();
		this.setAmount(apply.getAmount());
		this.setApplyId(apply.getApplyId());
		this.setAppNo(apply.getAppNo());
		this.setBaleId(apply.getBaleId());
		this.setBeneficiaryType(apply.getBeneficiaryType());
		IspBlueprint blueprint = CacheContainer.getByIdFromCache(apply.getBlueId(), IspBlueprint.class);
		this.setBlueName(blueprint.getBlueInnerName());
		this.setBlueId(apply.getBlueId());
		this.setBonusMode(apply.getBonusMode());
		this.setChargeType(apply.getChargeType());
		this.setChargeYear(apply.getChargeYear());
		this.setCheckBillStatus(apply.getCheckBillStatus());
		this.setCheckStatus(apply.getCheckStatus());
		this.setCheckTime(apply.getCheckTime());
		this.setCreateTime(apply.getCreateTime());
		this.setDiscount(apply.getDiscount());
		this.setExpirationDate(apply.getExpirationDate());
		
		String lv1Area = null;
		String lv2Area = null;
		IspArea area1 = CacheContainer.getByIdFromCache(apply.getLv1AreaId(), IspArea.class); 
		if (area1 != null) {
			lv1Area = area1.getAreaName();
		}
		IspArea area2 = CacheContainer.getByIdFromCache(apply.getLv2AreaId(), IspArea.class); 
		if (area2 != null) {
			lv2Area = area2.getAreaName();
		}
		this.setLv1Area(lv1Area);
		this.setLv2Area(lv2Area);
		this.setLv1AreaId(apply.getLv1AreaId());
		this.setLv2AreaId(apply.getLv2AreaId());
		this.setOrganId(apply.getOrganId());
		this.setPartnerId(apply.getPartnerId());
		this.setPartnerApplyId(apply.getPartnerApplyId());
		if (apply.getPayStatus() != null) {
			this.setPayStatus(apply.getPayStatus());
		}
		
		this.setPolicyNo(apply.getPolicyNo());
		this.setPremium(apply.getPremium());
		this.setrHolderInst(apply.getRHolderInst());
		this.setSellChannel(apply.getSellChannel());
		this.setUserId(apply.getUserId());
		this.setValidateDate(apply.getValidateDate());
		int applyStatus = this.getStatus(checkStatus, payStatus, checkBillStatus, policyStatus);
		this.setApplyStatus(applyStatus);
	}

	/**
     * 订单状态: 1待支付(核保成功)|6支付成功、承保成功|5支付成功、承保失败|4已退保
     * @param checkStatus
     * @param payStatus
     * @param checkBillStatus
     * @return
     */
    public int getStatus(Integer checkStatus,Integer payStatus,Integer checkBillStatus,Integer policyStatus){
    	if (checkStatus == 1 && (payStatus != 1 && checkBillStatus != 1)) {
    		return 1;
		}
    	
    	if (policyStatus != null && policyStatus == 4) {
    		return 4;
		}
    	
    	if (payStatus == 1 && checkBillStatus == 1) {
    		return 6;
		}
    	
		if (payStatus == 1 && checkBillStatus != 1) {
			return 5;
		}
    	return 0;
    }
	public ApplyResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

}

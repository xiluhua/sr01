package com.taiping.dianshang.service.seq.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.service.seq.SeqService;
import com.taiping.facility.redis.JedisClient2;
import com.taiping.framework.dao.CommonDao;

/**
 * use redis sequence
 * @author xilh
 * @since 20190226
 */

@Component
public class SeqImpl implements SeqService{

	static int AMOUNT = 300000; 
	@Resource
	CommonDao commonDao;
	@Resource
	IspSequenceDao ispSequenceDao;
	
	@Override
	public Long get1(String sequence) {
		Long seq = JedisClient2.incr(sequence);
		if (seq > 1000) {
			System.out.println("--- get sequence from redis: "+sequence+" ---");
			return seq;
		}
		
		String key = "key:"+sequence+":1000";
		if (JedisClient2.isExist(key)) {
			// 并发，走这里
			seq = commonDao.getSequnce(sequence);
			return seq;
		}
		
		// 只会走一次
		System.out.println();
		System.out.println();
		System.out.println("--- "+key+" ---");
		System.out.println();
		System.out.println();
		seq = commonDao.getSequnce(sequence);
		seq = seq + AMOUNT;
		JedisClient2.set(sequence, seq+"");
		return seq;
	}
	
	@Override
	public Long get2(String sequence) {
		Long seq = JedisClient2.incr(sequence);
		if (seq > 1000) {
			System.out.println("--- get sequence from redis: "+sequence+" ---");
			return seq;
		}
		
		String key = "key:"+sequence+":1000";
		if (JedisClient2.isExist(key)) {
			// 并发，走这里
			seq = ispSequenceDao.getSequnce(sequence);
			return seq;
		}
		
		System.out.println();
		System.out.println();
		System.out.println("--- "+key+" ---");
		System.out.println();
		System.out.println();
		// 只会走一次
		seq = ispSequenceDao.getSequnce(sequence);
		seq = seq + AMOUNT;
		JedisClient2.set(sequence, seq+"");
		return seq;
	}
	
	@Override
	public Long get3(String sequence) {
		Long seq = JedisClient2.incr(sequence);
		if (seq > 1000) {
			System.out.println("--- get sequence from redis: "+sequence+" ---");
			return seq;
		}
		
		String key = "key:"+sequence+":1000";
		if (JedisClient2.isExist(key)) {
			// 并发，走这里
			seq = ispSequenceDao.getSequnceWrite(sequence);
			return seq;
		}
		
		System.out.println();
		System.out.println();
		System.out.println("--- "+key+" ---");
		System.out.println();
		System.out.println();
		// 只会走一次
		seq = ispSequenceDao.getSequnceWrite(sequence);
		seq = seq + AMOUNT;
		JedisClient2.set(sequence, seq+"");
		return seq;
	}

	
}

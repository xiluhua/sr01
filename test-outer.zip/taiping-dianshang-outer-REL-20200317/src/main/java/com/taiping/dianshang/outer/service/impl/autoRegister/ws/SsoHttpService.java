package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity.AccountResponse;

public interface SsoHttpService {
	/**
	 * Post方式请求网络数据,
	 * 
	 * @param strUrl          网络地址
	 * @param body            发送的请求体
	 * @param headers         发送的请求头
	 * @param encoding        请求编码方式,默认 UTF-8
	 */
	public AccountResponse httpdoPostBodyHeader(IspApply apply, String strUrl, String body,String busiType);
}

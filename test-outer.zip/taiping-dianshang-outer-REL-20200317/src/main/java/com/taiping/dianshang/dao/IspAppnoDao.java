package com.taiping.dianshang.dao;

import java.util.LinkedList;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.entity.IspAppno;
import com.taiping.dianshang.entity.IspBlueprintFee;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspAppnoDao extends BaseWriteDao<IspAppno, String>{
	@Resource
	private CommonDao commonDao;
	
	@Transactional
	public String getAppno(){
		String appno = null;
		String sql = "SELECT a.appno FROM isp_appno a WHERE ROWNUM = 1 ";
		Object obj = commonDao.getSessionRead().createSQLQuery(sql).uniqueResult();
		
		if (obj != null) {
			appno = (String)obj;
		}
		if (!StringUtils.isEmpty(appno)) {
			super.delete(appno);
		}
		
		return appno;
	}
	
	/**
	 * 批量保存
	 * @param responseTrialDTOList
	 */
	@Transactional
	public void batchSave(LinkedList<IspAppno> appnoList){
		
		 //打开Session
	    Session session = super.getSession();
	    int size = appnoList.size();
	    //循环
	    if (appnoList.size() > 0  ) {
		    for (int i = 1 ; i <= size ; i++ ){
		        //创建User实例
		    	IspAppno ispAppno = appnoList.poll();
		        session.save(ispAppno);
	
		        //每当累加器是50的倍数时，将Session中的数据刷入数据库，并清空Session缓存
		        if (i % 50 == 0){
		            session.flush();
		            session.clear();
		        }
		    }
	    }
	}
}

package com.taiping.dianshang.dao;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IpayPay;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IpayPayDao extends BaseWriteDao<IpayPay, Long>{
	
	@Resource
	private CommonDao commonDao;
	
	public Long save(IpayPay pay){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_IPAY_PAY);
		pay.setPayId(seq);
		
		return super.save(pay);
	}
	
	public IpayPay getPayById(Long payId){
		String hql = "from IpayPay t where t.status = 1 and t.payId = ?";
		Object[] param = new Object[]{payId};
		return commonDao.singleResult(hql, param);
	}
	
	public IpayPay getPayByBillId(Long billId){
		String hql = "from IpayPay t where t.status = 1 and t.billId = ?";
		Object[] param = new Object[]{billId};
		return commonDao.singleResult(hql, param);
	}
	public IpayPay getPayByBillIdWrite(Long billId){
		String hql = "from IpayPay t where t.status = 1 and t.billId = ?";
		return (IpayPay)super.getSession().createQuery(hql).setLong(0,billId).uniqueResult();
	}
	
	public void update(Long payId){
		String sql = "update DS_IPAY_PAY t set t.CONFIRM_STATUS = 1 ,t.NOTIFY_TIME = ? where t.PAY_ID = ?";
		super.getSession().createSQLQuery(sql)
		.setTimestamp(0, new Date())
		.setLong(1, payId)
		.executeUpdate();
	}
}

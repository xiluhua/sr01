package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.SpringTool;

/**
 * 承保短信
 * @author xilh
 * @since 20181122
 */
@Service
public class ShortMsgAndGiftImpl_CBCG_1_FQZ_YYQ_tmall implements ShortMsgService{

	@Override
	public void handle(Map<String, Object> shortMsgParamMap) {
		String services = CacheContainer.getSystemParameterValueNoThrows("1.long.blue.shortMsg.services.tmall");
		// 流水号
        String partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
		LogTool.info(this.getClass(), partnerApplyId +",0, "+ services);
		String[] array  = services.split(",");
		for (int i = 0; i < array.length; i++) {
			String bean = array[i];
			try {
				ShortMsgService shortMsgService = SpringTool.getSpringBean(bean);
				shortMsgService.handle(shortMsgParamMap);
				LogTool.info(this.getClass(), partnerApplyId +","+(i+1)+", "+ bean);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
	}

	@Override
	public TPSmsMessages initMsg(Map<String, Object> shortMsgParamMap,
			String serviceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getContent(Map<String, Object> shortMsgParamMap,
			IspApply apply) {
		// TODO Auto-generated method stub
		return null;
	}
	
}

package com.taiping.dianshang.outer.service.impl.payCallback;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IpayRegisterDao;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.entity.IpayPay;
import com.taiping.dianshang.entity.IpayRegister;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspPayCallback;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.service.PayCallbackService;
import com.taiping.dianshang.outer.service.impl.shortMsg.ShortMsgImpl_ERR_COMMON;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;

/**
 * 合并支付，支付回调
 * @author xilh
 * @since 2017-06-29
 */
@Service
public class PayCallbackMultiImpl extends PayCallbackImpl implements PayCallbackService{

	@Resource
	IpayRegisterDao ipayRegisterDao;
	
	@Resource
	IspApplyDao ispApplyDao;
	
	@Override
	@Transactional
	public void handle(Map<String, Object> paramsMap) {
		String partnerBillId = MapTool.getStringFromMap(paramsMap, ConstantTool.OPERATE_NO);
		LogTool.debug(this.getClass(), "PayCallbackMultiImpl handle,1: "+partnerBillId);
		
		// 得到回调报文数据
		IpayRegister ipayRegister = ipayRegisterDao.getPayRegisterByPartnerBillId(partnerBillId,true);
		if (ipayRegister == null) {
			LogTool.error(this.getClass(), "无对应预支付信息，流水号："+partnerBillId);
			return;
		}
		LogTool.debug(this.getClass(), "PayCallbackMultiImpl handle,2: "+ipayRegister.toString());
		
		List<IspApply> applyList = ipayRegisterDao.getApplyListWrite(partnerBillId);
		if (applyList == null) {
			LogTool.error(this.getClass(), "无对应投保信息，流水号："+partnerBillId);
		}
		LogTool.debug(this.getClass(), "PayCallbackMultiImpl handle,3: "+applyList);
		
		IpayPay pay = ipayPayDao.getPayByBillIdWrite(ipayRegister.getBillId());
		LogTool.debug(this.getClass(), "PayCallbackMultiImpl handle,4: "+pay.toString());
		// 生成回调报文
		String requestXml = super.objectToXml(pay, ipayRegister, partnerBillId, 3);
		
		String url = ipayRegister.getAsynPayResultCallbackUrl();
		// add by xiluhua 20171201 for partners
		IspPayCallback ispPayCallback = CacheContainer.getByIdFromCache(ipayRegister.getPartnerId(), IspPayCallback.class);
		
		// 不是测试单，并且 ispPayCallback is not null
		if (ipayRegister.getPartnerBillId().indexOf("TEST") < 0 && ispPayCallback != null) {
			LogTool.debug(this.getClass(), "partner PayCallbackImpl url: "+ispPayCallback.getProxyUrl());
			url = ispPayCallback.getProxyUrl();
		}
		// -------------- 20171201 over --------------
		LogTool.debug(this.getClass(), "PayCallbackImpl url: "+url);
		// 日志（请求）
		for (IspApply apply : applyList) {
			businesslogService.postBusinessOpelog_1(apply, url + System.getProperty("line.separator")+requestXml, ConstantTool.PAY_CALLBACK, 1, 1);
		}
		
		// add by xiluhua 20171201 mock only
		if (LogTool.isFormal && ipayRegister.getPartnerBillId().indexOf("TEST") > -1) {
			LogTool.debug(this.getClass(), "attention!!! mock only: "+ipayRegister.getPartnerBillId());
			
			// 日志（返回）
			for (IspApply apply : applyList) {
				businesslogService.postBusinessOpelog_2(apply, System.getProperty("line.separator")+ "mock only: "+ipayRegister.getPartnerBillId(), ConstantTool.PAY_CALLBACK, 2, 1);
			}
			return;
		}
		
		// 回调
		String responseXml = super.callback(ipayRegister.getAsynPayResultCallbackUrl(),requestXml,partnerBillId);
		// 报文转对象
		ResponseDTO responseDTO = super.xmlToObject(responseXml, partnerBillId);

		Integer operateStatus = 1;
		boolean isSuccess = (responseDTO != null && responseDTO.getBusiness().isSuccess());
		if (!isSuccess) {
			LogTool.info(this.getClass(), paramsMap.toString());
			operateStatus = 0;
			Integer count = MapTool.getIntegerFromMap(paramsMap, ConstantTool.COUNT);
			if (count != null) {
				count++;
			}else {
				count = 1;
			}
			paramsMap.put(ConstantTool.COUNT, count);
			
			// 回调失败短信通知,模板id:2
			if (count > 30) {
				paramsMap.put(ConstantTool.SHORTMSG_TEMP_ID, 2);
				paramsMap.put(ConstantTool.SERVICE_ID, ShortMsgImpl_ERR_COMMON.class.getSimpleName());
				JedisClient_outer2.rpush(ConstantTool.QUEUE_SHORTMSG, JsonTool.toJson(paramsMap));
			}else {
				// 15分钟后再次执行
				paramsMap.put(ConstantTool.NEXT_CALLBACK_TIME, DateTool.add(new Date(), Calendar.MINUTE, 1));
				super.rpush(paramsMap);
			}
		}
		
		// 日志（返回）
		for (IspApply apply : applyList) {
			businesslogService.postBusinessOpelog_2(apply, responseXml, ConstantTool.PAY_CALLBACK, operateStatus, 1);
		}
		if (isSuccess) {
			// 回调结果更新
			pay.setConfirmStatus(1);
			pay.setNotifyTime(new Date());
			ipayPayDao.update(pay);
		}
	}
}

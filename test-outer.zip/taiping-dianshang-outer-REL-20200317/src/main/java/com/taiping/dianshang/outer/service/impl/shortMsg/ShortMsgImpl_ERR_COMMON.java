package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.ImsAdministratorShortmsgDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.ImsAdministratorShortmsg;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspPartner;
import com.taiping.dianshang.entity.IspShortmsgTemplate;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 失败通知服务
 * @author xilh
 * @since 20170701
 */
@Service
public class ShortMsgImpl_ERR_COMMON extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	ImsAdministratorShortmsgDao imsAdministratorShortmsgDao;
	
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		
		try {
			String wxhome = CacheContainer.getSystemParameterValue(ConstantTool.WXHOME);
			shortMsgParamMap.put("wxhome", wxhome);
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
			// 保单号/流水号等主键
	        String operateNo = MapTool.getStringFromMap(shortMsgParamMap,ConstantTool.OPERATE_NO);
	        String templateId = MapTool.getStringFromMap(shortMsgParamMap,ConstantTool.SHORTMSG_TEMP_ID);
	        
	        // update: rm by xiluhua 20190814
//			Map<Object, ImsAdministratorShortmsg> map = (Map<Object, ImsAdministratorShortmsg>)CacheContainer.getListByIdFromCache(ImsAdministratorShortmsg.class);
//			for (Map.Entry<Object, ImsAdministratorShortmsg> entry : map.entrySet()) {
//	            LogTool.debug(this.getClass(), entry.getKey() + "--->" + entry.getValue());
//	            if (entry.getValue().getService().equalsIgnoreCase(this.getClass().getSimpleName())) {
//	            	if (entry.getValue().getTemplateId().longValue() == Long.valueOf(templateId).longValue()) {
//	            		shortMsgParamMap.put("mobile", entry.getValue().getMobile());
//	            		
//	            		// 2,构造短信内容
//	            		String shortMsgContent = this.getContent(shortMsgParamMap);
//	            		shortMsgParamMap.put("shortMsgContent", shortMsgContent);
//	            		// 3,构造短信对象
//	            		TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
//	            		IspApply apply = new IspApply();
//	            		apply.setPartnerApplyId(operateNo);
//	            		apply.setAppNo(entry.getValue().getMobile());
//	            		//4,启动后台线程，发送短信
//	            		super.send(shortMsg, apply);
//					}
//				}
//			}
			
	        // update: add by xiluhua 20190814
			List<ImsAdministratorShortmsg> list = imsAdministratorShortmsgDao.getAll();
			for (ImsAdministratorShortmsg imsAdministratorShortmsg : list) {
				LogTool.debug(this.getClass(), JSON.toJSONString(imsAdministratorShortmsg));
				
				if (imsAdministratorShortmsg.getService().equalsIgnoreCase(this.getClass().getSimpleName())) {
					if (imsAdministratorShortmsg.getTemplateId().longValue() == Long.valueOf(templateId).longValue()) {
						LogTool.info(this.getClass(), "imsAdministratorShortmsg id: "+imsAdministratorShortmsg.getId());
						shortMsgParamMap.put("mobile", imsAdministratorShortmsg.getMobile());
						
						// 2,构造短信内容
						String shortMsgContent = this.getContent(shortMsgParamMap);
						shortMsgParamMap.put("shortMsgContent", shortMsgContent);
						// 3,构造短信对象
						TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
						IspApply apply = new IspApply();
						apply.setPartnerApplyId(operateNo);
						apply.setAppNo(imsAdministratorShortmsg.getMobile());
						//4,启动后台线程，发送短信
						super.send(shortMsg, apply);
					}
				}
			}
			// <== over 20190814 
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	/**
	 * 构造短信内容
	 * update by xiluhua 20180224 
	 * add 'partner'
	 */
	public String getContent(Map<String, Object> shortMsgParamMap){
		String content = "";			//短信内容
		String operateNo = MapTool.getStringFromMap(shortMsgParamMap,ConstantTool.OPERATE_NO);
		String templateId = MapTool.getStringFromMap(shortMsgParamMap,ConstantTool.SHORTMSG_TEMP_ID);
		String partnerId = MapTool.getStringFromMap(shortMsgParamMap,ConstantTool.PARTNER_ID);
		IspShortmsgTemplate shortmsgTemplate = CacheContainer.getShortmsgTemplateFromCache(Long.valueOf(templateId),Integer.valueOf(ConstantTool.STR_2), IspShortmsgTemplate.class);
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put(ConstantTool.OPERATE_NO, operateNo);
		if (!StringUtils.isEmpty(partnerId)) {
			IspPartner partner = CacheContainer.getByIdFromCache(Long.valueOf(partnerId), IspPartner.class);
			context.put("partner", partner);
		}
		
		content = TemplateToolV1218.fill(context, shortmsgTemplate.getRequestXmlTemplate()); // 填充模板  得到短信内容
		
		return content;
	}
}

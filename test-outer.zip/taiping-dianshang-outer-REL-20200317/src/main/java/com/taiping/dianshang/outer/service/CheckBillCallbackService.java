package com.taiping.dianshang.outer.service;

public interface CheckBillCallbackService extends OuterService{

}

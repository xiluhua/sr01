package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * IspBlueprintFee entity. 
 */
@Entity
@Table(name = "CP_ISP_BLUEPRINT_FEE")
public class IspBlueprintFee implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	
	// Fields

	private Long feeId;
	
	private Integer age;
	private Integer gender;
	private Integer chargeType;
	private Integer chargeYear;
	private Double amount;
	private Double premium;
	private String blueCode;
	private Integer baleNo;
	private Long blueId;
	private Long baleId;
	private Double discount;
	private Long coverPeriod;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;

	// Constructors

	/** default constructor */
	public IspBlueprintFee() {
	}

	/** full constructor */
	public IspBlueprintFee(Long feeId,Integer age, Integer gender, Integer chargeType,
			Integer chargeYear, Double amount, Double premium, String blueCode,
			Integer baleNo, Long blueId, Long baleId, Double discount,
			Long coverPeriod) {
		this.feeId = feeId;
		this.age = age;
		this.gender = gender;
		this.chargeType = chargeType;
		this.chargeYear = chargeYear;
		this.amount = amount;
		this.premium = premium;
		this.blueCode = blueCode;
		this.baleNo = baleNo;
		this.blueId = blueId;
		this.baleId = baleId;
		this.discount = discount;
		this.coverPeriod = coverPeriod;
	}

	// Property accessors

	@Id
	@Column(name="FEE_ID")
	public Long getFeeId() {
		return feeId;
	}

	public void setFeeId(Long feeId) {
		this.feeId = feeId;
	}
	

	@Column(name = "AGE", precision = 3, scale = 0)
	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	@Column(name = "GENDER", precision = 3, scale = 0)
	public Integer getGender() {
		return this.gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	@Column(name = "CHARGE_TYPE", precision = 3, scale = 0)
	public Integer getChargeType() {
		return this.chargeType;
	}

	public void setChargeType(Integer chargeType) {
		this.chargeType = chargeType;
	}

	@Column(name = "CHARGE_YEAR", precision = 3, scale = 0)
	public Integer getChargeYear() {
		return this.chargeYear;
	}

	public void setChargeYear(Integer chargeYear) {
		this.chargeYear = chargeYear;
	}

	@Column(name = "AMOUNT", precision = 12)
	public Double getAmount() {
		return this.amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Column(name = "PREMIUM", precision = 12)
	public Double getPremium() {
		return this.premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	@Column(name = "BLUE_CODE", length = 20)
	public String getBlueCode() {
		return this.blueCode;
	}

	public void setBlueCode(String blueCode) {
		this.blueCode = blueCode;
	}

	@Column(name = "BALE_NO", precision = 4, scale = 0)
	public Integer getBaleNo() {
		return this.baleNo;
	}

	public void setBaleNo(Integer baleNo) {
		this.baleNo = baleNo;
	}

	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Column(name = "BALE_ID", precision = 10, scale = 0)
	public Long getBaleId() {
		return this.baleId;
	}

	public void setBaleId(Long baleId) {
		this.baleId = baleId;
	}

	@Column(name = "DISCOUNT", precision = 7, scale = 6)
	public Double getDiscount() {
		return this.discount;
	}

	public void setDiscount(Double discount) {
		this.discount = discount;
	}

	@Column(name = "COVER_PERIOD", precision = 10, scale = 0)
	public Long getCoverPeriod() {
		return this.coverPeriod;
	}

	public void setCoverPeriod(Long coverPeriod) {
		this.coverPeriod = coverPeriod;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}
	
}
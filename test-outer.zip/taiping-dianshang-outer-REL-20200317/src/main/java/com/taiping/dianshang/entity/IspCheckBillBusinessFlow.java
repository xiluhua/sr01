package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspCheckBusinessFlow   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_CHECKBILL_BUSINESS_FLOW")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspCheckBillBusinessFlow implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4496191897468182036L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="BLUE_ID")
	private Long blueId;
	@Column(name="PARTNER_ID")
	private Integer partnerId;
	@Column(name="SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name="STATUS")
	private Integer status;
//	@Column(name="INNER_PAY_SERVICE")
	@Transient
	private String innerPayService;					// 内支付订单生成接口
	@Column(name="VALIDATOR_SERVICE")
	private String validatorService;				// 校验出单请求接口
	@Column(name="PARTNER_BUSI_PROPERTY_SERVICE")
	private String partnerBusiPropertyService;		// 第三方业务属性校验接口
	@Column(name="PERSIST_SERVICE")
	private String persistService;					// 出单持久化接口
	@Column(name="CHECKBILL_CORE_SERVICE")
	private String checkBillCoreService;			// 出单接口（到核心）
	@Column(name="SEND_EMAIL_SERVICE")
	private String sendEmailService;				// 发送邮件接口
	@Column(name="SEND_SHORTMSG_SERVICE")
	private String sendShortMsgService;				// 发送短信接口
	@Column(name="SEND_GIFT_SCORE_SERVICE")
	private String sendGiftScoreService;			// 投保礼积分赠送接口
	
	public IspCheckBillBusinessFlow() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Long getBlueId() {
		return blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	public Integer getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Integer partnerId) {
		this.partnerId = partnerId;
	}

	public Integer getSellChannel() {
		return sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}

	public String getPersistService() {
		return persistService;
	}

	public void setPersistService(String persistService) {
		this.persistService = persistService;
	}

	public String getCheckBillCoreService() {
		return checkBillCoreService;
	}


	public void setCheckBillCoreService(String checkBillCoreService) {
		this.checkBillCoreService = checkBillCoreService;
	}

	public String getValidatorService() {
		return validatorService;
	}

	public void setValidatorService(String validatorService) {
		this.validatorService = validatorService;
	}

	public String getPartnerBusiPropertyService() {
		return partnerBusiPropertyService;
	}

	public void setPartnerBusiPropertyService(String partnerBusiPropertyService) {
		this.partnerBusiPropertyService = partnerBusiPropertyService;
	}

	public String getInnerPayService() {
		return innerPayService;
	}

	public void setInnerPayService(String innerPayService) {
		this.innerPayService = innerPayService;
	}

	public String getSendEmailService() {
		return sendEmailService;
	}

	public void setSendEmailService(String sendEmailService) {
		this.sendEmailService = sendEmailService;
	}

	public String getSendShortMsgService() {
		return sendShortMsgService;
	}

	public void setSendShortMsgService(String sendShortMsgService) {
		this.sendShortMsgService = sendShortMsgService;
	}

	public String getSendGiftScoreService() {
		return sendGiftScoreService;
	}

	public void setSendGiftScoreService(String sendGiftScoreService) {
		this.sendGiftScoreService = sendGiftScoreService;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	


}





package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for userResponse complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="userResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="returnCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="returnFlag" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="returnMessage" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userResponse", propOrder = { "requestID", "returnCode",
		"returnFlag", "returnMessage" })
public class UserResponse {

	protected String requestID;
	protected String returnCode;
	protected boolean returnFlag;
	protected String returnMessage;

	/**
	 * Gets the value of the requestID property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRequestID() {
		return requestID;
	}

	/**
	 * Sets the value of the requestID property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRequestID(String value) {
		this.requestID = value;
	}

	/**
	 * Gets the value of the returnCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getReturnCode() {
		return returnCode;
	}

	/**
	 * Sets the value of the returnCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReturnCode(String value) {
		this.returnCode = value;
	}

	/**
	 * Gets the value of the returnFlag property.
	 * 
	 */
	public boolean getReturnFlag() {
		return returnFlag;
	}

	/**
	 * Sets the value of the returnFlag property.
	 * 
	 */
	public void setReturnFlag(boolean value) {
		this.returnFlag = value;
	}

	/**
	 * Gets the value of the returnMessage property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getReturnMessage() {
		return returnMessage;
	}

	/**
	 * Sets the value of the returnMessage property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setReturnMessage(String value) {
		this.returnMessage = value;
	}

	@Override
	public String toString() {
		return "UserResponse [requestID=" + requestID + ", returnCode="
				+ returnCode + ", returnFlag=" + returnFlag
				+ ", returnMessage=" + returnMessage + "]";
	}

}

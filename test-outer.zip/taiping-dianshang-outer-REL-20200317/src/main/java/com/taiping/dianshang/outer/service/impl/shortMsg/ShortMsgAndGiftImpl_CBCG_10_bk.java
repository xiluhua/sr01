package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.entity.IspShortmsgTemplate;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.GiftScoreService;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.dianshang.outer.service.impl.autoRegister.UniformUserIdentityService;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.RegisterResult;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 网电业务承保短信+积分发送服务
 * @author xilh
 * @since 20170606
 */

@Service
public class ShortMsgAndGiftImpl_CBCG_10_bk extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	@Resource(name="uniformUserIdentityImpl")
	UniformUserIdentityService uniformUserIdentityService;
	@Resource(name="giftScoreImpl_CBCG_mobile_1_new")
	GiftScoreService giftScoreService;
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		String partnerApplyId = null;
		try {
			IspBlueprint blueprint = null;
			String wxhome = CacheContainer.getSystemParameterValue(ConstantTool.WXHOME);
			shortMsgParamMap.put("wxhome", wxhome);
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
			// 保单号
	        partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
	        
	        LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
	        
	        IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply != null) {
				blueprint = CacheContainer.getByIdFromCacheThrows(apply.getBlueId(), IspBlueprint.class);
			}else {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			shortMsgParamMap.put("mobile", apply.getHolder().getMobile());
			shortMsgParamMap.put("blueName", blueprint.getBlueInnerName());
			apply.setInsuranceType(blueprint.getInsuranceType());
			
			String uid = uniformUserIdentityService.queryIsUserExist(apply, apply.getHolder().getMobile());
			// 本来就已注册
			if (!StringUtils.isEmpty(uid)) {
				shortMsgParamMap.put("isNewReg", ConstantTool.STR_0);
			}else {
				// 新注册
				RegisterResult registerResult = uniformUserIdentityService.registerNew(apply, apply.getHolder().getMobile());
//				RegisterResult registerResult = new RegisterResult();
//				registerResult.setPassword("123456");
//				registerResult.setUserName("test");
				shortMsgParamMap.put("isNewReg", ConstantTool.STR_1);
				shortMsgParamMap.put("regResult", registerResult);
				LogTool.debug(this.getClass(), registerResult.toString());
			}
			
			// 2,构造短信内容
			String shortMsgContent = this.getContent(shortMsgParamMap,apply);
			LogTool.debug(this.getClass(), "shortMsgContent："+shortMsgContent);
			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
			// 3,构造短信对象
			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);

			// 测试环境不支持实际执行发送，所以直接置为发送成功: "OK"
			String result = ConstantTool.SHOR_MSG_SEND_SUCCESS;
			// 4,生产环境，发送短信
			if (!super.isUat()) {
				result = super.send(shortMsg, apply);
			}
			LogTool.warn(this.getClass(), apply.getPartnerApplyId()+": "+result);
			
			if (result.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
				IspSendHistory ispSendHistory = ispSendHistoryDao.get("applyId", apply.getApplyId());
				if (ispSendHistory == null) {
					ispSendHistory = new IspSendHistory();
					ispSendHistory.setApplyId(apply.getApplyId());
					ispSendHistory.setIsShortmsgSend(1);
					ispSendHistoryDao.save(ispSendHistory);
				}else {
					ispSendHistory.setIsShortmsgSend(1);
					ispSendHistoryDao.update(ispSendHistory);
				}
			}
			
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally{
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("operateNo", partnerApplyId);//流水号
			giftScoreService.handle(map);
		}
	}
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply){
		String content = "";			//短信内容
		String holderSex = "";
		String holderName = "";
		String partnerApplyId = apply.getPartnerApplyId();
		IspCustomer holder = apply.getHolder(); 
		holderName = holder.getCustName();
		if (holder.getGender() == 1) {
			holderSex = "先生";
		} else {
			holderSex= "女士";
		}
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put("holderName", holderName);
		context.put("holderSex", holderSex);
		context.put("blueName", MapTool.getStringFromMap(shortMsgParamMap, "blueName"));
		context.put("partnerApplyId", partnerApplyId);
		context.put("polno", apply.getPolicyNo());
		context.put("userName", holder.getCustName());
		context.put("wxhome", shortMsgParamMap.get("wxhome"));
		context.put("validateDate", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK));
		context.put("expirationDate", DateTool.convertDataToString(apply.getExpirationDate(), DateTool.DATE_MASK));
		context.put("isNewReg", shortMsgParamMap.get("isNewReg"));
		context.put("regResult", shortMsgParamMap.get("regResult"));
		
		LogTool.debug(this.getClass(), "",true);
		IspShortmsgTemplate shortmsgTemplate = CacheContainer.getShortmsgTemplateFromCache(ConstantTool.STR_1,Integer.valueOf(ConstantTool.STR_2), IspShortmsgTemplate.class);
		LogTool.debug(this.getClass(), shortmsgTemplate.toString());
		
		content = TemplateToolV1218.fill(context, shortmsgTemplate.getRequestXmlTemplate()); // 填充模板  得到短信内容
		LogTool.debug(this.getClass(), "content: "+content);
		
		return content;
	}
}

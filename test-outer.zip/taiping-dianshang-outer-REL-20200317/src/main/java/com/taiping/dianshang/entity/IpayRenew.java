package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * IpayPay entity. 
 */
@Entity
@Table(name = "DS_IPAY_RENEW")
public class IpayRenew implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	private Long id;
	private Long applyId;
	private String renewBankCode;	// 续期支付网关
	private String renewBankAccount;// 续期账户
	private String renewAccountType;// 续期账户类型

	// Constructors

	/** default constructor */
	public IpayRenew() {
	}
	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	
	@Column(name = "APPLY_ID", length = 10)
	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Column(name = "RENEW_BANK_CODE")
	public String getRenewBankCode() {
		return renewBankCode;
	}


	public void setRenewBankCode(String renewBankCode) {
		this.renewBankCode = renewBankCode;
	}

	@Column(name = "RENEW_BANK_ACCOUNT")
	public String getRenewBankAccount() {
		return renewBankAccount;
	}


	public void setRenewBankAccount(String renewBankAccount) {
		this.renewBankAccount = renewBankAccount;
	}

	@Column(name = "RENEW_ACCOUNT_TYPE")
	public String getRenewAccountType() {
		return renewAccountType;
	}


	public void setRenewAccountType(String renewAccountType) {
		this.renewAccountType = renewAccountType;
	}

}
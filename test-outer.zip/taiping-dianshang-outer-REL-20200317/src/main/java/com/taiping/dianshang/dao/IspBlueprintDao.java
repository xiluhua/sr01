package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBlueprintDao extends BaseWriteDao<IspBlueprint, Long> implements CacheDaoService{
	
//	@Resource
//	private SynBlueprintCoreDao synBlueprintCoreDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	
	public Map<Object,String> getAllInMap(){
		List<IspBlueprint> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspBlueprint blueprint = list.get(i);
				String key = KeyTool.get(IspBlueprint.class, blueprint.getBlueId());
				map.put(key,JsonTool.toJson(blueprint));
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspBlueprint> getAll(){
		String hql = "from IspBlueprint t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}

//	public IspBlueprint getBlueprintCore(String blueCode){
//		IspBlueprint ispBlueprint = null;
//		Map<String, Object> map = synBlueprintCoreDao.queryForMap(ConstantSql.SQL_SYN_BLUEPRINT, blueCode);
//		
//		if (map.size() > 0) {
//			ispBlueprint = new IspBlueprint();
//			ispBlueprint.setBlueCode(blueCode);
//			ispBlueprint.setCoreBlueId(MapTool.getLongFromMap(map, "BLUE_ID"));
//			ispBlueprint.setBlueCoreName(MapTool.getStringFromMap(map, "BLUE_NAME"));
//		}
//		return ispBlueprint;
//	}
	
//	public IspBlueprint synBlueprint(BlueprintDTO blueprint)throws Exception{
//		IspBlueprint ispBlueprint = this.getBlueprintCore(blueprint.getBlueCode());
//		
//		if (ispBlueprint != null) {
//			Long seq = this.getUniqueSequence();
//			ispBlueprint.setBlueInnerName(ispBlueprint.getBlueCoreName());
//			ispBlueprint.setBlueId(seq);
//			ispBlueprint.setSellChannel(1);	//1寿险|2养老险|3财险
//			ispBlueprint.setStatus(1);		//1有效|其他无效
//			ispBlueprint.setDiscount(1d);	//默认这款为1.0
//			ispBlueprint.setBlueFeeType(Integer.valueOf(blueprint.getBlueFeeType()));		//0赠险|1付费现
//			ispBlueprint.setInsuranceType(Integer.valueOf(blueprint.getInsuranceType()));	//保险分类 1.意外险|2.重疾险|3.分红险|4.万能险。费率映射策略
//			ispBlueprint.setCreateTime(new Date());
//			this.save(ispBlueprint);
//		}
//		 
//		return ispBlueprint;
//	}
	
	private Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_BLUEPRINT);
			IspBlueprint ispBlueprint = super.get("blueId", seq);
			
			if (ispBlueprint == null) {
				return seq;
			}
		}
	}

	public static void main(String[] args) {
		String sql = "select t.blue_id,t.blue_code,t.blue_name from DM_BLUEPRINT@newbizdb.tplife.com t where t.blue_code=?";
		System.out.println(sql.toUpperCase());
	}
}
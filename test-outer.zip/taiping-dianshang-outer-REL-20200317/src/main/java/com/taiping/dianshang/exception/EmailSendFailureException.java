package com.taiping.dianshang.exception;


public class EmailSendFailureException extends Exception{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public EmailSendFailureException(String msg){
		super(msg);
	}
}


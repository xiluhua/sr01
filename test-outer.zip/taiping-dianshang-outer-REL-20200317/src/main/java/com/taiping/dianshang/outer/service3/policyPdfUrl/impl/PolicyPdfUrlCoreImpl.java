package com.taiping.dianshang.outer.service3.policyPdfUrl.impl;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.ResponsePolicyPdfUrlDTO;
import com.taiping.dianshang.outer.service3.policyPdfUrl.PolicyPdfUrlCoreService;
import com.taiping.dianshang.outer.service3.url.UrlService;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.facility.tool.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.dom4j.Document;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Li.Wei  2019/9/3 11:06 AM
 * @version 1.0
 * @since 亚太电子保单下载
 */
@Service
public class PolicyPdfUrlCoreImpl implements PolicyPdfUrlCoreService {
    @Resource
    private UrlService urlService;
    @Resource
    private HttpclientImpl httpclientImpl;

    @Override
    public void handleCore(Busi busi) throws Exception {
        String requestXml = objectToXml(busi,null);
        // 发送核心报文
        Date begin = new Date();
        Map<String, String> paramsMap = new HashMap<String, String>();
        paramsMap.put("packet", requestXml);

        String responseXml = this.sendMsgToCore(null, null, paramsMap);

        Date end = new Date();
        long inteval = end.getTime() - begin.getTime();
        LogTool.info(this.getClass(), "=============================================================");
        LogTool.info(this.getClass(), "核心处理时间：" + inteval + "ms");
        LogTool.info(this.getClass(), busi.getApply().getPartnerApplyId()+", responseXml:\n" + responseXml);

        this.xmlToObject(busi, responseXml);
    }

    @Override
    public String objectToXml(Busi busi, IspRmi rmi) {
        IspApply apply = busi.getApply();

        VelocityContext context = new VelocityContext();
        context.put("dateTools", new DateTool());
        context.put("apply", apply);
        context.put("transTime", new Date());

        String path = this.getClass().getResource("/template/pdfDownload/pdfUrlDownlaod.xml").getPath();
        String requestXml = IOTool.readFile(path, "GBK"); // 请确认编码方式
        requestXml = TemplateToolV1218.fill(context, requestXml);
        LogTool.info(this.getClass(), "电子保单下载报文: " + requestXml);
        return requestXml;
    }

    @Override
    public String sendMsgToCore(IspRmi rmi, IspHttpclientParams httpclientParams, Map<String, String> paramsMap) throws Exception {
        String coreUrl = urlService.dsCoreUrl();
        String requestXml = paramsMap.get("packet");
        String responseXml = httpclientImpl.post(coreUrl, requestXml, "UTF-8");
        return Base64Tool.decode(responseXml, "UTF-8");
    }

    @Override
    public void xmlToObject(Busi busi, String responseXml) {
        ResponsePolicyPdfUrlDTO responseDTO = (ResponsePolicyPdfUrlDTO)busi.getResponseDTO();
        try {
            if (StringUtils.isEmpty(responseXml)) {
                responseDTO.getBusiness().setReturnInfo("返回报文接口返回为空");
                return;
            }
            Document responseDoc = XmlTool.bulidXmlDoc(responseXml); // 报文对象
            String policyPdfUrl = responseDoc.selectSingleNode("/RESPONSE/MAIN/POLICY_URL") == null?"":responseDoc.selectSingleNode("/RESPONSE/MAIN/POLICY_URL").getText();
            if (!StringUtils.isEmpty(policyPdfUrl)){
                responseDTO.getBusiness().setSuccess(true);
                responseDTO.getBusiness().setReturnCode(ConstantTool.CoreReturnSuccess);
                responseDTO.getMain().setPolicyUrl(policyPdfUrl);
            }else {
                responseDTO.getBusiness().setSuccess(false);
                responseDTO.getBusiness().setReturnCode(ConstantTool.CoreReturnFailed);
                responseDTO.getBusiness().setReturnInfo("电子保单下载报文为空！");
            }
            busi.setResponseDTO(responseDTO);
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
        }
    }

    @Override
    public void updateAfterCoreBusiness(Busi busi) throws Exception {

    }
}

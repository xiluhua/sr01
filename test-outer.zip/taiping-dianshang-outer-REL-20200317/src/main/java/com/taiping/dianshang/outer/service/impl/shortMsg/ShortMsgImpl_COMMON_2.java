package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspShortmsgTemplate;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 发送短信服务
 * @author lh
 * @since 20190109
 */
@Service
public class ShortMsgImpl_COMMON_2 extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		
		try {
			LogTool.debug(this.getClass(), "shortMsgParamMap: "+shortMsgParamMap.toString());
			
			String wxhome = CacheContainer.getSystemParameterValue(ConstantTool.WXHOME);
			shortMsgParamMap.put("wxhome", wxhome);
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
			String mobile = MapTool.getStringFromMap(shortMsgParamMap, "mobile");
	        IspApply apply = new IspApply(mobile);
					
			// 2,构造短信内容
			String shortMsgContent = this.getContent(shortMsgParamMap);
			LogTool.debug(this.getClass(), "shortMsgContent："+shortMsgContent);
			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
			// 3,构造短信对象
			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
					
			String key = CacheContainer.getSystemParameterValueNoThrows(ConstantTool.SYS_KEY_1);
			LogTool.info(this.getClass(), "attention!!! key is not null, don't send shortmsg!");
			
			// 为空才发送
			if (StringUtils.isEmpty(key)) {
				//4,启动后台线程，发送短信
				super.send(shortMsg, apply);
			}
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap){
		String content = "";			//短信内容
		Object templateId = shortMsgParamMap.get(ConstantTool.TEMPLATE_ID);
		Integer type = MapTool.getIntegerFromMap(shortMsgParamMap, ConstantTool.TYPE);
		
		IspShortmsgTemplate shortmsgTemplate = CacheContainer.getShortmsgTemplateFromCache(templateId, type, IspShortmsgTemplate.class);
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put("params", shortMsgParamMap);
		content = TemplateToolV1218.fill(context, shortmsgTemplate.getRequestXmlTemplate()); // 填充模板  得到短信内容
		
		return content;
	}
}

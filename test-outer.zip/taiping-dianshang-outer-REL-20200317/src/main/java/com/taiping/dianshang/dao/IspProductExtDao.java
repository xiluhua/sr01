package com.taiping.dianshang.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantSql;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBale;
import com.taiping.dianshang.entity.IspBaleProductExt;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspProduct;
import com.taiping.dianshang.entity.IspProductExt;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspProductExtDao extends BaseWriteDao<IspProductExt, Long>{

	@Resource
	private CommonDao commonDao;
//	@Resource
//	private SynBlueprintCoreDao synBlueprintCoreDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	@Resource
	private IspBaleProductExtDao ispBaleProductExtDao;
	@Resource
	private IspProductDao ispProductDao;
	@Resource
	private IspBaleDao ispBaleDao;
	
	@Transactional
	public List<IspProductExt> getProductExt(Long baleId){
		List<IspProductExt> productExtList = null;
		StringBuffer sqlBuffer = new StringBuffer();
		sqlBuffer.append("select b.PRODUCT_EXT_ID, ");
		sqlBuffer.append("		 b.PRODUCT_ID, ");
		sqlBuffer.append("		 b.PRODUCT_ORDER, ");
		sqlBuffer.append("		 b.MA, ");
		sqlBuffer.append("		 b.UNIT, ");
		sqlBuffer.append("		 b.AMOUNT, ");
		sqlBuffer.append("		 b.PREMIUM, ");
		sqlBuffer.append("		 b.COVER_LEVEL, ");
		sqlBuffer.append("		 b.COVER_TYPE, ");
		sqlBuffer.append("		 b.COVER_YEAR, ");
		sqlBuffer.append("		 b.CHARGE_FREQ, ");
		sqlBuffer.append("		 b.CHARGE_TYPE, ");
		sqlBuffer.append("		 b.CHARGE_YEAR, ");
		sqlBuffer.append("		 b.DRAW_FREQ, ");
		sqlBuffer.append("		 b.DRAW_FST_TYPE, ");
		sqlBuffer.append("		 b.DRAW_FST_YEAR, ");
		sqlBuffer.append("		 b.DRAW_LST_TYPE, ");
		sqlBuffer.append("		 b.DRAW_LST_YEAR, ");
		sqlBuffer.append("		 b.DRAW_ENSURE ");
		sqlBuffer.append(" from isp_bale_product_ext a,isp_product_ext b ");
		sqlBuffer.append(" where a.PRODUCT_EXT_ID=b.PRODUCT_EXT_ID ");
		sqlBuffer.append(" and a.BALE_ID=?  ");  // sql查询语句
		
		LogTool.debug(this.getClass(), "sql:"+sqlBuffer.toString());
		LogTool.debug(this.getClass(), "==============================================");
		LogTool.debug(this.getClass(), "baleId:"+baleId);
		
		Query query = commonDao.getSessionWrite().createSQLQuery(sqlBuffer.toString());
		query.setParameter(0, baleId);
		query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> list = query.list();

        if (list != null && list.size() > 0) {
        	productExtList = new ArrayList<IspProductExt>();
            for (int i = 0; i < list.size(); i++) {
            	Map<String, Object> map = list.get(i);
            	IspProductExt productExt = this.buildProductExtObject(map);
            	productExtList.add(productExt);
			}
        }
        return productExtList;
	}

	/**
	 * 根据查询结果map，构造产品实例信息
	 * @param map 根据查询结果map
	 * @return 产品实例信息
	 */
	private IspProductExt buildProductExtObject(Map<String, Object> map) {
		// 定义局部变量
		IspProductExt productInstance = null;  // 产品实例信息 
		
		// 设置对象属性值
		productInstance = new IspProductExt();
		productInstance.setProductExtId(MapTool.getLongFromMap(map, "PRODUCT_EXT_ID"));
		productInstance.setProductId(MapTool.getLongFromMap(map, "PRODUCT_ID"));
		productInstance.setProductOrder(MapTool.getStringFromMap(map, "PRODUCT_ORDER"));
		productInstance.setMa(MapTool.getLongFromMap(map, "MA"));
		productInstance.setUnit(MapTool.getLongFromMap(map, "UNIT"));
		productInstance.setAmount(MapTool.getIntegerFromMap(map, "AMOUNT"));
		productInstance.setPremium(MapTool.getDoubleFromMap(map, "PREMIUM"));
		productInstance.setCoverLevel(MapTool.getLongFromMap(map, "COVER_LEVEL"));
		productInstance.setCoverType(MapTool.getLongFromMap(map, "COVER_TYPE"));
		productInstance.setCoverYear(MapTool.getLongFromMap(map, "COVER_YEAR"));
		productInstance.setChargeFreq(MapTool.getIntegerFromMap(map, "CHARGE_FREQ"));
		productInstance.setChargeType(MapTool.getIntegerFromMap(map, "CHARGE_TYPE"));
		productInstance.setChargeYear(MapTool.getLongFromMap(map, "CHARGE_YEAR"));
		productInstance.setDrawFreq(MapTool.getLongFromMap(map, "DRAW_FREQ"));
		productInstance.setDrawFstType(MapTool.getLongFromMap(map, "DRAW_FST_TYPE"));
		productInstance.setDrawFstYear(MapTool.getLongFromMap(map, "DRAW_FST_YEAR"));
		productInstance.setDrawLstType(MapTool.getLongFromMap(map, "DRAW_LST_TYPE"));
		productInstance.setDrawLstYear(MapTool.getLongFromMap(map, "DRAW_LST_YEAR"));
		productInstance.setDrawEnsure(MapTool.getLongFromMap(map, "DRAW_ENSURE"));
		
		// 返回业务对象
		return productInstance;
	}
	
//	public List<IspProductExt> synProductExt(IspBlueprint blueprint,List<IspBale> baleList) throws Exception{
//		// 1、定义局部变量
//		List<IspProductExt> mainProductExtList = new ArrayList<IspProductExt>(); //计划列表的主险实例列表
//		 
//		//插入产品实例信息
//		Long coreBlueId = blueprint.getCoreBlueId();
//		Long coreBaleId = null;
//		List<IspProductExt> coreProductExtList = null;
//		HashSet prods = new HashSet();  //需要同步的产品列表 hashset 不允许重复
//		for(IspBale bale:baleList){
//			coreBaleId = bale.getCoreBaleId();
//			coreProductExtList = this.getCoreBalePlans(coreBlueId, coreBaleId);	 
//			if(coreProductExtList != null && coreProductExtList.size()>0){
//				for(IspProductExt productExt:coreProductExtList){
//					this.save(productExt);
//					prods.add(productExt.getProductId());  //最后统一更新产品
//					int ma = productExt.getMa().intValue();
//					if(ma == 1){
//						mainProductExtList.add(productExt);
//						Integer amount = productExt.getAmount();
//						if(amount != null){ //设置计划金额
//							bale.setAmount(amount);
//						}
//						bale.setChargeYear(productExt.getChargeYear());//设置计划交费年期
//					}
//				}
//			}
//			 
//			//插入 计划实例关系 数据 
//			Long baleId = bale.getBaleId();
//			Long productExtId = null;
//			for(IspProductExt productExt:coreProductExtList){
//				productExtId = productExt.getProductExtId();
//				IspBaleProductExt baleProductExt = new IspBaleProductExt();
//				baleProductExt.setId(ispSequenceDao.getSequnce(ConstantTool.SEQ_ISP_BALE_PRODUCT_EXT));
//				baleProductExt.setBaleId(baleId);
//				baleProductExt.setProductExtId(productExtId);
//				baleProductExt.setCreateTime(new Date());
//				ispBaleProductExtDao.save(baleProductExt);
//			 }
//		 }
//		
//		 //更新 计划的金额和交费年期
//		this.updateBaleListAmountAndChargeYear(baleList);
//		
//	    //同步产品表
//	    Iterator it = prods.iterator();
//		while(it.hasNext()){
//			Long productId = (Long)it.next(); //产品ID			
//			//产品不存在 需要插入产品表
//			IspProduct product = ispProductDao.getIspProductById(productId);
//			if(product == null){
//				product = ispProductDao.getProductLife(productId);
//				if(product != null){
//					ispProductDao.save(product);
//				 }
//			 }
//		}
//			
//		//3、返回
//		return mainProductExtList;
//	}

	/**
    * 根据方案ID 和计划ID 获得核心产品实例列表
    * @param blue_id
    * @param bale_id
    * @return
    */
//	public List<IspProductExt> getCoreBalePlans(Long coreBlueId,Long coreBaleId){
//	    //1、定义局部变量
//	    List<IspProductExt> productExtList = new ArrayList<IspProductExt>();
//
//	    Object[] args = new Object[]{coreBlueId,coreBaleId};
//	    List<Map<String, Object>> planList = synBlueprintCoreDao.queryForListMap(ConstantSql.SQL_SYN_PRODUCT_EXT, args);	
//	    IspProductExt  productExt = null;
//	    if(planList.size() > 0){
//		    for(Map corePlan:planList){
//			    productExt = new IspProductExt();
//			    Long productExtId = this.getUniqueSequence();
//			    productExt.setProductExtId(productExtId);
//			    productExt.setProductId(MapTool.getLongFromMap(corePlan, "plan_id"));
//			    String ma = MapTool.getStringFromMap(corePlan, "plan_seq");
//			    productExt.setProductOrder(ma);
//			    if("1".equals(ma))
//				    productExt.setMa(1l);
//			    else
//		     		productExt.setMa(2l);
//			    productExt.setUnit(MapTool.getLongFromMap(corePlan, "UNIT"));
//			    productExt.setAmount(MapTool.getIntegerFromMap(corePlan, "AMOUNT"));
//				productExt.setPremium(MapTool.getDoubleFromMap(corePlan, "PREMIUM"));
//				productExt.setCoverLevel(MapTool.getLongFromMap(corePlan, "COVER_LEVEL"));
//				productExt.setCoverType(MapTool.getLongFromMap(corePlan, "COVER_TYPE"));
//				productExt.setCoverYear(MapTool.getLongFromMap(corePlan, "COVER_YEAR"));
//				productExt.setChargeFreq(MapTool.getIntegerFromMap(corePlan, "CHARGE_FREQ"));
//				productExt.setChargeType(MapTool.getIntegerFromMap(corePlan, "CHARGE_TYPE"));
//				productExt.setChargeYear(MapTool.getLongFromMap(corePlan, "CHARGE_YEAR"));
//				productExt.setDrawFreq(MapTool.getLongFromMap(corePlan, "DRAW_FREQ"));
//				productExt.setDrawFstType(MapTool.getLongFromMap(corePlan, "DRAW_FST_TYPE"));
//				productExt.setDrawFstYear(MapTool.getLongFromMap(corePlan, "DRAW_FST_YEAR"));
//				productExt.setDrawLstType(MapTool.getLongFromMap(corePlan, "DRAW_LST_TYPE"));	
//				productExt.setDrawLstYear(MapTool.getLongFromMap(corePlan, "DRAW_LST_YEAR"));
//				productExt.setDrawEnsure(MapTool.getLongFromMap(corePlan, "DRAW_ENSURE"));
//				productExt.setCoreBaleId(coreBaleId);
//				productExtList.add(productExt);
//		    }
//	    }			 
//		 
//		//3、返回查询结果集
//		return productExtList;
//	}
    /**
     * 更新计划列表的保额和交费年期
     * @param baleList
     * @return
     */
	public void updateBaleListAmountAndChargeYear(List<IspBale> baleList)throws Exception{

		//1、循环更新 计划金额
		for(IspBale bale:baleList){
			ispBaleDao.update(bale);
		}
	}
	
	private Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnce("SEQ_ISP_PRODUCT_EXT");
			IspProductExt productExt = super.get("productExtId", seq);
			
			if (productExt == null) {
				return seq;
			}
		}
	}
}

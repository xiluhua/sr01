package com.taiping.dianshang.outer.service.impl.checkBillCallback;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspApplyJiLiMallDao;
import com.taiping.dianshang.dao.IspKeyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspApplyJiLiMall;
import com.taiping.dianshang.entity.IspCheckBillCallback;
import com.taiping.dianshang.outer.DTO.callback.jiLiMall.ReturnData;
import com.taiping.dianshang.outer.service.CheckBillCallbackService;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.dianshang.outer.service.impl.shortMsg.ShortMsgImpl_ERR_COMMON;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.dianshang.service.httpclient.impl.JiLiMallHttpclientImpl;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * 承保回调外部第三个
 * @author xilh
 * @since 2018-03-31
 */
@Service
@Transactional
public class CheckBillCallback323Impl implements CheckBillCallbackService{

	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	BusinesslogService businesslogService;
	@Resource
	SignService signService;
	@Resource
	IspKeyDao ispKeyDao;
	@Resource
	IspApplyJiLiMallDao ispApplyJiLiMallDao;
	@Resource
	HttpclientImpl httpclientImpl;
	@Resource
	JiLiMallHttpclientImpl jiLiMallHttpclientImpl;
	
	/**
	 * 取消 by联通王伟
	 * @author xilh
	 * @since 20180806
	 */
	@Deprecated
	@Override
	public void handle(Map<String, Object> paramsMap) {
		String partnerBillId = MapTool.getStringFromMap(paramsMap, ConstantTool.OPERATE_NO);
		String errorMsg = "";
		Integer operateStatus = 1;

		// 首期
		IspApply apply = ispApplyDao.loadApply(partnerBillId, null, null, null);
		
		if (apply == null) {
			errorMsg = "无对应投保信息，流水号："+partnerBillId;
			LogTool.error(this.getClass(), errorMsg);
			operateStatus = 3;
			// 失败日志，便于排查
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.CHECKBILL_CALLBACK+323, operateStatus, 1);
			return;
		}
		IspApplyJiLiMall obj = ispApplyJiLiMallDao.getApplyJiLiMall2(apply.getApplyId());
		System.out.println(obj.toString());
		
		// add by xiluhua 20171201 for partners
		IspCheckBillCallback checkBillCallback = CacheContainer.getByIdFromCache(apply.getPartnerId(), IspCheckBillCallback.class);
		
		if (checkBillCallback == null) {
			errorMsg = "checkBillCallback is null: "+apply.getPartnerId();
			LogTool.error(this.getClass(), errorMsg);
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.CHECKBILL_CALLBACK+323, operateStatus, 1);
			return;
		}
		
		// 生成回调报文
		Map<String, String> params = null;
		try {
			params = this.objectToXml(apply, partnerBillId, apply.getSellChannel());
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
		// 生成回调报文
		String requestXml = jiLiMallHttpclientImpl.getRequestMsg(params);
		System.out.println("CheckBillCallback323Impl requestXml: "+requestXml);
		
		String url 		  = this.getUrlByEnv(checkBillCallback,apply);
		
		LogTool.debug(this.getClass(), "CheckBillCallback323Impl url: "+url);
		// 日志（请求）
		businesslogService.postBusinessOpelog_1(apply,url + System.getProperty("line.separator")+requestXml, ConstantTool.CHECKBILL_CALLBACK+323, 1, 1);
		
		// add by xiluhua 20171201 mock only
		if (LogTool.isFormal && apply.getPartnerApplyId().indexOf("TEST") > -1) {
			LogTool.debug(this.getClass(), "attention!!! mock only: "+apply.getPartnerApplyId());
			// 日志（返回）
			businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ "mock only: "+apply.getPartnerApplyId(), ConstantTool.CHECKBILL_CALLBACK+323, 2, 1);
			return;
		}
		
		// 回调
		String responseXml    = jiLiMallHttpclientImpl.callback(url,params,partnerBillId);
		// 报文转对象
		ReturnData returnData = jiLiMallHttpclientImpl.xmlToObject(responseXml, partnerBillId);
		
		boolean isSuccess = (returnData != null && returnData.isSuccess());
		if (!isSuccess) {
			LogTool.info(this.getClass(), paramsMap.toString());
			operateStatus = 0;
			Integer count = MapTool.getIntegerFromMap(paramsMap, ConstantTool.COUNT);
			if (count != null) {
				count++;
			}else {
				count = 1;
			}
			paramsMap.put(ConstantTool.COUNT, count);
			
			// 回调失败短信通知,模板id:2
			if (count > 30) {
				paramsMap.put(ConstantTool.SHORTMSG_TEMP_ID, 2);
				paramsMap.put(ConstantTool.SERVICE_ID, ShortMsgImpl_ERR_COMMON.class.getSimpleName());
				JedisClient_outer2.rpush(ConstantTool.QUEUE_SHORTMSG, JsonTool.toJson(paramsMap));
			}else {
				// 15分钟后再次执行
				paramsMap.put(ConstantTool.NEXT_CALLBACK_TIME, DateTool.add(new Date(), Calendar.MINUTE, 15));
				this.rpush(paramsMap);
			}
		}
		
		// 日志（返回）
		businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ responseXml, ConstantTool.CHECKBILL_CALLBACK+323, operateStatus, 1);
	}

	public Map<String, String> objectToXml(IspApply apply,String busiId,Integer sellChannel) throws Exception{
		Map<String, String> params = new HashMap<String, String>();
		String url = PropertyFileTool.get("accessToken.url");
		String token = httpclientImpl.post3(url, "1", ConstantTool.UTF8);
		params.put("token", token);
		params.put("method", "updateEncourageOrderStatus");
		params.put("providerCode", "tpy");
		params.put("providerName", "太平");
		params.put("status", "1");
		params.put("statusNote", "保单已生效");
		
		IspApplyJiLiMall jiLiMall = ispApplyJiLiMallDao.getApplyJiLiMall2(apply.getApplyId());
		if (jiLiMall == null) {
			LogTool.error(this.getClass(), "jiLiMall is null: "+apply.getPartnerApplyId());
		}else {
			params.put("comCode", jiLiMall.getComCode());
			params.put("company", jiLiMall.getCompany());
			params.put("orderNo", jiLiMall.getOrderNo());
		}
		
		return params;
	}
	
	private String getUrlByEnv(IspCheckBillCallback checkBillCallback, IspApply apply) {
		String url = checkBillCallback.getProxyUrl();
		// 是测试单的话，调用测试地址
		if (LogTool.isLocal) {
			url = PropertyFileTool.get("checkBill.callback.323.local");
			LogTool.info(this.getClass(), "LOCAL: "+apply.getPartnerApplyId());
		}
		if (LogTool.isUat) {
			
			if (ispKeyDao.getIspKey(323l) == null) {
				LogTool.debug(this.getClass(), "inner test!!!");
				// 内部测试
				url = PropertyFileTool.get("checkBill.callback.323.uat");
			}
			LogTool.info(this.getClass(), "UAT: "+apply.getPartnerApplyId());
		}
		if (LogTool.isFormal) {
			LogTool.info(this.getClass(), "FORMAL: "+apply.getPartnerApplyId());
		}

		return url;
	}
	
	public void rpush(Map<String, Object> paramsMap){
		if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
			// 本地 localhost
			JedisClient_outer2.rpush(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY_LOCAL, JsonTool.toJson(paramsMap));
		}else {
			JedisClient_outer2.rpush(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY, JsonTool.toJson(paramsMap));
		}
	}
    
}

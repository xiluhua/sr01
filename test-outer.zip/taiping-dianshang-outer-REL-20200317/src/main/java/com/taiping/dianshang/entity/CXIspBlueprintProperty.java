package com.taiping.dianshang.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * @ClassName CX_ISP_BLUEPRINT_PROPERTY
 * @Description
 * @Version
 */
@Entity
@Table(name = "CX_ISP_BLUEPRINT_PROPERTY")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class CXIspBlueprintProperty implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -725309447202996976L;
	@Id
	@Column(name = "ID")
	private Long id;
	@Column(name = "BLUE_ID")
	private Long blueId; 				// 方案ID
	@Column(name = "HOLDER_NAME")
	private String holderName;			// 投保人姓名
	@Column(name = "HOLDER_IDTYPE_LIST")
	private String holderIdTypeList; 	// 证件类型列表 逗号分割 1.身份证|2.军人证|3.护照|4.出生证|9.其他
	@Column(name = "HOLDER_IDNO")
	private String holderIdNo; 	
	@Column(name = "HOLDER_GENDER")
	private String holderGender; 		// 投保人性别
	@Column(name = "HOLDER_AGE")
	private String holderAge; 			// 投保人年龄
	@Column(name = "HOLDER_MOBILE")
	private String holderMobile; 		// 投保人手机
	@Column(name = "HOLDER_PHONE")
	private String holderPhone; 		// 投保人固话
	@Column(name = "HOLDER_EMAIL")
	private String holderEmail; 		// 投保人邮箱
	@Column(name = "HOLDER_ZIP")
	private String holderZip; 			// 投保人邮编
	@Column(name = "HOLDER_ADDR")
	private String holderAddr; 			// 投保人地址
	
	@Column(name = "RHOLDER_INSTLIST")
	private String rHolderInstList; 	// 投被保人关系列表
	
	@Column(name = "INSURED_NAME")
	private String insuredName;
	@Column(name = "INSURED_IDTYPE_LIST")
	private String insuredIdTypeList; 	// 证件类型列表 逗号分割 1.身份证|2.军人证|3.护照|4.出生证|9.其他
	@Column(name = "INSURED_IDNO")
	private String insuredIdNo; 	
	@Column(name = "INSURED_GENDER")
	private String insuredGender; 		// 被保人性别
	@Column(name = "INSURED_AGE")
	private String insuredAge; 			// 被保人年龄
	@Column(name = "INSURED_MOBILE")
	private String insuredMobile;		// 被保人手机
	@Column(name = "INSURED_PHONE")
	private String insuredPhone; 		// 被保人固话
	@Column(name = "INSURED_EMAIL")
	private String insuredEmail; 		// 被保人邮箱
	@Column(name = "INSURED_ZIP")
	private String insuredZip; 			// 被保人邮编
	@Column(name = "INSURED_ADDR")
	private String insuredAddr; 		// 被保人地址
	
	@Column(name = "RINSURED_BENELIST")
	private String rInsuredBeneList; 	// 受益人与被保人关系列表
	@Column(name = "BENE_NAME")
	private String beneName;
	@Column(name = "BENE_IDTYPE_LIST")
	private String beneIdTypeList; 	// 证件类型列表 逗号分割 1.身份证|2.军人证|3.护照|4.出生证|9.其他
	@Column(name = "BENE_IDNO")
	private String beneIdNo; 	
	@Column(name = "IS_VALIDATE")
	private Integer isValidate; 		// 是否可指定生效日期
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;			// 创建时间
	
	
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getHolderName() {
		return holderName;
	}
	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	public Integer getIsValidate() {
		return isValidate;
	}
	public void setIsValidate(Integer isValidate) {
		this.isValidate = isValidate;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getHolderIdTypeList() {
		return holderIdTypeList;
	}
	public void setHolderIdTypeList(String holderIdTypeList) {
		this.holderIdTypeList = holderIdTypeList;
	}
	public String getHolderGender() {
		return holderGender;
	}
	public void setHolderGender(String holderGender) {
		this.holderGender = holderGender;
	}
	public String getHolderAge() {
		return holderAge;
	}
	public void setHolderAge(String holderAge) {
		this.holderAge = holderAge;
	}
	public String getHolderMobile() {
		return holderMobile;
	}
	public void setHolderMobile(String holderMobile) {
		this.holderMobile = holderMobile;
	}
	public String getHolderPhone() {
		return holderPhone;
	}
	public void setHolderPhone(String holderPhone) {
		this.holderPhone = holderPhone;
	}
	public String getHolderEmail() {
		return holderEmail;
	}
	public void setHolderEmail(String holderEmail) {
		this.holderEmail = holderEmail;
	}
	public String getHolderZip() {
		return holderZip;
	}
	public void setHolderZip(String holderZip) {
		this.holderZip = holderZip;
	}
	public String getHolderAddr() {
		return holderAddr;
	}
	public void setHolderAddr(String holderAddr) {
		this.holderAddr = holderAddr;
	}
	public String getrHolderInstList() {
		return rHolderInstList;
	}
	public void setrHolderInstList(String rHolderInstList) {
		this.rHolderInstList = rHolderInstList;
	}
	public String getInsuredName() {
		return insuredName;
	}
	public void setInsuredName(String insuredName) {
		this.insuredName = insuredName;
	}
	public String getInsuredIdTypeList() {
		return insuredIdTypeList;
	}
	public void setInsuredIdTypeList(String insuredIdTypeList) {
		this.insuredIdTypeList = insuredIdTypeList;
	}
	public String getInsuredGender() {
		return insuredGender;
	}
	public void setInsuredGender(String insuredGender) {
		this.insuredGender = insuredGender;
	}
	public String getInsuredAge() {
		return insuredAge;
	}
	public void setInsuredAge(String insuredAge) {
		this.insuredAge = insuredAge;
	}
	public String getInsuredMobile() {
		return insuredMobile;
	}
	public void setInsuredMobile(String insuredMobile) {
		this.insuredMobile = insuredMobile;
	}
	public String getInsuredPhone() {
		return insuredPhone;
	}
	public void setInsuredPhone(String insuredPhone) {
		this.insuredPhone = insuredPhone;
	}
	public String getInsuredEmail() {
		return insuredEmail;
	}
	public void setInsuredEmail(String insuredEmail) {
		this.insuredEmail = insuredEmail;
	}
	public String getInsuredZip() {
		return insuredZip;
	}
	public void setInsuredZip(String insuredZip) {
		this.insuredZip = insuredZip;
	}
	public String getInsuredAddr() {
		return insuredAddr;
	}
	public void setInsuredAddr(String insuredAddr) {
		this.insuredAddr = insuredAddr;
	}
	public String getrInsuredBeneList() {
		return rInsuredBeneList;
	}
	public void setrInsuredBeneList(String rInsuredBeneList) {
		this.rInsuredBeneList = rInsuredBeneList;
	}
	public String getBeneName() {
		return beneName;
	}
	public void setBeneName(String beneName) {
		this.beneName = beneName;
	}
	public String getBeneIdTypeList() {
		return beneIdTypeList;
	}
	public void setBeneIdTypeList(String beneIdTypeList) {
		this.beneIdTypeList = beneIdTypeList;
	}
	public String getHolderIdNo() {
		return holderIdNo;
	}
	public void setHolderIdNo(String holderIdNo) {
		this.holderIdNo = holderIdNo;
	}
	public String getInsuredIdNo() {
		return insuredIdNo;
	}
	public void setInsuredIdNo(String insuredIdNo) {
		this.insuredIdNo = insuredIdNo;
	}
	public String getBeneIdNo() {
		return beneIdNo;
	}
	public void setBeneIdNo(String beneIdNo) {
		this.beneIdNo = beneIdNo;
	}
	
	
	
}

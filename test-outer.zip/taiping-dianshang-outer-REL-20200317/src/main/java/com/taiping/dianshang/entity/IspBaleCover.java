package com.taiping.dianshang.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * IspBaleCoverCover entity. 
 */
@Entity
@Table(name = "SX_ISP_BLUE_COVER")
public class IspBaleCover implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	private Long id;
	private String coverBenefit;
	private String coverAmount;
	private Integer displaySequence;
	private Long baleId;
	private Long blueId;
	private Date createTime;
	
	// Constructors

	/** default constructor */
	public IspBaleCover() {
	}

	/** minimal constructor */
	public IspBaleCover(Long baleId) {
		this.baleId = baleId;
	}

	// Property accessors
	
	@Column(name = "BALE_ID")
	public Long getBaleId() {
		return this.baleId;
	}

	public void setBaleId(Long baleId) {
		this.baleId = baleId;
	}
	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	@Id
	@Column(name = "ID", unique = true, nullable = false)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "COVER_BENEFIT")
	public String getCoverBenefit() {
		return coverBenefit;
	}

	public void setCoverBenefit(String coverBenefit) {
		this.coverBenefit = coverBenefit;
	}
	@Column(name = "COVER_AMOUNT")
	public String getCoverAmount() {
		return coverAmount;
	}

	public void setCoverAmount(String coverAmount) {
		this.coverAmount = coverAmount;
	}
	@Column(name = "DISPLAY_SEQUENCE")
	public Integer getDisplaySequence() {
		return displaySequence;
	}

	public void setDisplaySequence(Integer displaySequence) {
		this.displaySequence = displaySequence;
	}

}
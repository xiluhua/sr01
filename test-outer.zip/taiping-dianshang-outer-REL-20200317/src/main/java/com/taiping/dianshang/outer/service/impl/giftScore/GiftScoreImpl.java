package com.taiping.dianshang.outer.service.impl.giftScore;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.springframework.stereotype.Service;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspGiftStrategy;
import com.taiping.dianshang.outer.service.GiftScoreService;
import com.taiping.dianshang.outer.service.impl.giftScore.model.GiftScoreRequest;
import com.taiping.dianshang.service.seq.impl.SeqImpl;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.model.DictItems;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.Md5EncryptTool;

@Service
public class GiftScoreImpl implements GiftScoreService{

	@Override
	public void handle(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}
	
	@Resource
	private SeqImpl seqImpl;
	
//	@Resource
//	private IspSequenceDao ispSequenceDao;
	
	public GiftScoreRequest getGiftScoreRequest_1(IspApply apply,String actionId,String simpleName)throws Exception{
		// update by xiluhua 20190226
		// long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_TRANS);
		long seq = seqImpl.get3(ConstantTool.SEQ_TRANS);
		GiftScoreRequest giftScoreRequest = new GiftScoreRequest();
		
		try {
			giftScoreRequest.setActionId(actionId);
			giftScoreRequest.setPolicyNo(apply.getPolicyNo());
			giftScoreRequest.setBlueId(apply.getBlueId());	
			DictItems dictItems = CacheContainer.getDictionary("gift.score.channel");
			String channel = dictItems.getItemByCode(String.valueOf(apply.getPartnerId())).getValue();
			
			LogTool.debug(this.getClass(), "partnerApplyId:"+apply.getPartnerApplyId()+",gift.score.channel:"+channel);
			giftScoreRequest.setChannel(channel);
			
			if (simpleName.toLowerCase().indexOf("mobile") > -1) {
				giftScoreRequest.setPhone(apply.getHolder().getMobile());
			}else {
				giftScoreRequest.setEmail(apply.getHolder().getEmail());
			}
			giftScoreRequest.setMemberId(apply.getUserId());
			
			int paymentMethod = 0;
			if (apply.getChargeType() == 5) {
				paymentMethod = 1;//1--趸缴
			}else if (apply.getChargeType() == 1) {
				paymentMethod = 2;//2—-年缴
			}else if (apply.getChargeType() == 4) {
				paymentMethod = 3;//3—-月缴
			}
			giftScoreRequest.setPaymentMethod(paymentMethod);
			giftScoreRequest.setPremium(apply.getPremium());
			giftScoreRequest.setRequestId(String.valueOf(seq));
			giftScoreRequest.setRuleType(2);
			
			giftScoreRequest.setToken(this.getToken(apply,giftScoreRequest));
		} catch (Exception e) {
			String errorMsg = "get GiftScoreRequest failed,partnerApplyId:"+apply.getPartnerApplyId();
			LogTool.error(this.getClass(), e);
			LogTool.error(this.getClass(), errorMsg);
			throw new Exception(errorMsg);
		}
		
		return giftScoreRequest;
	}
	
	public String getToken(IspApply apply,GiftScoreRequest giftScoreRequest)throws Exception{
		StringBuffer buffer = new StringBuffer();
		String token = null;
		String md5Key = "";
		
		try {
			md5Key = CacheContainer.getSystemParameterValue(ConstantTool.GIFTSCORE_MD5KEY);
		
			buffer.append(md5Key+"|");	
			buffer.append(giftScoreRequest.getMemberId()+"|");	
			buffer.append(giftScoreRequest.getRuleType()+"|");
			buffer.append(giftScoreRequest.getChannel());
			token = Md5EncryptTool.getMd5(buffer.toString());
			LogTool.error(this.getClass(),buffer.toString());
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new Exception("getToken sign error,partnerApplyId:"+apply.getPartnerApplyId());
		}
		
		return token;
	}
	

	public boolean isInTime(IspGiftStrategy ispGiftStrategy) {
		boolean isInTime = false;
		try {
			Date date = new Date();
			Date date1 = DateTool.getDateTime(ispGiftStrategy.getStartTime(), DateTool.DATE_TIME_MASK);
			Date date2 = DateTool.getDateTime(ispGiftStrategy.getEndTime(), DateTool.DATE_TIME_MASK);
			if (date.after(date1) && date.before(date2)) {
				isInTime = true;
			}
		} catch (ParseException e) {
			LogTool.error(this.getClass(), e);
		}
		
		return isInTime;
	}
	
	public String send(String url)throws Exception{
		String timeoutString = null;
		int timeout = 10000;

		try {
//			timeoutString = runtimeApi.getParameter("system.timeout.1");
			timeoutString = CacheContainer.getSystemParameterValue(ConstantTool.SYSTEM_TIMEOUT_1);
			timeout = Integer.valueOf(timeoutString);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			LogTool.error(this.getClass(),"system.timeout.1系统参数未配置");
			return null;
		}

		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");
		httpPost.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(timeout);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(timeout);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			LogTool.error(this.getClass(),"statusCode:"+statusCode);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = "statusCode:"+statusCode;
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, "utf-8");
		}
		return responseMsg;
	}
}

package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SX_ISP_BLUE_ANNOUNCE")
public class IspBlueAnnounce {

	public Long id;         //ID
	public String announceInf;  //告知内容
	public Integer displaySeq;  //显示顺序
	public Long baleId;         //计划ID
	public Long blueId;         //方案ID
	private Date createTime;
	@Id
	@Column(name = "ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Column(name = "ANNOUNCE_INF")
	public String getAnnounceInf() {
		return announceInf;
	}
	public void setAnnounceInf(String announceInf) {
		this.announceInf = announceInf;
	}
	@Column(name = "DISPLAY_SEQ")
	public Integer getDisplaySeq() {
		return displaySeq;
	}
	public void setDisplaySeq(Integer displaySeq) {
		this.displaySeq = displaySeq;
	}
	@Column(name = "BALE_ID")
	public Long getBaleId() {
		return baleId;
	}
	public void setBaleId(Long baleId) {
		this.baleId = baleId;
	}
	@Column(name = "BLUE_ID")
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
}

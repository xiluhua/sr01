package com.taiping.dianshang.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspCustomerDao extends BaseWriteDao<IspCustomer, String>{
	@Resource
	private CommonDaoWrite commonDaoWrite;
	
	public IspCustomer getCusotmerByApplyId(Long applyId,int custType){
		String hql = "from IspCustomer t where t.applyId = ? and t.custType = ?";
		Object[] params = new Object[2];
		params[0] = applyId;
		params[1] = custType;
		return commonDaoWrite.singleResult(hql, params);
	}
	
	public String save(IspCustomer customer){
		Long seq = commonDaoWrite.getSequnce(ConstantTool.SEQ_CUSTOMER);
		customer.setAppCustId(String.valueOf(seq));
		
		return super.save(customer);
	}
}

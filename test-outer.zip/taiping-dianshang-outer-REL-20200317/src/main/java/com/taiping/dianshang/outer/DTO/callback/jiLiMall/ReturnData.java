package com.taiping.dianshang.outer.DTO.callback.jiLiMall;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true) 
public class ReturnData {

//	{
//		   success:接口返回成功与否,
//	      resultMessage:返回数据描述,
//	      resultCode:平台业务代码标记,
//	      result:业务数据
//	}

	private boolean success;
	private String resultMessage;
	private String resultCode;
	private String result;
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getResultMessage() {
		return resultMessage;
	}
	public void setResultMessage(String resultMessage) {
		this.resultMessage = resultMessage;
	}
	public String getResultCode() {
		return resultCode;
	}
	public void setResultCode(String resultCode) {
		this.resultCode = resultCode;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	@Override
	public String toString() {
		return "ReturnData [success=" + success + ", resultMessage="
				+ resultMessage + ", resultCode=" + resultCode + ", result="
				+ result + "]";
	}
	
	
	
}

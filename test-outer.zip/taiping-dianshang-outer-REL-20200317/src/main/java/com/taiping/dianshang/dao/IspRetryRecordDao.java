package com.taiping.dianshang.dao;

import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspRetryRecord;
import com.taiping.facility.tool.LogTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspRetryRecordDao  extends BaseWriteDao<IspRetryRecord, Long>{
	@Resource
	IspSequenceDao ispSequenceDao;
	
	public Long save(IspRetryRecord entity){
		Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_RETRY_RECORED);
		entity.setRetryId(seq);
		super.save(entity);
		return seq;
	}
	
	public Long saveOrUpdate(IspRetryRecord entity){
		int result = this.count(entity);
		
		if (result > 0) {
			return 0l;
		}
		
		Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_RETRY_RECORED);
		entity.setRetryId(seq);
		entity.setCreateTime(new Date());
		super.save(entity);
		return seq;
	}

	public int count(IspRetryRecord entity) {
		
		int result = 0;

		if (entity.getBusiType() == 1) {
			result = this.count1(entity);
		}else if (entity.getBusiType() == 4) {
			result = this.count4(entity);
		}
		
		return result;
	}
	
	public int count1(IspRetryRecord entity) {

		String sql = "SELECT count(1) COUNT FROM ISP_RETRY_RECORD t WHERE t.OPERATE_NO = ?";
		SQLQuery sqlQuery = super.getSession().createSQLQuery(sql);
		sqlQuery.setString(0, entity.getOperateNo());
		
		LogTool.debug(this.getClass(), sql);
		LogTool.debug(this.getClass(), "record count operateNo  : "+entity.getOperateNo());
		
		int result = 0;
		Object obj = sqlQuery.uniqueResult();
		if (obj != null) {
			result = ((BigDecimal)obj).intValue();
		}
		return result;
	}
	
	public int count4(IspRetryRecord entity) {
		String sql = "SELECT count(1) COUNT FROM ISP_RETRY_RECORD t WHERE t.OPERATE_NO = ? AND t.bill_id = ? AND t.busi_type = ?"; 
		SQLQuery sqlQuery = super.getSession().createSQLQuery(sql);
		sqlQuery.setString(0, entity.getOperateNo());
		sqlQuery.setLong(1, entity.getBillId());
		sqlQuery.setInteger(2, entity.getBusiType());
		
		LogTool.debug(this.getClass(), sql);
		LogTool.debug(this.getClass(), "record count operateNo  : "+entity.getOperateNo());
		LogTool.debug(this.getClass(), "record count billId  : "+entity.getBillId());
		LogTool.debug(this.getClass(), "record count busiType: "+entity.getBusiType());

		int result = 0;
		Object obj = sqlQuery.uniqueResult();
		if (obj != null) {
			result = ((BigDecimal)obj).intValue();
		}
		return result;
	}
}

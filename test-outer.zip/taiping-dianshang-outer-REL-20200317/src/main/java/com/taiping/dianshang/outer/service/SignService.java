package com.taiping.dianshang.outer.service;

import com.taiping.dianshang.exception.SignVerifyException;

/**
 * @author xilh
 * @since 20161018
 * @category 签名接口 
 * @version 3.0
 */
public interface SignService {
	
	/**
	 * 签名
	 * @param srcString 签名明文
	 * @return
	 */
	public void verify(String xmlData, String sign,Long partnerId) throws SignVerifyException;
	/**
	 * 签名
	 * @param srcString 签名明文
	 * @return
	 */
	public String sign(String xmlData,Long partnerId);
}

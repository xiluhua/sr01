package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * 亿起发 entity.
 */
@Entity
@Table(name = "ISP_YQFAD")
public class IspYqfad implements java.io.Serializable {

	// Fields
	/**
	 * 
	 */
	private static final long serialVersionUID = 3589346042123254439L;
	private Long applyId;
	private String ad;
	private String channel;
	private String cid;
	private String wi;
	private String target;
	
	private Date createTime;
	private Date updateTime;
	
	@Column(name = "AD")
	public String getAd() {
		return ad;
	}
	public void setAd(String ad) {
		this.ad = ad;
	}
	@Column(name = "CHANNEL")
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	@Column(name = "CID")
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	@Column(name = "WI")
	public String getWi() {
		return wi;
	}
	public void setWi(String wi) {
		this.wi = wi;
	}
	@Column(name = "TARGET")
	public String getTarget() {
		return target;
	}
	public void setTarget(String target) {
		this.target = target;
	}
	
	@Id
	@Column(name = "APPLY_ID", precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}


	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public IspYqfad() {
		super();
		// TODO Auto-generated constructor stub
	}


}
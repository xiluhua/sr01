package com.taiping.dianshang.outer.service.impl.policyPdf;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.caucho.hessian.client.HessianProxyFactory;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.model.BussinessInterface;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.dianshang.outer.service.FileService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;

@Component
@Transactional
public class DownloadPolicyPdfImpl_1 implements DownloadPolicyPdfService{
	
	@Autowired
	private FileService fileService;
	@Resource
	private IspPolicyDao ispPolicyDao;
	
	/**
	 * 从核心系统下载电子保单
	 * @param policyNo
	 * @param idNo
	 * @return
	 */
	public String download(String policyNo,String idNo) {
		
		String url = CacheContainer.getSystemParameterValue(ConstantTool.POLICY_DOWNLOAD_URL_NEW);
		// 测试环境环境问题
		if (LogTool.isLocal || LogTool.isUat) {
			IspPolicy policy = ispPolicyDao.getIspPolicy(policyNo);
			IspBlueprint blueprint = CacheContainer.getByIdFromCache(policy.getBlueId(), IspBlueprint.class);
			if (blueprint != null && !StringUtils.isEmpty(blueprint.getImagePath())) {
				url = CacheContainer.getSystemParameterValue(ConstantTool.POLICY_DOWNLOAD_URL_NEW+"."+blueprint.getImagePath());
			}
		}
		
		String path = null;
		OutputStream outputStream = null;
		DataOutputStream dout = null;
		try {
			String dir = PropertyFileTool.get("policy.pdf.dir");
			if (!new File(dir).exists()) {
				new File(dir).mkdirs();
			}
			path = dir+policyNo+".pdf";
			LogTool.debug(this.getClass(),"download.pdf.dir.path：" + path);
			LogTool.debug(this.getClass(),"policy.download.url.new: " + url);
			
			IspHttpclientParams ihcp = CacheContainer.getByIdFromCache(50L, IspHttpclientParams.class);
			HessianProxyFactory factory = new HessianProxyFactory();
			factory.setReadTimeout(ihcp.getConnectionTimeout());
			BussinessInterface bussinessInterface = (BussinessInterface) factory.create(BussinessInterface.class, url);
			Map<String, Object> param = new HashMap<String, Object>();
			
			param.put("policyCode", policyNo);
			param.put("usercertcode", idNo.toUpperCase());
			
			LogTool.debug(this.getClass(),"入参：" + param.toString());
			Map<String, Object> map = bussinessInterface.getPolicyFile(param);
			// 先从map中获取成功标识，0代表成功，0以外都是失败
			String flag = (String) map.get("ESERVICE_RETURN_FLAG");
			byte[] by = (byte[]) map.get("POLICY_FILE");
			// 判断是成功状态，并且二进制流不为空时，进行输出
			if("0".equals(flag) && null != by) {
				outputStream = new FileOutputStream(path);
				dout = new DataOutputStream(outputStream);
				for (byte b : by) {
					dout.write(b);
				}
				outputStream.close();
				dout.close();
			}
			LogTool.debug(this.getClass(),"出参：" + map.toString());
			
			// 如果新接口没有电子保单，就使用老接口电子保单
			// 20171114 太寿核心系统 田威 反馈此接口已过期
			String use = CacheContainer.getSystemParameterValueNoThrows("is.use.old.policy.pdf");
			if (map.get("POLICY_FILE") == null && !StringUtils.isEmpty(use)) {
				path = fileService.getPolFile(policyNo,1,path);
			}
		} catch (Exception e) {
			path = null;
			LogTool.error(this.getClass(), e);
			throw new DownloadPolicyPdfSysException();
		} finally {
			try {
				if (outputStream!= null) {
					outputStream.close();
				}
				if (dout != null) {
					dout.close();
				}
			} catch (Exception e2) {
				LogTool.error(this.getClass(), e2);
			}
		}
		
		return path;
	}
}

package com.taiping.dianshang.exception;

/**
 * 
 * @author xilh
 * @since
 */
public class DownloadInvoicePdfException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public DownloadInvoicePdfException(String msg){
		super(msg);
	}
	
	public DownloadInvoicePdfException(){
		super();
	}
}


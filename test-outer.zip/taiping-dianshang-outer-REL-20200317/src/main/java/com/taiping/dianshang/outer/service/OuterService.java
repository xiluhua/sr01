package com.taiping.dianshang.outer.service;

import java.util.Map;

public interface OuterService{

	/**
	 * 发送服务
	 * @param paramsMap
	 */
	public void handle(Map<String, Object> paramsMap);
}

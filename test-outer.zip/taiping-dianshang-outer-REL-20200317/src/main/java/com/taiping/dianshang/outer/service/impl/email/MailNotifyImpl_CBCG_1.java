package com.taiping.dianshang.outer.service.impl.email;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspEmailTemplate;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.outer.service.ContentService;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.dianshang.outer.service.MailNotifyService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.SpringTool;
import com.taiping.facility.tool.StringTool;
import com.taiping.framework.bean.MailAttachment;
import com.taiping.framework.bean.MailMessageBean;
import com.taiping.framework.service.MailService;

@Service
public class MailNotifyImpl_CBCG_1 extends MailNotifyImpl implements MailNotifyService{
	@Resource
    private MailService mailService;
	@Resource
	private IspApplyDao ispApplyDao;
	@Resource
	private IspSendHistoryDao ispSendHistoryDao;
	@Resource
	private BusinesslogService businesslogService;
	/**
	 * 发送承保通知邮件
	 * @param emailParamsMap
	 */
	@Transactional
	public void handle(Map<String, Object> emailParamsMap){
		String partnerApplyId = null;
		try {
	        // 保单号
	        partnerApplyId = StringTool.nullToEmpty(emailParamsMap.get("operateNo"));
			
	        LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
			IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply == null) {
				String msg = "邮件发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId);
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			
			// 创建mail info对象
	        MailMessageBean mmsg = super.initMailMessageBean(ConstantTool.WX_CBCG, apply);
	        if (mmsg == null) {
				return;
			}
			String realName = apply.getHolder().getCustName();
			String email = apply.getHolder().getEmail();
			String policyNo = apply.getPolicyNo();
			// 电子保单所在路径
			String path = null;
			DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_"+apply.getSellChannel());
			path = dpps.download(policyNo, apply.getHolder().getIdNo());
			
			if (StringUtils.isEmpty(email)) {
				String msg = "partnerApplyId: "+partnerApplyId+" holder's email is empty, task stopped: MailNotifyImpl_CBCG_1";
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			// 封装附件
			MailAttachment attachment = null;
			if (!StringUtils.isEmpty(path)) {
				attachment = this.getAttachment(path,apply.getPolicyNo()); 
				mmsg.addAttachment(attachment);
			}else {
				LogTool.debug(this.getClass(), apply.getPartnerApplyId()+",can't download policyPDF from new address!",true);
			}
	        
			IspEmailTemplate template = CacheContainer.getEmailTemplateByIdFromCache(apply.getBlueId(), apply.getPartnerId(), apply.getSellChannel(), IspEmailTemplate.class);
			if (template == null) {
				String msg = "partnerApplyId: "+partnerApplyId+", IspShortmsgTemplate strategy is empty";
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			
			ContentService contentService = SpringTool.getSpringBean(template.getContentService());
			String emailContent = contentService.getContent(apply, template);
			LogTool.debug(this.getClass(), "policyNo: "+ policyNo +"\nemailContent: "+emailContent);
			
			//3,构造待发送信息,并保存到数据库
			mmsg.setToAddress(email);
	        mmsg.setToName(realName);
	        mmsg.setContent(emailContent);
	        
            // 发送邮件，添加到数据库
            Integer result = mailService.sendMailCommon(mmsg);
            // 成功就更新保单表的已发送邮件字段
            if (result == 1) {
            	businesslogService.postBusinessOpelog_2(apply, "", ConstantTool.INTERFACE_F_108_SENDEMAIL, 1, 1);
            	IspSendHistory ispSendHistory = ispSendHistoryDao.load(apply.getApplyId());
            	ispSendHistory.setIsEmailSend(1);
            	ispSendHistoryDao.update(ispSendHistory);
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(),"邮件发送失败,流水号:"+StringUtils.defaultString(partnerApplyId));
			LogTool.error(this.getClass(),e);
		}
	}

	/**
	 * 得到邮件的附件
	 * @param path 附件路径
	 * @param fileName 附件名称
	 * @return
	 */
	public MailAttachment getAttachment(String path,String fileName){
		MailAttachment attachment = new MailAttachment();
		File policyPdf = new File(path);
		// added by xiluhua 20170206
		attachment.setName(fileName+".pdf");
		attachment.setSize(String.valueOf(policyPdf.length()));

		String fileType = path.substring(path.lastIndexOf(".") + 1);
        attachment.setType(fileType);

        InputStream in = null;
		try {
			in = new FileInputStream(policyPdf);
			byte[] fileByte = new byte[in.available()];
		    in.read(fileByte);
		    LogTool.error(this.getClass(), "fileName's fileByte: "+fileByte);
		    attachment.setAtachment(fileByte);
		} catch (FileNotFoundException e) {
			LogTool.error(this.getClass(), "无法从系统下载电子保单,fileName:"+fileName);
			LogTool.error(this.getClass(), e);
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
		}finally{
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					LogTool.error(this.getClass(), e);
				}
			}
		}
        return attachment;
	}

}

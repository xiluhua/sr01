package com.taiping.dianshang.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ScIspPolicy entity. 
 */
@Entity
@Table(name = "SC_ISP_POLICY")
public class IspPolicy implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private String policyNo;
	private String appNo;
	private Integer applyType;
	private Integer chargeType;
	private Integer policyStatus;
	private Integer premiumStatus;
	private Integer checkBillStatus;
	private Integer renewPremiumStatus;
	private Integer renewCheckBillStatus;
	private Date acceptDate;
	private Date validateDate;
	private Date expirationDate;
	private Date nextPremiumDate;
	private Date lastPremiumTime;
	private Double premium;
	private Integer bonusMode;
	private Integer beneficiaryType;
	private Integer RHolderInst;
	private String blueName;
	private String organName;
	private String payerName;
	private String accountName;
	private Long applyId;
	private Long blueId;
	private String blueCode;
	private Long baleId;
	private Integer baleNo;
	private Long organId;
	private Long partnerId;
	private Long lv1AreaId;
	private Long lv2AreaId;
	private String lv1AreaName;
	private String lv2AreaName;
	private Long payerId;
	private String userId;
	private Date createTime;
	private Date updateTime;
	private Integer isSendedEmail;
	private Integer sellChannel;
	private Long coverPeriod;
	private String downloadRes;
	private Double cashValue;
	private Date cashValueTime;
	private Integer insuranceType;
	private String createAid;
	private Long standardPremium;
	private String updateAid;
	// added by xiluhua 20171016
	private Long isPaperPdfSent;
	// add by xiluhua 20180802 for 321 blueId:200000107
	private String policyNoBig;
	// add by xilh 20200212
	private String invoicePdfUrl;
	// Constructors

	/** default constructor */
	public IspPolicy() {
	}

	/** minimal constructor */
	public IspPolicy(String policyNo) {
		this.policyNo = policyNo;
	}

	/** full constructor */
	public IspPolicy(String policyNo, String appNo, Integer applyType,
			Integer chargeType, Integer policyStatus, Integer premiumStatus,
			Integer checkBillStatus, Integer renewPremiumStatus,
			Integer renewCheckBillStatus, Date acceptDate, Date validateDate,
			Date expirationDate, Date nextPremiumDate, Date lastPremiumTime,
			Double premium, Integer bonusMode, Integer beneficiaryType,
			Integer RHolderInst, String blueName, String organName,
			String payerName, String accountName, Long applyId, Long blueId,
			String blueCode, Long baleId, Integer baleNo, Long organId,
			Long partnerId, Long lv1AreaId, Long lv2AreaId, String lv1AreaName,
			String lv2AreaName, Long payerId, String userId, Date createTime,
			Date updateTime, Integer isSendedEmail, Integer sellChannel,
			Long coverPeriod, String downloadRes, Double cashValue,
			Date cashValueTime, Integer insuranceType, String createAid,
			Long standardPremium, String updateAid) {
		this.policyNo = policyNo;
		this.appNo = appNo;
		this.applyType = applyType;
		this.chargeType = chargeType;
		this.policyStatus = policyStatus;
		this.premiumStatus = premiumStatus;
		this.checkBillStatus = checkBillStatus;
		this.renewPremiumStatus = renewPremiumStatus;
		this.renewCheckBillStatus = renewCheckBillStatus;
		this.acceptDate = acceptDate;
		this.validateDate = validateDate;
		this.expirationDate = expirationDate;
		this.nextPremiumDate = nextPremiumDate;
		this.lastPremiumTime = lastPremiumTime;
		this.premium = premium;
		this.bonusMode = bonusMode;
		this.beneficiaryType = beneficiaryType;
		this.RHolderInst = RHolderInst;
		this.blueName = blueName;
		this.organName = organName;
		this.payerName = payerName;
		this.accountName = accountName;
		this.applyId = applyId;
		this.blueId = blueId;
		this.blueCode = blueCode;
		this.baleId = baleId;
		this.baleNo = baleNo;
		this.organId = organId;
		this.partnerId = partnerId;
		this.lv1AreaId = lv1AreaId;
		this.lv2AreaId = lv2AreaId;
		this.lv1AreaName = lv1AreaName;
		this.lv2AreaName = lv2AreaName;
		this.payerId = payerId;
		this.userId = userId;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.isSendedEmail = isSendedEmail;
		this.sellChannel = sellChannel;
		this.coverPeriod = coverPeriod;
		this.downloadRes = downloadRes;
		this.cashValue = cashValue;
		this.cashValueTime = cashValueTime;
		this.insuranceType = insuranceType;
		this.createAid = createAid;
		this.standardPremium = standardPremium;
		this.updateAid = updateAid;
	}

	// Property accessors
	@Id
	@Column(name = "POLICY_NO", unique = true, nullable = false, length = 50)
	public String getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Column(name = "APP_NO", length = 50)
	public String getAppNo() {
		return this.appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	@Column(name = "APPLY_TYPE", precision = 3, scale = 0)
	public Integer getApplyType() {
		return this.applyType;
	}

	public void setApplyType(Integer applyType) {
		this.applyType = applyType;
	}

	@Column(name = "CHARGE_TYPE", precision = 3, scale = 0)
	public Integer getChargeType() {
		return this.chargeType;
	}

	public void setChargeType(Integer chargeType) {
		this.chargeType = chargeType;
	}

	@Column(name = "POLICY_STATUS", precision = 3, scale = 0)
	public Integer getPolicyStatus() {
		return this.policyStatus;
	}

	public void setPolicyStatus(Integer policyStatus) {
		this.policyStatus = policyStatus;
	}

	@Column(name = "PREMIUM_STATUS", precision = 3, scale = 0)
	public Integer getPremiumStatus() {
		return this.premiumStatus;
	}

	public void setPremiumStatus(Integer premiumStatus) {
		this.premiumStatus = premiumStatus;
	}

	@Column(name = "CHECK_BILL_STATUS", precision = 3, scale = 0)
	public Integer getCheckBillStatus() {
		return this.checkBillStatus;
	}

	public void setCheckBillStatus(Integer checkBillStatus) {
		this.checkBillStatus = checkBillStatus;
	}

	@Column(name = "RENEW_PREMIUM_STATUS", precision = 3, scale = 0)
	public Integer getRenewPremiumStatus() {
		return this.renewPremiumStatus;
	}

	public void setRenewPremiumStatus(Integer renewPremiumStatus) {
		this.renewPremiumStatus = renewPremiumStatus;
	}

	@Column(name = "RENEW_CHECK_BILL_STATUS", precision = 3, scale = 0)
	public Integer getRenewCheckBillStatus() {
		return this.renewCheckBillStatus;
	}

	public void setRenewCheckBillStatus(Integer renewCheckBillStatus) {
		this.renewCheckBillStatus = renewCheckBillStatus;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ACCEPT_DATE", length = 7)
	public Date getAcceptDate() {
		return this.acceptDate;
	}

	public void setAcceptDate(Date acceptDate) {
		this.acceptDate = acceptDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "VALIDATE_DATE", length = 7)
	public Date getValidateDate() {
		return this.validateDate;
	}

	public void setValidateDate(Date validateDate) {
		this.validateDate = validateDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "EXPIRATION_DATE", length = 7)
	public Date getExpirationDate() {
		return this.expirationDate;
	}

	public void setExpirationDate(Date expirationDate) {
		this.expirationDate = expirationDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "NEXT_PREMIUM_DATE", length = 7)
	public Date getNextPremiumDate() {
		return this.nextPremiumDate;
	}

	public void setNextPremiumDate(Date nextPremiumDate) {
		this.nextPremiumDate = nextPremiumDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "LAST_PREMIUM_TIME")
	public Date getLastPremiumTime() {
		return this.lastPremiumTime;
	}

	public void setLastPremiumTime(Date lastPremiumTime) {
		this.lastPremiumTime = lastPremiumTime;
	}

	@Column(name = "PREMIUM", precision = 12)
	public Double getPremium() {
		return this.premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	@Column(name = "BONUS_MODE", precision = 3, scale = 0)
	public Integer getBonusMode() {
		return this.bonusMode;
	}

	public void setBonusMode(Integer bonusMode) {
		this.bonusMode = bonusMode;
	}

	@Column(name = "BENEFICIARY_TYPE", precision = 3, scale = 0)
	public Integer getBeneficiaryType() {
		return this.beneficiaryType;
	}

	public void setBeneficiaryType(Integer beneficiaryType) {
		this.beneficiaryType = beneficiaryType;
	}

	@Column(name = "R_HOLDER_INST", precision = 3, scale = 0)
	public Integer getRHolderInst() {
		return this.RHolderInst;
	}

	public void setRHolderInst(Integer RHolderInst) {
		this.RHolderInst = RHolderInst;
	}

	@Column(name = "BLUE_NAME", length = 100)
	public String getBlueName() {
		return this.blueName;
	}

	public void setBlueName(String blueName) {
		this.blueName = blueName;
	}

	@Column(name = "ORGAN_NAME", length = 100)
	public String getOrganName() {
		return this.organName;
	}

	public void setOrganName(String organName) {
		this.organName = organName;
	}

	@Column(name = "PAYER_NAME", length = 100)
	public String getPayerName() {
		return this.payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	@Column(name = "ACCOUNT_NAME", length = 200)
	public String getAccountName() {
		return this.accountName;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	@Column(name = "APPLY_ID", precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Column(name = "BLUE_CODE", length = 20)
	public String getBlueCode() {
		return this.blueCode;
	}

	public void setBlueCode(String blueCode) {
		this.blueCode = blueCode;
	}

	@Column(name = "BALE_ID", precision = 10, scale = 0)
	public Long getBaleId() {
		return this.baleId;
	}

	public void setBaleId(Long baleId) {
		this.baleId = baleId;
	}

	@Column(name = "BALE_NO", precision = 3, scale = 0)
	public Integer getBaleNo() {
		return this.baleNo;
	}

	public void setBaleNo(Integer baleNo) {
		this.baleNo = baleNo;
	}

	@Column(name = "ORGAN_ID", precision = 10, scale = 0)
	public Long getOrganId() {
		return this.organId;
	}

	public void setOrganId(Long organId) {
		this.organId = organId;
	}

	@Column(name = "PARTNER_ID", precision = 10, scale = 0)
	public Long getPartnerId() {
		return this.partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	@Column(name = "LV1_AREA_ID", precision = 10, scale = 0)
	public Long getLv1AreaId() {
		return this.lv1AreaId;
	}

	public void setLv1AreaId(Long lv1AreaId) {
		this.lv1AreaId = lv1AreaId;
	}

	@Column(name = "LV2_AREA_ID", precision = 10, scale = 0)
	public Long getLv2AreaId() {
		return this.lv2AreaId;
	}

	public void setLv2AreaId(Long lv2AreaId) {
		this.lv2AreaId = lv2AreaId;
	}

	@Column(name = "LV1_AREA_NAME", length = 100)
	public String getLv1AreaName() {
		return this.lv1AreaName;
	}

	public void setLv1AreaName(String lv1AreaName) {
		this.lv1AreaName = lv1AreaName;
	}

	@Column(name = "LV2_AREA_NAME", length = 100)
	public String getLv2AreaName() {
		return this.lv2AreaName;
	}

	public void setLv2AreaName(String lv2AreaName) {
		this.lv2AreaName = lv2AreaName;
	}

	@Column(name = "PAYER_ID", precision = 10, scale = 0)
	public Long getPayerId() {
		return this.payerId;
	}

	public void setPayerId(Long payerId) {
		this.payerId = payerId;
	}

	@Column(name = "USER_ID", length = 32)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "IS_SENDED_EMAIL", precision = 3, scale = 0)
	public Integer getIsSendedEmail() {
		return this.isSendedEmail;
	}

	public void setIsSendedEmail(Integer isSendedEmail) {
		this.isSendedEmail = isSendedEmail;
	}

	@Column(name = "SELL_CHANNEL", precision = 3, scale = 0)
	public Integer getSellChannel() {
		return this.sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}

	@Column(name = "COVER_PERIOD", precision = 10, scale = 0)
	public Long getCoverPeriod() {
		return this.coverPeriod;
	}

	public void setCoverPeriod(Long coverPeriod) {
		this.coverPeriod = coverPeriod;
	}

	@Column(name = "DOWNLOAD_RES", length = 1000)
	public String getDownloadRes() {
		return this.downloadRes;
	}

	public void setDownloadRes(String downloadRes) {
		this.downloadRes = downloadRes;
	}

	@Column(name = "CASH_VALUE", precision = 12)
	public Double getCashValue() {
		return this.cashValue;
	}

	public void setCashValue(Double cashValue) {
		this.cashValue = cashValue;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CASH_VALUE_TIME")
	public Date getCashValueTime() {
		return this.cashValueTime;
	}

	public void setCashValueTime(Date cashValueTime) {
		this.cashValueTime = cashValueTime;
	}

	@Column(name = "INSURANCE_TYPE", precision = 3, scale = 0)
	public Integer getInsuranceType() {
		return this.insuranceType;
	}

	public void setInsuranceType(Integer insuranceType) {
		this.insuranceType = insuranceType;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "STANDARD_PREMIUM", precision = 12, scale = 0)
	public Long getStandardPremium() {
		return this.standardPremium;
	}

	public void setStandardPremium(Long standardPremium) {
		this.standardPremium = standardPremium;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}
	@Column(name = "IS_PAPER_PDF_SENT")
	public Long getIsPaperPdfSent() {
		return isPaperPdfSent;
	}

	public void setIsPaperPdfSent(Long isPaperPdfSent) {
		this.isPaperPdfSent = isPaperPdfSent;
	}

	@Column(name = "POLICY_NO_BIG")
	public String getPolicyNoBig() {
		return policyNoBig;
	}

	public void setPolicyNoBig(String policyNoBig) {
		this.policyNoBig = policyNoBig;
	}
	
	@Column(name = "INVOICE_PDF_URL")
	public String getInvoicePdfUrl() {
		return invoicePdfUrl;
	}

	public void setInvoicePdfUrl(String invoicePdfUrl) {
		this.invoicePdfUrl = invoicePdfUrl;
	}
}
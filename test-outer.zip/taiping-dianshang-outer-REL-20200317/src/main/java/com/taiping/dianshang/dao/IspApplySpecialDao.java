package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspApplySpecial;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspApplySpecialDao extends BaseWriteDao<IspApplySpecial, Long>{
	
	public IspApplySpecial getApplySpecial(Long applyId) {
		IspApplySpecial obj = (IspApplySpecial) super.get("applyId", applyId);
		return obj;
	}
}

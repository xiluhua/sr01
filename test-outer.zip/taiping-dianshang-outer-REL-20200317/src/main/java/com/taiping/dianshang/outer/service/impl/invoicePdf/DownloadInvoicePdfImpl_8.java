package com.taiping.dianshang.outer.service.impl.invoicePdf;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.service.DownloadInvoicePdfService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PdfDownloadHttpsTool;
import com.taiping.facility.tool.PdfDownloadTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * <b>Title: 阳光下载电子发票</b>
 * @author xilh
 * @date 20200212
 */
@Service
public class DownloadInvoicePdfImpl_8 implements DownloadInvoicePdfService {
	@Resource
    private IspPolicyDao ispPolicyDao;
	
	@Transactional
	public String download(String policyNo, String idNo) {
		String path = null;
		String invoiceUrl = null;
		try {
			IspPolicy policy = ispPolicyDao.getIspPolicy(policyNo);
        	if (!StringUtils.isEmpty(policy.getInvoicePdfUrl())) {
        		invoiceUrl = policy.getInvoicePdfUrl();
			}
        	// 代理的设置  
			String proxy = CacheContainer.getSystemParameterValue(ConstantTool.INTERNET_PROXY_1);
			if (LogTool.isLocal) {
				proxy = PropertyFileTool.get(ConstantTool.INTERNET_PROXY_1);
			}
            //3. 电子保单生成
            String dir = PropertyFileTool.get("policy.pdf.dir");
            path = dir+policyNo+".pdf";

            if (invoiceUrl.startsWith("https")) {
            	PdfDownloadHttpsTool tool = new PdfDownloadHttpsTool();
            	tool.persistentPDF(policyNo, proxy, path, invoiceUrl);
            	return path;
			}
            PdfDownloadTool httpClient = new PdfDownloadTool();
            httpClient.setProxy(proxy.split(":")[0], proxy.split(":")[1]);
			httpClient.persistentPDF(invoiceUrl,path);
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
            throw new DownloadPolicyPdfSysException();
        }
        return path;
	}

//	//1. 保单号相关信息校验
//    IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
//
//    //2. 调用核心获取电子发票地址
//    Busi busi = new Busi();
//    ResponseInvoicePdfUrlDTO responseDTO = new ResponseInvoicePdfUrlDTO(busi);
//    busi.setApply(apply);
//    busi.setResponseDTO(responseDTO);
//    invoicePdfUrlCoreImpl.handleCore(busi);
//    if (!responseDTO.getBusiness().isSuccess()) {
//        throw new DownloadInvoicePdfException("电子发票下载异常！");
//    }
//    
//    invoiceUrl = responseDTO.getMain().getUrl();
}

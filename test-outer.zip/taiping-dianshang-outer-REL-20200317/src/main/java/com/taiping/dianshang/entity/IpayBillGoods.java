package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ScIpayBillGoods entity.
 */
@Entity
@Table(name = "DS_IPAY_BILL_GOODS")
public class IpayBillGoods implements java.io.Serializable {

	// Fields
	/**
	 * 
	 */
	private static final long serialVersionUID = -731215478208477329L;
	private Long goodId;
	private String goodName;
	private Integer goodType;
	private Integer goodNum;
	private Double amount;
	private Integer status;
	private Long blueId;
	private Long applyId;
	private Long billId;
	private Date createTime;
	private Date updateTime;
	// Constructors

	/** default constructor */
	public IpayBillGoods() {
	}
	@Column(name = "BILL_ID")
	public Long getBillId() {
		return billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}

	/** minimal constructor */
	public IpayBillGoods(Long goodId) {
		this.goodId = goodId;
	}

	// Property accessors
	@Id
	@Column(name = "GOOD_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getGoodId() {
		return this.goodId;
	}

	public void setGoodId(Long goodId) {
		this.goodId = goodId;
	}

	@Column(name = "GOOD_NAME", length = 100)
	public String getGoodName() {
		return this.goodName;
	}

	public void setGoodName(String goodName) {
		this.goodName = goodName;
	}

	@Column(name = "GOOD_TYPE", length = 3)
	public Integer getGoodType() {
		return this.goodType;
	}

	public void setGoodType(Integer goodType) {
		this.goodType = goodType;
	}

	@Column(name = "GOOD_NUM", precision = 5, scale = 0)
	public Integer getGoodNum() {
		return this.goodNum;
	}

	public void setGoodNum(Integer goodNum) {
		this.goodNum = goodNum;
	}

	@Column(name = "AMOUNT", precision = 12)
	public Double getAmount() {
		return this.amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "APPLY_ID", precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	/**
	 * @return the blueId
	 */
	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return blueId;
	}

	/**
	 * @param blueId the blueId to set
	 */
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

}
package com.taiping.dianshang.outer.service.impl.autoRegister.impl;

import javax.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;
import com.alibaba.fastjson.JSON;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.impl.autoRegister.UniformUserIdentityService;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity.AccountInfo;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity.AccountRequest;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity.AccountResponse;
import com.taiping.dianshang.outer.service.impl.autoRegister.sso.util.MD5;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.RegisterResult;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.SsoHttpService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;

/**
 * Created by lk on 2017/11/28.
 */
@Component
public class UniformUserIdentityImpl_2 implements UniformUserIdentityService {
    @Resource
    BusinesslogService businesslogService;
    @Resource
    SsoHttpService ssoHttpService;

    @Override
    public String autoRegister(IspApply apply, String keyWord) {
        String uid = this.queryIsUserExist(apply, keyWord);
        if (StringUtils.isEmpty(uid)) {
        	uid = this.ssoRegister(apply);
        }
        return uid;
    }

    @Override
    public String queryIsUserExist(IspApply apply, String keyWord) {
        String uid = "";
        
        //"http://baoxian.itaiping.com/ssoapi/api/searchAccount"
        String strUrl = CacheContainer.getSystemParameterValueNoThrows("uniformUserIdentity.url.search.v2");
        LogTool.info(this.getClass(), "uniformUserIdentity.url.search.v2: "+ strUrl);
        
        AccountRequest requestBody = new AccountRequest();
        requestBody.setRequestID(apply.getPolicyNo());
        AccountInfo accountInfo = new AccountInfo();
        if (!StringUtils.isEmpty(apply.getHolder().getMobile())) {
        	accountInfo.setPhone(apply.getHolder().getMobile());
		}else {
			accountInfo.setEmail(apply.getHolder().getEmail());
		}
        
        requestBody.setAccountInfo(accountInfo);
        
        String body = JSON.toJSONString(requestBody);
        LogTool.info(UniformUserIdentityImpl_2.class,"queryIsUserExist requestBody:"+body);
    	// 日志
		businesslogService.postBusinessOpelog_1(apply, strUrl+System.getProperty("line.separator")+body, ConstantTool.INTERFACE_R_104_AUTO_REGI_QUERY, 1, 1);

        AccountResponse ac = ssoHttpService.httpdoPostBodyHeader(apply, strUrl, body, ConstantTool.INTERFACE_R_104_AUTO_REGI_QUERY);

        LogTool.info(UniformUserIdentityImpl_2.class,apply.getPartnerApplyId()+", result:"+ac.isReturnFlag());
        LogTool.info(UniformUserIdentityImpl_2.class,apply.getPartnerApplyId()+", size:"+ac.getAccountInfoSize());
        
        int operateStatus = 2;
        if (ac.isReturnFlag()) {
        	operateStatus = 1;
        	uid = ac.getAccountInfoList().get(0).getUserId();
        	LogTool.info(UniformUserIdentityImpl_2.class,apply.getPartnerApplyId()+", uid:"+uid);
		}
        // 日志
        businesslogService.postBusinessOpelog_2(apply, strUrl+System.getProperty("line.separator")+ac.getResponseaMsg(), ConstantTool.INTERFACE_R_104_AUTO_REGI_QUERY, operateStatus, 1);
        
        return uid;
    }

    @Override
    public RegisterResult register(IspApply apply, String keyWord) {
        return null;
    }

    public String ssoRegister(IspApply apply) {
        
        //"http://baoxian.itaiping.com/ssoapi/api/addAccount";
        String strUrl = CacheContainer.getSystemParameterValueNoThrows("uniformUserIdentity.url.regist.v2");
        LogTool.debug(this.getClass(), "uniformUserIdentity.url.regist.v2: "+strUrl);
        // 请求参数对象
        AccountRequest requestBody = new AccountRequest();
        requestBody.setRequestID(apply.getPolicyNo()); //可选
        // 用户信息参数
        AccountInfo accountInfo = new AccountInfo();
        // add by xiluhua 20170516 for 统一用户需求，朱焓
        // add by xiluhua from xuchanghong 徐长虹 20180719
        // add by xiluhua from miaoshule 缪舒乐 20180809
        String registerSource = CacheContainer.getDictionaryItemByValue(ConstantTool.UNIFORMUSERIDENTITY_SOURCE, apply.getPartnerId());
        if (StringUtils.isEmpty(registerSource)) {
        	registerSource = CacheContainer.getDictionaryItemByValue(ConstantTool.UNIFORMUSERIDENTITY_SOURCE, ConstantTool.STR_0);
		}
        LogTool.debug(this.getClass(), "registerSource: "+registerSource);
        accountInfo.setSource(registerSource);
//        if (321 == apply.getPartnerId()) {
//        	String source = "itp_epay";
//        	accountInfo.setSource(source);
//        	LogTool.debug(this.getClass(), "registerSource: "+source);
//		}
//        else if (101 == apply.getPartnerId()) {
//        	String source = "tp_zhiyuzengxian";
//        	accountInfo.setSource(source);
//        	LogTool.debug(this.getClass(), "registerSource: "+source);
//		}
//        else {
//			String registerSource = CacheContainer.getSystemParameterValue(ConstantTool.UNIFORMUSERIDENTITY_SOURCE);
//			LogTool.debug(this.getClass(), "registerSource: "+registerSource);
//			accountInfo.setSource(registerSource);
//		}
        
        MD5 mmd5 = new MD5();
        String pw = mmd5.getMD5Str(apply.getHolder().getIdNo());
        LogTool.debug(this.getClass(), "ssoRegister pw:"+pw);
        accountInfo.setPassword(pw);
        
        if (!StringUtils.isEmpty(apply.getHolder().getMobile())) {
        	accountInfo.setPhone(apply.getHolder().getMobile());
		}else {
			accountInfo.setEmail(apply.getHolder().getEmail());
		}
        
        requestBody.setAccountInfo(accountInfo);
        // 转成json
        String body = JSON.toJSONString(requestBody);
        LogTool.debug(this.getClass(), "ssoRegister requestBody:" + body);
        // 日志
		businesslogService.postBusinessOpelog_1(apply, strUrl+System.getProperty("line.separator")+body, ConstantTool.INTERFACE_R_105_AUTO_REGI, 1, 1);

        // 发送请求
        AccountResponse ac = ssoHttpService.httpdoPostBodyHeader(apply, strUrl, body,ConstantTool.INTERFACE_R_105_AUTO_REGI);
        if (ac.isReturnFlag()) {
            return ac.getAccountInfoList().get(0).getUserId();
        }
        return null;
    }

    @Override
    public RegisterResult registerNew(IspApply apply, String keyWord) {
    	RegisterResult result = new RegisterResult();
    	 //"http://baoxian.itaiping.com/ssoapi/api/addAccount";
        String strUrl = CacheContainer.getSystemParameterValueNoThrows("uniformUserIdentity.url.regist.v2");
        LogTool.debug(this.getClass(), "uniformUserIdentity.url.regist.v2: "+strUrl);
        // 请求参数对象
        AccountRequest requestBody = new AccountRequest();
        requestBody.setRequestID(apply.getPolicyNo()); //可选
        // 用户信息参数
        AccountInfo accountInfo = new AccountInfo();
        // added by xiluhua 20170516 for 统一用户需求，朱焓
		String registerSource = CacheContainer.getSystemParameterValue(ConstantTool.UNIFORMUSERIDENTITY_SOURCE);
		LogTool.debug(this.getClass(), "registerSource: "+registerSource);
        accountInfo.setSource(registerSource);
        
        String logPwd = apply.getHolder().getIdNo();
        String logUserName = "";
        MD5 mmd5 = new MD5();
        String pw = mmd5.getMD5Str(apply.getHolder().getIdNo());
        LogTool.debug(this.getClass(), "ssoRegister pw:"+pw);
        accountInfo.setPassword(pw);
        
        if (!StringUtils.isEmpty(apply.getHolder().getMobile())) {
        	accountInfo.setPhone(apply.getHolder().getMobile());
        	logUserName = apply.getHolder().getMobile();
		}else {
			accountInfo.setEmail(apply.getHolder().getEmail());
			logUserName = apply.getHolder().getEmail();
		}
        
        requestBody.setAccountInfo(accountInfo);
        // 转成json
        String body = JSON.toJSONString(requestBody);
        LogTool.debug(this.getClass(), "ssoRegister requestBody:" + body);
        // 日志
		businesslogService.postBusinessOpelog_1(apply, strUrl+System.getProperty("line.separator")+requestBody, ConstantTool.INTERFACE_R_105_AUTO_REGI, 1, 1);

        // 发送请求
        AccountResponse ac = ssoHttpService.httpdoPostBodyHeader(apply, strUrl, body,ConstantTool.INTERFACE_R_105_AUTO_REGI);
        if (ac.isReturnFlag()) {
        	// old 20180608
            // result.setUserName(apply.getHolder().getCustName());
            // result.setPassword(pw);
            
        	// update by xiluhua 20180608
            result.setUserName(logUserName);
            result.setPassword(logPwd);
        }
        return result;
    }

    public String getDesignedLengthRandom(int length) {
        return String.valueOf(Math.random()).substring(2, length + 2);
    }
}

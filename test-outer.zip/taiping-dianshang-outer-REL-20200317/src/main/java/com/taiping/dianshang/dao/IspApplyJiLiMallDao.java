package com.taiping.dianshang.dao;

import javax.annotation.Resource;
import org.springframework.stereotype.Repository;
import com.taiping.dianshang.entity.IspApplyJiLiMall;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.ICommonDao;

@Repository
public class IspApplyJiLiMallDao extends BaseWriteDao<IspApplyJiLiMall, Long>{
	@Resource
	private ICommonDao commonDao;
	
	public IspApplyJiLiMall getApplyJiLiMall(Long applyId) {
		String hql = "from IspApplyJiLiMall t where t.applyId = ?";
		Object [] objects = {applyId};
		IspApplyJiLiMall obj = (IspApplyJiLiMall) commonDao.singleResult(hql, objects);
		return obj;
	}
	
	public IspApplyJiLiMall getApplyJiLiMall2(Long applyId) {
		String hql = "from IspApplyJiLiMall t where t.applyId = ?";
		IspApplyJiLiMall obj = (IspApplyJiLiMall) super.getSession().createQuery(hql).setLong(0, applyId).uniqueResult();
		return obj;
	}
}

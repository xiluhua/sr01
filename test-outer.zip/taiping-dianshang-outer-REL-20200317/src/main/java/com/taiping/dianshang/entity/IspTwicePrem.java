package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SX_ISP_TWICEPREM")
public class IspTwicePrem {

	/**
	 * -- Create table
		create table SX_ISP_TWICEPREM
		(
		  apply_id         NUMBER(20),
		  received_premium NUMBER(12,2),
		  periods          NUMBER(3),
		  create_time      TIMESTAMP(6) default SYSDATE
		)
	 */
	@Id
	@Column(name="APPLY_ID")
	private Long applyId;
	@Column(name="RECEIVED_PREMIUM")
	private Double receivedPremium;
	@Column(name="PERIODS")
	private Integer periods;
	@Column(name="CREATE_TIME")
	private Date createTime;
	
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public Double getReceivedPremium() {
		return receivedPremium;
	}
	public void setReceivedPremium(Double receivedPremium) {
		this.receivedPremium = receivedPremium;
	}
	public Integer getPeriods() {
		return periods;
	}
	public void setPeriods(Integer periods) {
		this.periods = periods;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
}

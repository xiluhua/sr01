package com.taiping.dianshang.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * IspBeneficiary entity. 
 */
@Entity
@Table(name = "SC_ISP_APP_BENEFICIARY")
public class IspBeneficiary implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long appBeneficiaryId;
	private String beneficiaryName;
	private Integer gender;
	private Date birthday;
	private Integer idType;
	private String idNo;
	private Double beneRatio;
	private Integer beneOrder;
	private Integer holderRelationNo;
	private Integer insuredRelationNo;
	private Long applyId;
	private String appNo;
	private String createDate;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private String occupationTypeId;
	private String occupationId;
	private String kindOfWorkId;
	private String licenseNo;
	private Date IdNoEndDate;
	
	@Column(name = "ID_NO_END_DATE")
	public Date getIdNoEndDate() {
		return IdNoEndDate;
	}

	public void setIdNoEndDate(Date idNoEndDate) {
		IdNoEndDate = idNoEndDate;
	}
	// Constructors

	/** default constructor */
	public IspBeneficiary() {
	}

	/** minimal constructor */
	public IspBeneficiary(Long appBeneficiaryId) {
		this.appBeneficiaryId = appBeneficiaryId;
	}

	/** full constructor */
	public IspBeneficiary(Long appBeneficiaryId, String beneficiaryName,
			Integer gender, Date birthday, Integer idType, String idNo,
			Double beneRatio, Integer beneOrder, Integer holderRelationNo,
			Integer insuredRelationNo, Long applyId, String appNo,
			String createDate, Date createTime, Date updateTime,
			String createAid, String updateAid, String occupationTypeId,
			String occupationId, String kindOfWorkId, String licenseNo) {
		this.appBeneficiaryId = appBeneficiaryId;
		this.beneficiaryName = beneficiaryName;
		this.gender = gender;
		this.birthday = birthday;
		this.idType = idType;
		this.idNo = idNo;
		this.beneRatio = beneRatio;
		this.beneOrder = beneOrder;
		this.holderRelationNo = holderRelationNo;
		this.insuredRelationNo = insuredRelationNo;
		this.applyId = applyId;
		this.appNo = appNo;
		this.createDate = createDate;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
		this.occupationTypeId = occupationTypeId;
		this.occupationId = occupationId;
		this.kindOfWorkId = kindOfWorkId;
		this.licenseNo = licenseNo;
	}

	// Property accessors
	@Id
	@Column(name = "APP_BENEFICIARY_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getAppBeneficiaryId() {
		return this.appBeneficiaryId;
	}

	public void setAppBeneficiaryId(Long appBeneficiaryId) {
		this.appBeneficiaryId = appBeneficiaryId;
	}

	@Column(name = "BENEFICIARY_NAME", length = 40)
	public String getBeneficiaryName() {
		return this.beneficiaryName;
	}

	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}

	@Column(name = "GENDER", precision = 3, scale = 0)
	public Integer getGender() {
		return this.gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "BIRTHDAY", length = 7)
	public Date getBirthday() {
		return this.birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	@Column(name = "ID_TYPE", precision = 3, scale = 0)
	public Integer getIdType() {
		return this.idType;
	}

	public void setIdType(Integer idType) {
		this.idType = idType;
	}

	@Column(name = "ID_NO", length = 30)
	public String getIdNo() {
		return this.idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	@Column(name = "BENE_RATIO", precision = 4, scale = 3)
	public Double getBeneRatio() {
		return this.beneRatio;
	}

	public void setBeneRatio(Double beneRatio) {
		this.beneRatio = beneRatio;
	}

	@Column(name = "BENE_ORDER", precision = 3, scale = 0)
	public Integer getBeneOrder() {
		return this.beneOrder;
	}

	public void setBeneOrder(Integer beneOrder) {
		this.beneOrder = beneOrder;
	}

	@Column(name = "HOLDER_RELATION_NO", precision = 3, scale = 0)
	public Integer getHolderRelationNo() {
		return this.holderRelationNo;
	}

	public void setHolderRelationNo(Integer holderRelationNo) {
		this.holderRelationNo = holderRelationNo;
	}

	@Column(name = "INSURED_RELATION_NO", precision = 3, scale = 0)
	public Integer getInsuredRelationNo() {
		return this.insuredRelationNo;
	}

	public void setInsuredRelationNo(Integer insuredRelationNo) {
		this.insuredRelationNo = insuredRelationNo;
	}

	@Column(name = "APPLY_ID", precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Column(name = "APP_NO", length = 20)
	public String getAppNo() {
		return this.appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	@Column(name = "CREATE_DATE")
	public String getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Column(name = "OCCUPATION_TYPE_ID", length = 32)
	public String getOccupationTypeId() {
		return this.occupationTypeId;
	}

	public void setOccupationTypeId(String occupationTypeId) {
		this.occupationTypeId = occupationTypeId;
	}

	@Column(name = "OCCUPATION_ID", length = 32)
	public String getOccupationId() {
		return this.occupationId;
	}

	public void setOccupationId(String occupationId) {
		this.occupationId = occupationId;
	}

	@Column(name = "KIND_OF_WORK_ID", length = 32)
	public String getKindOfWorkId() {
		return this.kindOfWorkId;
	}

	public void setKindOfWorkId(String kindOfWorkId) {
		this.kindOfWorkId = kindOfWorkId;
	}

	@Column(name = "LICENSE_NO", length = 32)
	public String getLicenseNo() {
		return this.licenseNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	
	
	
	
}
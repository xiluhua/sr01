package com.taiping.dianshang.dao;

import javax.annotation.Resource;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspYangLaoTrans;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspYangLaoTransDao extends BaseWriteDao<IspYangLaoTrans, Long>{
	@Resource
	private CommonDao commonDao;
	
	public IspYangLaoTrans getIspYangLaoTransByApplyId(Long applyId){
		return commonDao.findUniqueByProperty(IspYangLaoTrans.class, "applyId", applyId);
	}
	
	@Override
	public Long save(IspYangLaoTrans yangLaoTrans) {
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_YANGLAO_TRANS);
		yangLaoTrans.setId(seq);
		return super.save(yangLaoTrans);
	}
}
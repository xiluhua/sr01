package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.ImsAdministratorShortmsg;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class ImsAdministratorShortmsgDao extends BaseWriteDao<ImsAdministratorShortmsg, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<ImsAdministratorShortmsg> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				ImsAdministratorShortmsg obj = list.get(i);
				if (obj.getMobile() != null) {
					String key = KeyTool.get(ImsAdministratorShortmsg.class,obj.getMobile());
					map.put(key, JsonTool.toJson(obj));	
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<ImsAdministratorShortmsg> getAll(){
		String hql = "from ImsAdministratorShortmsg t";
		return super.getSession().createQuery(hql).list();
	}
}

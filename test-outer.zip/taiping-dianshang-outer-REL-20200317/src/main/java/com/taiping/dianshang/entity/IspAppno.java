package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * ScIspAppno entity. 
 */
@Entity
@Table(name = "SC_ISP_APPNO")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspAppno implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private String appno;
	private Date createTime;
	// Constructors

	// Property accessors
	@Id
	@Column(name = "APPNO", unique = true, nullable = false, length = 20)
	public String getAppno() {
		return this.appno;
	}

	public IspAppno() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setAppno(String appno) {
		this.appno = appno;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}


}
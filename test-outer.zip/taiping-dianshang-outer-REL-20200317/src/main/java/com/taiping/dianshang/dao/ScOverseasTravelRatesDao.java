package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.ScOverseasTravelRates;
import com.taiping.framework.dao.BaseReadDao;

@Repository
public class ScOverseasTravelRatesDao extends BaseReadDao<ScOverseasTravelRates, Long> {

}

package com.taiping.dianshang.outer.service;


public interface CancelService {

	public Integer exec(String partnerApplyId,Long partnerId);
}

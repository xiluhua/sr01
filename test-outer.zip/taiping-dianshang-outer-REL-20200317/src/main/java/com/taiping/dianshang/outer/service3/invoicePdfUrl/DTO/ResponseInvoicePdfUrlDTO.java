package com.taiping.dianshang.outer.service3.invoicePdfUrl.DTO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.ResponseBusinessDTO;

/**
 * 电子发票下载返回对象
 * @author xiluhua 
 * @since 20200212
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		
		"main"
})
@XmlRootElement(name = "RESPONSE")
public class ResponseInvoicePdfUrlDTO extends ResponseDTO {

	@XmlElement(name = "MAIN")
	protected InvoicePdfUrlDTO main = new InvoicePdfUrlDTO();


	public ResponseBusinessDTO getBusiness() {
		return business;
	}

	public void setBusiness(ResponseBusinessDTO business) {
		this.business = business;
	}

	public ResponseInvoicePdfUrlDTO() {
		super();
		this.main = new InvoicePdfUrlDTO();
		// TODO Auto-generated constructor stub
	}

	public ResponseInvoicePdfUrlDTO(Busi busi) {
		super(busi);
	}

	public InvoicePdfUrlDTO getMain() {
		return main;
	}

	public void setMain(InvoicePdfUrlDTO main) {
		this.main = main;
	}
	
	
}

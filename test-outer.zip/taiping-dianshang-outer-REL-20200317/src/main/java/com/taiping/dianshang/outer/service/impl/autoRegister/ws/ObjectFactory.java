package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;

/**
 * This object contains factory methods for each Java content interface and Java
 * element interface generated in the com.ws package.
 * <p>
 * An ObjectFactory allows you to programatically construct new instances of the
 * Java representation for XML content. The Java representation of XML content
 * can consist of schema derived interfaces and classes representing the binding
 * of schema type definitions, element declarations and model groups. Factory
 * methods for each of these are provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

	private final static QName _ModifyUser_QNAME = new QName(
			"http://cntp.com/", "modifyUser");
	private final static QName _RegisterUser_QNAME = new QName(
			"http://cntp.com/", "registerUser");
	private final static QName _SelectUserResponse_QNAME = new QName(
			"http://cntp.com/", "selectUserResponse");
	private final static QName _ModifyUserResponse_QNAME = new QName(
			"http://cntp.com/", "modifyUserResponse");
	private final static QName _VerifyUserPasswd_QNAME = new QName(
			"http://cntp.com/", "verifyUserPasswd");
	private final static QName _SelectUser_QNAME = new QName(
			"http://cntp.com/", "selectUser");
	private final static QName _VerifyUserPasswdResponse_QNAME = new QName(
			"http://cntp.com/", "verifyUserPasswdResponse");
	private final static QName _RegisterUserResponse_QNAME = new QName(
			"http://cntp.com/", "registerUserResponse");

	/**
	 * Create a new ObjectFactory that can be used to create new instances of
	 * schema derived classes for package: com.ws
	 * 
	 */
	public ObjectFactory() {
	}

	/**
	 * Create an instance of {@link VerifyUserPasswdResponse }
	 * 
	 */
	public VerifyUserPasswdResponse createVerifyUserPasswdResponse() {
		return new VerifyUserPasswdResponse();
	}

	/**
	 * Create an instance of {@link SelectUser }
	 * 
	 */
	public SelectUser createSelectUser() {
		return new SelectUser();
	}

	/**
	 * Create an instance of {@link VerifyUserPasswd }
	 * 
	 */
	public VerifyUserPasswd createVerifyUserPasswd() {
		return new VerifyUserPasswd();
	}

	/**
	 * Create an instance of {@link ModifyUserResponse }
	 * 
	 */
	public ModifyUserResponse createModifyUserResponse() {
		return new ModifyUserResponse();
	}

	/**
	 * Create an instance of {@link RegisterUser }
	 * 
	 */
	public RegisterUser createRegisterUser() {
		return new RegisterUser();
	}

	/**
	 * Create an instance of {@link ModifyUser }
	 * 
	 */
	public ModifyUser createModifyUser() {
		return new ModifyUser();
	}

	/**
	 * Create an instance of {@link SelectUserResponse }
	 * 
	 */
	public SelectUserResponse createSelectUserResponse() {
		return new SelectUserResponse();
	}

	/**
	 * Create an instance of {@link RegisterUserResponse }
	 * 
	 */
	public RegisterUserResponse createRegisterUserResponse() {
		return new RegisterUserResponse();
	}

	/**
	 * Create an instance of {@link UserResponse }
	 * 
	 */
	public UserResponse createUserResponse() {
		return new UserResponse();
	}

	/**
	 * Create an instance of {@link UserRequest }
	 * 
	 */
	public UserRequest createUserRequest() {
		return new UserRequest();
	}

	/**
	 * Create an instance of {@link UserInfo }
	 * 
	 */
	public UserInfo createUserInfo() {
		return new UserInfo();
	}

	/**
	 * Create an instance of {@link UserSearchResponse }
	 * 
	 */
	public UserSearchResponse createUserSearchResponse() {
		return new UserSearchResponse();
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link ModifyUser }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "modifyUser")
	public JAXBElement<ModifyUser> createModifyUser(ModifyUser value) {
		return new JAXBElement<ModifyUser>(_ModifyUser_QNAME, ModifyUser.class,
				null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link RegisterUser }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "registerUser")
	public JAXBElement<RegisterUser> createRegisterUser(RegisterUser value) {
		return new JAXBElement<RegisterUser>(_RegisterUser_QNAME,
				RegisterUser.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link SelectUserResponse }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "selectUserResponse")
	public JAXBElement<SelectUserResponse> createSelectUserResponse(
			SelectUserResponse value) {
		return new JAXBElement<SelectUserResponse>(_SelectUserResponse_QNAME,
				SelectUserResponse.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link ModifyUserResponse }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "modifyUserResponse")
	public JAXBElement<ModifyUserResponse> createModifyUserResponse(
			ModifyUserResponse value) {
		return new JAXBElement<ModifyUserResponse>(_ModifyUserResponse_QNAME,
				ModifyUserResponse.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link VerifyUserPasswd }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "verifyUserPasswd")
	public JAXBElement<VerifyUserPasswd> createVerifyUserPasswd(
			VerifyUserPasswd value) {
		return new JAXBElement<VerifyUserPasswd>(_VerifyUserPasswd_QNAME,
				VerifyUserPasswd.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}{@link SelectUser }
	 * {@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "selectUser")
	public JAXBElement<SelectUser> createSelectUser(SelectUser value) {
		return new JAXBElement<SelectUser>(_SelectUser_QNAME, SelectUser.class,
				null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link VerifyUserPasswdResponse }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "verifyUserPasswdResponse")
	public JAXBElement<VerifyUserPasswdResponse> createVerifyUserPasswdResponse(
			VerifyUserPasswdResponse value) {
		return new JAXBElement<VerifyUserPasswdResponse>(
				_VerifyUserPasswdResponse_QNAME,
				VerifyUserPasswdResponse.class, null, value);
	}

	/**
	 * Create an instance of {@link JAXBElement }{@code <}
	 * {@link RegisterUserResponse }{@code >}
	 * 
	 */
	@XmlElementDecl(namespace = "http://cntp.com/", name = "registerUserResponse")
	public JAXBElement<RegisterUserResponse> createRegisterUserResponse(
			RegisterUserResponse value) {
		return new JAXBElement<RegisterUserResponse>(
				_RegisterUserResponse_QNAME, RegisterUserResponse.class, null,
				value);
	}

}

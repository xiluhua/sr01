package com.taiping.dianshang.test;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.Md5EncryptTool;
/**
 * 可成功回调淘宝
 * @author Administrator
 *
 */
public class Taobao_Callback {

	public static void main(String[] args) throws Exception {
		String path = Taobao_Callback.class.getResource("/template/test/refund_request_rest.xml").getPath();
		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"));
		String xml = new Taobao_Callback().readFile(new FileInputStream(new File(path)) , "gbk");
		
		System.out.println("requestXml:"+xml);
		String sign = new Taobao_Callback().sign(xml);
		// localhost本地
		final String url = "http://cooperation.baoxian.taobao.com/cooperation/?com_id=1639876414&sign=" + sign;
		
		System.out.println("url:"+url);
		System.out.println("sign:"+sign);
		// 请确认编码方式
		final String encode = "gbk";
		
		String response = HttpclientTool.post(url, xml, encode);
		System.out.println("response:"+response);
		
	}


	/**
	 * 签名
	 * @param srcString 签名明文
	 * @return
	 */
	private String sign(String xmlData) {
		String sign = "";
		
		try {
			sign = Md5EncryptTool.getMD5(("TPRS123SAD" + xmlData).getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			System.out.println("淘宝签名错误。");
			System.out.println(e);
		}
		
		return sign;
	}
	
	private String readFile(InputStream in,String encode) throws IOException{
		String content = "";
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		if (in != null) {
			byte[] buffer = new byte[1024];
			int length = 0;
			while ((length = in.read(buffer)) != -1) {
				out.write(buffer, 0, length);
			}
			out.close();
			in.close();
			content = new String(out.toByteArray(),encode);
		}
		return content;
	}
}

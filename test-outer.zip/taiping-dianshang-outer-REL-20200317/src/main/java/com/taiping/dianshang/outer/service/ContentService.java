package com.taiping.dianshang.outer.service;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspEmailTemplate;
import com.taiping.dianshang.entity.IspRenewInfo;


public interface ContentService {

	/**
	 * 得到邮件正文
	 * @author xilh
	 * @since 20181009
	 */
	public String getContent(IspApply apply, IspEmailTemplate template);
	
	/**
	 * 续期邮件填充模板
	 * @param apply
	 * @param renewApply
	 * @param template
	 * @return
	 */
	public String getContent(IspApply apply,IspRenewInfo renewInfo,IspEmailTemplate template);
	
}

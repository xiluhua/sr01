package com.taiping.dianshang.outer.service3.invoicePdfUrl;

import com.taiping.dianshang.outer.service3.CoreService;

public interface InvoicePdfUrlCoreService extends CoreService{

}

package com.taiping.dianshang.service.seq;

public interface SeqService {

	public Long get1(String sequence);
	
	public Long get2(String sequence);
	
	public Long get3(String sequence);
}

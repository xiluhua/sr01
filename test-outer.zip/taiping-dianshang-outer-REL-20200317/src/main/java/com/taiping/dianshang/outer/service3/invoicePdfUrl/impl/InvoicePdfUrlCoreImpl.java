package com.taiping.dianshang.outer.service3.invoicePdfUrl.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.service3.invoicePdfUrl.InvoicePdfUrlCoreService;
import com.taiping.dianshang.outer.service3.invoicePdfUrl.DTO.ResponseInvoicePdfUrlDTO;
import com.taiping.dianshang.outer.service3.policyPdfUrl.impl.PolicyPdfUrlCoreImpl;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.IOTool;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 
 * @author xilh
 * @since 20200213
 */
@Service
public class InvoicePdfUrlCoreImpl extends PolicyPdfUrlCoreImpl implements InvoicePdfUrlCoreService {

	@Override
	public void handleCore(Busi busi) throws Exception {
		
		String path = this.getClass().getResource("/template/applyInvoice.xml").getPath();
		busi.setTmp(path);
		String requestXml = this.objectToXml(busi, null);
		// 发送核心报文
		Date begin = new Date();
		Map<String, String> paramsMap = new HashMap<String, String>();
		paramsMap.put("packet", requestXml);
		
		String responseXml = super.sendMsgToCore(null, null, paramsMap);
		
		Date end = new Date();
		long inteval = end.getTime() - begin.getTime();
		LogTool.info(this.getClass(), "=============================================================");
		LogTool.info(this.getClass(), "核心处理时间：" + inteval + "ms");
		LogTool.info(this.getClass(), busi.getApply().getPartnerApplyId()+", responseXml:\n" + responseXml);
		
		this.xmlToObject(busi, responseXml);
	}

	@Override
	public String objectToXml(Busi busi, IspRmi rmi){
		IspApply apply = busi.getApply();

		VelocityContext context = new VelocityContext();
		context.put("dateTools", new DateTool());
		context.put("apply", apply);
		context.put("transTime", new Date());

		String path = (String)busi.getTmp();
		String requestXml = IOTool.readFile(path, "GBK"); // 请确认编码方式
		requestXml = TemplateToolV1218.fill(context, requestXml);
		LogTool.info(this.getClass(), apply.getPartnerApplyId()+", sendCoreApplyPost Invoice xml is: " + requestXml);

		if (StringUtils.isEmpty(requestXml)) {
			throw new RuntimeException("请求申请发票报文模板出错");
		}
		return requestXml;
	}

	@Override
	public void xmlToObject(Busi busi, String responseXml) {
		ResponseInvoicePdfUrlDTO responseDTO = (ResponseInvoicePdfUrlDTO)busi.getResponseDTO();
		try {
			if (StringUtils.isEmpty(responseXml)) {
				responseDTO.getBusiness().setReturnInfo("电子发票申请接口返回为空");
				return;
			}
			ResponseInvoicePdfUrlDTO responseDTO2 = (ResponseInvoicePdfUrlDTO)JAXBTool.unmarshal(responseXml, ResponseInvoicePdfUrlDTO.class);
			busi.setResponseDTO(responseDTO2);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}

}

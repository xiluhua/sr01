package com.taiping.dianshang.outer.DTO.request;

public interface RequestDTO {

}

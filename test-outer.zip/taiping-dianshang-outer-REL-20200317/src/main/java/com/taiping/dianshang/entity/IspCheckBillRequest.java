package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspCore   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_CHECKBILL_REQUEST")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspCheckBillRequest implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3788522661633768891L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="BLUE_ID")
	private String blueId;
	
	@Column(name="CHECKBILL_REQUEST_SERVICE")
	private String checkBillRequestService;

	@Column(name="STATUS")
	private Integer status;		// 1有效|其他失效
	@Column(name="SEQ_PRE")
	private String seqPre;
	
	// => Hy.20190422.AM.Add.Info：
	@Column(name="TOKEN")
	private String token;
	@Column(name="COOPERATION")
	private String cooperation;
	// <<<
	
	public IspCheckBillRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getBlueId() {
		return blueId;
	}
	public void setBlueId(String blueId) {
		this.blueId = blueId;
	}

	public String getCheckBillRequestService() {
		return checkBillRequestService;
	}
	public void setCheckBillRequestService(String checkBillRequestService) {
		this.checkBillRequestService = checkBillRequestService;
	}

	public String getSeqPre() {
		return seqPre;
	}
	public void setSeqPre(String seqPre) {
		this.seqPre = seqPre;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getCooperation() {
		return cooperation;
	}
	public void setCooperation(String cooperation) {
		this.cooperation = cooperation;
	}


}





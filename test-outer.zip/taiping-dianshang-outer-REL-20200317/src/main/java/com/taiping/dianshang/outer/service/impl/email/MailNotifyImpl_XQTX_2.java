package com.taiping.dianshang.outer.service.impl.email;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspRenewInfoDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspEmailTemplate;
import com.taiping.dianshang.entity.IspRenewInfo;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.outer.service.ContentService;
import com.taiping.dianshang.outer.service.MailNotifyService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.SpringTool;
import com.taiping.facility.tool.StringTool;
import com.taiping.framework.bean.MailAttachment;
import com.taiping.framework.bean.MailMessageBean;
import com.taiping.framework.service.MailService;

/**
 * 续期提醒邮件
 * @author liuhe
 * @since 20190816
 */
@Service
public class MailNotifyImpl_XQTX_2 extends MailNotifyImpl implements MailNotifyService {
	@Resource
    private MailService mailService;
	@Resource
	private IspApplyDao ispApplyDao;
	@Resource
	private IspSendHistoryDao ispSendHistoryDao;
	@Resource
	private BusinesslogService businesslogService;
	@Resource
	private IspRenewInfoDao ispRenewInfoDao;
	
	/**
	 * 发送续期通知邮件
	 * @param emailParamsMap
	 */
	@Transactional
	public void handle(Map<String, Object> emailParamsMap){
		String policyNo = "";
		try {
	        // 保单号
	       // partnerApplyId = StringTool.nullToEmpty(emailParamsMap.get("operateNo"));
	        policyNo = StringTool.nullToEmpty(emailParamsMap.get("operateNo"));
	        String email = StringTool.nullToEmpty(emailParamsMap.get("email"));
	        String premium = StringTool.nullToEmpty(emailParamsMap.get("premium"));
	        String term = StringTool.nullToEmpty(emailParamsMap.get("term"));
	        
	        LogTool.info(this.getClass(), "policyNo :"+policyNo,true);
			IspApply apply = ispApplyDao.loadApply(null,policyNo,null,null);
			if (apply == null) {
				String msg = "邮件发送失败,加载 apply 失败:"+policyNo;
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			
			IspRenewInfo renewInfo = ispRenewInfoDao.getIspRenewInfoByTerm(policyNo, Integer.parseInt(term));
			if(renewInfo==null) {
				String msg = "邮件发送失败,加载 renewInfo 失败:"+policyNo;
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			
			// 创建mail info对象
	        MailMessageBean mmsg = super.initMailMessageBean(ConstantTool.WX_XQTX, apply);
	        if (mmsg == null) {
				return;
			}
			String realName = apply.getHolder().getCustName();
			//String email = apply.getHolder().getEmail();
			//String policyNo = apply.getPolicyNo();
			// 电子保单所在路径
			String path = null;
			//DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_"+apply.getSellChannel());
			//path = dpps.download(policyNo, apply.getHolder().getIdNo());
			
			if (StringUtils.isEmpty(email)) {
				String msg = "policyNo: "+policyNo+" holder's email is empty, task stopped: MailNotifyImpl_";
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			// 封装附件
			MailAttachment attachment = null;
			if (!StringUtils.isEmpty(path)) {
				attachment = this.getAttachment(path,apply.getPolicyNo()); 
				mmsg.addAttachment(attachment);
			}else {
				LogTool.debug(this.getClass(), apply.getPartnerApplyId()+",can't download policyPDF from new address!",true);
			}
			IspEmailTemplate template = CacheContainer.getEmailTemplateByIdFromCache(apply.getBlueId(), apply.getPartnerId(), apply.getSellChannel(),ConstantTool.EMAIL_CODE_RENEW,IspEmailTemplate.class);
			
			if (template == null) {
				String msg = "policyNo: "+policyNo+", IspShortmsgTemplate strategy is empty MailNotifyImpl_XQTX_2";
				LogTool.error(this.getClass(), msg);
				businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
				return;
			}
			
			ContentService contentService = SpringTool.getSpringBean(template.getContentService());
			String emailContent = contentService.getContent(apply, renewInfo,template);
			LogTool.debug(this.getClass(), "policyNo: "+ policyNo +"\nemailContent: "+emailContent);
			
			//3,构造待发送信息,并保存到数据库
			mmsg.setToAddress(email);
	        mmsg.setToName(realName);
	        mmsg.setContent(emailContent);
	        
            // 发送邮件，添加到数据库
            Integer result = mailService.sendMailCommon(mmsg);
            // 成功就更新保单表的已发送邮件字段
            if (result == 1) {
            	businesslogService.postBusinessOpelog_2(apply, "", ConstantTool.INTERFACE_F_108_SENDEMAIL, 1, 1);
            	IspSendHistory ispSendHistory = ispSendHistoryDao.load(apply.getApplyId());
            	ispSendHistory.setIsEmailSend(1);
            	ispSendHistoryDao.update(ispSendHistory);
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(),"邮件发送失败,流水号:"+StringUtils.defaultString(policyNo));
			LogTool.error(this.getClass(),e);
		}
	}
}

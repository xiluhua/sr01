package com.taiping.dianshang.outer.service3.invoicePdf;

import com.taiping.dianshang.outer.service3.CoreService;

public interface InvoicePdfCoreService extends CoreService{

}

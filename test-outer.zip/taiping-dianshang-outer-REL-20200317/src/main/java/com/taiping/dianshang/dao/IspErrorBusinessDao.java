package com.taiping.dianshang.dao;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspErrorBusiness;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspErrorBusinessDao extends BaseWriteDao<IspErrorBusiness, Long> {
	
	@Resource
	IspSequenceDao ispSequenceDao;
	
	@Transactional
	public Long save(IspErrorBusiness entity){
		Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_ERROR_BUSINESS);
		
		entity.setErrorBusinessId(seq);
		entity.setCreateTime(new Date());
		
		return super.save(entity);
	}
}
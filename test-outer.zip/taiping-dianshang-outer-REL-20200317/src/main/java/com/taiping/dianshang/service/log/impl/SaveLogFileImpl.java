package com.taiping.dianshang.service.log.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.service.log.SaveLogFileService;
import com.taiping.facility.model.ScIlogBusinessOperateLog;
import com.taiping.facility.model.ScIlogMsg;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.SpringTool;
/**
 * 
 * @author xiluhua by 20160119
 *
 */
public class SaveLogFileImpl implements SaveLogFileService {

	
	public void saveLogFile(ScIlogMsg msg) {
		this.StringFile(msg);
	}
	
	public void saveLogFile(ScIlogBusinessOperateLog msg) {
		this.StringFile(msg);
	}

	/**
	 * 文件保存
	 * 
	 * @param path
	 *            保存路径
	 * @param content
	 *            保存内容
	 * @throws IOException
	 */
	public void StringFile(ScIlogMsg msg){
		String date = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		String fileName = date + "_" + msg.getTemplateId() + "_"+ msg.getLogIndex() + ".txt";
		// d://taobaoLog//date//templateId//fileName.txt	
		String path = PropertyFileTool.get("log.msg.path") + "/"+ date + "/" + msg.getTemplateId();
	
		File file1 = new File(path);
		if (!file1.exists())
			file1.mkdirs();
		File file = new File(path, fileName);
		System.out.println(file.getAbsolutePath());
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("log time:"+time+ "\r\n");
		buffer.append("sendId:"+msg.getSenderId() + "\r\n");
		buffer.append("receiveId:"+msg.getReceiverId() + "\r\n");
		buffer.append(msg.getMsgContent());
		
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(file, true);
			out.write(buffer.toString().getBytes("utf-8"));
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
	
	public void StringFile(ScIlogBusinessOperateLog msg) {
		String date = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
		IspSequenceDao ispSequenceDao = SpringTool.getSpringBean("ispSequenceDao");
		Long seq = ispSequenceDao.getSequnce("seq_business_operate_log");
		
		String fileName = date +".txt";
		String path = PropertyFileTool.get("log.msg.path") +"/BUSINESS_OPERATE_LOG";
		
		File file1 = new File(path);
		if (!file1.exists())
			file1.mkdirs();
		File file = new File(path, fileName);
		System.out.println("=============================================================");
		System.out.println("write businessOpeLog into local file:"+file.getAbsolutePath());
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("insert into sc_ilog_business_operate_log ");
		buffer.append("(business_operate_log_id,apply_id,pay_id,business_Type,business_operate_type,");
		buffer.append("operate_status,operate_no,premium,Holder_Name,");
		buffer.append("Holder_Idno,Card_Buyer_Name,Card_Buyer_Idno,");
		buffer.append("Link_Id,Partner_Id,Partner_Name,Partner_Trans_Code,");
		buffer.append("Payer_Id,Payer_Name,Ip,Msg_Id,CREATE_TIME) values(");
		
		buffer.append("#business_operate_log_id,#apply_id,#pay_id,#business_Type,#business_operate_type,");
		buffer.append("#operate_status,#operate_no,#premium,#Holder_Name,");
		buffer.append("#Holder_Idno,#Card_Buyer_Name,#Card_Buyer_Idno,");
		buffer.append("#Link_Id,#Partner_Id,#Partner_Name,#Partner_Trans_Code,");
		buffer.append("#Payer_Id,#Payer_Name,#Ip,#Msg_Id,#CREATE_TIME);\r\n");
		
		String sql = buffer.toString();
		sql = sql.replace("#business_operate_log_id", seq==null?"null":seq.toString());
		sql = sql.replace("#apply_id", msg.getApplyId()==null?"null":msg.getApplyId().toString());
		sql = sql.replace("#pay_id", msg.getPayId()==null?"null":msg.getPayId().toString());
		sql = sql.replace("#business_Type", msg.getBusinessType()==null?"null":msg.getBusinessType().toString());
		sql = sql.replace("#business_operate_type", msg.getBusinessOperateType()==null?"null":msg.getBusinessOperateType().toString());
		sql = sql.replace("#operate_status", msg.getOperateStatus()==null?"null":msg.getOperateStatus().toString());
		sql = sql.replace("#operate_no", msg.getOperateNo()==null?"null":"'"+msg.getOperateNo().toString()+"'");
		sql = sql.replace("#premium", msg.getPremium()==null?"null":msg.getPremium().toString());
		sql = sql.replace("#Holder_Name", msg.getHolderName()==null?"null":"'"+msg.getHolderName().toString()+"'");
		sql = sql.replace("#Holder_Idno", msg.getHolderIdno()==null?"null":"'"+msg.getHolderIdno().toString()+"'");
		sql = sql.replace("#Card_Buyer_Name", msg.getCardBuyerName()==null?"null":"'"+msg.getCardBuyerName().toString()+"'");
		sql = sql.replace("#Card_Buyer_Idno", msg.getCardBuyerIdno()==null?"null":"'"+msg.getCardBuyerIdno().toString()+"'");
		sql = sql.replace("#Link_Id", msg.getLinkId()==null?"null":msg.getLinkId().toString());
		sql = sql.replace("#Partner_Id", msg.getPartnerId()==null?"null":msg.getPartnerId().toString());
		sql = sql.replace("#Partner_Name", msg.getPartnerName()==null?"null":"'"+msg.getPartnerName().toString()+"'");
		sql = sql.replace("#Partner_Trans_Code",msg.getPartnerTransCode()==null?"null":"'"+msg.getPartnerTransCode().toString()+"'");
		sql = sql.replace("#Payer_Id",msg.getPayerId()==null?"null":msg.getPayerId().toString());
		sql = sql.replace("#Payer_Name",msg.getPayerName()==null?"null":"'"+msg.getPayerName().toString()+"'");
		sql = sql.replace("#Ip",msg.getIp()==null?"null":"'"+msg.getIp().toString()+"'");
		sql = sql.replace("#Msg_Id",msg.getMsgId()==null?"null":msg.getMsgId().toString());
		sql = sql.replace("#CREATE_TIME","to_date('"+time+"','yyyy-MM-dd HH24:mi:ss')");
		
		FileOutputStream out = null;
		try {
			out = new FileOutputStream(file, true);
			out.write(sql.getBytes("utf-8"));
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			try {
				out.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
	}
}


package com.taiping.dianshang.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 合作方业务属性类
 */
@Entity
@Table(name = "SC_ISP_PARTNER_BUSI_PROPERTY")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspPartnerBusiProperty implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 3881343626494954239L;
	@Id
	@Column(name = "ID", unique = true)
	private Long id;  			// 第三方合作方编码
	@Column(name="PARTNER_ID")
	private Long partnerId;  	// 保险方ID
	@Column(name="BLUE_ID")
	private Long blueId;  		// 保险公司商品ID
	@Column(name="STATUS")
	private Long status;  		// 状态 1有效|其他无效
//	@Column(name="MAX_ACCEPT_NUM")
//	private Long maxAcceptNum;	// 最大承保数量
	@Column(name="STRATEGY_SERVICE")
	private String strategyService;
	@Column(name="STRATEGY_EXPRESS")
	private String strategyExpress;
	@Column(name="VAILD_SERVICE")	// 在哪些服务里有效
	private String validService;
	@Column(name="RESPONSE_DESC")	// 返回信息
	private String responseDesc;
	@Column(name="MEMO")
	private String memo;
	@Temporal(TemporalType.DATE)
	@Column(name="CREATE_TIME")
	private Date createTime;  	// 创建时间
	
	
	
	public IspPartnerBusiProperty() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	
	public Long getStatus() {
		return status;
	}
	public void setStatus(Long status) {
		this.status = status;
	}
	
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getStrategyService() {
		return strategyService;
	}
	public void setStrategyService(String strategyService) {
		this.strategyService = strategyService;
	}
	public String getStrategyExpress() {
		return strategyExpress;
	}
	public void setStrategyExpress(String strategyExpress) {
		this.strategyExpress = strategyExpress;
	}
	public String getResponseDesc() {
		return responseDesc;
	}
	public void setResponseDesc(String responseDesc) {
		this.responseDesc = responseDesc;
	}
	public String getValidService() {
		return validService;
	}
	public void setValidService(String validService) {
		this.validService = validService;
	}
	
	
	
	
}

package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspCheckBillRequest;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspCheckBillRequestDao extends BaseWriteDao<IspCheckBillRequest, Long> implements CacheDaoService{

	@Override
	public Map<Object, String> getAllInMap() {
		List<IspCheckBillRequest> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspCheckBillRequest ispCheckBillRequest = list.get(i);
				if (ispCheckBillRequest.getBlueId() != null) {
					String key = KeyTool.get(IspCheckBillRequest.class, ispCheckBillRequest.getBlueId());
					map.put(key, JsonTool.toJson(ispCheckBillRequest));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
				}
			}
		}
		
		return map;
	}

	@SuppressWarnings("unchecked")
	public List<IspCheckBillRequest> getAll(){
		String hql = "from IspCheckBillRequest t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
}

package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspKey;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspKeyDao extends BaseWriteDao<IspKey, Long> {

	public IspKey getIspKey(Long keyID) {
//		Query query = this.getSessionRead().createQuery("from IspKey t where t.keyID = ?");
//		query.setLong(0, keyID);
//		IspKey key = (IspKey) query.uniqueResult();
//		return key;
		return super.get("keyID", keyID);
	}

}

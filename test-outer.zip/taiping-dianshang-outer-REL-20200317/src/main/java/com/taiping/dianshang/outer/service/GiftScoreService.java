package com.taiping.dianshang.outer.service;

public interface GiftScoreService extends OuterService{

}

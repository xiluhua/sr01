package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * ImsActiveMq entity. 
 */
@Entity
@Table(name = "IMS_MQ_REDIS_RESOURCE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsMqRedisResource implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	
	private Long id;
	private String ip;
	private String port;
	private Integer type;//1:MQ|2:REDIS
	private Integer status;
	// Constructors

	/** default constructor */
	public ImsMqRedisResource() {
	}
	
	@Id
	@Column(name = "ID", length = 10)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "IP")
	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
	
	@Column(name = "PORT")
	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}
	
	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	@Column(name = "TYPE")
	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

}
package com.taiping.dianshang.outer.service.impl.autoRegister.sso.util;


import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import com.taiping.facility.tool.LogTool;

import java.io.UnsupportedEncodingException;

public abstract class MyAESUtil {
	
	/**
	 * 加密返回,Base64编码字符串
	 * @param input 待加密内容
	 * @param key 加密密钥
	 * @return
	 */
	public static String encrypt(String body, String key) {
		byte[] crypted = null;
		try {
			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, skey);
			crypted = cipher.doFinal(body.getBytes());
		} catch (Exception e) {
			System.out.println(e.toString());
		}
		//return new String(Base64.encode(crypted));
		//return new String(Base64.getEncoder().encode(crypted));
		return Base64Util.getEncoder().encodeToString(crypted);
	}

	/**
	 * 解密,返回明文
	 * @param input base64编码的待解密内容
	 * @param key 解密密钥
	 * @return
	 */
	public static String decrypt(String body, String key) {
		byte[] output = null;
		try {
			SecretKeySpec skey = new SecretKeySpec(key.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, skey);
			//output = cipher.doFinal(Base64.decode(input));
			output = cipher.doFinal(Base64Util.getDecoder().decode(body));
			LogTool.debug(MyAESUtil.class, "decrypt bytes:"+output);
		} catch (Exception e) {
			LogTool.error(MyAESUtil.class, e);
		}
		try {
			String theEncoding=getEncoding(new String(output));
			LogTool.debug(MyAESUtil.class, "MyAESUtil theEncoding:"+theEncoding);
			return new String(output,theEncoding);
		} catch (UnsupportedEncodingException e) {
			LogTool.error(MyAESUtil.class, e);
		}
		return null;
	}
	
	public static String getEncoding(String str){
		String encode[] = new String[]{
				"UTF-8",
				"ISO-8859-1",
				"GB2312",
				"GBK",
				"GB18030",
				"Big5",
				"Unicode",
				"ASCII"
		};
		for (int i=0;i<encode.length;i++){
			try {
				if(str.equals(new String(str.getBytes(encode[i]),encode[i]))){
					String s=encode[i];
					return s;
				}
			} catch (UnsupportedEncodingException e) {
				e.printStackTrace();
			}
		}
		return "";
	}
}

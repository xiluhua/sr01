package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.ImsDictionary;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.model.DictItem;
import com.taiping.facility.model.DictItems;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class ImsDictoryDao extends BaseWriteDao<ImsDictionary, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<ImsDictionary> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				ImsDictionary dictionary = list.get(i);
				if (dictionary.getDictCode() != null) {
					String key = KeyTool.get(ImsDictionary.class, dictionary.getDictCode());
					map.put(key, JsonTool.toJson(this.buildDictItems(dictionary)));	
				}
			}
		}
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<ImsDictionary> getAll(){
		String hql = "from ImsDictionary t where t.dictExpress is not null";
		return super.getSession().createQuery(hql).list();
	}
	
	public DictItems buildDictItems(ImsDictionary dictionary){
		DictItems items = null;
		if (StringUtils.isNotEmpty(dictionary.getDictExpress())) {
			items = new DictItems();
			items.setDictCode(dictionary.getDictCode());
			items.setDictName(dictionary.getDictName());

			try{
				String express = dictionary.getDictExpress();
				String[] itemStr = express.split("\\|");
				for(String s:itemStr){
					String[] itemValueStr=s.split("\\.");
					DictItem item=new DictItem();
					item.setValue(itemValueStr[0].trim());
					item.setCode(itemValueStr[1].trim());
					item.setText(itemValueStr[2].trim());
					items.addItem(item);
				}
			}catch(Exception e){
				items = null;
				e.printStackTrace();
				System.out.println("Dictionary Format error,please check table Dictionary ,dic code="+dictionary.getDictCode());
			}
		}
		return items;
	}
}

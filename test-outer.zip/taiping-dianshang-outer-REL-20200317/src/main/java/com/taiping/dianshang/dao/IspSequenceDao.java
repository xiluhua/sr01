package com.taiping.dianshang.dao;

import java.math.BigDecimal;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspSpecialBusi;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspSequenceDao extends BaseWriteDao<IspSpecialBusi, Long>{
	
	@Resource
	private CommonDao commonDao;
	
	public Long getSequnce(String sequence) {
		Long seq = commonDao.getSequnce(sequence);
		return seq;
	}
	
	public Long getSequnceWrite(String sequence) {
		String sql = "select " + sequence + ".nextval as key from dual";
		Long logIndex = ((BigDecimal) super.getSession().createSQLQuery(sql).uniqueResult()).longValue();
		return logIndex;
	}	

}
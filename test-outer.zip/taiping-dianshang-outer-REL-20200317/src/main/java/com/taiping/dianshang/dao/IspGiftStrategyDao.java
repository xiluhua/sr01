package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspGiftStrategy;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspGiftStrategyDao extends BaseWriteDao<IspGiftStrategy, Long> implements CacheDaoService{
	
	@Override
	public Map<Object, String> getAllInMap() {
		List<IspGiftStrategy> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspGiftStrategy ispGiftStrategy = list.get(i);
				String key = KeyTool.get(IspGiftStrategy.class,ispGiftStrategy.getPartnerId()+ConstantTool.UNDERLINE+ispGiftStrategy.getBlueId());
				map.put(key, JsonTool.toJson(ispGiftStrategy));                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          
			}
		}
		
		return map;
	}

	@SuppressWarnings("unchecked")
	public List<IspGiftStrategy> getAll(){
		String hql = "from IspGiftStrategy t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
	
	@Transactional
	@Deprecated
	public IspGiftStrategy getIspGiftStrategy(Long partnerId,Long blueId) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("from IspGiftStrategy t ");
		buffer.append("where t.partnerId = ? ");
		buffer.append("  and t.blueId = ?");
		buffer.append("  and t.status = 1");
		
		Query query = getSession().createQuery(buffer.toString());
		query.setLong(0, partnerId);
		query.setLong(1, blueId);
		IspGiftStrategy ispGiftStrategy = (IspGiftStrategy) query.uniqueResult();
		return ispGiftStrategy;
	}

	@Transactional
	@Deprecated
	public IspGiftStrategy getIspGiftStrategy(Long partnerId) {
		StringBuffer buffer = new StringBuffer();
		buffer.append("from IspGiftStrategy t ");
		buffer.append("where t.partnerId = ? ");
		buffer.append("  and t.status = 1");
		
		Query query = getSession().createQuery(buffer.toString());
		query.setLong(0, partnerId);
		IspGiftStrategy ispGiftStrategy = (IspGiftStrategy) query.uniqueResult();
		return ispGiftStrategy;
	}

	
}

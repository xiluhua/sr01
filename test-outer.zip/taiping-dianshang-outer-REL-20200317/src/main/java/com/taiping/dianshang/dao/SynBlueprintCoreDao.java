///**
// * @(#)SynBlueDao.java
// * project：taiping-dianshang-core
// * Copyright ©2013 - 2016 太平电子商务有限公司.  All rights reserved.
// * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
// */
//package com.taiping.dianshang.dao;
//
//import java.util.List;
//import java.util.Map;
//
//import javax.annotation.Resource;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.context.annotation.Scope;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.stereotype.Repository;
//
///**
// * @author xiluhua 20160312
// *<p>Description : SynBlueDao基础类</p>
// *<p>Remark      : </p>
// * @version
// */
//@Repository
//@Scope("prototype")
//public class SynBlueprintCoreDao {
//	protected Logger logger = LoggerFactory.getLogger(getClass());
//	
//	@Resource
//	private JdbcTemplate jdbcTemplate; 
//
//	@SuppressWarnings("deprecation")
//	public int count(String sql){
//		return jdbcTemplate.queryForInt(sql);
//	}
//	
//	public Map<String, Object> queryForMap(String sql,String blueCode){
//		Object[] args = new String[]{blueCode};
//		return jdbcTemplate.queryForMap(sql, args);
//	}
//	
//	public List<Map<String, Object>> queryForListMap(String sql,Object[] args){
//		return jdbcTemplate.queryForList(sql, args);
//	}
//	
//	public int update(String sql,Object[] args){
//		return jdbcTemplate.update(sql, args);
//	}
//	
//	
//}

package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * IpayPay entity. 
 */
@Entity
@Table(name = "DS_IPAY_PAY")
public class IpayPay implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long payId;
	private Double amount;
	private Integer status;
	private Integer payStatus;
	private Integer confirmStatus;
	private String partnerUrl;
	private Date notifyTime;
	private Long payerId;
	private String payerCode;
	private String payerTransNo; // 支付宝对账订单号
//	private String payerNotifyId;
//	private String payerSignInfo;
	private String agentmanCode; // 业务员编号 added by xiluhua 2017-05-08 for 太财赚八\转介绍
//	private String payerErrorInfo;
//	private String partnerCode;
//	private Long partnerId;
	private Long billId;
	private String partnerBillId;
	private String buyerAccount;
	private String accountType;
	private Date createTime;
	private Date updateTime;
	private String merchantNo;
	private String payBank;
//	private String platformCode;
	private String payerCodeLv2;

	// Constructors

	/** default constructor */
	public IpayPay() {
	}

	/** minimal constructor */
	public IpayPay(Long payId) {
		this.payId = payId;
	}

	// Property accessors
	@Id
	@Column(name = "PAY_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getPayId() {
		return this.payId;
	}

	public void setPayId(Long payId) {
		this.payId = payId;
	}

	@Column(name = "AMOUNT", precision = 12)
	public Double getAmount() {
		return this.amount;
	}

	public void setAmount(Double amount) {
		this.amount = amount;
	}

	@Column(name = "PAY_STATUS", precision = 3, scale = 0)
	public Integer getPayStatus() {
		return this.payStatus;
	}

	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	@Column(name = "CONFIRM_STATUS", precision = 3, scale = 0)
	public Integer getConfirmStatus() {
		if (this.confirmStatus == null) {
			this.confirmStatus = 0;
		}
		return this.confirmStatus;
	}

	public void setConfirmStatus(Integer confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

	@Column(name = "PARTNER_URL", length = 500)
	public String getPartnerUrl() {
		return this.partnerUrl;
	}

	public void setPartnerUrl(String partnerUrl) {
		this.partnerUrl = partnerUrl;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "NOTIFY_TIME")
	public Date getNotifyTime() {
		return this.notifyTime;
	}

	public void setNotifyTime(Date notifyTime) {
		this.notifyTime = notifyTime;
	}

	@Column(name = "PAYER_ID", precision = 10, scale = 0)
	public Long getPayerId() {
		return this.payerId;
	}

	public void setPayerId(Long payerId) {
		this.payerId = payerId;
	}

	@Column(name = "PAYER_CODE", length = 50)
	public String getPayerCode() {
		return this.payerCode;
	}

	public void setPayerCode(String payerCode) {
		this.payerCode = payerCode;
	}
	@Column(name = "PAYER_TRANS_NO")
	public String getPayerTransNo() {
		return this.payerTransNo;
	}

	public void setPayerTransNo(String payerTransNo) {
		this.payerTransNo = payerTransNo;
	}
//
//	@Column(name = "PAYER_NOTIFY_ID", length = 50)
//	public String getPayerNotifyId() {
//		return this.payerNotifyId;
//	}
//
//	public void setPayerNotifyId(String payerNotifyId) {
//		this.payerNotifyId = payerNotifyId;
//	}
//

//
//	@Column(name = "PAYER_SIGN_INFO", length = 4000)
//	public String getPayerSignInfo() {
//		return this.payerSignInfo;
//	}
//
//	public void setPayerSignInfo(String payerSignInfo) {
//		this.payerSignInfo = payerSignInfo;
//	}
//
//	@Column(name = "PAYER_BACK_INFO", length = 4000)
//	public String getPayerBackInfo() {
//		return this.payerBackInfo;
//	}
//
//	public void setPayerBackInfo(String payerBackInfo) {
//		this.payerBackInfo = payerBackInfo;
//	}
//
//	@Column(name = "PAYER_ERROR_INFO", length = 200)
//	public String getPayerErrorInfo() {
//		return this.payerErrorInfo;
//	}
//
//	public void setPayerErrorInfo(String payerErrorInfo) {
//		this.payerErrorInfo = payerErrorInfo;
//	}
//
//	@Column(name = "PARTNER_CODE", length = 100)
//	public String getPartnerCode() {
//		return this.partnerCode;
//	}
//
//	public void setPartnerCode(String partnerCode) {
//		this.partnerCode = partnerCode;
//	}
//
//	@Column(name = "PARTNER_ID", precision = 10, scale = 0)
//	public Long getPartnerId() {
//		return this.partnerId;
//	}
//
//	public void setPartnerId(Long partnerId) {
//		this.partnerId = partnerId;
//	}

	@Column(name = "BILL_ID", precision = 10, scale = 0)
	public Long getBillId() {
		return this.billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}

	@Column(name = "PARTNER_BILL_ID", length = 20)
	public String getPartnerBillId() {
		return this.partnerBillId;
	}

	public void setPartnerBillId(String partnerBillId) {
		this.partnerBillId = partnerBillId;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "BUYER_ACCOUNT", length = 100)
	public String getBuyerAccount() {
		return this.buyerAccount;
	}

	public void setBuyerAccount(String buyerAccount) {
		this.buyerAccount = buyerAccount;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	@Column(name = "ACCOUNT_TYPE", length = 32)
	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Column(name = "AGENTMAN_CODE")
	public String getAgentmanCode() {
		return agentmanCode;
	}

	public void setAgentmanCode(String agentmanCode) {
		this.agentmanCode = agentmanCode;
	}
	@Column(name = "MERCHANT_NO")
	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	@Column(name = "PAY_BANK")
	public String getPayBank() {
		return payBank;
	}

	public void setPayBank(String payBank) {
		this.payBank = payBank;
	}
	@Column(name = "PAYER_CODE_LV2")
	public String getPayerCodeLv2() {
		return payerCodeLv2;
	}

	public void setPayerCodeLv2(String payerCodeLv2) {
		this.payerCodeLv2 = payerCodeLv2;
	}
//
//	@Column(name = "PLATFORM_CODE", length = 30)
//	public String getPlatformCode() {
//		return this.platformCode;
//	}
//
//	public void setPlatformCode(String platformCode) {
//		this.platformCode = platformCode;
//	}
	
}
/**
 * @(#)LogPool.java
 *
 * project：taiping-svc-log
 *
 * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.dianshang.service.log;

import com.taiping.facility.model.LinkedListQueue;
import com.taiping.facility.model.ScIlogBusinessOperateLog;
import com.taiping.facility.model.ScIlogErrorLog;
import com.taiping.facility.model.ScIlogMsg;

/**
 * <p>Description : log队列池</p>
 * <p>Date        : May 29, 2013</p>
 * <p>Remark      : </p>
 */
public class LogPool {

	// 错误队列
    public static LinkedListQueue<ScIlogErrorLog> errorLogQ = new LinkedListQueue<ScIlogErrorLog>();
    // 业务操作日志队列
    public static LinkedListQueue<ScIlogBusinessOperateLog> busiOpeLogQ = new LinkedListQueue<ScIlogBusinessOperateLog>();
    // 报文日志表
    public static LinkedListQueue<ScIlogMsg> msgLogQ = new LinkedListQueue<ScIlogMsg>();

}

package com.taiping.dianshang.outer.service;

import java.util.Map;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.entity.IspApply;

public interface ShortMsgService extends OuterService{

	/**
	 * 初始化短信数据
	 * @return
	 */
	public TPSmsMessages initMsg(Map<String, Object> shortMsgParamMap,String serviceId);
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply);
}

package com.taiping.dianshang.outer.service.impl.giftScore.model;

import java.net.URLEncoder;

import net.sf.json.JSONObject;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.facility.tool.AesUtil;
import com.taiping.facility.tool.LogTool;


public class GiftScoreRequest {

	private String memberId;		
	private String phone;			// 手机号码和邮箱必须填其一
	private String email;			// 手机号码和邮箱必须填其一
	private Integer ruleType;		// 1—行为规则赠送；2—购买产品规则赠送；
	private String channel;			// 渠道Id 1—太平网上商城| 2—微幸福商城| 3—微信| 4—移动商城| 5—网服|	//6—转网|7-转介绍
	private String requestId;		// 此字段主要是防止渠道重复性提交请求，及便于事后和各渠道进行对账
	private Long blueId;			// 当赠送规则类型为2时，此字段必填
	private Integer paymentMethod;	// 当赠送规则类型为2时，此字段必填；1--趸缴；2—年缴；3—月缴
	private Double premium;			// 当赠送规则类型为2时，此字段必填
	private String actionId;		// 当赠送规则类型为1时，此字段必填
	private String token;			// md5(md5key|memberId| ruleType|channel)
	private String policyNo;
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Integer getRuleType() {
		return ruleType;
	}
	public void setRuleType(Integer ruleType) {
		this.ruleType = ruleType;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	public Integer getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(Integer paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	public Double getPremium() {
		return premium;
	}
	public void setPremium(Double premium) {
		this.premium = premium;
	}
	public String getActionId() {
		return actionId;
	}
	public void setActionId(String actionId) {
		this.actionId = actionId;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	
	public String getJSONObject(String simpleName){
		
		String jsonString = "{#jsonString}";
		try {
			JSONObject jobj = new JSONObject(); 
			jobj.put("memberId", this.getMemberId());
			
			if (simpleName.toLowerCase().indexOf("mobile") > -1) {
				jobj.put("phone", this.getPhone());
			}else {
				jobj.put("email", this.getEmail());
			}
			
			jobj.put("ruleType", this.getRuleType());
			jobj.put("channel", this.getChannel());
			jobj.put("requestId", this.getRequestId());
			
			if (this.getBlueId() != null) {
				jobj.put("blueId", this.getBlueId());
			}
			if (this.getPaymentMethod() != null) {
				jobj.put("paymentMethod", this.getPaymentMethod());
			}
			if (this.getPremium() != null) {
				jobj.put("premium", this.getPremium());
			}
			if (this.getActionId() != null) {
				jobj.put("actionId", this.getActionId());
			}
			
			jobj.put("token", this.getToken());

			StringBuffer sb = new StringBuffer();   
			for(Object key:jobj.keySet()){  
	            sb.append("\""+key+"\":\""+jobj.get(key)+"\",");  
	        }  
	        String temp = sb.toString().substring(0, sb.toString().length()-1);
	        jsonString = jsonString.replaceAll("#jsonString", temp);
		} catch (Exception e) {
			e.printStackTrace();
			jsonString = null;
		}
		
		return jsonString;
	}
	
	public String getUrl(IspApply apply,String url,String aesKey)throws Exception{
		String demoUrl = new String(url);
		LogTool.debug(this.getClass(), ToStringBuilder.reflectionToString(this),true);
		try {
			String memberId = AesUtil.Encrypt(StringUtils.defaultString(this.getMemberId(),""), aesKey);
			String phone = AesUtil.Encrypt(StringUtils.defaultString(this.getPhone(),""), aesKey);
			String email = AesUtil.Encrypt(StringUtils.defaultString(this.getEmail(), ""), aesKey);
			String channel = AesUtil.Encrypt(StringUtils.defaultString(this.getChannel(), ""), aesKey);
			String ruleType = AesUtil.Encrypt(StringUtils.defaultString(this.getRuleType()+"", ""), aesKey);
			String requestId = AesUtil.Encrypt(StringUtils.defaultString(this.getRequestId()), aesKey);
			String blueId = AesUtil.Encrypt(StringUtils.defaultString(String.valueOf(this.getBlueId()), ""), aesKey);
			String paymentMethod = AesUtil.Encrypt(StringUtils.defaultString(String.valueOf(this.getPaymentMethod()), ""), aesKey);
			String policyNo = AesUtil.Encrypt(StringUtils.defaultString(this.getPolicyNo(),""), aesKey);
			String premium = AesUtil.Encrypt(StringUtils.defaultString(String.valueOf(this.getPremium()),""), aesKey);
			String actionId = AesUtil.Encrypt(StringUtils.defaultString(this.getActionId(), ""), aesKey);
			String token = AesUtil.Encrypt(StringUtils.defaultString(this.getToken(),""), aesKey);
			//http://10.1.117.34:8001/b2b2eM2/ws/addGifts
			///#memberId/#phone/#email/#ruleType/#channel/#requestId/#blueId/#paymentMethod/#policyNo/#premium/#actionId/#token

			demoUrl = demoUrl.replaceAll("#memberId", URLEncoder.encode(memberId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#phone", URLEncoder.encode(phone,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#email", URLEncoder.encode(email,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#ruleType", URLEncoder.encode(ruleType,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#channel", URLEncoder.encode(channel,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#requestId", URLEncoder.encode(requestId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#blueId", URLEncoder.encode(blueId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#paymentMethod", URLEncoder.encode(paymentMethod,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#policyNo", URLEncoder.encode(policyNo,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#premium", URLEncoder.encode(premium,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#actionId", URLEncoder.encode(actionId,"UTF-8"));
			demoUrl = demoUrl.replaceAll("#token", URLEncoder.encode(token,"UTF-8"));
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new Exception("fail to build url,applyId:"+apply.getApplyId());
		}
		
		return demoUrl;
	}
}

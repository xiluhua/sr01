/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.dianshang.outer.DTO.callback.baidu;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by tianhuang on 17/12/19.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
        "ApplyNo",
        "PolicyNo",
        "ApplicationNo",
        "Status",
        "PolicyAmount",
        "Premium",
        "Unit",
        "PayAmount",
        "PayTime",
        "AcceptTime",
        "ValidateDate",
        "ExpireDate",
        "Memo"
})
public class Apply {

    @XmlElement(name = "ApplyNo")
    private String ApplyNo;
    @XmlElement(name = "PolicyNo")
    private String PolicyNo;
    @XmlElement(name = "ApplicationNo")
    private String ApplicationNo;
    @XmlElement(name = "Status")
    private String Status;
    @XmlElement(name = "PolicyAmount")
    private String PolicyAmount;
    @XmlElement(name = "Premium")
    private String Premium;
    @XmlElement(name = "Unit")
    private String Unit;
    @XmlElement(name = "PayAmount")
    private String PayAmount;
    @XmlElement(name = "PayTime")
    private String PayTime;
    @XmlElement(name = "AcceptTime")
    private String AcceptTime;
    @XmlElement(name = "ValidateDate")
    private String ValidateDate;
    @XmlElement(name = "ExpireDate")
    private String ExpireDate;
    @XmlElement(name = "Memo")
    private String Memo;

    public String getApplyNo() {
        return ApplyNo;
    }

    public void setApplyNo(String applyNo) {
        ApplyNo = applyNo;
    }

    public String getPolicyNo() {
        return PolicyNo;
    }

    public void setPolicyNo(String policyNo) {
        PolicyNo = policyNo;
    }

    public String getApplicationNo() {
        return ApplicationNo;
    }

    public void setApplicationNo(String applicationNo) {
        ApplicationNo = applicationNo;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String status) {
        Status = status;
    }

    public String getPolicyAmount() {
        return PolicyAmount;
    }

    public void setPolicyAmount(String policyAmount) {
        PolicyAmount = policyAmount;
    }

    public String getPremium() {
        return Premium;
    }

    public void setPremium(String premium) {
        Premium = premium;
    }

    public String getUnit() {
        return Unit;
    }

    public void setUnit(String unit) {
        Unit = unit;
    }

    public String getPayAmount() {
        return PayAmount;
    }

    public void setPayAmount(String payAmount) {
        PayAmount = payAmount;
    }

    public String getPayTime() {
        return PayTime;
    }

    public void setPayTime(String payTime) {
        PayTime = payTime;
    }

    public String getAcceptTime() {
        return AcceptTime;
    }

    public void setAcceptTime(String acceptTime) {
        AcceptTime = acceptTime;
    }

    public String getValidateDate() {
        return ValidateDate;
    }

    public void setValidateDate(String validateDate) {
        ValidateDate = validateDate;
    }

    public String getExpireDate() {
        return ExpireDate;
    }

    public void setExpireDate(String expireDate) {
        ExpireDate = expireDate;
    }


    public String getMemo() {
        return Memo;
    }

    public void setMemo(String memo) {
        Memo = memo;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }



}

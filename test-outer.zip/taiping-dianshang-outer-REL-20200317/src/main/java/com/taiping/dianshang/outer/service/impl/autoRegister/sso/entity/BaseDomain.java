package com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity;

import java.util.Date;

/**
 * 基础属性,所有的DO继承这个实体类
 * 
 * @author bruce 2017年9月10日 上午9:28:17
 */
public class BaseDomain {
	
	private Date dateCreated; //创建时间
	
	private Date deleteDate; //删除时间
	
	private Integer isDelete; //是否删除
	
	private Date lastUpdated; //更新时间
	
	private Integer version;  //版本
	
	
	  /**get 创建时间**/
	public Date getDateCreated(){
	      return dateCreated;
	}
	  /**set 创建时间**/
	public void setDateCreated(Date dateCreated){
	      this.dateCreated = dateCreated;
	}
	  /**get 删除时间**/
	public Date getDeleteDate(){
	      return deleteDate;
	}
	  /**set 删除时间**/
	public void setDeleteDate(Date deleteDate){
	      this.deleteDate = deleteDate;
	}
	  /**get 是否删除**/
	public Integer getIsDelete(){
	      return isDelete;
	}
	  /**set 是否删除**/
	public void setIsDelete(Integer isDelete){
	      this.isDelete = isDelete;
	}
	  /**get 更新时间**/
	public Date getLastUpdated(){
	      return lastUpdated;
	}
	  /**set 更新时间**/
	public void setLastUpdated(Date lastUpdated){
	      this.lastUpdated = lastUpdated;
	}
	  /**get 版本**/
	public Integer getVersion(){
	      return version;
	}
	  /**set 版本**/
	public void setVersion(Integer version){
	      this.version = version;
	}


}

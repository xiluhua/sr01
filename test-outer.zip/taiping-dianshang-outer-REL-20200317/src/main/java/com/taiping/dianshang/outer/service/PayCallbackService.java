package com.taiping.dianshang.outer.service;

public interface PayCallbackService extends OuterService{

}

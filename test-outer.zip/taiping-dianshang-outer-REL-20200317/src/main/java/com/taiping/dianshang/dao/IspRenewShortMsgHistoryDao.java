package com.taiping.dianshang.dao;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.entity.IspRenewShortmsgHistory;
import com.taiping.framework.dao.BaseWriteDao;

/**
 * @author qby
 * @since 20200317
 */
@Repository
public class IspRenewShortMsgHistoryDao extends BaseWriteDao<IspRenewShortmsgHistory, String>{
	

}
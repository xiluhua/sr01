package com.taiping.dianshang.entity;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**   
 * @ClassName IspYangLaoTrans   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_YANGLAO_TRANS")
public class IspYangLaoTrans {
	private Long id;
	private Long applyId;
	private String checkTrans;
	private String checkBillTrans;
	private Date createTime;
	@Id
	@Column(name = "ID", nullable = false, precision = 10, scale = 0)
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	
    @Column(name = "APPLY_ID", nullable = false, precision = 10, scale = 0)
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	
	@Column(name = "CHECK_TRANS", length = 100)
	public String getCheckTrans() {
		return checkTrans;
	}
	public void setCheckTrans(String checkTrans) {
		this.checkTrans = checkTrans;
	}
	@Column(name = "CHECK_BILL_TRANS", length = 100)
	public String getCheckBillTrans() {
		return checkBillTrans;
	}
	public void setCheckBillTrans(String checkBillTrans) {
		this.checkBillTrans = checkBillTrans;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
	
}

package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBlueprintFeeQuote;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBlueprintFeeQuoteDao extends BaseWriteDao<IspBlueprintFeeQuote, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<IspBlueprintFeeQuote> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspBlueprintFeeQuote obj = list.get(i);
				/*
				 * 两种策略
				 * 1. blueId_sellChannel
				 * 2. partnerId_sellChannel
				 */
				String key = KeyTool.get(IspBlueprintFeeQuote.class, obj.getBlueId()+ConstantTool.UNDERLINE+obj.getPartnerId());
				map.put(key, JsonTool.toJson(obj));
				
				key = KeyTool.get(IspBlueprintFeeQuote.class, obj.getPartnerId()+ConstantTool.UNDERLINE+obj.getSellChannel());
				map.put(key, JsonTool.toJson(obj));
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspBlueprintFeeQuote> getAll(){
		String hql = "from IspBlueprintFeeQuote t";
		return super.getSession().createQuery(hql).list();
	}
}


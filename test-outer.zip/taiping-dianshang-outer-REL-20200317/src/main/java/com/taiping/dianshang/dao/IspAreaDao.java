package com.taiping.dianshang.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspArea;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspAreaDao extends BaseWriteDao<IspArea, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<IspArea> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspArea area = list.get(i);
				if (area.getAreaId() != null) {
					String key = KeyTool.get(IspArea.class, area.getAreaId());
					map.put(key,JsonTool.toJson(area));
				}
				if (area.getGbCode() != null) {
					String key = KeyTool.get(IspArea.class, area.getGbCode());
					map.put(key,JsonTool.toJson(area));
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspArea> getAll(){
		String hql = "from IspArea t where t.leafLevel > 0";
		return super.getSession().createQuery(hql).list();
	}
	
	public String getCoverOrganList(){
		StringBuffer coverOrganBuffer = new StringBuffer();
		HashSet<Long> set = new HashSet<Long>();
		@SuppressWarnings("unchecked")
		Map<Object, String> map = (Map<Object, String>) CacheContainer.getCacheMap().get(IspArea.class.getSimpleName());
		
		if (map == null) {
			map = this.getAllInMap();
		}
		
		for (Entry<Object, String> entry : map.entrySet()) {
			String json = entry.getValue();
			IspArea area = JsonTool.toObject(json, IspArea.class);
			set.add(area.getOrganId());
		}
		
		List<Long> organIdList = new ArrayList<Long>();
		organIdList.addAll(set);
		organIdList.remove(null);
		Collections.sort(organIdList);
		
		for (Long organId : organIdList) {
			coverOrganBuffer.append(organId);
			coverOrganBuffer.append(",");
			
		}
		
		return coverOrganBuffer.toString().substring(0, coverOrganBuffer.length() - 1);
	}
	
	public static void main(String[] args) {
		StringBuffer coverOrganBuffer = new StringBuffer();
		HashSet<Long> set = new HashSet<Long>();
		set.add(3l);
		set.add(1l);
		set.add(2l);
		set.add(5l);
		set.add(4l);
		
		List<Long> organIdList = new ArrayList<Long>();
		organIdList.addAll(set);
		Collections.sort(organIdList);
		
		for (Long organId : organIdList) {
			coverOrganBuffer.append(organId);
			coverOrganBuffer.append(",");
			
		}
		
		System.out.println(coverOrganBuffer.toString().substring(0, coverOrganBuffer.length() - 1));
	}
}
package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 续期信息
 * @author liuhe
 * @since 20190815
 */
@Entity
@Table(name = "ISP_RENEW_INFO")
public class IspRenewInfo implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	private Long id;
	private String policyNo;
	private Double amount;
	private String email;
	private Integer term;
	private Long applyId;
	private Double score;
	private Double retry;
	private String isSendEmail;
	
	@Id
	@Column(name = "ID", unique = true, nullable = false)	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Column(name = "POLICY_NO")
	public String getPolicyNo() {
		return policyNo;
	}
	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}
	@Column(name = "EMAIL")
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Column(name = "TERM")
	public Integer getTerm() {
		return term;
	}
	public void setTerm(Integer term) {
		this.term = term;
	}
	@Column(name = "APPLY_ID")
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	@Column(name = "SCORE")
	public Double getScore() {
		return score;
	}
	public void setScore(Double score) {
		this.score = score;
	}
	@Column(name = "AMOUNT")
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	@Column(name = "RETRY")
	public Double getRetry() {
		return retry;
	}
	public void setRetry(Double retry) {
		this.retry = retry;
	}
	@Column(name = "IS_SEND_EMAIL")
	public String getIsSendEmail() {
		return isSendEmail;
	}
	public void setIsSendEmail(String isSendEmail) {
		this.isSendEmail = isSendEmail;
	}
}

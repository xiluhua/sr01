package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.entity.IspRenewInfo;
import com.taiping.framework.dao.BaseWriteDao;

/**
 * 续期信息Dao
 * @author liuhe
 * @since 20190815
 */
@Repository
public class IspRenewInfoDao extends BaseWriteDao<IspRenewInfo, Long> {
	
	@Transactional
	public IspRenewInfo getIspRenewInfoByTerm(String policyNo,Integer term) {
		String hql = "from IspRenewInfo t where t.policyNo = '"+policyNo+"' and t.term= "+term;
		return (IspRenewInfo)super.getSession().createQuery(hql).uniqueResult();
	}
}

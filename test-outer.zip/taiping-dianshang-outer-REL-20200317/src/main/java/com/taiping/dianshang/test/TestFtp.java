//package com.taiping.dianshang.test;
//
//import java.io.File;
//import java.io.FileInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//
//
//import sun.net.TelnetInputStream;
//import sun.net.TelnetOutputStream;
//import sun.net.ftp.FtpClient;
//
//public class TestFtp {
//	private final static Log logger = LogFactory.getLog(TestFtp.class);
//
//	/**
//	 * 创建连接
//	 * 
//	 * @param IP FTP服务器地址
//	 * @param userName FTP服务器用户名
//	 * @param passWord FTP服务器密码
//	 * @return
//	 * @throws Exception
//	 */
//	public FtpClient ftpConnection(String IP, String userName, String passWord)
//			throws Exception {
//		FtpClient fc = null;
//		try {
//			fc = new FtpClient();
//			fc.openServer(IP);
//			fc.login(userName, passWord);
//			fc.binary();
//		} catch (Exception e) {
//			logger.error(e);
//		}
//		return fc;
//	}
//
//	/**
//	 * 关闭连接
//	 * 
//	 * @param fc FTP连接对象
//	 * @return
//	 */
//	public boolean ftpClose(FtpClient fc) {
//		try {
//			fc.closeServer();
//		} catch (Exception e) {
//			logger.error(e);
//			return false;
//		}
//		return true;
//	}
//
//	/**
//	 * 获取当前目录
//	 * 
//	 * @param fc FTP连接对象
//	 * @return
//	 */
//	public String ftpPWD(FtpClient fc){
//		try {
//			return fc.pwd();
//		} catch (Exception e) {
//			logger.error(e);
//			return null;
//		}
//	}
//
//	public void ftpCD(FtpClient fc, String path){
//		try {
//			fc.cd(path);
//		} catch (Exception e) {
//			logger.error("FTP 转换到目录" + path + "异常：" + e);
//		}
//	}
//
//	/**
//	 * 获取文件列表
//	 * 
//	 * @param fc FTP连接对象
//	 * @return
//	 * @throws Exception
//	 */
//	public String ftpList(FtpClient fc){
//		try {
//			TelnetInputStream is = fc.list();
//			StringBuffer sb = new StringBuffer();
//			int k;
//			while ((k = is.read()) != -1) {
//				sb.append((char) k);
//			}
//			is.close();
//			return new String(sb.toString().getBytes("iso-8859-1"), "GBK");
//		} catch (Exception e) {
//			logger.error(e);
//			return null;
//		}
//	}
//
//	/**
//	 * 下载文件
//	 * 
//	 * @param fc FTP连接对象
//	 * @param filename 下载的文件名称
//	 * @return
//	 * @throws Exception
//	 */
//	public InputStream getFile(FtpClient fc, String filename){
//		InputStream is = null;
//		try {
//			fc.binary();
//			is = fc.get(filename);
//			return is;
//		} catch (Exception e) {
//			logger.error("下载文件:" + filename + " 异常");
//			return null;
//		}
//	}
//
//	/**
//	 * 上传文件
//	 * 
//	 * @param fc FTP连接对象
//	 * @param filename  上传的文件名称
//	 * @return
//	 * @throws IOException
//	 */
//	public boolean ftpPut(FtpClient fc, String filename, String Url) {
//		FileInputStream is = null;
//		TelnetOutputStream os = null;
//
//		try {
//
//			os = fc.put(filename);
//			File file_in = new File(Url);
//			is = new FileInputStream(file_in);
//			byte[] bytes = new byte[1024];
//			int c;
//			while ((c = is.read(bytes)) != -1) {
//				os.write(bytes, 0, c);
//			}
//		} catch (IOException ex) {
//			logger.error(ex);
//			return false;
//		} finally {
//			try {
//				is.close();
//				os.close();
//			} catch (Exception e) {
//				logger.error(e);
//			}
//
//		}
//		return true;
//	}
//	/**
//	 * 删除文件
//	 * 
//	 * @param fc FTP连接对象
//	 * @param filename 删除的文件名称
//	 * @return
//	 */
//	public boolean ftpDelete(FtpClient fc, String filename) {
//		try {
//			fc.cd(ftpPWD(fc));
//		} catch (IOException e) {
//			logger.error(e);
//			return false;
//		} 
//		fc.sendServer("dele " + filename + "\r\n");
//		try {
//			fc.readServerResponse();
//		} catch (IOException e) {
//			logger.error(e);
//		}
//		return true;
//	}
//	
//	public static void main(String[] args) throws Exception {
//		String IP = "220.250.65.22";
//		String userName = "ftp_hangye20";
//		String userPassword = "oUo2JD7oK#u-epw";
//		FtpClient fc = null;
//		String fileList = "";
//		// 文件名为项目路径下的文件
//		String upFileName = "d:\\a.txt";
//		String dictionary = "";
//		TestFtp ftp = new TestFtp();
//
//		// 链接FTP
//		fc = ftp.ftpConnection(IP, userName, userPassword);
//		// 获得文件列表
//		fileList = ftp.ftpList(fc);
//		logger.info("当前文件列表：\n" + fileList);
//		// 获得当前目录
//		dictionary = ftp.ftpPWD(fc);
//		logger.info("当前目录：" + dictionary);
//		// 上传文件
//		ftp.ftpPut(fc, upFileName, "d:\\a.txt");
//		// 下载文件
//		// ftp.getFile(fc, "b.txt");
//		// 删除文件
//		// ftp.ftpDelete(fc, "PSS.rar");
//
//		// 关闭连接
//		ftp.ftpClose(fc);
//	}
//
//}

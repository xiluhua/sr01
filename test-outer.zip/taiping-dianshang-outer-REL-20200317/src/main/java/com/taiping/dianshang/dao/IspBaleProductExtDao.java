package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspBaleProductExt;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBaleProductExtDao  extends BaseWriteDao<IspBaleProductExt, Long>{
	

}

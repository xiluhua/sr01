package com.taiping.dianshang.outer.DTO.request.element;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBeneficiary;
import com.taiping.dianshang.outer.DTO.response.element.info.ApplyResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.BeneficiaryResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.CustomerResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.RenewInfResponseDTO;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"apply",
		"holder",
		"insured",
		"renewInf",
		"beneficiaryList"
})
public class CheckBillCallbackDTO{
	@XmlElement(name = "APPLY")
	private ApplyResponseDTO apply = new ApplyResponseDTO();
	@XmlElement(name = "HOLDER")
	private CustomerResponseDTO holder = new CustomerResponseDTO();
	@XmlElement(name = "INSURED")
	private CustomerResponseDTO insured = new CustomerResponseDTO();
	@XmlElement(name = "RENEW")
	private RenewInfResponseDTO renewInf; 			// 续期信息
	@XmlElementWrapper(name="BENEFICIARYS")
    @XmlElement(name = "BENEFICIARY")
    private List<BeneficiaryResponseDTO> beneficiaryList = new ArrayList<BeneficiaryResponseDTO>(); 						// 受益人信息
	
	
	public ApplyResponseDTO getApply() {
		return apply;
	}
	public void setApply(ApplyResponseDTO apply) {
		this.apply = apply;
	}
	public CustomerResponseDTO getHolder() {
		return holder;
	}
	public void setHolder(CustomerResponseDTO holder) {
		this.holder = holder;
	}
	public CustomerResponseDTO getInsured() {
		return insured;
	}
	public void setInsured(CustomerResponseDTO insured) {
		this.insured = insured;
	}
	public RenewInfResponseDTO getRenewInf() {
		return renewInf;
	}
	public void setRenewInf(RenewInfResponseDTO renewInf) {
		this.renewInf = renewInf;
	}
	public List<BeneficiaryResponseDTO> getBeneficiaryList() {
		return beneficiaryList;
	}
	public void setBeneficiaryList(List<BeneficiaryResponseDTO> beneficiaryList) {
		this.beneficiaryList = beneficiaryList;
	}
	public CheckBillCallbackDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	public CheckBillCallbackDTO(IspApply applyModel) {
		super();
		this.apply = new ApplyResponseDTO(applyModel);
		this.holder = new CustomerResponseDTO(applyModel.getHolder());
		this.insured = new CustomerResponseDTO(applyModel.getInsured());
		
		if (applyModel.getBeneficiaryList()!=null) {
			for (int i = 0; i < applyModel.getBeneficiaryList().size(); i++) {
				IspBeneficiary beneficiary = applyModel.getBeneficiaryList().get(i);
				BeneficiaryResponseDTO beneficiaryResponseDTO = new BeneficiaryResponseDTO(beneficiary);
				this.beneficiaryList.add(beneficiaryResponseDTO);
			}
		}
	}
	
}

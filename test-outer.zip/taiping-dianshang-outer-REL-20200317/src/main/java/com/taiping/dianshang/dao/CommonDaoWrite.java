package com.taiping.dianshang.dao;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.compass.core.util.Assert;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Example;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.taiping.framework.dao.ICommonDao;

@Repository
public class CommonDaoWrite implements ICommonDao {

	private Logger logger = Logger.getLogger(getClass());
	
	//-------------sessionFactory read-------------
	@Resource
	private SessionFactory sessionFactory; 
	
	/**
	 * @param sessionFactory the sessionFactory to set
	 */
	@Resource(name="sessionFactoryWrite")
	public void setSessionFactory(SessionFactory sessionFactoryWrite) {
		this.sessionFactoryWrite = sessionFactoryWrite;
	}
	
	public Session getSession(){
		return sessionFactoryWrite.getCurrentSession();
	}
	
	/**
	 * 根据ID获取实体对象
	 * 
	 * @param entityClass
	 * @param id
	 * @return T
	 */
	public <T> T get(Class<T> entityClass, Serializable id) {
		Assert.notNull(id, "id is required");
		return (T) getSession().get(entityClass, id);
	}

	/**
	 * 根据ID数组获取实体对象的集合
	 * 
	 * @param entityClass
	 * @param ids
	 * @return List<T>
	 */
	public <T> List<T> get(Class<T> entityClass,Object... ids) {
		Assert.notEmpty(ids, "ids must not be empty");
		String hql = "from " + entityClass.getName() + " as model where model.id in(:ids)";
		return getSession().createQuery(hql).setParameterList("ids", ids).list();
	}
	
	/**
	 * 根据ID数组获取实体对象的集合
	 * 
	 * @param entityClass
	 * @param ids
	 * @return List<T>
	 */
	public <T> List<T> getAll(Class<T> entityClass) {
		String hql = "from " + entityClass.getName() + " as model";
		return getSession().createQuery(hql).list();
	}

	/**
	 * 根据属性和属性值获取获取实体对象集合
	 * 
	 * @param entityClass
	 * @param propertyName
	 * @param value
	 * @return List<T>
	 */
	public <T> List<T> get(Class<T> entityClass, String propertyName, Object value) {
		Assert.hasText(propertyName, "propertyName must not be empty");
		Assert.notNull(value, "value is required");
		String hql = "from " + entityClass.getName() + " as model where model." + propertyName + " = ?";
		return (List<T>) getSession().createQuery(hql).setParameter(0, value).list();
	}

	/**
	 * 根据ID获取实体对象
	 * 
	 * @param entityClass
	 * @param id
	 * @return T
	 */
	public <T> T load(Class<T> entityClass, Serializable id) {
		Assert.notNull(id, "id is required");
		return (T) getSession().load(entityClass, id);
	}
	
	/**
	 * 通过hql查询语句查找HashMap对象
	 * 
	 * @param hql 参数以"?"占位
	 * @param objects 参数数组
	 * @return Map<Object, Object>
	 */
	public Map<Object, Object> getMapByQuery(String hql, Object ... param) {
		Query query = getSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				query.setParameter(i, param[i]);
			}
		}
		List list = query.list();
		Map<Object, Object> map = new HashMap<Object, Object>();
		for (Iterator iterator = list.iterator(); iterator.hasNext();) {
			Object[] tm = (Object[]) iterator.next();
			map.put(tm[0].toString(), tm[1].toString());
		}
		return map;
	}
	
	/**
	 * 获取所有实体对象总数
	 * 
	 * @param entityClass
	 * @return Long
	 */
	public Long getTotalCount(Class entityClass) {
		String hql = "select count(*) from " + entityClass.getName();
		return (Long) getSession().createQuery(hql).uniqueResult();
	}
	
	/**
	 * 获取序列号
	 * 
	 * @param sequnceName      
	 * @return Long
	 */
	public Long getSequnce(String sequnceName) {
		String sql = "select " + sequnceName + ".nextval as key from dual";
		Long seq = ((BigDecimal) getSession().createSQLQuery(sql)
				.uniqueResult()).longValue();
		return seq;
	}
	
	/**
	 * 通过hql查询唯一对象
	 * 
	 * @param hql 参数以"?"占位
	 * @param param 参数数组
	 * @return T
	 */
	public <T> T singleResult(String hql, Object... param) {
		T t = null;
		Query query = getSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				query.setParameter(i, param[i]);
			}
		}
		List<T> list = query.list();
		if (list.size() == 1) {
			//getSession().flush();
			t = list.get(0);
		}
		return t;
	}

	/**
	 * 根据实体名字获取唯一记录
	 * 
	 * @param propertyName
	 * @param value
	 * @return T
	 */
	public <T> T findUniqueByProperty(Class<T> entityClass, String propertyName, Object value) {
		return (T) createCriteria(entityClass, Restrictions.eq(propertyName, value)).uniqueResult();
	}
	
	/**
	 * 按属性和属性值查找对象列表
	 * 
	 * @param propertyName
	 * @param value
	 * @return List<T>
	 */
	public <T> List<T> findListByProperty(Class<T> entityClass,String propertyName, Object value) {
		return (List<T>) createCriteria(entityClass, Restrictions.eq(propertyName, value)).list();
	}
	
	/**
	 * 按属性和属性值查找对象列表
	 * 
	 * @param propertyMap
	 *           查询条件(key:属性名,value:属性值)
	 * @param orderMap
	 *          排序条件（key:属性名,value:是否按升序排列）
	 * @return List<T>
	 */
	public <T> List<T> findListByPropertyMap(Class<T> entityClass,Map<String,Object> propertyMap,Map<String,Boolean> orderMap) {
		Assert.notNull(propertyMap, "property must not be null");
		return (List<T>) createCriteria(entityClass,orderMap, Restrictions.allEq(propertyMap)).list();
	}
	
	

	/**
	 * 按参数数组查找对象列表(hql)
	 * 
	 * @param hql
	 * @param param
	 * @return List<T>
	 */
	public <T> List<T> findListByHql(String hql, Object... param) {
		Query query = getSession().createQuery(hql);
		
		for(int i = 0;i < param.length;i++){
			query.setParameter(i, param[i]);
		}
		return query.list();
	}
	
	/**
	 * 根据hql取前几条数据(hql)
	 * 
	 * @param hql
	 * @param param
	 * @return List<T>
	 */
	public <T> List<T> findListByHqlBef(String hql,int count, Object... param) {
		Query query = getSession().createQuery(hql);
		
		for(int i = 0;i < param.length;i++){
			query.setParameter(i, param[i]);
		}
		if(count > 0){
			query.setMaxResults(count);
		}
		return query.list();
	}

	/**
	 * 按参数数组查找对象列表(sql)
	 * 
	 * @param hql
	 * @param param
	 * @return List<T>
	 */
	public <T> List<T> findListBySql(String sql, Object... param) {
		Query query = getSession().createSQLQuery(sql);
		for(int i = 0;i < param.length;i++){
			query.setParameter(i, param[i]);
		}
		return query.list();
	}
	
	/**
	 * 根据sql取前几条数据
	 * 
	 * @param <T>
	 * @param sql
	 * @param count
	 *            取得最大条数
	 * @param param
	 * @return
	 */
	public <T> List<T> findListBySqlBef(String sql,int count, Object... param){
		Query query = getSession().createSQLQuery(sql);
		for(int i = 0;i < param.length;i++){
			query.setParameter(i, param[i]);
		}
		if(count > 0){
			query.setMaxResults(count);
		}
		
		return query.list();
	}


	/**
	 * 按属性和属性值排序查找对象列表
	 * 
	 * @param entityClass
	 * @param propertyName
	 * @param value
	 * @param isAsc
	 * @return List<T>
	 */
	public <T> List<T> findByPropertyisOrder(Class<T> entityClass,String propertyName, Object value, boolean isAsc) {
		return createCriteria(entityClass, isAsc, Restrictions.eq(propertyName, value)).list();
	}

	/**
	 * 按模板查询对象列表
	 * 
	 * @param entityName
	 * @param exampleEntity
	 * @return List<T>
	 */
	public List findListByExample(String entityName, Object exampleEntity) {
		Assert.notNull(exampleEntity, "Example entity must not be null");
		Criteria criteria = (entityName != null ? getSession().createCriteria(entityName) : getSession().createCriteria(exampleEntity.getClass()));
		criteria.add(Example.create(exampleEntity));
		return criteria.list();
	}
	
	
	
	private <T> Criteria createCriteria(Class<T> entityClass, Criterion... criterions) {
		Criteria criteria = getSession().createCriteria(entityClass);
		for (Criterion c : criterions) {
			criteria.add(c);
		}
		return criteria;
	}

	
	private <T> Criteria createCriteria(Class<T> entityClass, boolean isAsc, Criterion... criterions) {
		Criteria criteria = createCriteria(entityClass, criterions);
		if (isAsc) {
			criteria.addOrder(Order.asc("asc"));
		} else {
			criteria.addOrder(Order.desc("desc"));
		}
		return criteria;
	}
	
	private <T> Criteria createCriteria(Class<T> entityClass, Map<String,Boolean> orderMap, Criterion... criterions) {
		Criteria criteria = createCriteria(entityClass, criterions);
		if (orderMap != null) {
			for (Entry<String, Boolean> entry : orderMap.entrySet()) {
				if(entry.getValue()){
					criteria.addOrder(Order.asc(entry.getKey()));
				} else {
					criteria.addOrder(Order.desc(entry.getKey()));
				}
			}
		} 
		return criteria;
	}

	//-------------sessionFactory write-------------
	private SessionFactory sessionFactoryWrite;
	
	@Resource(name="sessionFactoryWrite")
	public void setSessionFactoryWrite(SessionFactory sessionFactoryWrite) {
		this.sessionFactoryWrite = sessionFactoryWrite;
	}

	public Session getSessionWrite(){
		return sessionFactoryWrite.getCurrentSession();
	}
	
	/**
	 * 根据传入的实体添加对象
	 * 
	 * @param entity
	 */
	public <T> void save(T entity) {
		getSessionWrite().save(entity);
	}
	
	/**
	 * 保存实体对象.
	 * 
	 * @param entity
	 *            对象
	 * @return ID
	 */
	public <T,Pk> Pk saveReturnPk(T entity) {
		Assert.notNull(entity, "entity不能为空");
		return (Pk) getSessionWrite().save(entity);
		
	}
	
	/**
	 * 根据传入的实体添加或更新对象
	 * 
	 * @param entity
	 */
	public <T> void saveOrUpdate(T entity) {
		getSessionWrite().saveOrUpdate(entity);
		//getSessionWrite().flush();
	}
	
	/**
	 * 批量保存数据
	 * @param <T>
	 * @param entitys 要持久化的临时实体对象集合
	 */
	public <T> void batchSave(List<T> entitys) {
		for (int i=0; i<entitys.size();i++) {
			getSessionWrite().save(entitys.get(i));
		}		
	}	
	
	/**
	 * 根据传入的实体添加对象
	 * 
	 * @param entity
	 */
	public <T> void delete(T entity) {
		Assert.notNull(entity, "entity不能为空");
		getSessionWrite().delete(entity);
	}

	/**
	 * 按ID删除实体
	 * 
	 * @param <T>
	 * 
	 * @param entitys
	 */
	public <T> void deleteEntityById(Class<T> entityClass, Serializable id) {
		delete(get(entityClass, id));
	}
	
	/**
	 * 删除全部的实体
	 * 
	 * @param <T>
	 * 
	 * @param entitys
	 */
	public <T> void deleteAllEntities(Collection<T> entitys) {
		for (Object entity : entitys) {
			getSessionWrite().delete(entity);
		}
	}
	
	/**
	 * 更新指定的实体
	 * 
	 * @param <T>
	 * @param pojo
	 */
	public <T> void update(T entity) {
		getSessionWrite().update(entity);
		//getSessionWrite().flush();
	}

	/**
	 * 更新指定的实体
	 * 
	 * @param className
	 * @param obj
	 */
	public void update(String className, Object obj) {
		getSessionWrite().update(className, obj);
		//getSessionWrite().flush();
	}
	
	/**
	 * 更新指定的实体
	 * 
	 * @param entityName
	 * @param id
	 */
	public void updateEntityById(Class entityName, Serializable id) {
		update(get(entityName, id));
	}
	
	/**
	 * 通过sql更新记录
	 * 
	 * @param sql
	 * @return
	 */
	public int updateBySql(String sql,Object... param) {
		Query query = getSessionWrite().createSQLQuery(sql);
		for(int i = 0;i < param.length;i++){
			query.setParameter(i, param[i]);
		}
		return query.executeUpdate();
	}
	
	/**
	 * 通过hql更新记录
	 * 
	 * @param hql
	 * @return
	 */
	public int updateByHql(String hql,Object... param) {
		Query query = getSessionWrite().createQuery(hql);
		for(int i = 0;i < param.length;i++){
			query.setParameter(i, param[i]);
		}
		return query.executeUpdate();
	}
}

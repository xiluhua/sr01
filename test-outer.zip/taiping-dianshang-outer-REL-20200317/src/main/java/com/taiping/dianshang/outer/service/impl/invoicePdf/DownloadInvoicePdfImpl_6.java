package com.taiping.dianshang.outer.service.impl.invoicePdf;

import java.io.DataOutputStream;
import java.io.File;
import java.io.OutputStream;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspCheckBillRequest;
import com.taiping.dianshang.exception.DownloadPolicyPdfException;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.service.DownloadInvoicePdfService;
import com.taiping.dianshang.outer.service.IspApplyService;
import com.taiping.dianshang.utils.Md5;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PdfDownloadTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * <b>Title: 下载电子发票</b>
 * <p>Description: </p>
 * 
 * @author H.Yang
 * @email xhaimail@163.com
 * @date 2019/04/24
 */
@Service
public class DownloadInvoicePdfImpl_6 implements DownloadInvoicePdfService {

	@Resource
	private IspApplyService ispApplyService;

	@Transactional
	public String download(String policyNo, String idNo) {
		String path = null;
		OutputStream outputStream = null;
		DataOutputStream dout = null;
		try {
			IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
			if (apply == null || !apply.getHolder().getIdNo().equalsIgnoreCase(idNo)) {
				throw new DownloadPolicyPdfException();
			}

			IspCheckBillRequest ispCheckBillRequest = CacheContainer.getByIdFromCache(apply.getBlueId(), IspCheckBillRequest.class);

			String dir = PropertyFileTool.get("invoice.pdf.dir");
			if (!new File(dir).exists()) {
				new File(dir).mkdirs();
			}
			path = dir + policyNo + ".pdf";
			LogTool.info(this.getClass(), "download.pdf.dir.path：" + path);

			String url = CacheContainer.getSystemParameterValueNoThrows("tianan.invoice.download.url");

			LogTool.info(this.getClass(), "invoice.download.url: " + url);
			PdfDownloadTool httpClient = new PdfDownloadTool();

			httpClient.addParameter("sign", Md5.EncoderByMd5(ispCheckBillRequest.getToken() + policyNo));
			httpClient.addParameter("PolicyNo", policyNo);
			httpClient.addParameter("corporation", ispCheckBillRequest.getCooperation());

			String useProxy = CacheContainer.getSystemParameterValueNoThrows("tianan.invoice.use.proxy");
			if (!StringUtils.isEmpty(useProxy)) {
				String agentIp = CacheContainer.getSystemParameterValue("internet.proxy2");
				LogTool.info(this.getClass(), "    agentIp : " + agentIp);
				String[] arrProxy = agentIp.split(":");
				httpClient.setProxy(arrProxy[0], arrProxy[1]);
				if (LogTool.isLocal) {
					httpClient.setProxy("10.4.233.50", "31151");
				}
			}
			

			httpClient.persistentPDF(url, path);
		} catch (Exception e) {
			path = null;
			LogTool.error(this.getClass(), e);
			throw new DownloadPolicyPdfSysException();
		} finally {
			try {
				if (outputStream != null) {
					outputStream.close();
				}
				if (dout != null) {
					dout.close();
				}
			} catch (Exception e2) {
				LogTool.error(this.getClass(), e2);
			}
		}

		return path;
	}

}

package com.taiping.dianshang.outer.service;

/**
 * <b>Title: 下载电子发票</b>
 * <p>Description: </p>
 * 
 * @author H.Yang
 * @email xhaimail@163.com
 * @date 2019/04/24
 */
public interface DownloadInvoicePdfService {

	/**
	 * 从核心系统下载电子发票
	 * @param policyNo
	 * @param idNo
	 * @return
	 */
	public String download(String policyNo, String idNo);

}

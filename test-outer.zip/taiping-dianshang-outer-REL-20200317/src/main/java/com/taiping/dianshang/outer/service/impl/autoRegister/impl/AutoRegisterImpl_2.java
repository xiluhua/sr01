package com.taiping.dianshang.outer.service.impl.autoRegister.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.outer.service.impl.autoRegister.AutoRegisterService;
import com.taiping.dianshang.outer.service.impl.autoRegister.UniformUserIdentityService;
import com.taiping.facility.tool.StringTool;

/**
 * Created by lk on 2017/11/28.
 */
@Service
public class AutoRegisterImpl_2 implements AutoRegisterService {
   @Resource
   private IspApplyDao ispApplyDao;
    @Resource
    private IspPolicyDao ispPolicyDao;
    @Resource(name="uniformUserIdentityImpl_2")
    private UniformUserIdentityService uniformUserIdentityService;

    @Override
    @Transactional
    public void handle(Map<String, Object> paramsMap) {
        // 保单号
        String partnerApplyId = StringTool.nullToEmpty(paramsMap.get("operateNo"));
        IspApply apply = ispApplyDao.loadApply(partnerApplyId, null, null, null);
        if (StringUtils.isEmpty(apply.getUserId())) {
            try {
                String userId = uniformUserIdentityService.autoRegister(apply,apply.getHolder().getMobile());
                if (!StringUtils.isEmpty(userId)) {
                    apply.setUserId(userId);
                    // 更新 userId 到 IspApply
                    ispApplyDao.update(apply);
                    // 更新 userId 到 IspPolicy
                    IspPolicy policy = ispPolicyDao.load(apply.getPolicyNo());
                    if (policy != null) {
                        policy.setUserId(userId);
                        ispPolicyDao.update(policy);
                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}

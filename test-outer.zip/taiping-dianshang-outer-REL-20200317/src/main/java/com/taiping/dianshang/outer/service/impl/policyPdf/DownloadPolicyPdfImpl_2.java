package com.taiping.dianshang.outer.service.impl.policyPdf;

import org.springframework.stereotype.Component;

import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;

@Component
public class DownloadPolicyPdfImpl_2 extends DownloadPolicyPdfImpl_3 implements DownloadPolicyPdfService{
	
	
}

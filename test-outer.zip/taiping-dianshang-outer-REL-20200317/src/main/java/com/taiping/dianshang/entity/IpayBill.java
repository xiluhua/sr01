package com.taiping.dianshang.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ScIpayBill entity. 
 */
@Entity
@Table(name = "DS_IPAY_BILL")
public class IpayBill implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	
	// Fields
	private Long billId;
	private String partnerBillId;
	private Long applyId;
	private double amount;
	private Integer status;
	private Integer payStatus;
	private Long payerId;
	private Date payTime;
	private Date createTime;
	private Date updateTime;
	
	// Constructors

	/** default constructor */
	public IpayBill() {
	}

	/** minimal constructor */
	public IpayBill(Long billId) {
		this.billId = billId;
	}

	// Property accessors
	@Column(name = "AMOUNT", precision = 12)
	public double getAmount() {
		return this.amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}
	
	@Id
	@Column(name = "BILL_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getBillId() {
		return this.billId;
	}

	public void setBillId(Long billId) {
		this.billId = billId;
	}

	@Column(name = "PARTNER_BILL_ID", length = 40)
	public String getPartnerBillId() {
		return this.partnerBillId;
	}

	public void setPartnerBillId(String partnerBillId) {
		this.partnerBillId = partnerBillId;
	}

	
	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "PAY_STATUS", precision = 3, scale = 0)
	public Integer getPayStatus() {
		return this.payStatus;
	}

	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	@Column(name = "PAYER_ID", precision = 10, scale = 0)
	public Long getPayerId() {
		return this.payerId;
	}

	public void setPayerId(Long payerId) {
		this.payerId = payerId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PAY_TIME")
	public Date getPayTime() {
		return this.payTime;
	}

	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	//@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "scIpayBill")
//	@Transient
//	public Set<IpayBillGoods> getBillGoods() {
//		return this.billGoods;
//	}
//
//	public void setBillGoods(Set<IpayBillGoods> scIpayBillGoodses) {
//		this.billGoods = scIpayBillGoodses;
//	}
	@Column(name = "APPLY_ID")
	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

}
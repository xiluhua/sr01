package com.taiping.dianshang.exception;


public class SignVerifyException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public SignVerifyException(String msg){
		super(msg);
	}
	
	public SignVerifyException(){
		super();
	}
}


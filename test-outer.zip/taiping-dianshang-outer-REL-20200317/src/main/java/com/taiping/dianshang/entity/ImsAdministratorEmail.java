package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * ImsDictionary entity. 
 */
@Entity
@Table(name = "IMS_ADMINISTRATOR_EMAIL")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsAdministratorEmail implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	@Id
	@Column(name = "id", length = 20)
	private Long id;
	@Column(name = "SERVICE")
	private String service;
	@Column(name = "ADMIN_NAME")
	private String adminName;
	@Column(name = "EMAIL")
	private String email;
	@Column(name = "STATUS")
	private Integer status;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;

	// Constructors

	/** default constructor */
	public ImsAdministratorEmail() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
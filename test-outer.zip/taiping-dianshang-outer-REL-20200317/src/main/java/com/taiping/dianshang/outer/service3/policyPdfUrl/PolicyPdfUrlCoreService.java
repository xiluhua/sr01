package com.taiping.dianshang.outer.service3.policyPdfUrl;

import com.taiping.dianshang.outer.service3.CoreService;

/**
 * @author Li.Wei  2019/9/3 11:05 AM
 * @version 1.0
 * @since TODO
 */
public interface PolicyPdfUrlCoreService extends CoreService {

}

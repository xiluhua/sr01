package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.ImsAdministratorEmail;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class ImsAdministratorEmailDao extends BaseWriteDao<ImsAdministratorEmail, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<ImsAdministratorEmail> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				ImsAdministratorEmail obj = list.get(i);
				if (obj.getEmail() != null) {
					String key = KeyTool.get(ImsAdministratorEmail.class,obj.getEmail());
					map.put(key, JsonTool.toJson(obj));	
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<ImsAdministratorEmail> getAll(){
		String hql = "from ImsAdministratorEmail t";
		return super.getSession().createQuery(hql).list();
	}
}
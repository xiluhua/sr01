package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 联通导航承保短信发送服务
 * @author xilh
 * @since 20170321
 */

@Service
public class ShortMsgImpl_CBCG_200000022 extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	
	// add by xiluhua 20171206
	private static HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();

	static{
		map.put(0, 0);
		map.put(1, 1);
		map.put(2, 2);
		map.put(3, 3);
		map.put(4, 4);
		map.put(5, 5);
		map.put(6, 6);
		map.put(21, 21);
		map.put(22, 22);
		map.put(23, 23);
	}
	
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		try {
			if (new Date().before(DateTool.getDateTime("2018-01-01", "yyyy-MM-dd"))) {
				// add by xiluhua 20171130
				// 在任务暂停时间内，sleep 1 minute a time
				boolean isPause = isPause();
				if (isPause) {
					String t2 = DateTool.convertDataToString(new Date(), DateTool.DATE_TIME_MASK);
					LogTool.debug(this.getClass(), "is in ltdh.shortmsg.pause.time: "+t2);
					return;
				}
			}
			
			IspBlueprint blueprint = null;
			String wxhome = CacheContainer.getSystemParameterValue(ConstantTool.WXHOME);
			shortMsgParamMap.put("wxhome", wxhome);
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
			// 保单号
	        String partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
	        
	        LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
	        
	        IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply != null) {
				blueprint = CacheContainer.getByIdFromCacheThrows(apply.getBlueId(), IspBlueprint.class);
			}else {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			shortMsgParamMap.put("mobile", apply.getHolder().getMobile());
			shortMsgParamMap.put("blueName", blueprint.getBlueInnerName());
			apply.setInsuranceType(blueprint.getInsuranceType());
			
			// 2,构造短信内容
			String shortMsgContent = this.getContent(shortMsgParamMap,apply);
			LogTool.debug(this.getClass(), "shortMsgContent："+shortMsgContent);
			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
			// 3,构造短信对象
			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);

			//4,启动后台线程，发送短信
			String result = super.send(shortMsg, apply);
			if (result.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
				IspSendHistory ispSendHistory = ispSendHistoryDao.load(apply.getApplyId());
				ispSendHistory.setIsShortmsgSend(1);
				ispSendHistoryDao.update(ispSendHistory);
			}
			
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply){
		String content = "";			//短信内容
		String holderSex = "";
		String holderName = "";
		String partnerApplyId = apply.getPartnerApplyId();
		IspCustomer holder = apply.getHolder(); 
		holderName = holder.getCustName();
		if (holder.getGender() == 1) {
			holderSex = "先生";
		} else {
			holderSex= "女士";
		}
		
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put("holderName", holderName);
		context.put("holderSex", holderSex);
		context.put("blueName", MapTool.getStringFromMap(shortMsgParamMap, "blueName"));
		context.put("partnerApplyId", partnerApplyId);
		context.put("polno", apply.getPolicyNo());
		context.put("userName", holder.getCustName());
		context.put("wxhome", shortMsgParamMap.get("wxhome"));
		context.put("validateDate", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK));
		context.put("expirationDate", DateTool.convertDataToString(apply.getExpirationDate(), DateTool.DATE_MASK));

		content = TemplateToolV1218.fill(context, ConstantTool.SHORTMSG_TEMPLATE_PATH, ConstantTool.SHORT_CB_LTDH,"UTF-8","GBK"); // 填充模板  得到短信内容
		
		return content;
	}
	
	public boolean isPause(){
		String t1 = DateTool.convertDataToString(new Date(), "HH");
		Integer key = new BigDecimal(t1).intValue();
		if (map.containsKey(key)) {
			System.out.println("in pause hour!!!");
			return true;
		}else {
			System.out.println("OK");
			return false;
		}
	}
	
	public static void main(String[] args) throws ParseException {
//		String startEnd = "#TODAY 20:00:00;#YEDAY 08:00:00";
//		String t1 = DateTool.convertDataToString(new Date(), "yyyy-MM-dd");
//		String t2 = DateTool.convertDataToString(DateTool.getTomorrow(), "yyyy-MM-dd");
//		startEnd = startEnd.replace("#TODAY", t1);
//		startEnd = startEnd.replace("#YEDAY", t2);
//		System.out.println(startEnd);
//		System.out.println(new Date().before(DateTool.getDateTime("2018-01-01", "yyyy-MM-dd")));
		
		String t2 = DateTool.convertDataToString(new Date(), DateTool.DATE_TIME_MASK);
		System.out.println(t2);
		System.out.println("t2: "+t2);
		
		String t1 = DateTool.convertDataToString(new Date(), "HH");
		System.out.println("t1: "+t1);
		Integer key = new BigDecimal(t1).intValue();
		if (map.containsKey(key)) {
			System.out.println("in pause hour!!!");
		}else {
			System.out.println("OK");
		}
	}
	
	
}

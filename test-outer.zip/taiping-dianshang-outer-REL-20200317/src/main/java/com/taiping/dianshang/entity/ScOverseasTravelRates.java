package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**   
 * @ClassName CXIspAcceptProperty   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "SC_OVERSEAS_TRAVEL_RATES")
public class ScOverseasTravelRates {
	@Id
	@Column(name="ID")
	private Long id;
	@Column(name="PRODUCT_AREA")
	private String product_area;
	@Column(name="DESTINATION")
	private String destination;
	@Column(name="PLAN_TYPE")
	private String planType;
	@Column(name="HIGH_RISK_SPORTS")
	private Long high_risk_spors;
	@Column(name="INSURANCE_SCHEME_START")
	private String insurance_scheme_start;
	@Column(name="INSURANCE_SCHEME_END")
	private String insurance_scheme_end;
	@Column(name="AMOUNT")
	private String amount;
	@Column(name="ONE_YEAR")
	private String one_year;
	@Column(name="FOUR_WEEKS")
	private String four_weeks;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getProduct_area() {
		return product_area;
	}
	public void setProduct_area(String product_area) {
		this.product_area = product_area;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}
	public Long getHigh_risk_spors() {
		return high_risk_spors;
	}
	public void setHigh_risk_spors(Long high_risk_spors) {
		this.high_risk_spors = high_risk_spors;
	}
	public String getInsurance_scheme_start() {
		return insurance_scheme_start;
	}
	public void setInsurance_scheme_start(String insurance_scheme_start) {
		this.insurance_scheme_start = insurance_scheme_start;
	}
	public String getInsurance_scheme_end() {
		return insurance_scheme_end;
	}
	public void setInsurance_scheme_end(String insurance_scheme_end) {
		this.insurance_scheme_end = insurance_scheme_end;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getOne_year() {
		return one_year;
	}
	public void setOne_year(String one_year) {
		this.one_year = one_year;
	}
	public String getFour_weeks() {
		return four_weeks;
	}
	public void setFour_weeks(String four_weeks) {
		this.four_weeks = four_weeks;
	}
	
	
	
	
}

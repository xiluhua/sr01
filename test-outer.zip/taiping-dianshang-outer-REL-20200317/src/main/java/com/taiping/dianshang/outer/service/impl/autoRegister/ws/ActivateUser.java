package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

/*
 * 激活用户所需的信息
 */
public class ActivateUser {
	
	private String userName;
	private String validateCode;  //邮箱手机验证码
	private String password;     //密码
	private String inviteCode;  //邀请码
	private String activateType;   //1为邮箱手机激活2为邀请码激活
	private String checkCode; //验证码
	private String enterpriseCode;
	private String accountId;
	private String employeeId;
	private String mallUserId;
	private Short registType;         //注册类型 1.信任链接(0,1,2,3)|2.标准(1,2)|3.邀请码(2)|9.其他(1) 
	private String registChannel;
	
	
	public String getRegistChannel() {
		return registChannel;
	}
	public void setRegistChannel(String registChannel) {
		this.registChannel = registChannel;
	}
	public String getMallUserId() {
		return mallUserId;
	}
	public void setMallUserId(String mallUserId) {
		this.mallUserId = mallUserId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public String getEnterpriseCode() {
		return enterpriseCode;
	}
	public void setEnterpriseCode(String enterpriseCode) {
		this.enterpriseCode = enterpriseCode;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getValidateCode() {
		return validateCode;
	}
	public void setValidateCode(String validateCode) {
		this.validateCode = validateCode;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getInviteCode() {
		return inviteCode;
	}
	public void setInviteCode(String inviteCode) {
		this.inviteCode = inviteCode;
	}
	
	public String getActivateType() {
		return activateType;
	}
	public void setActivateType(String activateType) {
		this.activateType = activateType;
	}
	public String getCheckCode() {
		return checkCode;
	}
	public void setCheckCode(String checkCode) {
		this.checkCode = checkCode;
	}
	public Short getRegistType() {
		return registType;
	}
	public void setRegistType(Short registType) {
		this.registType = registType;
	}
	
	

}

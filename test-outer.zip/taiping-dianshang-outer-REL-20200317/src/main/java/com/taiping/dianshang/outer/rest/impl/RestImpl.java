package com.taiping.dianshang.outer.rest.impl;

import java.io.IOException;
import java.util.Date;

import javax.annotation.Resource;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonProcessingException;

import com.opensymphony.xwork2.ActionSupport;
import com.taiping.dianshang.outer.rest.RestService;
import com.taiping.facility.cache.CacheService;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;

/**
 * 
 * @author xilh by 20160119
 *
 */
@Path("/business")
@Produces({"plain/text"})
@Consumes({"plain/text"})
public class RestImpl implements RestService{

	@Resource
	private CacheService cacheService;
	
	@GET
	@Path(value = "/cacheRefresh")
	// http://localhost:7002/taiping-dianshang-outer/services/rest/business/cacheRefresh
	public String cacheRefresh(){
		cacheService.init();
		return ActionSupport.SUCCESS;
	}
	
	@POST
	@Path(value = "/entrance")
	// http://localhost:7788/taiping-dianshang-core/services/rest/core/business/entrance
	public String entrance(String requestMsg){
		
		LogTool.debug(this.getClass(), "");
		LogTool.debug(this.getClass(), "");
		LogTool.debug(this.getClass(), "=============== arrived at RestImpl !!! ===============");
		LogTool.debug(this.getClass(), requestMsg);
		LogTool.debug(this.getClass(), "");
		LogTool.debug(this.getClass(), DateTool.getDateTime(DateTool.DATE_TIME_MASK, new Date()));
		
		return null;
	}
	
	public String getServiceCode(String requestMsg){
		String service = null;
		try {
			JsonNode nodeTransInfo = JsonTool.readValue(requestMsg, "transInfo");
			JsonNode nodeServiceCode = nodeTransInfo.path("serviceCode");
			service = nodeServiceCode.getTextValue();
		} catch (JsonProcessingException e) {
			LogTool.error(this.getClass(), e);
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
		}
		
		return service;
	}
	
	public static void main(String[] args) {
		String sssString = "{";
		System.out.println(sssString.startsWith("{"));
	}
}

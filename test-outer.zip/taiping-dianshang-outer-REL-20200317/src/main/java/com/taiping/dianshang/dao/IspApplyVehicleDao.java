package com.taiping.dianshang.dao;

import javax.annotation.Resource;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.taiping.dianshang.entity.IspApplyVehicle;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.ICommonDao;

@Repository
@Transactional
public class IspApplyVehicleDao extends BaseWriteDao<IspApplyVehicle, Long>{
	@Resource
	private ICommonDao commonDao;
	
	public IspApplyVehicle getApplyVehicle(Long applyId) {
		String hql = "from IspApplyVehicle t where t.applyId = ?";
		Object [] objects = {applyId};
		IspApplyVehicle vehicle = (IspApplyVehicle) commonDao.singleResult(hql, objects);
		return vehicle;
	}
}

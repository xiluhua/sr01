package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspPolicyDao extends BaseWriteDao<IspPolicy, String>{
	public IspPolicy getIspPolicy(String policyNo){
		return super.get("policyNo", policyNo);
	}
}

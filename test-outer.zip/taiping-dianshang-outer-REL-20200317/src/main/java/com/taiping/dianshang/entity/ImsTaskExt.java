package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ScImsTaskExt entity. 
 */
@Entity
@Table(name = "SC_IMS_TASK_EXT")
public class ImsTaskExt implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long taskExtId;
	private Integer status;
	private String resultDes;
	private Date requestTime;
	private Date responseTime;
	private String url;
	private String taskClass;
	private String parameter;
	private Long taskId;
	private String memo;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	
	// Constructors

	/** default constructor */
	public ImsTaskExt() {
	}

	/** minimal constructor */
	public ImsTaskExt(Long taskExtId) {
		this.taskExtId = taskExtId;
	}

	/** full constructor */
	public ImsTaskExt(Long taskExtId, Integer status, String resultDes,
			Date requestTime, Date responseTime, String url,
			String taskClass, String parameter, Long taskId, String memo,
			Date createTime, Date updateTime, String createAid,
			String updateAid) {
		this.taskExtId = taskExtId;
		this.status = status;
		this.resultDes = resultDes;
		this.requestTime = requestTime;
		this.responseTime = responseTime;
		this.url = url;
		this.taskClass = taskClass;
		this.parameter = parameter;
		this.taskId = taskId;
		this.memo = memo;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
	}

	// Property accessors

	@Id
	@Column(name = "TASK_EXT_ID", nullable = false, precision = 20, scale = 0)
	public Long getTaskExtId() {
		return this.taskExtId;
	}

	public void setTaskExtId(Long taskExtId) {
		this.taskExtId = taskExtId;
	}

	@Column(name = "STATUS", precision = 3, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "RESULT_DES", length = 1000)
	public String getResultDes() {
		return this.resultDes;
	}

	public void setResultDes(String resultDes) {
		this.resultDes = resultDes;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "REQUEST_TIME")
	public Date getRequestTime() {
		return this.requestTime;
	}

	public void setRequestTime(Date requestTime) {
		this.requestTime = requestTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "RESPONSE_TIME")
	public Date getResponseTime() {
		return this.responseTime;
	}

	public void setResponseTime(Date responseTime) {
		this.responseTime = responseTime;
	}

	@Column(name = "URL", length = 200)
	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	@Column(name = "TASK_CLASS", length = 200)
	public String getTaskClass() {
		return this.taskClass;
	}

	public void setTaskClass(String taskClass) {
		this.taskClass = taskClass;
	}

	@Column(name = "PARAMETER", length = 1000)
	public String getParameter() {
		return this.parameter;
	}

	public void setParameter(String parameter) {
		this.parameter = parameter;
	}

	@Column(name = "TASK_ID")
	public Long getTaskId() {
		return this.taskId;
	}

	public void setTaskId(Long taskId) {
		this.taskId = taskId;
	}

	@Column(name = "MEMO", length = 500)
	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

}
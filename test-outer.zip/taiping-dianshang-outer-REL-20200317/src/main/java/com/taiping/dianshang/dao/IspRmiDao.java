package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspRmi;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspRmiDao extends BaseWriteDao<IspRmi, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<IspRmi> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspRmi rmi = list.get(i);
				if (rmi.getId() != null) {
					String key = KeyTool.get(IspRmi.class, String.valueOf(rmi.getId()));
					map.put(key, JsonTool.toJson(rmi));		
				}
				
				if (rmi.getBlueId() != null) {
					String key = KeyTool.get(IspRmi.class, String.valueOf(rmi.getBlueId()));
					map.put(key, JsonTool.toJson(rmi));	
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspRmi> getAll(){
		String hql = "from IspRmi t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
}
package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspSendHistoryDao  extends BaseWriteDao<IspSendHistory, Long>{
	
	public Long save(IspSendHistory entity){
			Long id = super.save(entity);
		return id;
	}
}

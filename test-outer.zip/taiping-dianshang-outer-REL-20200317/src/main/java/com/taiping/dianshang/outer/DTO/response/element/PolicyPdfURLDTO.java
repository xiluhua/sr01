package com.taiping.dianshang.outer.DTO.response.element;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"policyUrl",
		"policyByteString"
})
public class PolicyPdfURLDTO {

	@XmlElement(name = "POLICY_URL")
	private String policyUrl = "";   // 首期保费
	// add by xiluhua 20200206
	@XmlElement(name = "POLICY_BYTE_STRING")
	private String policyByteString = "";
	
	public String getPolicyUrl() {
		return policyUrl;
	}
	public void setPolicyUrl(String policyUrl) {
		this.policyUrl = policyUrl;
	}
	public String getPolicyByteString() {
		return policyByteString;
	}
	public void setPolicyByteString(String policyByteString) {
		this.policyByteString = policyByteString;
	}

}

package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * 新词典数据表，为不影响老业务
 * @author xiluhua
 * @since 20180807
 */
@Entity
@Table(name = "DS_IMS_DICTIONARY")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class DsImsDictionary implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long dictId;
	private String dictCode;
	private String dictName;
	private String columnList;
	private String dictExpress;
	private String memo;
	private Integer status;
	private String systemCode;
	private Date createDate;
	private Date updateDate;

	// Constructors

	/** default constructor */
	public DsImsDictionary() {
	}

	/** minimal constructor */
	public DsImsDictionary(Long dictId) {
		this.dictId = dictId;
	}

	/** full constructor */
	public DsImsDictionary(Long dictId, String dictCode, String dictName,
			String columnList, String dictExpress, String memo,
			Date createDate, Date updateDate, String createAid,
			String updateAid) {
		this.dictId = dictId;
		this.dictCode = dictCode;
		this.dictName = dictName;
		this.columnList = columnList;
		this.dictExpress = dictExpress;
		this.memo = memo;
		this.createDate = createDate;
		this.updateDate = updateDate;
	}

	// Property accessors
	@Id
	@Column(name = "DICT_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getDictId() {
		return this.dictId;
	}

	public void setDictId(Long dictId) {
		this.dictId = dictId;
	}

	@Column(name = "DICT_CODE", length = 50)
	public String getDictCode() {
		return this.dictCode;
	}

	public void setDictCode(String dictCode) {
		this.dictCode = dictCode;
	}

	@Column(name = "DICT_NAME", length = 100)
	public String getDictName() {
		return this.dictName;
	}

	public void setDictName(String dictName) {
		this.dictName = dictName;
	}

	@Column(name = "COLUMN_LIST", length = 2000)
	public String getColumnList() {
		return this.columnList;
	}

	public void setColumnList(String columnList) {
		this.columnList = columnList;
	}

	@Column(name = "DICT_EXPRESS", length = 4000)
	public String getDictExpress() {
		return this.dictExpress;
	}

	public void setDictExpress(String dictExpress) {
		this.dictExpress = dictExpress;
	}

	@Column(name = "MEMO", length = 500)
	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_DATE")
	public Date getCreateDate() {
		return this.createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_DATE")
	public Date getUpdateDate() {
		return this.updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	@Column(name = "SYSTEM_CODE")
	public String getSystemCode() {
		return systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}
}
package com.taiping.dianshang.outer.service.impl.email.content;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspEmailTemplate;
import com.taiping.dianshang.entity.IspRenewInfo;
import com.taiping.dianshang.outer.service.ContentService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.DesTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.TemplateToolV1218;

@Service
public class ContentImpl implements ContentService{
	
	@Resource
	BusinesslogService businesslogService;
	
	/**
	 * 得到邮件正文
	 * @author xilh
	 * @since 20181009
	 * @return
	 */
	public String getContent(IspApply apply, IspEmailTemplate template)
	{
		String blueName = "";
		IspBlueprint blueprint = CacheContainer.getByIdFromCache(apply.getBlueId(), IspBlueprint.class);
		if (blueprint == null) {
			String msg = "partnerApplyId: "+apply.getPartnerApplyId()+", IspBlueprint is empty";
			LogTool.error(this.getClass(), msg);
			businesslogService.postBusinessOpelog_2(apply, msg, ConstantTool.INTERFACE_F_108_SENDEMAIL, 2, 1);
		}else {
			blueName = StringUtils.defaultString(blueprint.getBlueInnerName());
		}
		String realName = apply.getHolder().getCustName();
		String policyNo = apply.getPolicyNo();
		String insuredName = apply.getInsured().getCustName();
		String emailContent = "";        	//邮件内容
		// 获取一个新的模板上下文,生成邮件内容
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy年MM月dd日");
		Date date = new Date();
		String sysdate=sdf.format(date);
		
		VelocityContext context = new VelocityContext();
		context.put("realName", realName);
		context.put("policyNo", policyNo);
		context.put("sysdate", sysdate);
		context.put("insuredName", insuredName);
		context.put("blueName", blueName);
		context.put("apply", apply);
		
		String noPdfBlues = StringUtils.defaultString(CacheContainer.getSystemParameterValueNoThrows("no.pdf.blues"));
		if (noPdfBlues.indexOf(apply.getBlueId()+",") < 0) {
			String tmp = apply.getPolicyNo()+"_"+apply.getHolder().getIdNo();
			tmp = new DesTool().getEncString(tmp);
			String url = StringUtils.defaultString(CacheContainer.getSystemParameterValueNoThrows("outr.policy.pdf.url"));
			url = url.replace("#policyNoEnc", tmp);
			context.put("pdfUrl", url);
		}
		
		if (apply.getValidateDate() != null) {
			context.put("validDate1", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK));
			context.put("validDate2", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK2));
			context.put("validDate3", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK3));
		}
		
		//emailContent = TemplateToolV1218.fill(context, ConstantTool.EMAIL_TEMPLATE_PATH, ConstantTool.CBCG,"UTF-8","GBK"); // 填充模板  得到邮件内容
		
		emailContent = TemplateToolV1218.fill(context, template.getTemplate()); // 填充模板  得到邮件内容
		return emailContent;
	}

	@Override
	public String getContent(IspApply apply, IspRenewInfo renewInfo,
			IspEmailTemplate template) {
		return null;
	}
	
}

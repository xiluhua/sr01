package com.taiping.dianshang.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspApply entity.
 */
@Entity
@Table(name = "SC_ISP_APPLY")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspApply implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    // Fields
    private Long applyId;
    private String appNo;
    private String policyNo;
    private Integer applyType;
    private Integer RHolderInst;
    private Integer beneficiaryType;
    private Integer chargeType;
    private Integer chargeYear;
    private Integer amount;
    private Integer bonusMode;
    private Double discount;
    private Double premium;
    private Integer checkStatus;
    private Integer checkruleStatus;
    private Integer payStatus;
    private Long payId;
    private Integer checkBillStatus;
    private String bankCode;
    private Integer isAgreed;
    private Integer isCanceled;
    private Date applyTime;
    private Date checkTime;
    private Date checkruleTime;
    private Date acceptTime;
    private Date validateDate;
    private Date expirationDate;
    private Integer deliverType;
    private String deliverAddress;
    private String userId;
    private Long blueId;
    private Long baleId;
    private Long organId;
    private Long lv1AreaId;
    private Long lv2AreaId;
    private Long partnerId;
    private Long linkId;
    private Date createTime;
    private Date updateTime;
    private String createAid;
    private String updateAid;
    private Integer sellChannel;
    private Long coverPeriod;
    private String partnerApplyId;
    private Integer insuranceType;
    private String channelNumber;
    private String mediumNumber;
    private String activityId;

    private Double trialPremium;
    private double multiPremium;
    private String checkApplyId;
    private Integer unit;	// 份数, 淘宝、蚂蚁需要用到
	// added by xiluhua
	private String lv1GbCode;
    private String lv2GbCode;
    private String downloadRes;
	private IspCustomer holder;
	private IspCustomer insured;
	private List<IspBeneficiary> beneficiaryList;
	private IspYangLaoTrans yangLaoTrans;
	private IspApplyVehicle applyVehicle;
	
// Constructors

    /**
     * default constructor
     */
    public IspApply() {
    }
   
    public IspApply(String partnerApplyId) {
    	this.partnerApplyId = partnerApplyId;
    }
	/**
     * minimal constructor
     */
    public IspApply(Long applyId) {
        this.applyId = applyId;
    }

    /**
     * full constructor
     */


    // Property accessors
    @Id
    @Column(name = "APPLY_ID", nullable = false, precision = 10, scale = 0)
    public Long getApplyId() {
        return this.applyId;
    }

    public void setApplyId(Long applyId) {
        this.applyId = applyId;
    }

    @Column(name = "APP_NO", length = 50)
    public String getAppNo() {
        return this.appNo;
    }

    public void setAppNo(String appNo) {
        this.appNo = appNo;
    }

    @Column(name = "POLICY_NO", length = 50)
    public String getPolicyNo() {
        return this.policyNo;
    }

    public void setPolicyNo(String policyNo) {
        this.policyNo = policyNo;
    }

    @Column(name = "APPLY_TYPE", precision = 3, scale = 0)
    public Integer getApplyType() {
        return this.applyType;
    }

    public void setApplyType(Integer applyType) {
        this.applyType = applyType;
    }

    @Column(name = "R_HOLDER_INST", precision = 3, scale = 0)
    public Integer getRHolderInst() {
        return this.RHolderInst;
    }

    public void setRHolderInst(Integer RHolderInst) {
        this.RHolderInst = RHolderInst;
    }

    @Column(name = "BENEFICIARY_TYPE", precision = 3, scale = 0)
    public Integer getBeneficiaryType() {
        return this.beneficiaryType;
    }

    public void setBeneficiaryType(Integer beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }

    @Column(name = "CHARGE_TYPE", precision = 3, scale = 0)
    public Integer getChargeType() {
        return this.chargeType;
    }

    public void setChargeType(Integer chargeType) {
        this.chargeType = chargeType;
    }

    @Column(name = "CHARGE_YEAR", precision = 3, scale = 0)
    public Integer getChargeYear() {
        return this.chargeYear;
    }

    public void setChargeYear(Integer chargeYear) {
        this.chargeYear = chargeYear;
    }

    @Column(name = "AMOUNT", precision = 12)
    public Integer getAmount() {
        return this.amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    @Column(name = "BONUS_MODE", precision = 3, scale = 0)
    public Integer getBonusMode() {
        return this.bonusMode;
    }

    public void setBonusMode(Integer bonusMode) {
        this.bonusMode = bonusMode;
    }

    @Column(name = "DISCOUNT", precision = 3)
    public Double getDiscount() {
        return this.discount;
    }

    public void setDiscount(Double discount) {
        this.discount = discount;
    }

    @Column(name = "PREMIUM", precision = 12)
    public Double getPremium() {
        return this.premium;
    }

    public void setPremium(Double premium) {
        this.premium = premium;
    }

    @Column(name = "CHECK_STATUS", precision = 3, scale = 0)
    public Integer getCheckStatus() {
        return this.checkStatus;
    }

    public void setCheckStatus(Integer checkStatus) {
        this.checkStatus = checkStatus;
    }

    @Column(name = "PAY_STATUS", precision = 3, scale = 0)
    public Integer getPayStatus() {
        return this.payStatus;
    }

    public void setPayStatus(Integer payStatus) {
        this.payStatus = payStatus;
    }

    @Column(name = "PAY_ID", precision = 10, scale = 0)
    public Long getPayId() {
        return this.payId;
    }

    public void setPayId(Long payId) {
        this.payId = payId;
    }

    @Column(name = "CHECK_BILL_STATUS", precision = 3, scale = 0)
    public Integer getCheckBillStatus() {
        return this.checkBillStatus;
    }

    public void setCheckBillStatus(Integer checkBillStatus) {
        this.checkBillStatus = checkBillStatus;
    }

    @Column(name = "BANK_CODE", length = 20)
    public String getBankCode() {
        return this.bankCode;
    }

    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    @Column(name = "IS_AGREED", precision = 3, scale = 0)
    public Integer getIsAgreed() {
        return this.isAgreed;
    }

    public void setIsAgreed(Integer isAgreed) {
        this.isAgreed = isAgreed;
    }

    @Column(name = "IS_CANCELED", precision = 3, scale = 0)
    public Integer getIsCanceled() {
        return this.isCanceled;
    }

    public void setIsCanceled(Integer isCanceled) {
        this.isCanceled = isCanceled;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "APPLY_TIME")
    public Date getApplyTime() {
        return this.applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CHECK_TIME")
    public Date getCheckTime() {
        return this.checkTime;
    }

    public void setCheckTime(Date checkTime) {
        this.checkTime = checkTime;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ACCEPT_TIME")
    public Date getAcceptTime() {
        return this.acceptTime;
    }

    public void setAcceptTime(Date acceptTime) {
        this.acceptTime = acceptTime;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "VALIDATE_DATE", length = 7)
    public Date getValidateDate() {
        return this.validateDate;
    }

    public void setValidateDate(Date validateDate) {
        this.validateDate = validateDate;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "EXPIRATION_DATE", length = 7)
    public Date getExpirationDate() {
        return this.expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    @Column(name = "DELIVER_TYPE", precision = 3, scale = 0)
    public Integer getDeliverType() {
        return this.deliverType;
    }

    public void setDeliverType(Integer deliverType) {
        this.deliverType = deliverType;
    }

    @Column(name = "DELIVER_ADDRESS", length = 500)
    public String getDeliverAddress() {
        return this.deliverAddress;
    }

    public void setDeliverAddress(String deliverAddress) {
        this.deliverAddress = deliverAddress;
    }

    @Column(name = "USER_ID", length = 32)
    public String getUserId() {
        return this.userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    @Column(name = "BLUE_ID", precision = 10, scale = 0)
    public Long getBlueId() {
        return this.blueId;
    }

    public void setBlueId(Long blueId) {
        this.blueId = blueId;
    }

    @Column(name = "BALE_ID", precision = 10, scale = 0)
    public Long getBaleId() {
        return this.baleId;
    }

    public void setBaleId(Long baleId) {
        this.baleId = baleId;
    }

    @Column(name = "ORGAN_ID", precision = 10, scale = 0)
    public Long getOrganId() {
        return this.organId;
    }

    public void setOrganId(Long organId) {
        this.organId = organId;
    }

    @Column(name = "LV1_AREA_ID", precision = 10, scale = 0)
    public Long getLv1AreaId() {
        return this.lv1AreaId;
    }

    public void setLv1AreaId(Long lv1AreaId) {
        this.lv1AreaId = lv1AreaId;
    }

    @Column(name = "LV2_AREA_ID", precision = 10, scale = 0)
    public Long getLv2AreaId() {
        return this.lv2AreaId;
    }

    public void setLv2AreaId(Long lv2AreaId) {
        this.lv2AreaId = lv2AreaId;
    }

    @Column(name = "PARTNER_ID", precision = 10, scale = 0)
    public Long getPartnerId() {
        return this.partnerId;
    }

    public void setPartnerId(Long partnerId) {
        this.partnerId = partnerId;
    }

    @Column(name = "LINK_ID", precision = 10, scale = 0)
    public Long getLinkId() {
        return this.linkId;
    }

    public void setLinkId(Long linkId) {
        this.linkId = linkId;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_TIME")
    public Date getCreateTime() {
        return this.createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UPDATE_TIME")
    public Date getUpdateTime() {
        return this.updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    @Column(name = "CREATE_AID", length = 32)
    public String getCreateAid() {
        return this.createAid;
    }

    public void setCreateAid(String createAid) {
        this.createAid = createAid;
    }

    @Column(name = "UPDATE_AID", length = 32)
    public String getUpdateAid() {
        return this.updateAid;
    }

    public void setUpdateAid(String updateAid) {
        this.updateAid = updateAid;
    }

    @Column(name = "SELL_CHANNEL", precision = 3, scale = 0)
    public Integer getSellChannel() {
        return this.sellChannel;
    }

    public void setSellChannel(Integer sellChannel) {
        this.sellChannel = sellChannel;
    }

    @Column(name = "COVER_PERIOD", precision = 10, scale = 0)
    public Long getCoverPeriod() {
        return this.coverPeriod;
    }

    public void setCoverPeriod(Long coverPeriod) {
        this.coverPeriod = coverPeriod;
    }

    @Column(name = "PARTNER_APPLY_ID", length = 50)
    public String getPartnerApplyId() {
        return this.partnerApplyId;
    }

    public void setPartnerApplyId(String partnerApplyId) {
        this.partnerApplyId = partnerApplyId;
    }

    @Column(name = "INSURANCE_TYPE", precision = 3, scale = 0)
    public Integer getInsuranceType() {
        return this.insuranceType;
    }

    public void setInsuranceType(Integer insuranceType) {
        this.insuranceType = insuranceType;
    }

    @Column(name = "CHANNEL_NUMBER", length = 100)
    public String getChannelNumber() {
        return this.channelNumber;
    }

    public void setChannelNumber(String channelNumber) {
        this.channelNumber = channelNumber;
    }

    @Column(name = "MEDIUM_NUMBER", length = 100)
    public String getMediumNumber() {
        return this.mediumNumber;
    }

    public void setMediumNumber(String mediumNumber) {
        this.mediumNumber = mediumNumber;
    }

    @Column(name = "ACTIVITY_ID", length = 32)
    public String getActivityId() {
        return this.activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    @Column(name = "TRIAL_PREMIUM", precision = 12)
    public Double getTrialPremium() {
        return this.trialPremium;
    }

    public void setTrialPremium(Double trialPremium) {
        this.trialPremium = trialPremium;
    }

    @Column(name = "CHECK_APPLY_ID", length = 100)
    public String getCheckApplyId() {
        return this.checkApplyId;
    }

    public void setCheckApplyId(String checkApplyId) {
        this.checkApplyId = checkApplyId;
    }

	@Column(name = "CHECK_RULE_STATUS", length = 2)
	public Integer getCheckruleStatus() {
		return checkruleStatus;
	}

	public void setCheckruleStatus(Integer checkruleStatus) {
		this.checkruleStatus = checkruleStatus;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CHECK_RULE_TIME")
	public Date getCheckruleTime() {
		return checkruleTime;
	}

	public void setCheckruleTime(Date checkruleTime) {
		this.checkruleTime = checkruleTime;
	}

	@Transient
	public IspCustomer getHolder() {
		return holder;
	}

	public void setHolder(IspCustomer holder) {
		this.holder = holder;
	}
	@Transient
	public IspCustomer getInsured() {
		return insured;
	}

	public void setInsured(IspCustomer insured) {
		this.insured = insured;
	}
	@Transient
	public List<IspBeneficiary> getBeneficiaryList() {
		return beneficiaryList;
	}

	public void setBeneficiaryList(List<IspBeneficiary> beneficiaryList) {
		this.beneficiaryList = beneficiaryList;
	}
	@Transient
	public String getLv1GbCode() {
		return lv1GbCode;
	}

	public void setLv1GbCode(String lv1GbCode) {
		this.lv1GbCode = lv1GbCode;
	}
	@Transient
	public String getLv2GbCode() {
		return lv2GbCode;
	}

	public void setLv2GbCode(String lv2GbCode) {
		this.lv2GbCode = lv2GbCode;
	}
	
	@Transient
	public IspYangLaoTrans getYangLaoTrans() {
		return yangLaoTrans;
	}

	public void setYangLaoTrans(IspYangLaoTrans yangLaoTrans) {
		this.yangLaoTrans = yangLaoTrans;
	}

	@Transient
	public String getDownloadRes() {
		return downloadRes;
	}

	public void setDownloadRes(String downloadRes) {
		this.downloadRes = downloadRes;
	}

	@Transient
	public IspApplyVehicle getApplyVehicle() {
		return applyVehicle;
	}
	
	public void setApplyVehicle(IspApplyVehicle applyVehicle) {
		this.applyVehicle = applyVehicle;
	}

	@Transient
	public double getMultiPremium() {
		return multiPremium;
	}

	public void setMultiPremium(double multiPremium) {
		this.multiPremium = multiPremium;
	}
	@Column(name = "UNIT")
	public Integer getUnit() {
		return unit;
	}

	public void setUnit(Integer unit) {
		this.unit = unit;
	}
}
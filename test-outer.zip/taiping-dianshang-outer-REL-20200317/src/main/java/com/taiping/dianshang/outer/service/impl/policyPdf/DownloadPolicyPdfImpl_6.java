package com.taiping.dianshang.outer.service.impl.policyPdf;

import java.io.DataOutputStream;
import java.io.File;
import java.io.OutputStream;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PdfDownloadTool;
import com.taiping.facility.tool.PropertyFileTool;


/**
 * <b>Title: 天安</b>
 * <p>Description: </p>
 * 
 * @author QBY.20190315
 * 
 */
@Service
public class DownloadPolicyPdfImpl_6 implements DownloadPolicyPdfService {
	@Autowired
	IspPolicyDao ispPolicyDao;
	
	/**
	 * 从核心系统下载电子保单
	 * @param policyNo
	 * @param idNo
	 * DEMO http://10.0.100.55:7001/TPEBizWeb/pages/B2C/show/downLoad.do?policyNo=383414749741A36D1D6B07947583E904B559324E0CBC4C8E2D4657749C197D7956C7C0871E9907A92a1c4ef1h3hf6g3e&insuredName=5D9ABEE885488761F8EFFE84B3D6005752FE298CBB8307332a1c4ef1h3hf6g3e&queryConditionType=person
	 * @return
	 */
	@Transactional
	public String download(String policyNo,String idNo) {
		String path = null;
		OutputStream outputStream = null;
		DataOutputStream dout = null;
		try {
			IspPolicy policy = ispPolicyDao.load(policyNo);
			if (policy == null || StringUtils.isEmpty(policy.getDownloadRes())) {
				return null;
			}
			String dir = PropertyFileTool.get("policy.pdf.dir");
			if (!new File(dir).exists()) {
				new File(dir).mkdirs();
			}
			path = dir+policyNo+".pdf";
			LogTool.debug(this.getClass(),"download.pdf.dir.path：" + path);
			LogTool.debug(this.getClass(),"policy.download.url: " + policy.getDownloadRes());
			
			String url = policy.getDownloadRes();
			String domainIp = CacheContainer.getSystemParameterValue(ConstantTool.SYS_TPI_DOMAIN_IP);
			String[] arr = domainIp.split(";");
			
			for (int i = 0; i < arr.length; i++) {
				String[] tmp = arr[i].split(",");
				url = url.replaceAll(tmp[0], tmp[1]);
			}
			
			LogTool.debug(this.getClass(), "policy.download.url: "+url);
			PdfDownloadTool httpClient = new PdfDownloadTool();
			//10.1.118.45,8808
			String agentIp = CacheContainer.getSystemParameterValue(ConstantTool.SYS_TPI_AGENT_IP);	
			String[] arrProxy = agentIp.split(",");
			httpClient.setProxy(arrProxy[0], arrProxy[1]);
			
			httpClient.persistentPDF(url,path);
		} catch (Exception e) {
			path = null;
			LogTool.error(this.getClass(), e);
			throw new DownloadPolicyPdfSysException();
		} finally {
			try {
				if (outputStream!= null) {
					outputStream.close();
				}
				if (dout != null) {
					dout.close();
				}
			} catch (Exception e2) {
				LogTool.error(this.getClass(), e2);
			}
		}
		
		return path;
	}
	
	public static void main(String[] args) {
		String url = "http://ebiz.tpi.cntaiping.com";
		String domainIp = "ectp.tpi.cntaiping.com,10.12.41.1;ebiz.tpi.cntaiping.com,10.12.41.1";
		String[] arr = domainIp.split(";");
		System.out.println(arr.length);
		for (int i = 0; i < arr.length; i++) {
			String[] tmp = arr[i].split(",");
			for (int j = 0; j < tmp[i].length(); j++) {
				url = url.replaceAll(tmp[0], tmp[1]);
			}
		}
		
		System.err.println(url);
	}
}

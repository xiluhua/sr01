package com.taiping.dianshang.exception;


public class CacheObjectNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public CacheObjectNotFoundException(String msg){
		super(msg);
	}
}


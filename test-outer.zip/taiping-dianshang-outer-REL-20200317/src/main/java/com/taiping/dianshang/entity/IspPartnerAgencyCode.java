package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspPartnerAgencyCode   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_PARTNER_AGENCY_CODE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspPartnerAgencyCode implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -4009414866092257310L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="PARTNER_ID")
	private Long partnerId;
	@Column(name="AGENCY_CODE")
	private String agencyCode;
	@Column(name="MD5_KEY")
	private String md5Key;
	@Column(name="STATUS")
	private Integer status;
	
	public IspPartnerAgencyCode() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public String getAgencyCode() {
		return agencyCode;
	}
	public void setAgencyCode(String agencyCode) {
		this.agencyCode = agencyCode;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getMd5Key() {
		return md5Key;
	}
	public void setMd5Key(String md5Key) {
		this.md5Key = md5Key;
	}
	
	
}





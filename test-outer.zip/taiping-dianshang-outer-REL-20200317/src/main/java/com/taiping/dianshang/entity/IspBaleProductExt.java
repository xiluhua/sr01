package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * IspBaleProductExt entity. 
 */
@Entity
@Table(name = "CP_ISP_BALE_PRODUCT_EXT")
public class IspBaleProductExt implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	private Long id;
	private Long productExtId;
	private Long baleId;
	private Date createTime;

	// Constructors

	/** default constructor */
	public IspBaleProductExt() {
	}

	// Property accessors

	@Id
	public Long getId() {
		return id;
	}
	
	public void setId(Long id) {
		this.id = id;
	}


	@Column(name = "PRODUCT_EXT_ID", nullable = false, length = 96)
	public Long getProductExtId() {
		return this.productExtId;
	}
	
	public void setProductExtId(Long productExtId) {
		this.productExtId = productExtId;
	}

	
	@Column(name = "BALE_ID", nullable = false)
	public Long getBaleId() {
		return this.baleId;
	}

	public void setBaleId(Long baleId) {
		this.baleId = baleId;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	
	
}
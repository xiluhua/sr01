package com.taiping.dianshang.outer.DTO.response;


import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.element.PolicyPdfURLDTO;
import com.taiping.dianshang.outer.DTO.response.element.ResponseBusinessDTO;

import javax.xml.bind.annotation.*;

/**
 * 电子保单下载返回对象
 * @author xiluhua by liwei
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		
		"main"
})
@XmlRootElement(name = "RESPONSE")
public class ResponsePolicyPdfUrlDTO extends ResponseDTO {

	@XmlElement(name = "MAIN")
	protected PolicyPdfURLDTO main;


	public PolicyPdfURLDTO getMain() {
		if (main == null){
			this.main = new PolicyPdfURLDTO();
		}
		return main;
	}

	public void setMain(PolicyPdfURLDTO main) {
		this.main = main;
	}

	public ResponseBusinessDTO getBusiness() {
		return business;
	}

	public void setBusiness(ResponseBusinessDTO business) {
		this.business = business;
	}

	public ResponsePolicyPdfUrlDTO() {
		super();
		this.main = new PolicyPdfURLDTO();
		// TODO Auto-generated constructor stub
	}

	public ResponsePolicyPdfUrlDTO(Busi busi) {
		super(busi);
	}
}

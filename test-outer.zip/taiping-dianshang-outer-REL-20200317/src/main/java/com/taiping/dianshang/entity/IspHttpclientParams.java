package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspHttpclientParams   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_HTTP_CLIENT_PARAMS")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspHttpclientParams implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4939656166422372091L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="RETRY_TIME")
	private Integer retryTime;
	@Column(name="CONTENT_CHARSET_REQUEST")
	private String contentCharsetRequest;
	@Column(name="CONTENT_TYPE")
	private String contentType;
	@Column(name="CONNECTION_TIMEOUT")
	private Integer connectionTimeout;
	@Column(name="SO_TIMEOUT")
	private Integer soTimeout;
	@Column(name="CONTENT_CHARSET_RESPONSE")
	private String contentCharsetResponse;
	
	
	public IspHttpclientParams() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		Id = id;
	}

	public Integer getRetryTime() {
		return retryTime;
	}

	public void setRetryTime(Integer retryTime) {
		this.retryTime = retryTime;
	}

	public String getContentCharsetRequest() {
		return contentCharsetRequest;
	}

	public void setContentCharsetRequest(String contentCharsetRequest) {
		this.contentCharsetRequest = contentCharsetRequest;
	}

	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public Integer getConnectionTimeout() {
		return connectionTimeout;
	}

	public void setConnectionTimeout(Integer connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}

	public Integer getSoTimeout() {
		return soTimeout;
	}

	public void setSoTimeout(Integer soTimeout) {
		this.soTimeout = soTimeout;
	}

	public String getContentCharsetResponse() {
		return contentCharsetResponse;
	}

	public void setContentCharsetResponse(String contentCharsetResponse) {
		this.contentCharsetResponse = contentCharsetResponse;
	}

}





package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * ImsSysParamList entity. 
 */
@Entity
@Table(name = "IMS_SYS_PARAM_LIST")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsSysParamList implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	private Long paramId;
	private String paramCode;
	private String paramValue;
	private String paramName;
	private String memo;
	private Integer status;
	private Date createTime;
	// Constructors

	/** default constructor */
	public ImsSysParamList() {
	}


	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	@Id
	@Column(name = "PARAM_ID")
	public Long getParamId() {
		return paramId;
	}

	public void setParamId(Long paramId) {
		this.paramId = paramId;
	}
	@Column(name = "PARAM_CODE")
	public String getParamCode() {
		return paramCode;
	}

	public void setParamCode(String paramCode) {
		this.paramCode = paramCode;
	}
	@Column(name = "PARAM_VALUE")
	public String getParamValue() {
		return paramValue;
	}

	public void setParamValue(String paramValue) {
		this.paramValue = paramValue;
	}
	@Column(name = "PARAM_NAME")
	public String getParamName() {
		return paramName;
	}

	public void setParamName(String paramName) {
		this.paramName = paramName;
	}
	@Column(name = "MEMO")
	public String getMemo() {
		return memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}


	public void setStatus(Integer status) {
		this.status = status;
	}

}
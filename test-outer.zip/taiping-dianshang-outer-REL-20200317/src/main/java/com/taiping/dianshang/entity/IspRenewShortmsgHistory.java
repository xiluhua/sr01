package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author qby
 * @since 20200317
 */
@Entity
@Table(name = "ISP_RENEW_SHORTMSG_HISTORY")
public class IspRenewShortmsgHistory {
	
	@Id
	@Column(name="ID")
    private String id;
	
	@Column(name="POLICY_NO")
    private String policyNo;
    
    @Column(name="SHORTMSG")
    private String shortMsg;
    
    @Column(name="SENDING_TIME")
    private Date sendingtime;

	@Column(name="CREATE_TIME")
    private Date createTime;

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public Date getSendingtime() {
		return sendingtime;
	}

	public void setSendingtime(Date sendingtime) {
		this.sendingtime = sendingtime;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getShortMsg() {
		return shortMsg;
	}

	public void setShortMsg(String shortMsg) {
		this.shortMsg = shortMsg;
	}
    
}

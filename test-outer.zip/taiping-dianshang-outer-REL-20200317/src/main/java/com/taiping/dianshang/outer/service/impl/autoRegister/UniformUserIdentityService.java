package com.taiping.dianshang.outer.service.impl.autoRegister;

import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.RegisterResult;


/**
 * 统一身份管理保 Service
 * @author FengJian
 *
 */
public interface UniformUserIdentityService {
	
	/**
	 * 注册接口（该接口最初是为B2B2E开的，商城这边业务一直所以接着用）
	 * @param applyDTO
	 * @return
	 * @throws Exception 
	 */
	public String autoRegister(IspApply apply,String keyWord);
	
	/**
	 * 查询用户是否存在（该接口最初是为B2B2E开的，商城这边业务一直所以接着用）
	 * @param Apply apply
	 * @return
	 * @throws Exception 
	 */
	public String queryIsUserExist(IspApply apply,String keyWord);
	
	/**
	 * 注册
	 * @param Apply apply
	 * @return
	 * @throws Exception 
	 */
	public RegisterResult register(IspApply apply,String keyWord);
	
	/**
	 * 注册
	 * @param Apply apply
	 * @return
	 * @throws Exception 
	 */
	public RegisterResult registerNew(IspApply apply,String keyWord);
	
}

package com.taiping.dianshang.service.httpclient.impl;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.util.Map;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.springframework.stereotype.Service;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.service.httpclient.HttpclientService;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;

@Service
public class HttpclientImpl implements HttpclientService{
	
	/**
	 * post 方法
	 * @param  url
	 * @param httpclientParams
	 * @return
	 */
	public String get(String url, IspHttpclientParams httpclientParams,String trans) throws Exception {
		DataInputStream in = null;
		BufferedReader reader = null;
		String responseMsg = "";
		HttpClient httpclient = new HttpClient();
		GetMethod httpGet = new GetMethod(url);
		httpGet.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(httpclientParams.getRetryTime(), false));

		//（2）、设置自己想要的编码格式对于get方法也可以这样设置 
		httpGet.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET,httpclientParams.getContentCharsetRequest());  
			 
		//（3）、还可以如下这样设置
		httpGet.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");  
		
		//（5）、设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(httpclientParams.getConnectionTimeout());
		//（6）、设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(httpclientParams.getSoTimeout());
		try {
			// get
			int statusCode = httpclient.executeMethod(httpGet);
			String[] arr = {trans,String.valueOf(statusCode)};
			LogTool.info(this.getClass(),"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:{},statusCode:{}",arr);
			
			// success
			if (statusCode == HttpStatus.SC_OK) {
				StringBuffer rspContent = new StringBuffer();
				in = new DataInputStream(httpGet.getResponseBodyAsStream());
				reader = new BufferedReader(new InputStreamReader(in, httpclientParams.getContentCharsetResponse()));
				String aLine = "";
				while ((aLine = reader.readLine()) != null) {
					rspContent.append(aLine);
				}
				responseMsg = rspContent.toString();
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpGet.releaseConnection();
			if (reader != null) {
				reader.close();
			}
			if (in != null) {
				in.close();
			}
		}
	
		return responseMsg;
	}
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content, String encode) throws Exception {
		String trans = "";
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");  
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(60000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				trans = map.get("trans");
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), "gbk"));
					index++;
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				httpPost.setRequestEntity(new StringRequestEntity((String)content,"plain/text", encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			String[] arr = {trans,String.valueOf(statusCode)};
			LogTool.info(this.getClass(),"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:{},statusCode:{}",arr);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}

	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content, String encode,String contentType, boolean needProxy) throws Exception {
		String trans = "";
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		if (needProxy) {
			HttpclientTool.setProxy(httpclient);
		}
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");  
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(60000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				trans = map.get("trans");
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), "gbk"));
					index++;
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				httpPost.setRequestEntity(new StringRequestEntity((String)content,contentType, encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			String[] arr = {trans,String.valueOf(statusCode)};
			LogTool.info(this.getClass(),"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:{},statusCode:{}",arr);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content,String contentType, String encode,int connectionTimeout,int soTimeout,int retryTime) throws Exception {
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");  
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(connectionTimeout);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(soTimeout);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(retryTime, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), "GBK"));
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				httpPost.setRequestEntity(new StringRequestEntity((String)content,contentType, encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);

			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object obj, IspHttpclientParams httpclientParams) throws Exception {
		
		String trans = "";
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(httpclientParams.getConnectionTimeout());
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(httpclientParams.getConnectionTimeout());
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded");
		httpPost.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, httpclientParams.getContentCharsetRequest());
		httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(httpclientParams.getRetryTime(), false));
		try {
			if (obj instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map  = (Map<String, String>)obj;
				trans = MapTool.getStringFromMap(map, "trans");
				map.remove("trans");
				// 填充参数
				NameValuePair[] param = new NameValuePair[map.size()];
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),entry.getValue().toString());
					index++;
			    }
				httpPost.setRequestBody(param);
			}else {
				// rest
				httpPost.setRequestEntity(new StringRequestEntity((String) obj, httpclientParams.getContentType(), httpclientParams.getContentCharsetRequest()));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			LogTool.info(this.getClass(),"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:"+ trans +",statusCode:"+statusCode);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			LogTool.error(this.getClass(), e);
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, httpclientParams.getContentCharsetResponse());
		}
		LogTool.debug(this.getClass(), responseMsg);
		
		return responseMsg;
	}
	
	/**
	 * 发送报文方法
	 * @param url  发送URL地址
	 * @param xml  报文消息体
	 * @param md5key 机构验证码
	 * @return   合作方应答报文
	 * 
	 */
	public String post3(String url, Object content, String encode) throws Exception {
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setRequestHeader("ContentType", "application/json");
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(6000000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(6000000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			httpPost.setRequestEntity(new StringRequestEntity((String)content,"application/json", encode));
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			System.out.println("statusCode:"+statusCode);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = String.valueOf(statusCode);
			}
		} catch (HttpException e) {
			throw new RuntimeException(e.getMessage());
		} catch (IOException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}

}

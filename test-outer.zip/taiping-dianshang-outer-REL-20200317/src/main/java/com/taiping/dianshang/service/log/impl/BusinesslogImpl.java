/**
 * @(#)BusinesslogImpl.java
 *       
 * project：taiping-sol-insu-vehicle-BRANCH-20150818
 * 
 * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.dianshang.service.log.impl;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.model.DsIlogBusinessOperateLog;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * <p>Description : 业务日志服务类</p>
 * @author xiluhua by 20160119
 *
 */
@Component
public class BusinesslogImpl implements BusinesslogService{

	@Autowired 
	private IspSequenceDao ispSequenceDao;
	
	public String getBusinessOperateType_1(String businessOperateType,int phase){
		int tmp = Math.abs(phase*2 - 1);
		return businessOperateType+ConstantTool.UNDERLINE+tmp;
	}
	
	public String getBusinessOperateType_2(String businessOperateType,int phase){
		int tmp = Math.abs(phase*2);
		return businessOperateType+ConstantTool.UNDERLINE+tmp;
	}
	
	/**
	 * 业务日志
	 * @param apply
	 * @param businessOperateType
	 * @param operateStatus
	 */
	public void postBusinessOpelog_1(IspApply apply,String packet,String businessOperateType,Integer operateStatus,int phase){
		
		DsIlogBusinessOperateLog busiOpeLog = new DsIlogBusinessOperateLog();
		try {
			if (apply == null) {
				return;
			}
			if (apply.getApplyId() == null) {
				busiOpeLog.setApplyId(null);
			}else {
				busiOpeLog.setApplyId(String.valueOf(apply.getApplyId()));
			}
			
			
			if (apply.getPayId() == null) {
				busiOpeLog.setPayId(null);
			}else {
				busiOpeLog.setPayId(String.valueOf(apply.getPayId()));
			}
			
			busiOpeLog.setBusinessOperateType(getBusinessOperateType_1(businessOperateType, phase));
			busiOpeLog.setOperateStatus(operateStatus);
			busiOpeLog.setAppNo(StringUtils.defaultString(apply.getAppNo()));
			busiOpeLog.setPremium(apply.getPremium());
			busiOpeLog.setUserId(StringUtils.defaultString(apply.getUserId()));
			if (apply.getHolder() != null) {
				busiOpeLog.setHolderName(StringUtils.defaultString(apply.getHolder().getCustName()));
				busiOpeLog.setHolderIdno(StringUtils.defaultString(apply.getHolder().getIdNo()));
			}
			busiOpeLog.setPartnerId(apply.getPartnerId());
			busiOpeLog.setPartnerTransCode(StringUtils.defaultString(apply.getPartnerApplyId()));
			busiOpeLog.setFromIp(LogTool.localIp);
			busiOpeLog.setMsgPath(PropertyFileTool.get("log.msg.path"));
			busiOpeLog.setMsg(StringUtils.defaultString(packet));
			busiOpeLog.setCreateTime(new Date());
			LogTool.put(busiOpeLog);
		} catch (Exception e) {
			LogTool.error(BusinesslogImpl.class, e);
		}
	}
	
	/**
	 * 业务日志
	 * @param apply
	 * @param businessOperateType
	 * @param operateStatus
	 */
	public void postBusinessOpelog_2(IspApply apply,String packet,String businessOperateType,Integer operateStatus,int phase){

		DsIlogBusinessOperateLog busiOpeLog = new DsIlogBusinessOperateLog();
		try {
			if (apply == null) {
				return;
			}
			if (apply.getApplyId() == null) {
				busiOpeLog.setApplyId(null);
			}else {
				busiOpeLog.setApplyId(String.valueOf(apply.getApplyId()));
			}
			
			
			if (apply.getPayId() == null) {
				busiOpeLog.setPayId(null);
			}else {
				busiOpeLog.setPayId(String.valueOf(apply.getPayId()));
			}
			
			busiOpeLog.setBusinessOperateType(getBusinessOperateType_2(businessOperateType, phase));
			busiOpeLog.setOperateStatus(operateStatus);
			busiOpeLog.setAppNo(StringUtils.defaultString(apply.getAppNo()));
			busiOpeLog.setPremium(apply.getPremium());
			busiOpeLog.setUserId(StringUtils.defaultString(apply.getUserId()));
			if (apply.getHolder() != null) {
				busiOpeLog.setHolderName(StringUtils.defaultString(apply.getHolder().getCustName()));
				busiOpeLog.setHolderIdno(StringUtils.defaultString(apply.getHolder().getIdNo()));
			}
			busiOpeLog.setPartnerId(apply.getPartnerId());
			busiOpeLog.setPartnerTransCode(StringUtils.defaultString(apply.getPartnerApplyId()));
			busiOpeLog.setFromIp(LogTool.localIp);
			busiOpeLog.setMsgPath(PropertyFileTool.get("log.msg.path"));
			busiOpeLog.setMsg(StringUtils.defaultString(packet));
			busiOpeLog.setCreateTime(new Date());
			LogTool.put(busiOpeLog);
		} catch (Exception e) {
			LogTool.error(BusinesslogImpl.class, e);
		}
	}
	
	@Override
	public Long getLogIndex() {
		Long logIndex = ispSequenceDao.getSequnce(ConstantTool.SEQ_LOG_INDEX);
		return logIndex;
	}
	
	@Override
	public Long getLogIndexWrite(){
		Long logIndex = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_LOG_INDEX);
		return logIndex;
	}
}
package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.dianshang.service.log.impl.BusinesslogImpl;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.SpringTool;

/**
 * 异步执行服务列表
 * @author xilh
 * @since 20181216
 */
@Service
public class ShortMsgAndGiftImpl_CBCG_2_list implements ShortMsgService{

	@Resource
	BusinesslogImpl businesslogImpl;
	
	@Override
	public void handle(Map<String, Object> shortMsgParamMap) {
		String code     = MapTool.getStringFromMap(shortMsgParamMap,"serviceCode");
		String services = CacheContainer.getSystemParameterValueNoThrows(code);
		// 流水号
        String partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
		LogTool.info(this.getClass(), partnerApplyId +",services: "+ services);
		if (StringUtils.isEmpty(services)) {
			IspApply apply = new IspApply();
			apply.setPartnerApplyId(partnerApplyId);
			businesslogImpl.postBusinessOpelog_1(apply, "services value is null", this.getClass().getSimpleName(), 2, 1);
			return;
		}
		
		String[] array  = StringUtils.defaultString(services).split("@");
		for (int i = 0; i < array.length; i++) {
			String bean = array[i];
			try {
				ShortMsgService shortMsgService = SpringTool.getSpringBean(bean);
				shortMsgService.handle(shortMsgParamMap);
				LogTool.info(this.getClass(), partnerApplyId +","+(i+1)+", "+ bean);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
	}

	@Override
	public TPSmsMessages initMsg(Map<String, Object> shortMsgParamMap,
			String serviceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getContent(Map<String, Object> shortMsgParamMap,
			IspApply apply) {
		// TODO Auto-generated method stub
		return null;
	}
	
}

package com.taiping.dianshang.test;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;

import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.facility.tool.IOTool;
import com.taiping.facility.tool.LogTool;

public class HttpXmlSender_life_1
{
	
	public static void main(String[] args) throws Exception
	{
		// localhost本地
		String url = "http://10.10.4.200/life/servlet/com.tpdm.outer.realize.RealTransPortal?protocol=01&packet=#packet";
		String encode = "utf-8";
		String file = "test_life_core.xml";
		String path = HttpXmlSender_life_1.class.getResource("/template/test/"+file).getPath();
		System.out.println("path : "+path);
		String xml = IOTool.readFile(path,"gbk");  //请确认编码方式
		System.out.println("request:");
		System.out.println(xml);
		
		IspHttpclientParams httpclientParams = new IspHttpclientParams();
		httpclientParams.setRetryTime(1);
		httpclientParams.setConnectionTimeout(60000);
		httpclientParams.setSoTimeout(60000);
		httpclientParams.setContentCharsetRequest(encode);
		httpclientParams.setContentType("");
		httpclientParams.setContentCharsetResponse("gbk");

		url = url.replaceAll("#packet", URLEncoder.encode(xml, "utf-8"));
		System.out.println(url);
		System.out.println("response:");
		System.out.println(HttpXmlSender_life_1.get(url,httpclientParams, "1"));
	}
	
	
	/**
	 * post 方法
	 * @param  url
	 * @param httpclientParams
	 * @return
	 */
	public static String get(String url, IspHttpclientParams httpclientParams,String trans) throws Exception {
		DataInputStream in = null;
		BufferedReader reader = null;
		String responseMsg = "";
		HttpClient httpclient = new HttpClient();
		GetMethod httpGet = new GetMethod(url);
		httpGet.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(httpclientParams.getRetryTime(), false));

		//（2）、设置自己想要的编码格式对于get方法也可以这样设置 
		httpGet.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET,httpclientParams.getContentCharsetRequest());  
			 
		//（3）、还可以如下这样设置
		httpGet.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");  
		
		//（5）、设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(httpclientParams.getConnectionTimeout());
		//（6）、设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(httpclientParams.getSoTimeout());
		try {
			// get
			int statusCode = httpclient.executeMethod(httpGet);
			String[] arr = {trans,String.valueOf(statusCode)};
			LogTool.info(HttpXmlSender_life_1.class ,"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:{},statusCode:{}",arr);
			
			// success
			if (statusCode == HttpStatus.SC_OK) {
				StringBuffer rspContent = new StringBuffer();
				in = new DataInputStream(httpGet.getResponseBodyAsStream());
				reader = new BufferedReader(new InputStreamReader(in, httpclientParams.getContentCharsetResponse()));
				String aLine = "";
				while ((aLine = reader.readLine()) != null) {
					rspContent.append(aLine);
				}
				responseMsg = rspContent.toString();
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpGet.releaseConnection();
			if (reader != null) {
				reader.close();
			}
			if (in != null) {
				in.close();
			}
		}
	
		return responseMsg;
	}
}

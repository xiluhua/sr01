package com.taiping.dianshang.outer.service3.url;

/**
 * @author xilh
 * @since 20161018
 * @category 获取网销核心请求地址接口 
 * @version 3.0
 */
public interface UrlService {

	public String dsCoreUrl();
}

package com.taiping.dianshang.test;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.utils.CreateDTOTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.LogTool;

public class HttpXmlSender_3_178 {

	public static void main(String[] args) throws Exception {
		String encode = "GBK";
		
		String content = CreateDTOTool.create(3,"178_LOCAL20160226_1",true,2);
		LogTool.info(HttpXmlSender_1_178.class, "content:{}", content);
		
		String url = "http://localhost:7788/taiping-dianshang-core/services/rest/core/business/entrance";

		String response = HttpclientTool.post(url, content, encode);
		
		System.out.println("response:"+Base64Tool.decode(response, "utf-8"));
	}
}

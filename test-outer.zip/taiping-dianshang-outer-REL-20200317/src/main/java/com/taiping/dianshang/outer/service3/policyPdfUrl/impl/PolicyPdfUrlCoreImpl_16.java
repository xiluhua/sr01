package com.taiping.dianshang.outer.service3.policyPdfUrl.impl;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.ResponsePolicyPdfUrlDTO;
import com.taiping.dianshang.outer.service3.policyPdfUrl.PolicyPdfUrlCoreService;
import com.taiping.dianshang.outer.service3.url.UrlService;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.facility.tool.*;
import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.dom4j.Document;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author Li.Wei  2019/9/3 11:06 AM
 * @version 1.0
 * @since 亚太电子保单下载
 */
@Service
public class PolicyPdfUrlCoreImpl_16 extends PolicyPdfUrlCoreImpl implements PolicyPdfUrlCoreService {

    @Override
    public void xmlToObject(Busi busi, String responseXml) {
        ResponsePolicyPdfUrlDTO responseDTO = (ResponsePolicyPdfUrlDTO)busi.getResponseDTO();
        try {
            if (StringUtils.isEmpty(responseXml)) {
                responseDTO.getBusiness().setReturnInfo("返回报文接口返回为空");
                return;
            }
            Document responseDoc = XmlTool.bulidXmlDoc(responseXml); // 报文对象
            String policyByteString = responseDoc.selectSingleNode("/RESPONSE/MAIN/POLICY_BYTE_STRING") == null?"":responseDoc.selectSingleNode("/RESPONSE/MAIN/POLICY_BYTE_STRING").getText();
            if (!StringUtils.isEmpty(policyByteString)){
                responseDTO.getBusiness().setSuccess(true);
                responseDTO.getBusiness().setReturnCode(ConstantTool.CoreReturnSuccess);
                responseDTO.getMain().setPolicyByteString(policyByteString);
            }else {
                responseDTO.getBusiness().setSuccess(false);
                responseDTO.getBusiness().setReturnCode(ConstantTool.CoreReturnFailed);
                responseDTO.getBusiness().setReturnInfo("电子保单下载报文为空！");
            }
            busi.setResponseDTO(responseDTO);
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
        }
    }

    @Override
    public void updateAfterCoreBusiness(Busi busi) throws Exception {

    }
}

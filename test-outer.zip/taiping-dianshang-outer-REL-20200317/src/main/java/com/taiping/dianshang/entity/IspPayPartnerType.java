package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**   
 * @ClassName IspPayPartner   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "DS_ISP_PAY_PARTNER_TYPE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspPayPartnerType implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7133502128679408348L;
	@Id
	@Column(name="PARTNER_ID")
	private Long partnerId;
	@Column(name="STATUS")
	private Integer status;
	@Column(name="TYPE")
	private Integer type;
	
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	
}

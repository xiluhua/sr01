package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ScOverseasSecurityProject entity.
 */
@Entity
@Table(name = "SC_OVERSEAS_SECURITY_PROJECT")
public class ScOverseasSecurityProject implements java.io.Serializable  {
	private static final long serialVersionUID = 1L;

	// Fields
	private String id;
	private String product_area;
	private String destination;
	private String plan_type;
	private String security_project;
	private String security_payments;
	private String security_amount;
	private String insurance;
	private String insurance_code;
	private String limit_name;
	private String limit_code;
	private String limit_description;
	private String limit_amount;

	// Constructors

	/** default constructor */
	public ScOverseasSecurityProject() {
	}

	/** minimal constructor */
	public ScOverseasSecurityProject(String id) {
		this.id = id;
	}

	/** full constructor */
	public ScOverseasSecurityProject(String id, String product_area,
			String destination, String plan_type, String security_project,
			String security_payments, String security_amount, String insurance,
			String insurance_code, String limit_name, String limit_code,
			String limit_description, String limit_amount) {
		this.id = id;
		this.product_area = product_area;
		this.destination = destination;
		this.plan_type = plan_type;
		this.security_project = security_project;
		this.security_payments = security_payments;
		this.security_amount = security_amount;
		this.insurance = insurance;
		this.insurance_code = insurance_code;
		this.limit_name = limit_name;
		this.limit_code = limit_code;
		this.limit_description = limit_description;
		this.limit_amount = limit_amount;
	}

	@Id
	@Column(name = "ID", unique = true, nullable = false, length = 50)
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Column(name = "PRODUCT_AREA", length = 3)
	public String getProduct_area() {
		return product_area;
	}

	public void setProduct_area(String product_area) {
		this.product_area = product_area;
	}

	@Column(name = "DESTINATION", length = 3)
	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	@Column(name = "PLAN_TYPE", length = 3)
	public String getPlan_type() {
		return plan_type;
	}

	public void setPlan_type(String plan_type) {
		this.plan_type = plan_type;
	}

	@Column(name = "SECURITY_PROJECT", length = 400)
	public String getSecurity_project() {
		return security_project;
	}

	public void setSecurity_project(String security_project) {
		this.security_project = security_project;
	}

	@Column(name = "SECURITY_PAYMENTS", length = 400)
	public String getSecurity_payments() {
		return security_payments;
	}

	public void setSecurity_payments(String security_payments) {
		this.security_payments = security_payments;
	}

	@Column(name = "SECURITY_AMOUNT", length = 20)
	public String getSecurity_amount() {
		return security_amount;
	}

	public void setSecurity_amount(String security_amount) {
		this.security_amount = security_amount;
	}

	@Column(name = "INSURANCE", length = 20)
	public String getInsurance() {
		return insurance;
	}

	public void setInsurance(String insurance) {
		this.insurance = insurance;
	}

	@Column(name = "INSURANCE_CODE", length = 400)
	public String getInsurance_code() {
		return insurance_code;
	}

	public void setInsurance_code(String insurance_code) {
		this.insurance_code = insurance_code;
	}

	@Column(name = "LIMIT_NAME", length = 20)
	public String getLimit_name() {
		return limit_name;
	}

	public void setLimit_name(String limit_name) {
		this.limit_name = limit_name;
	}

	@Column(name = "LIMIT_CODE", length = 20)
	public String getLimit_code() {
		return limit_code;
	}

	public void setLimit_code(String limit_code) {
		this.limit_code = limit_code;
	}

	@Column(name = "LIMIT_DESCRIPTION", length = 200)
	public String getLimit_description() {
		return limit_description;
	}

	public void setLimit_description(String limit_description) {
		this.limit_description = limit_description;
	}

	@Column(name = "LIMIT_AMOUNT", length = 20)
	public String getLimit_amount() {
		return limit_amount;
	}

	public void setLimit_amount(String limit_amount) {
		this.limit_amount = limit_amount;
	}

}
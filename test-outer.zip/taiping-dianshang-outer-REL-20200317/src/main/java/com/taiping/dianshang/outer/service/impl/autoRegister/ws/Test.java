package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

import com.taiping.common.MD5Utils;


public class Test {
	public static void main(String args[]) throws Exception{
		
		String requestId = "11213111";
		UserInfo accountInfo = new UserInfo();
		UserRequest userRequest = new UserRequest();


//		 accountInfo.setPolicyNumber("");
//		accountInfo.setAccountId("ltb2b2e163.com");
//		accountInfo.setEmail("wujx_wb@ec.cntaiping.com");
//		accountInfo.setCenterId("FFFFFFFFFFFFFFFFFFFF");
		accountInfo.setCenterId("81606710e9f2452961e9b2260ee546dc");
//		accountInfo.setUid("FFFFFFFFFFFFFFFFFFFF"); 
//		accountInfo.setMobile("FFFFFFFFFFFFFFFFFFFF");
//		accountInfo.setOldEmail("wujx_wb@ec.cntaiping.com");
//		accountInfo.setCenterId("3e2fadd39fd524882cc5f71d9af1a7bb");
//		accountInfo.setCenterId("5ff19ec1518a33feb500d8f229c755b0");
//		accountInfo.setCenterId("S5992845");
//		accountInfo.setCenterId("S5992840");
//		accountInfo.setAddress("环林东路");  //
//		accountInfo.setDeliveryAddress("");//配送地址
//		accountInfo.setDeliveryCode("");//配送邮编
//		accountInfo.setLv1Area("");
//		accountInfo.setLv2Area("");//所在城市
//		accountInfo.setQqId("");
//		accountInfo.setHasChild("");
//		accountInfo.setHasHousing("");
//		accountInfo.setIncomeLevels("");
//		accountInfo.setPostCode("");
//		accountInfo.setMarriageStatus("");
//		accountInfo.setTelephone("021-50427571");
//		accountInfo.setCenterMId("M5515910");
//		accountInfo.setEmail("ltb2b2e163.com");
//		accountInfo.setMobile("15162775726");
//		accountInfo.setOldMobile("15162775726");
		accountInfo.setUserPassword(MD5Utils.encrypt("tp123456"));
//		accountInfo.setUserPassword("tp123456");
//		 String pwdChangeDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date());
//		accountInfo.setPwdChangeDate(pwdChangeDate);
//		accountInfo.setRiskLevel("0");
//		accountInfo.setUpdateDate("2012-05-26 10:19:21");
		accountInfo.setServiceId("B2B2E");
		userRequest.setRequestID(requestId);
		userRequest.setUserInfo(accountInfo);
  		CNTPWebService webService = new CNTPWebService();
  		String url= "http://10.1.117.11:9080/CNTPWInterFace/CNTPWebService?wsdl";
		CNTPWebServiceImplDelegate webServiceImplDelegate = webService.getCNTPWebService(url);
		UserResponse userResponse = webServiceImplDelegate.registerUser(userRequest);
		UserSearchResponse userSearchResponse = webServiceImplDelegate.selectUser(userRequest);
//		UserResponse userResponse = webServiceImplDelegate.verifyUserPasswd(userRequest);
//		 UserResponse userResponse = webServiceImplDelegate.modifyUser(userRequest);
		
		System.out.println(userResponse.getRequestID());
		System.out.println(userResponse.getReturnCode());
		System.out.println(userResponse.getReturnMessage());
	}

}

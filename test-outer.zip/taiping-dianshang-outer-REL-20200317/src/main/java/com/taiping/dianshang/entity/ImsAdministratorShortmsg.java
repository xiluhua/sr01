package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * ImsDictionary entity. 
 */
@Entity
@Table(name = "IMS_ADMINISTRATOR_SHORTMSG")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsAdministratorShortmsg implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	@Id
	@Column(name = "id", length = 20)
	private Long id;
	@Column(name = "SERVICE")
	private String service;
	@Column(name = "ADMIN_NAME")
	private String adminName;
	@Column(name = "MOBILE")
	private String mobile;
	@Column(name = "STATUS")
	private Integer status;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;
	@Column(name = "TEMPLATE_ID")
	private Long templateId;
	// Constructors

	public Long getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	/** default constructor */
	public ImsAdministratorShortmsg() {
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getService() {
		return service;
	}


	@Override
	public String toString() {
		return "ImsAdministratorShortmsg [id=" + id + ", service=" + service
				+ ", adminName=" + adminName + ", mobile=" + mobile
				+ ", status=" + status + ", createTime=" + createTime
				+ ", templateId=" + templateId + "]";
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getAdminName() {
		return adminName;
	}

	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	
}
package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspRenewInfoDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspRenewInfo;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.entity.IspShortmsgTemplate;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;
import com.taiping.facility.tool.VelocityTool;

/**
 * 养老续期短信提醒
 * @author liuhe
 * @since 20190905
 */
@Service
public class ShortMsgImpl_renew_200000094 extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	@Resource
	IspRenewInfoDao ispRenewInfoDao;
	
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		
		try {
			String policyNo = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
			String term = MapTool.getStringFromMap(shortMsgParamMap,"term");
			String mobile = MapTool.getStringFromMap(shortMsgParamMap,"mobile");
			
			IspRenewInfo ispRenewInfo = ispRenewInfoDao.getIspRenewInfoByTerm(policyNo, Integer.parseInt(term));
			if(ispRenewInfo==null) {
				LogTool.error(this.getClass(), "IspRenewInfo : 没有续期信息,保单号:"+policyNo+",续期期数:"+term);
				return;
			}
			
			IspBlueprint blueprint = null;
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
	        
	        IspApply apply = ispApplyDao.loadApply(null,policyNo,null,null);
			if (apply != null) {
				blueprint = CacheContainer.getByIdFromCacheThrows(apply.getBlueId(), IspBlueprint.class);
			}else {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+policyNo);
				return;
			}
			if(StringUtils.isEmpty(mobile)) {
				shortMsgParamMap.put("mobile", apply.getHolder().getMobile());
			}else {				
				shortMsgParamMap.put("mobile", mobile);
			}
			shortMsgParamMap.put("blueName", blueprint.getBlueInnerName());
			apply.setInsuranceType(blueprint.getInsuranceType());
			// 下期续期时间
			Date nextPremiumDate = DateTool.calcuNextPremiumDate(apply.getValidateDate(), apply.getChargeType(), Integer.parseInt(term));
			shortMsgParamMap.put("nextPremiumDate", nextPremiumDate);
			
			// 2,构造短信内容
			String shortMsgContent = this.getContent(shortMsgParamMap,apply);
			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
			// 3,构造短信对象
			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
			
			//4,启动后台线程，发送短信
			String result = super.send(shortMsg, apply);
			if (result.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
				IspSendHistory ispSendHistory = ispSendHistoryDao.load(apply.getApplyId());
				ispSendHistory.setIsShortmsgSend(1);
				ispSendHistoryDao.update(ispSendHistory);
			}
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply){
		String content = "";			//短信内容
		Object templateId = shortMsgParamMap.get(ConstantTool.TEMPLATE_ID);
		Integer type = MapTool.getIntegerFromMap(shortMsgParamMap, ConstantTool.TYPE);
		
		IspShortmsgTemplate shortmsgTemplate = CacheContainer.getShortmsgTemplateFromCache(templateId, type, IspShortmsgTemplate.class);
		// 获取一个新的模板上下文,生成短信内容
		VelocityTool velocityTool = new VelocityTool();
		VelocityContext context = new VelocityContext();
		context.put("velocityTool", velocityTool);
		context.put("params", shortMsgParamMap);
		content = TemplateToolV1218.fill(context, shortmsgTemplate.getRequestXmlTemplate()); // 填充模板  得到短信内容
		
		return content;
	}
}

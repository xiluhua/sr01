package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "DS_IPAY_REGISTER_TEMPLATE_CODE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IpayRegisterTemplateCode implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Fields
	private Long Id;
	private Long blueId;
	private Long partnerId;
	private Integer sellChannel;
	private Integer chargeType;
	private Integer status;
	private Integer type;
	private String paymentMethod;			// 1:web.电脑PC支付|2:wechat.微信公众号支付|3:alipay.支付宝移动wap支付|4:bill99.快钱移动wap支付|5:wap.支付宝移动wap支付
	private String payTemplateCode;			// 支付平台支付模板映射代码
	private String companyName;	
	private String orgName;
	
	@Id
	@Column(name = "ID")
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	@Column(name = "SELL_CHANNEL")
	public Integer getSellChannel() {
		return sellChannel;
	}
	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}
	@Column(name = "PAYMENT_METHOD")
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	@Column(name = "PAY_TEMPLATE_CODE")
	public String getPayTemplateCode() {
		return payTemplateCode;
	}

	public void setPayTemplateCode(String payTemplateCode) {
		this.payTemplateCode = payTemplateCode;
	}
	
	@Column(name = "ORG_NAME")
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	
	@Column(name = "COMPANY_NAME")
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	
	@Column(name = "TYPE")
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	
	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
	@Column(name = "BLUE_ID")
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	
	@Column(name = "PARTNER_ID")
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	
	@Column(name = "CHARGE_TYPE")
	public Integer getChargeType() {
		return chargeType;
	}
	public void setChargeType(Integer chargeType) {
		this.chargeType = chargeType;
	}
	
	
	
}

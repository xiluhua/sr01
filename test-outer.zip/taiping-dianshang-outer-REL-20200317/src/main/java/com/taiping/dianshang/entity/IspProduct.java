package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * IspProduct entity. 
 */
@Entity
@Table(name = "CP_ISP_PRODUCT")
public class IspProduct implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long productId;
	private String productCode;
	private String productName;
	private String ma;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;

	// Constructors

	/** default constructor */
	public IspProduct() {
	}

	/** minimal constructor */
	public IspProduct(Long productId) {
		this.productId = productId;
	}

	/** full constructor */
	public IspProduct(Long productId, String productCode, String productName,
			String ma, Date createTime, Date updateTime, String createAid,
			String updateAid) {
		this.productId = productId;
		this.productCode = productCode;
		this.productName = productName;
		this.ma = ma;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
	}

	// Property accessors
	@Id
	@Column(name = "PRODUCT_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getProductId() {
		return this.productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	@Column(name = "PRODUCT_CODE", length = 20)
	public String getProductCode() {
		return this.productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	@Column(name = "PRODUCT_NAME", length = 200)
	public String getProductName() {
		return this.productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	@Column(name = "MA", length = 10)
	public String getMa() {
		return this.ma;
	}

	public void setMa(String ma) {
		this.ma = ma;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

}
/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.dianshang.outer.DTO.callback.baidu;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by tianhuang on 17/12/18.
 */

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
        "SpNo",
        "ChannelId",
        "RequestTime",
        "Version",
        "BizType"
})
public class Head {
    @XmlElement(name = "SpNo")
    private String SpNo = "1000000005";
    @XmlElement(name = "ChannelId")
    private String ChannelId = "taiping";
    @XmlElement(name = "RequestTime")
    private String RequestTime = null;
    @XmlElement(name = "Version")
    private String Version = "1.0";
    @XmlElement(name = "BizType")
    private String BizType = "101";

    public String getSpNo() {
        return SpNo;
    }

    public void setSpNo(String spNo) {
        SpNo = spNo;
    }

    public String getChannelId() {
        return ChannelId;
    }

    public void setChannelId(String channelId) {
        ChannelId = channelId;
    }

    public String getRequestTime() {
        return RequestTime;
    }

    public void setRequestTime(String requestTime) {
        RequestTime = requestTime;
    }

    public String getVersion() {
        return Version;
    }

    public void setVersion(String version) {
        Version = version;
    }

    public String getBizType() {
        return BizType;
    }

    public void setBizType(String bizType) {
        BizType = bizType;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}

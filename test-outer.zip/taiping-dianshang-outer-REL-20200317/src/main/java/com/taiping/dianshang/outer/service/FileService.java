package com.taiping.dianshang.outer.service;

import java.io.IOException;
import java.io.InputStream;

public interface FileService {
	
	/**
	 * 将文件流转成byte
	 * @param in
	 * @return
	 * @throws Exception
	 */
	public byte[] read(InputStream in) throws Exception;
	/**
	 * 从核心获取电子保单
	 * @param userId
	 * @return
	 */
	public String getPolFile(String polno,Integer sellChannel,String rootPath)throws Exception;
	/**
	 * 获取电子保单路径
	 * @param polno
	 * @param userId
	 * @return
	 */
	public String getPolPath(String polno,Integer sellChannel)throws Exception;
	
	/**
	 * 将保单copy到一个指定文件夹
	 * @param uploadFilePath 上传的保单集合
	 * @param srcFilePathDir 原电子保单所在目录
	 * @param newFilePath	新电子保单存储目录
	 * by xiluhua by 2012-12-24
	 * @throws IOException 
	 * @throws IOException 
	 */
	public void copyPoliciesToNewdir(String policies,String srcFilePathDir,String newFilePath) throws IOException;
	
	/**
	 * 得到保单文件路径
	 * @param srcFilePathDir 原保单文件目录
	 * @param policyNo 保单号
	 * @return
	 * by xiluhua 2012-12-24
	 */
	public String getSrcFilePath(String srcFilePathDir,String policyNo);	
}

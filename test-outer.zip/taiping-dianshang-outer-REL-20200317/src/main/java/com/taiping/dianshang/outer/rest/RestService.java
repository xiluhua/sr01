package com.taiping.dianshang.outer.rest;

import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Path("/core/business")
@Produces("*/*")
public interface RestService {

	@GET
	@Path(value = "/cacheRefresh")
	public String cacheRefresh();
	
	@POST
	@Path(value = "/entrance")
	public String entrance(String requestMsg);
	
	
}

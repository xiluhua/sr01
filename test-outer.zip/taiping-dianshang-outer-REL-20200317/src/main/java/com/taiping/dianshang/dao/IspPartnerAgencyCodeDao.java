package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspPartnerAgencyCode;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspPartnerAgencyCodeDao extends BaseWriteDao<IspPartnerAgencyCode, Long> implements CacheDaoService{

	@Override
	public Map<Object, String> getAllInMap() {
		List<IspPartnerAgencyCode> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspPartnerAgencyCode partnerAgencyCode = list.get(i);
				if (partnerAgencyCode.getPartnerId() != null) {
					String key = KeyTool.get(IspPartnerAgencyCode.class, partnerAgencyCode.getPartnerId());
					map.put(key, JsonTool.toJson(partnerAgencyCode));	
				}
			}
		}
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspPartnerAgencyCode> getAll(){
		String hql = "from IspPartnerAgencyCode t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
	
}

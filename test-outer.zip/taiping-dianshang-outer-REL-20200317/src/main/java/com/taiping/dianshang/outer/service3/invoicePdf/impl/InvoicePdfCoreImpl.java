package com.taiping.dianshang.outer.service3.invoicePdf.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.dom4j.Document;
import org.springframework.stereotype.Service;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.service3.invoicePdf.InvoicePdfCoreService;
import com.taiping.dianshang.outer.service3.url.UrlService;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.IOTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.TemplateToolV1218;
import com.taiping.facility.tool.XmlTool;

@Service
public class InvoicePdfCoreImpl implements InvoicePdfCoreService {

	@Resource
	private UrlService urlService;
	@Resource
	private HttpclientImpl httpclientImpl;
	
	@Override
	public void handleCore(Busi busi) throws Exception {
		
		String requestXml = this.objectToXml(busi, null);

		// 发送核心报文
		Date begin = new Date();
		Map<String, String> paramsMap = new HashMap<String, String>();
		paramsMap.put("packet", requestXml);
		
		String responseXml = this.sendMsgToCore(null, null, paramsMap);
		
		Date end = new Date();
		long inteval = end.getTime() - begin.getTime();
		LogTool.info(this.getClass(), "=============================================================");
		LogTool.info(this.getClass(), "核心处理时间：" + inteval + "ms");
		LogTool.info(this.getClass(), busi.getApply().getPartnerApplyId()+", responseXml:\n" + responseXml);
		
		this.xmlToObject(busi, responseXml);
	}

	@Override
	public String objectToXml(Busi busi, IspRmi rmi) throws Exception {
		IspApply apply = busi.getApply();

		VelocityContext context = new VelocityContext();
		context.put("dateTools", new DateTool());
		context.put("apply", apply);
		context.put("transTime", new Date());

		String path = this.getClass().getResource("/template/applyInvoice.xml").getPath();
		String requestXml = IOTool.readFile(path, "GBK"); // 请确认编码方式
		requestXml = TemplateToolV1218.fill(context, requestXml);
		LogTool.info(this.getClass(), "sendCoreApplyPost Invoice xml is: " + requestXml);

		if (StringUtils.isEmpty(requestXml)) {
			throw new Exception("请求申请发票报文模板出错");
		}
		return requestXml;
	}

	@Override
	public String sendMsgToCore(IspRmi rmi, IspHttpclientParams httpclientParams, Map<String, String> paramsMap) throws Exception {
		String coreUrl = urlService.dsCoreUrl();
		if (LogTool.isLocal) {
			if (PropertyFileTool.get("core.invoice.apply.url") != null) {
				coreUrl = PropertyFileTool.get("core.invoice.apply.url");
			}
		}
		String requestXml = paramsMap.get("packet");
		String responseXml = httpclientImpl.post(coreUrl, requestXml, "UTF-8");
		return responseXml = Base64Tool.decode(responseXml, "UTF-8");
	}

	@Override
	public void xmlToObject(Busi busi, String responseXml) throws Exception {
		ResponseDTO responseDTO = busi.getResponseDTO();
		try {
			if (StringUtils.isEmpty(responseXml)) {
				responseDTO.getBusiness().setReturnInfo("电子发票申请接口返回为空");
				return;
			}
			Document responseDoc = XmlTool.bulidXmlDoc(responseXml); // 报文对象
			String succNode = "/RESPONSE/BUSINESS/IS_SUCCESS";
			String infoNode = "/RESPONSE/BUSINESS/RETURN_INFO";
			String result = responseDoc.selectSingleNode(succNode) == null?"":responseDoc.selectSingleNode(succNode).getText();
			String info   = responseDoc.selectSingleNode(infoNode) == null?"电子发票申请失败":responseDoc.selectSingleNode(infoNode).getText();
			if (Boolean.valueOf(result)) {
				responseDTO.getBusiness().setSuccess(true);
			}else {
				responseDTO.getBusiness().setReturnInfo(info);
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}

	@Override
	public void updateAfterCoreBusiness(Busi busi) throws Exception {
		// TODO Auto-generated method stub

	}
}

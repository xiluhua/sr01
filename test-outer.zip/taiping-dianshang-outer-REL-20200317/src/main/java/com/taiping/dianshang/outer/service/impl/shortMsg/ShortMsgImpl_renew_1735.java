package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;
import javax.annotation.Resource;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.entity.IspPartner;
import com.taiping.dianshang.entity.IspShortmsgTemplate;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.DesTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 短信发送通用服务
 * @author xilh
 * @since 20170321
 */
@Service
public class ShortMsgImpl_renew_1735 extends ShortMsgImpl_COMMON_1 implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	@Override

	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply){
		String content = "";			//短信内容
		String holderSex = "";
		String holderName = "";
		String blueName = "";
		
		Long templateId = MapTool.getLongFromMap(shortMsgParamMap, ConstantTool.TEMPLATE_ID);
		Integer type = MapTool.getIntegerFromMap(shortMsgParamMap, ConstantTool.TYPE);
		String partnerApplyId = apply.getPartnerApplyId();
		IspCustomer holder = apply.getHolder(); 
		holderName = holder.getCustName();
		if (holder.getGender() == 1) {
			holderSex = "先生";
		} else {
			holderSex= "女士";
		}
		
		IspBlueprint blueprint = CacheContainer.getByIdFromCache(apply.getBlueId(), IspBlueprint.class);
		if (blueprint != null) {
			blueName = blueprint.getBlueInnerName();
		}
		
		IspShortmsgTemplate shortmsgTemplate = CacheContainer.getShortmsgTemplateFromCache(templateId,type, IspShortmsgTemplate.class);
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put("holderName", holderName);
		context.put("holderSex", holderSex);
		context.put("blueName", blueName);
		context.put("partnerApplyId", partnerApplyId);
		context.put("apply", apply);
		context.put("polno", apply.getPolicyNo());
		context.put("userName", holder.getCustName());
		context.put("wxhome", shortMsgParamMap.get("wxhome"));
		context.put("validateDate", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK));
		context.put("expirationDate", DateTool.convertDataToString(apply.getExpirationDate(), DateTool.DATE_MASK));
		// add by xiluhua 20180809 for 百万医疗续期
		String expireDateZH = DateTool.convertDataToString(apply.getExpirationDate(), DateTool.DATE_MASK2);
		context.put("expireDateZH", expireDateZH);
		
		String polnoEnc			 = this.encode(apply.getPolicyNo());
		String partnerApplyIdEnc = this.encode(apply.getPartnerApplyId());
		context.put("polnoEnc", polnoEnc);
		context.put("partnerApplyIdEnc", partnerApplyIdEnc);
		content = TemplateToolV1218.fill(context, shortmsgTemplate.getRequestXmlTemplate()); // 填充模板  得到短信内容
		
		return content;
	}
	
	private String encode(String value) {
		String key = CacheContainer.getSystemParameterValueNoThrows("1735.policyNo.private.key");
		DesTool desTool = new DesTool();
		desTool.setKey(key);
		String polnoEnc = desTool.getEncString(value);
		return polnoEnc;
	}
}

package com.taiping.dianshang.outer.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.IspApplyService;

@Service
public class IspApplyImpl implements IspApplyService{

	@Resource
	IspApplyDao ispApplyDao;
	
	@Override
	@Transactional
	public IspApply loadApply(String partnerApplyId, String policyNo,
			String appno, Long applyId) {
		return ispApplyDao.loadApply(partnerApplyId, policyNo, appno, applyId);
	}

}

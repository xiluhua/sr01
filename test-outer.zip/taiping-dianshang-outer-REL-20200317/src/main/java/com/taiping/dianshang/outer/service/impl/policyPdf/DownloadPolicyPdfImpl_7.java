package com.taiping.dianshang.outer.service.impl.policyPdf;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.*;
import com.taiping.facility.tool.fosun.util.SecurityUtil;
import org.apache.velocity.VelocityContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.util.Date;

/**
 * Created with IntelliJ IDEA.
 * Author Li.Wei
 * Date 2019/5/8 2:59 PM
 * Description: 复星产品电子保单下载
 */
@Service
public class DownloadPolicyPdfImpl_7 implements DownloadPolicyPdfService {
    @Autowired
    IspPolicyDao ispPolicyDao;

    /**
     * Author Li.Wei
     * Date  2019/5/8 2:59 PM
     * Description 拼装报文从复星下载电子保单
    */
    @Transactional
    public String download(String policyNo, String idNo) {
        String path = null;
        try {
            IspPolicy policy = ispPolicyDao.load(policyNo);
            if (policy == null) {
                return null;
            }

            //1. init path
            String dir = PropertyFileTool.get("policy.pdf.dir");
            if (!new File(dir).exists()) {
                new File(dir).mkdirs();
            }
            path = dir+policyNo+".pdf";
            LogTool.debug(this.getClass(),"download.pdf.dir.path：" + path);
            LogTool.debug(this.getClass(),"policy.download.url: " + policy.getDownloadRes());

            //2. get send URL
            IspRmi rmi = CacheContainer.getByIdFromCache(ConstantTool.FOSUN_DOWNLOAD_POLICY_PDF_RMI,IspRmi.class);
            if (rmi ==null) {
                throw new Exception("保单下载地址未配置");
            }

            //3. init param
            String date = DateTool.convertDataToString(policy.getAcceptDate(),"yyyy-MM-dd");
            String requestXml = concatRequestXML(rmi,policyNo,date);
            String signKey = PropertyFileTool.get("fx_sign_key");
            String requetXmlKey = PropertyFileTool.get("fx_request_key");
            String greatSignKey = SecurityUtil.Md5(requestXml + signKey); //签名
            requestXml = SecurityUtil.aesEncrypt(requestXml, requetXmlKey); //加密后的报文

            //4. download
            PdfDownloadTool httpClient = new PdfDownloadTool();
            httpClient.addParameter("request_xml", requestXml);
            httpClient.addParameter("ebiz_sign", greatSignKey);
            httpClient.persistentPDF(rmi.getUrl(),path);
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
            throw new DownloadPolicyPdfSysException();
        }
        return path;
    }

    /**
     * Author Li.Wei
     * Date  2019/5/8 5:27 PM
     * Description 组装XML
    */
    private String concatRequestXML(IspRmi rmi,String policyNo, String date){
        String serialNo = policyNo+DateTool.convertDataToString(new Date(), DateTool.DATE_TIME_MASK2);
        // 构建请求报文，并转换成报文字符串
        VelocityContext context = new VelocityContext();
        context.put("velocityTool", new VelocityTool());
        context.put("policyNo", policyNo);
        context.put("date", date);
        context.put("serialNo", serialNo);
        String  requestXml = TemplateToolV1218.fill(context, rmi.getRequestXmlTemplate());
        LogTool.debug(this.getClass(), "Fosun downloadPolicyPdf xml is: " + requestXml);
        return requestXml;
    }
}

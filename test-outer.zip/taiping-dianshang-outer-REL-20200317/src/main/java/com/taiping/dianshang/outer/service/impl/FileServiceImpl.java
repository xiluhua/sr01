package com.taiping.dianshang.outer.service.impl;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspPolicyDao;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.outer.service.FileService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.FileTool;
import com.taiping.facility.tool.FilesUtil;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PdfDownloadTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.XmlTool;
import com.taiping.facility.tool.ZipFileTool;

@Service
public class FileServiceImpl implements FileService {

	@Resource
	private IspPolicyDao ispPolicyDao;
	
	/**
	 * 将文件流转换成byte
	 */
	public byte[] read(InputStream in) throws Exception {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		if (in != null) {
			byte[] buffer = new byte[1024];
			int length = 0;
			while ((length = in.read(buffer)) != -1) {
				out.write(buffer, 0, length);
			}
			out.close();
			in.close();
			return out.toByteArray();
		}
		return null;
	}

	

	/**
	 * 验证保单文件下载参数
	 * 
	 * @param polno
	 * @param sellChannel
	 * @return
	 */
	private boolean checkPolicyFileDownloadParms(String polno,
			Integer sellChannel) {
		// 销售渠道非空判断
		if (sellChannel == null) {
			LogTool.info(this.getClass(), "销售渠道sellChannel字段不能为空："+ sellChannel);
			return false;
		}
		// 保单号非空及长度判断
		if (polno == null || "null".equals(polno.trim())|| polno.trim().length() < 12) {
			LogTool.info(this.getClass(), "保单号polNO字段不能为空且长度必须大于12：" + polno);
			return false;
		}
		return true;
	}

	

	/**
	 * 判断文件是否为有效文件
	 * 
	 * @param filePath
	 * @return
	 */
	private boolean fileIsAvailable(String filePath) {
		File policyFile = new File(filePath);
		InputStream in = null;
		try {
			if (policyFile.exists()) {
				in = new FileInputStream(policyFile);
				if (in.available() == 0) {
					return false;
				}
			} else {
				return false;
			}
		} catch (Exception e) {
			return false;
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (Exception e2) {
					e2.printStackTrace();
				}
			}
		}
		return true;
	}

	/**
	 * 获取保单文件路径
	 * 
	 * @param polno
	 * @param sellChannel
	 * @return 成功返回文件路径，失败返回failed字符
	 */
	public String getPolPath(String polno, Integer sellChannel) throws Exception{
		String rootPath = PropertyFileTool.get("policy.pdf.dir");
		// //验证保单文件下载参数
		if (!checkPolicyFileDownloadParms(polno, sellChannel)) {
			return "failed";
		}
		
		// 打印系统获取参数
		LogTool.info(this.getClass(), "==================================================");
		LogTool.info(this.getClass(), "PolicyPath:" + rootPath);
		// 存放文件路径
		String policyFilePath = buildPolicyFilePath(polno, rootPath) + polno+ ".pdf";
		if (!fileIsAvailable(rootPath)) {
			return this.getPolFile(polno, sellChannel,rootPath);
		}
		return policyFilePath;
	}

	/**
	 * 将保单copy到一个指定文件夹
	 * 
	 * @param uploadFilePath
	 *            上传的保单集合
	 * @param srcFilePathDir
	 *            原电子保单所在目录
	 * @param newFilePath
	 *            新电子保单存储目录 by xiluhua by 2012-12-24
	 * @throws IOException
	 */
	public void copyPoliciesToNewdir(String policies, String srcFilePathDir,
			String newFilePath) throws IOException {
		FilesUtil filesUtil = new FilesUtil();
		List nonexistPolicyList = new ArrayList<String>();
		String[] policiesArray = policies.split(",");

		for (int i = 0; i < policiesArray.length; i++) {
			String newFilePathTemp = newFilePath;
			String tempPolicy = policiesArray[i].toString().trim();
			String tempPath = this.getSrcFilePath(srcFilePathDir, tempPolicy);

			System.out.println("newFilePath ====>" + newFilePath
					+ "\n\nnew File(tempPath).exists() ====> "
					+ new File(tempPath).exists());

			if (new File(tempPath).exists()) {
				if (!new File(newFilePath).exists()) {
					new File(newFilePath).mkdirs();
				}
				newFilePathTemp = newFilePathTemp + "/" + tempPolicy + ".pdf";
				System.out.println("\nnewFilePath ====>"
						+ newFilePath);
				filesUtil.copyFile(tempPath, newFilePathTemp);
			} else {
				nonexistPolicyList.add(tempPolicy);
			}
		}
		String zipFile = newFilePath + ".zip";
		ZipFileTool.zip(newFilePath, zipFile);
		FileTool.deleteFile(newFilePath);
		new File(newFilePath).delete();
		System.out.println("those policies not available : "
				+ nonexistPolicyList.toString());
	}

	/**
	 * 得到保单文件路径
	 * 
	 * @param srcFilePathDir
	 *            原保单文件目录
	 * @param policyNo
	 *            保单号
	 * @return by xiluhua 2012-12-24
	 */
	public String getSrcFilePath(String srcFilePathDir, String policyNo) {
		String pathLayer2 = policyNo.substring(0, 6);
		String pathLayer3 = policyNo.substring(6, 9);
		String pathLayer4 = policyNo.substring(9, 12);

		StringBuffer buffer = new StringBuffer(srcFilePathDir);
		buffer.append(pathLayer2);
		buffer.append(File.separator);
		buffer.append(pathLayer3);
		buffer.append(File.separator);
		buffer.append(pathLayer4);
		buffer.append(File.separator);
		buffer.append(policyNo);
		buffer.append(".pdf");

		return buffer.toString();
	}

	public static void main(String[] args) {
		String pathString = FileServiceImpl.class.getResource("/template/downloadLifePDF.xml").getPath();
		System.out.println(pathString);
		File file = new File(pathString);
		System.out.println(file.exists());
		Document doc = XmlTool.bulidXmlDocByFile(pathString);
		System.out.println(doc.asXML());
		
	}
	/**
	 * 电子保单下载
	 * 
	 * @param polno
	 * @param sellChannel
	 * @return 成功返回文件转换成的byte数据，失败返回failed字符
	 */
	public String getPolFile(String polno,Integer sellChannel,String path)throws Exception {
		
		String downloadUrl = CacheContainer.getSystemParameterValue(ConstantTool.TPLIFE_POLICY_PDF_DOWNLOAD_URL);
		if (LogTool.isLocal || LogTool.isUat) {
			IspPolicy policy = ispPolicyDao.getIspPolicy(polno);
			IspBlueprint blueprint = CacheContainer.getByIdFromCache(policy.getBlueId(), IspBlueprint.class);
			if (blueprint != null && !StringUtils.isEmpty(blueprint.getImagePath())) {
				downloadUrl = CacheContainer.getSystemParameterValue(ConstantTool.TPLIFE_POLICY_PDF_DOWNLOAD_URL+"."+blueprint.getImagePath());
			}
		}
		
		//存放文件路径
		LogTool.debug(this.getClass(), "downloadUrl: "+downloadUrl);
		
		PdfDownloadTool httpClient = new PdfDownloadTool();//组织保单下载请求信息
		//根据销售渠道类型查找对应渠道目录
		if (1 == sellChannel) {//寿险处理
			//获取下载保单报文模板
			String pathString = this.getClass().getResource("/template/downloadLifePDF.xml").getPath();
			LogTool.debug(this.getClass(), "/template/downloadLifePDF.xml path: "+pathString);
			Document doc = XmlTool.bulidXmlDocByFile(pathString,ConstantTool.GBK);
			//组织报文信息
			doc.selectSingleNode("/REQUEST/BUSI/CONTENT/MAIN/POL").setText(polno);
			doc.selectSingleNode("/REQUEST/BUSI/TRSDATE").setText(DateTool.getDateTime("yyyyMMdd",  new Date()));
			doc.selectSingleNode("/REQUEST/BUSI/TRANS").setText(DateTool.getDateTime("yyyyMMdd",  new Date()));
			httpClient.setService("DOWN-PDF");
			LogTool.debug(this.getClass(), doc.asXML());
			//初始化保单下载参数
			Map<String, String> parameters = new HashMap<String, String>();
			parameters.put("packet", doc.asXML());
			parameters.put("protocol", "01");
			httpClient.setParameters(parameters);
			
			//打印系统获取参数
			LogTool.info(this.getClass(), "系统参数获取:rootPath:"+path+",download_policyUrl:"+downloadUrl);
			
			try {
				//保存电子保单
				httpClient.persistentPDF(downloadUrl,path);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
		
		return path;
	}
	
	/**
	 * 构建保单文件路径
	 * 
	 * @param rootPath
	 * @param polNO
	 * @return
	 */
	private String buildPolicyFilePath(String polno, String rootPath) {
		// 保单存放目录，保单号的按照6/3/3长度拆分后作为分级目录
		StringBuffer filePathBuffer = new StringBuffer();
		filePathBuffer.append(rootPath);
		filePathBuffer.append(polno.substring(0, 6));
		filePathBuffer.append(File.separator);
		filePathBuffer.append(polno.substring(6, 9));
		filePathBuffer.append(File.separator);
		filePathBuffer.append(polno.substring(9, 12));
		filePathBuffer.append(File.separator).toString();
		File policyFolderFile = new File(filePathBuffer.toString());
		if (!policyFolderFile.exists()) {
			policyFolderFile.mkdirs();
		}
		LogTool.info(this.getClass(), "保单存放目录:" + filePathBuffer.toString());
		return filePathBuffer.toString();
	}
}

package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.SpringTool;

/**
 * @category 网电业务承保短信+积分发送服务
 * 太平网上商城除天猫、蚂蚁渠道以外的：
1、	承保短信：内容更新为：【太平保险经纪】尊敬的  <APPLICANT_NAME投保人 先生/女士>,感谢您投保太平网上商城保险产品 [产品名称（交xx年）]，保单号为 <承保单号>,
下载电子保单点击：<电子保单下载链接>。欢迎关注“太平金服”微信公众号。
发送时间：承保后即时
发送范围：太平网上商城除天猫、蚂蚁渠道以外的长期寿险（短险请评估是否有下载电子保单的链接）
<电子保单下载链接>：长期寿险需要含有回执回销流程及纸质保单补发功能（太寿网厅流程）
2、	防欺诈短信：【太平保险经纪】温馨提示：为避免诈骗电话或短信给您带来不必要的损失，保障您的利益，不要轻信陌生电话和手机短信。如有疑问，欢迎致电咨询：中国太平官方客服95589，
太平保险经纪客服10109999转1。
发送时间：承保后即时
发送范围：太平网上商城除天猫、蚂蚁渠道以外的网上商城所有承保保单
3、	犹豫期告知短信1：【太平保险经纪】温馨提示：尊敬的  <APPLICANT_NAME投保人 先生/女士>,感谢您投保太平网上商城保险产品 [产品名称（交xx年）]，从您确认收到电子保单起
您有15天的犹豫期，在犹豫期内您可以无条件解除保险合同，超过犹豫期解除保险合同您会有一定的损失。如有疑问，欢迎致电咨询：中国太平官方客服95589，太平保险经纪客服10109999转1。
发送时间：承保后发送
发送范围：太平网上商城除天猫、蚂蚁渠道以外的长期寿险承保保单

 * @author xilh
 * @since 20181122
 * from 王丽军
 */
@Service
public class ShortMsgAndGiftImpl_CBCG_1_FQZ_YYQ_taiping implements ShortMsgService{

	@Override
	public void handle(Map<String, Object> shortMsgParamMap) {
		String services = CacheContainer.getSystemParameterValueNoThrows("1.long.blue.shortMsg.services.taiping");
		// 流水号
        String partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
		LogTool.info(this.getClass(), partnerApplyId +",0, "+ services);
		String[] array  = services.split(",");
		for (int i = 0; i < array.length; i++) {
			String bean = array[i];
			try {
				ShortMsgService shortMsgService = SpringTool.getSpringBean(bean);
				shortMsgService.handle(shortMsgParamMap);
				LogTool.info(this.getClass(), partnerApplyId +","+(i+1)+", "+ bean);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
	}

	@Override
	public TPSmsMessages initMsg(Map<String, Object> shortMsgParamMap,
			String serviceId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getContent(Map<String, Object> shortMsgParamMap,
			IspApply apply) {
		// TODO Auto-generated method stub
		return null;
	}
	

}

package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.exception.EmailSendFailureException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;

@Service
public class ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	BusinesslogService businesslogService;
	
	static{
		shortMsgTemplatePathInit();
	}
	
	/**
	 * 得到短信模板根目录路径
	 */
	public static void shortMsgTemplatePathInit(){
		LogTool.info(ConstantTool.class, "=== INIT SHORTMSG TEMPLATE ===");
		String shortMsgTemplate = ConstantTool.class.getResource("/template/shortMsg/XYHCB.html").getPath();
		LogTool.info(ConstantTool.class, "SHORTMSG TEMPLATE : "+shortMsgTemplate);
		ConstantTool.SHORTMSG_TEMPLATE_PATH = shortMsgTemplate.substring(0, shortMsgTemplate.lastIndexOf("/")+1);
	}
	
	/**
	 * 初始化短信数据
	 * @return
	 */
	public TPSmsMessages initMsg(Map<String, Object> shortMsgParamMap,String serviceId){
		TPSmsMessages msgs = new TPSmsMessages();
		// shortMsgParams涉及到的参数参考IIP_EMAIL_SEND_LIST表对应字段
		String shortMsgParams = null;
		try {
			shortMsgParams = CacheContainer.getSystemParameterValue(serviceId);
		} catch (SystemParameterNotFoundException e) {
			LogTool.error(this.getClass(), e);
			return null;
		}
		
		LogTool.debug(this.getClass(), "===================================");
		LogTool.debug(this.getClass(), "shortMsgParams:"+String.valueOf(shortMsgParams));
		LogTool.debug(this.getClass(), "===================================");
		
		String[] array = shortMsgParams.split(":");
		
		msgs.setIIP_ID((String)shortMsgParamMap.get("shortMsgId"));	//短信主键，唯一
		msgs.setBranchID(array[0]);                			//注1机构编码字段 1
		msgs.setFromID(array[1]);                 			//注2系统来源 FROM_WX
		msgs.setOrgID(array[2]);                  			//注3集团成员 ORG_TPRS
		msgs.setChannelID(array[3]);              			//注4渠道编码 CHANNEL_WX
		msgs.setServiceID(serviceId); 						//注5服务类型ID
		msgs.setStartTime(null);  							//注6发送时间 ,时间格式，为空为即时发送
		msgs.setEndTime(null);   							//注7过期时间，时间格式
		msgs.setLengthSMFLag("1");              			//注8默认为长短信,1为长短信,20130320余方方 邮件中答复的结果
		msgs.setReceiver((String)shortMsgParamMap.get("mobile"));         	//注9手机号码
		msgs.setContents((String)shortMsgParamMap.get("shortMsgContent"));	//注10短信内容
		msgs.setUsername(array[4]); 								//注12保信通登录用户名
		msgs.setPassword(array[5]);									//注13保信通登录用户密码

		return msgs;
	}
	
	public Boolean isUat(){
		Boolean isUat = true;
		String localIp = LogTool.getLocalIp();
		// 正式环境10.4.*
		if (localIp.indexOf("10.4.233") > -1) {
			isUat = false;
		}

		System.out.println("============================");
		System.out.println("localIp:"+localIp);
		System.out.println("isUat:"+isUat);
		System.out.println("============================");
		return isUat;
	}
	
	public String getServiceId(Map<String, Object> shortMsgParamMap){
		String temp = (String)shortMsgParamMap.get(ConstantTool.SERVICE_ID);
		String[] arr = temp.split("_");
		return arr[1];
	}
	
	@Override
	public void handle(Map<String, Object> map) {
		// TODO Auto-generated method stub
		
	}
	
	public String send(TPSmsMessages msgs,IspApply apply) throws EmailSendFailureException {
		String sendReturn = "";
		// 初始化
		//发送失败的话，再发送，连续3次失败就写入日志
		int sendTime = 3;
		try {
			for (int i = 0; i < sendTime; i++) {
				//记录请求3大日志：1,接口访问日志2,报文3,业务操作日志
				this.writeLogRequest(msgs,apply);
				LogTool.info(this.getClass(), "--- sending ---");
				//发送结果
				sendReturn = msgs.send(this.isUat());
				LogTool.info(this.getClass(), "--- after send ---");
				//记录返回3大日志：1,接口访问日志2,报文3,业务操作日志
				this.writeLogReturn(msgs,apply,sendReturn);
				
				if (sendReturn.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
					break;
				}
			}
			
			if (!sendReturn.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
				log_2(msgs,sendReturn);
			}
		} catch (Exception e) {
			//记录返回3大日志：1,接口访问日志2,报文3,业务操作日志
			this.writeLogReturn(msgs,apply,sendReturn);
			log_2(msgs,sendReturn);
			throw new EmailSendFailureException("短信发送失败");
		}
		
		return sendReturn;
	}
	
	/**
	 * //记录请求3大日志：1,接口访问日志2,报文3,业务操作日志
	 * @return
	 */
	public void writeLogRequest(TPSmsMessages msgs, IspApply apply) {
		
	    // 2,记录发送报文日志
		String requestXml = "partnerApplyId: "+apply.getPartnerApplyId()+", IIPID:" + msgs.getIIP_ID() + ".serviceID:"
				+ msgs.getServiceID() + "--mobile:" + msgs.getReceiver()
				+ "--content:" + msgs.getContents();

		LogTool.info(this.getClass(), requestXml);
		
		// 保存 serviceID 便于统计发送数量 add by xiluhua 20190412
		IspApply apply2 = this.getApply2(msgs, apply);
		// 3,记录业务操作日志，业务类型：51，业务操作类型：5101.即时短信发送 请求，5102.即时短信发送 返回
		// businesslogService.postBusinessOpelog(apply,510,1,logIndex);
		businesslogService.postBusinessOpelog_1(apply2, "mobile:" + msgs.getReceiver()+"\r\n"+msgs.getContents(), ConstantTool.INTERFACE_E_510_SHORTMSG, 1, 1);
	}
	
	/**
	 * //记录返回3大日志：1,接口访问日志2,报文3,业务操作日志
	 * @return
	 */
	public void writeLogReturn(TPSmsMessages msgs,IspApply apply,String sendReturn) {
		
	    // 2,记录接收报文日志
		String returnXml = "partnerApplyId: "+apply.getPartnerApplyId()+", IIPID:" + msgs.getIIP_ID() + ".serviceID:"
				+ msgs.getServiceID() + "--mobile:" + msgs.getReceiver()
				+ "--sendReturn:" + sendReturn;
		
		LogTool.info(this.getClass(), returnXml);
	    
	    int operateStatus = 2;
	    if (sendReturn.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
	    	operateStatus = 1;	//	操作成功
		}
	    
	    // 保存 serviceID 便于统计发送数量 add by xiluhua 20190412
	    IspApply apply2 = this.getApply2(msgs, apply);
		//3,记录业务操作日志，业务类型：51，业务操作类型：5101.即时短信发送 请求，5102.即时短信发送 返回
//	    businesslogService.postBusinessOpelog(apply,5102,operateStatus,logIndex);
	    businesslogService.postBusinessOpelog_2(apply2, "mobile:" + msgs.getReceiver()+"\r\n"+sendReturn, ConstantTool.INTERFACE_E_510_SHORTMSG, operateStatus, 1);
	}

	@Override
	public String getContent(Map<String, Object> shortMsgParamMap,
			IspApply apply) {
		// TODO Auto-generated method stub
		return null;
	}
	
	private void log_2(TPSmsMessages msgs,String sendReturn){
		//写入错误日志,并存数据库待事后处理
		LogTool.error(this.getClass(),"failure to send ShortMsg.IIPID:"
				+ msgs.getIIP_ID() + ",serviceID:"
				+ msgs.getServiceID() + "--mobile:"
				+ msgs.getReceiver() + "--sendReturn:"
				+ sendReturn);
	}
	
	/**
	 * 保存 serviceID 便于统计发送数量
	 * @author xilh
	 * @since 20190412
	 * @param msgs
	 * @param apply
	 * @return
	 */
	public IspApply getApply2(TPSmsMessages msgs, IspApply apply){
		IspApply apply2 = new IspApply();
		BeanUtils.copyProperties(apply, apply2);
		
		IspCustomer holder2 = new IspCustomer();
		if (apply2.getHolder() != null) {
			BeanUtils.copyProperties(apply2.getHolder(), holder2);
		}
		
		holder2.setIdNo(msgs.getServiceID());
		apply2.setHolder(holder2);
		return apply2;
	}
}

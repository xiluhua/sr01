package com.taiping.dianshang.outer.DTO.request;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.taiping.dianshang.outer.DTO.request.element.BusinessDTO;
import com.taiping.dianshang.outer.DTO.request.element.CheckBillCallbackDTO;

/**
 * @author: xiluhua by 20181102
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"business",
		"callback"
})
@XmlRootElement(name = "REQUEST")
public class RequestCheckBillCallbackDTO implements RequestDTO {
	@XmlElement(name = "BUSINESS")
	protected BusinessDTO business = new BusinessDTO();
	@XmlElement(name = "CALLBACK")
	protected CheckBillCallbackDTO callback = new CheckBillCallbackDTO();
	
	public BusinessDTO getBusiness() {
		return business;
	}
	public void setBusiness(BusinessDTO business) {
		this.business = business;
	}
	public CheckBillCallbackDTO getCallback() {
		return callback;
	}
	public void setCallback(CheckBillCallbackDTO callback) {
		this.callback = callback;
	}
	public RequestCheckBillCallbackDTO() {
		super();
	}
	
}

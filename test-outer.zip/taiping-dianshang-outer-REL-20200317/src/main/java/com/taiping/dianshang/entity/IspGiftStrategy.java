package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "DS_ISP_GIFT_STRATEGY")
public class IspGiftStrategy implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -8843703108225306620L;
	@Id
	@Column(name="ID")
	private Long id;
	@Column(name="PARTNER_ID")
	private Long partnerId;
	@Column(name="BLUE_ID")
	private Long blueId;
	@Column(name="START_TIME")
	private String startTime;
	@Column(name="END_TIME")
	private String endTime;
	@Column(name="GIFT_SERVICE")
	private String giftService;
	@Column(name="STATUS")
	private Integer status;
	
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
	public String getGiftService() {
		return giftService;
	}
	public void setGiftService(String giftService) {
		this.giftService = giftService;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	
}

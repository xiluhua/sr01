package com.taiping.dianshang.outer.service.impl.autoRegister.ws;


public class RegisterResult {
	
	private String requestId;
	private String serviceId;
	private String appId;
	private String responseCode;
	private String errorMessage;
	private String responseTime;
	private String responseBusinessCode;
	private String responseBusinessMessage;
	private String userId;
	private String status;
	private String trueName;
	// added by xiluhua 2017-06-06
	private String userName;
	private String password;     //密码

	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getTrueName() {
		return trueName;
	}
	public void setTrueName(String trueName) {
		this.trueName = trueName;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getServiceId() {
		return serviceId;
	}
	public void setServiceId(String serviceId) {
		this.serviceId = serviceId;
	}
	public String getAppId() {
		return appId;
	}
	public void setAppId(String appId) {
		this.appId = appId;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public String getResponseTime() {
		return responseTime;
	}
	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}
	public String getResponseBusinessCode() {
		return responseBusinessCode;
	}
	public void setResponseBusinessCode(String responseBusinessCode) {
		this.responseBusinessCode = responseBusinessCode;
	}
	public String getResponseBusinessMessage() {
		return responseBusinessMessage;
	}
	public void setResponseBusinessMessage(String responseBusinessMessage) {
		this.responseBusinessMessage = responseBusinessMessage;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "RegisterResult [requestId=" + requestId + ", serviceId="
				+ serviceId + ", appId=" + appId + ", responseCode="
				+ responseCode + ", errorMessage=" + errorMessage
				+ ", responseTime=" + responseTime + ", responseBusinessCode="
				+ responseBusinessCode + ", responseBusinessMessage="
				+ responseBusinessMessage + ", userId=" + userId + ", status="
				+ status + ", trueName=" + trueName + ", userName=" + userName
				+ ", password=" + password + "]";
	}

	
}

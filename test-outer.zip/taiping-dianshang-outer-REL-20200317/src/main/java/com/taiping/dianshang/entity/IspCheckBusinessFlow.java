package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspCheckBusinessFlow   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_CHECK_BUSINESS_FLOW")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspCheckBusinessFlow implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3852360255317000358L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="BLUE_ID")
	private Long blueId;
	@Column(name="PARTNER_ID")
	private Integer partnerId;
	@Column(name="SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name="STATUS")
	private Integer status;
	@Column(name="NOT_NULL_FIELDS_SERVICE")
	private String notNullFieldsService;			// 非空字段校验
	@Column(name="VALIDATOR_SERVICE")
	private String validatorService;				// 投被保人字段校验
	@Column(name="BALCK_NAME_VALIDATOR_SERVICE")
	private String blackNameValidatorService;		// 黑名单校验
	@Column(name="IDNO_TERM_VALIDATOR_SERVICE")
	private String idNoTermValidatorService;		// 身份证有效期校验	
	@Column(name="PARTNER_BUSI_PROPERTY_SERVICE")
	private String partnerBusiPropertyService;		// 合作方业务属性校验
//	@Column(name="GET_BLUEPRINTFEE_SERVICE")
//	private String getBlueprintfeeService;
	@Column(name="SUPPLEMENT_SERVICE")		
	private String supplementService;				// 投保信息补全
	@Column(name="PERSIST_SERVICE")
	private String persistService;					// 持久化
	@Column(name="PRECHECK_SERVICE")
	private String precheckService;					// 预核保
	@Column(name="CHECKCORE_SERVICE")
	private String checkcoreService;				// 核保（到核心）
	@Column(name="CHECKRULECORE_SERVICE")
	private String checkruleCoreService;			// 规则库（到核心）

	
	public IspCheckBusinessFlow() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Long getId() {
		return Id;
	}


	public void setId(Long id) {
		Id = id;
	}


	public Long getBlueId() {
		return blueId;
	}


	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}


	public Integer getPartnerId() {
		return partnerId;
	}


	public void setPartnerId(Integer partnerId) {
		this.partnerId = partnerId;
	}

	public Integer getSellChannel() {
		return sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}
	
	public String getValidatorService() {
		return validatorService;
	}


	public void setValidatorService(String validatorService) {
		this.validatorService = validatorService;
	}


	public String getPartnerBusiPropertyService() {
		return partnerBusiPropertyService;
	}


	public void setPartnerBusiPropertyService(String partnerBusiPropertyService) {
		this.partnerBusiPropertyService = partnerBusiPropertyService;
	}


//	public String getGetBlueprintfeeService() {
//		return getBlueprintfeeService;
//	}
//
//
//	public void setGetBlueprintfeeService(String getBlueprintfeeService) {
//		this.getBlueprintfeeService = getBlueprintfeeService;
//	}


	public String getSupplementService() {
		return supplementService;
	}


	public void setSupplementService(String supplementService) {
		this.supplementService = supplementService;
	}


	public String getPersistService() {
		return persistService;
	}


	public void setPersistService(String persistService) {
		this.persistService = persistService;
	}


	public String getPrecheckService() {
		return precheckService;
	}

	public void setPrecheckService(String precheckService) {
		this.precheckService = precheckService;
	}

	public String getCheckcoreService() {
		return checkcoreService;
	}

	public void setCheckcoreService(String checkcoreService) {
		this.checkcoreService = checkcoreService;
	}

	public String getCheckruleCoreService() {
		return checkruleCoreService;
	}

	public void setCheckruleCoreService(String checkruleCoreService) {
		this.checkruleCoreService = checkruleCoreService;
	}

	public String getNotNullFieldsService() {
		return notNullFieldsService;
	}

	public void setNotNullFieldsService(String notNullFieldsService) {
		this.notNullFieldsService = notNullFieldsService;
	}

	public String getBlackNameValidatorService() {
		return blackNameValidatorService;
	}

	public void setBlackNameValidatorService(String blackNameValidatorService) {
		this.blackNameValidatorService = blackNameValidatorService;
	}

	public String getIdNoTermValidatorService() {
		return idNoTermValidatorService;
	}

	public void setIdNoTermValidatorService(String idNoTermValidatorService) {
		this.idNoTermValidatorService = idNoTermValidatorService;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}





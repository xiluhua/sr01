package com.taiping.dianshang.outer.service.impl.email;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.ImsAdministratorEmailDao;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.entity.ImsAdministratorEmail;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.outer.service.MailNotifyService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.StringTool;
import com.taiping.facility.tool.TemplateToolV1218;
import com.taiping.framework.bean.MailAttachment;
import com.taiping.framework.bean.MailMessageBean;
import com.taiping.framework.service.MailService;

@Service
public class MailNotifyImpl_CB_ERR_1 extends MailNotifyImpl implements MailNotifyService{
	@Resource
    private MailService mailService;
	@Resource
	private IspApplyDao ispApplyDao;
	@Resource
	private ImsAdministratorEmailDao imsAdministratorEmailDao;
	
	/**
	 * 发送承保失败通知邮件
	 * @param emailParamsMap
	 */
	@Transactional
	public void handle(Map<String, Object> emailParamsMap){
		String blueName = null;
		String partnerApplyId = null;
		try {
			// 创建mail info对象
	        MailMessageBean mmsg = super.initMailMessageBean(ConstantTool.WX_CBCG);
	        if (mmsg == null) {
				return;
			}
	        // 保单号
	        partnerApplyId = StringTool.nullToEmpty(emailParamsMap.get("operateNo"));
			
			IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply != null) {
				IspBlueprint blueprint = CacheContainer.getByIdFromCacheThrows(apply.getBlueId(), IspBlueprint.class);
				blueName=blueprint.getBlueInnerName();
			}else {
				LogTool.error(this.getClass(),"邮件发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			
			// update: rm by xiluhua 20190814
//			Map<Object, ImsAdministratorEmail> map = (Map<Object, ImsAdministratorEmail>)CacheContainer.getListByIdFromCache(ImsAdministratorEmail.class);
//			for (Map.Entry<Object, ImsAdministratorEmail> entry : map.entrySet()) {
//	            LogTool.debug(this.getClass(), entry.getKey() + "--->" + entry.getValue());
//	            if (entry.getValue().getService().equalsIgnoreCase(this.getClass().getSimpleName())) {
//	            	String realName = apply.getHolder().getCustName();
//					String email = entry.getValue().getEmail();
//					String insuredName = apply.getInsured().getCustName();
//					String policyNo = apply.getPolicyNo();
//			        
//					String emailContent = this.getContent(blueName,realName,apply.getPartnerApplyId(),insuredName);
//					LogTool.debug(this.getClass(), "policyNo: "+ policyNo +"\nemailContent: "+emailContent);
//					
//					//3,构造待发送信息,并保存到数据库
//					mmsg.setToAddress(email);
//			        mmsg.setToName(realName);
//			        mmsg.setContent(emailContent);
//		        
//		            // 发送邮件，添加到数据库
//		            mailService.sendMailCommon(mmsg);
//				}
//			}
			
			// update: add by xiluhua 20190814
			List<ImsAdministratorEmail> list = imsAdministratorEmailDao.getAll();
			for (ImsAdministratorEmail imsAdministratorEmail : list) {
				
	            LogTool.debug(this.getClass(), JSON.toJSONString(imsAdministratorEmail));
	            if (imsAdministratorEmail.getService().equalsIgnoreCase(this.getClass().getSimpleName())) {
	            	LogTool.info(this.getClass(), "imsAdministratorEmail id: "+imsAdministratorEmail.getId());
	            	String realName = apply.getHolder().getCustName();
					String email = imsAdministratorEmail.getEmail();
					String insuredName = apply.getInsured().getCustName();
					String policyNo = apply.getPolicyNo();
			        
					String emailContent = this.getContent(blueName,realName,apply.getPartnerApplyId(),insuredName);
					LogTool.debug(this.getClass(), "policyNo: "+ policyNo +"\nemailContent: "+emailContent);
					
					//3,构造待发送信息,并保存到数据库
					mmsg.setToAddress(email);
			        mmsg.setToName(realName);
			        mmsg.setContent(emailContent);
		        
		            // 发送邮件，添加到数据库
		            mailService.sendMailCommon(mmsg);
				}
			}
			// <== over 20190814 
		} catch (Exception e) {
			LogTool.error(this.getClass(),"邮件发送失败,流水号:"+StringUtils.defaultString(partnerApplyId));
			LogTool.error(this.getClass(),e);
		}
	}

	/**
	 * 得到邮件正文
	 * @param realNameAndSex	姓名与性别
	 * @param policyNo	保单号
	 * @param insuredName	被保人
	 * @return
	 */
	public String getContent(String blueName,String realName,String partnerApplyId,String insuredName)
	{
		String emailContent = "";        	//邮件内容
		// 获取一个新的模板上下文,生成邮件内容
		VelocityContext context = new VelocityContext();
		context.put("holderName", realName);
		context.put("blueName", blueName);
		context.put("partnerApplyId", partnerApplyId);
		context.put("sysdate", DateTool.getFormatDate(DateTool.DATE_TIME_MASK, new Date()));
		emailContent = TemplateToolV1218.fill(context, ConstantTool.EMAIL_TEMPLATE_PATH, ConstantTool.CBSB_WTJ,"UTF-8","GBK"); // 填充模板  得到邮件内容
		return emailContent;
	}
	
	/**
	 * 得到邮件的附件
	 * @param path 附件路径
	 * @param fileName 附件名称
	 * @return
	 */
	public MailAttachment getAttachment(String path,String fileName){
		MailAttachment attachment = new MailAttachment();
		File policyPdf = new File(path);
		attachment.setName(fileName);
		attachment.setSize(String.valueOf(policyPdf.length()));

		String fileType = path.substring(path.lastIndexOf(".") + 1);
        attachment.setType(fileType);

        InputStream in = null;
		try {
			in = new FileInputStream(policyPdf);
			byte[] fileByte = new byte[in.available()];
		    in.read(fileByte);
		    attachment.setAtachment(fileByte);
		} catch (FileNotFoundException e) {
			LogTool.error(this.getClass(), "无法从核心系统下载电子保单,fileName:"+fileName);
			LogTool.error(this.getClass(), e);
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
		}finally{
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					LogTool.error(this.getClass(), e);
				}
			}
		}
        return attachment;
	}

}

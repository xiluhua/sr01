package com.taiping.dianshang.outer.service.impl.autoRegister;

import com.taiping.dianshang.outer.service.OuterService;

public interface AutoRegisterService extends OuterService{


}

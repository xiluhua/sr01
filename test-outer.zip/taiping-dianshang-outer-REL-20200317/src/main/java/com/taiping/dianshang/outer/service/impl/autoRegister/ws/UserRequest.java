package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for userRequest complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="userRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="requestID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userInfo" type="{http://cntp.com/}userInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userRequest", propOrder = { "requestID", "userInfo" })
public class UserRequest {

	protected String requestID;
	protected UserInfo userInfo;

	/**
	 * Gets the value of the requestID property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRequestID() {
		return requestID;
	}

	/**
	 * Sets the value of the requestID property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRequestID(String value) {
		this.requestID = value;
	}

	/**
	 * Gets the value of the userInfo property.
	 * 
	 * @return possible object is {@link UserInfo }
	 * 
	 */
	public UserInfo getUserInfo() {
		return userInfo;
	}

	/**
	 * Sets the value of the userInfo property.
	 * 
	 * @param value
	 *            allowed object is {@link UserInfo }
	 * 
	 */
	public void setUserInfo(UserInfo value) {
		this.userInfo = value;
	}

	@Override
	public String toString() {
		return "UserRequest [requestID=" + requestID + ", userInfo=" + userInfo
				+ "]";
	}

}

package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.entity.IspSendHistory;
import com.taiping.dianshang.entity.IspShortmsgTemplate;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

/**
 * 承保短信发送通用服务
 * @author xilh
 * @since 20170321
 */
@Service
public class ShortMsgImpl_COMMON_1 extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		
		try {
			LogTool.debug(this.getClass(), "shortMsgParamMap: "+shortMsgParamMap.toString());
			
			String wxhome = CacheContainer.getSystemParameterValue(ConstantTool.WXHOME);
			shortMsgParamMap.put("wxhome", wxhome);
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
			// 保单号
	        String partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
	        
	        LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
	        
	        IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply == null) {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			
			if (apply.getHolder() == null || StringUtils.isEmpty(apply.getHolder().getMobile())) {
				LogTool.error(this.getClass(),"短信发送失败,投保人手机号码为空（ShortMsgImpl_COMMON）:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			shortMsgParamMap.put("mobile", apply.getHolder().getMobile());
			
			// 2,构造短信内容
			String shortMsgContent = this.getContent(shortMsgParamMap,apply);
			LogTool.debug(this.getClass(), "shortMsgContent："+shortMsgContent);
			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
			// 3,构造短信对象
			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
			
			// 4,holdername == key时，不发送短信
			String key = CacheContainer.getSystemParameterValueNoThrows(ConstantTool.SYS_KEY_1);
			
			String result= "";
			// 生产测试用
			if (!StringUtils.isEmpty(key) && key.equals(apply.getHolder().getCustName())) {
				//4,启动后台线程，发送短信
				result = super.send(shortMsg, apply);
				// add by liuhe 20200302 更新数据发送记录
				updateIspSendHistory(result,apply);
				return;
			}
			
			// 为空才发送
			if (StringUtils.isEmpty(key)) {
				//4,启动后台线程，发送短信
				result = super.send(shortMsg, apply);
				// add by liuhe 20200302 添加发送短信结果
				updateIspSendHistory(result,apply);
			}
			
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	/**
	 * 更新短信发送记录
	 * @author liuhe
	 * @see 20200302
	 * @param result
	 * @param apply
	 */
	public void updateIspSendHistory(String result,IspApply apply) {
		if (result.equalsIgnoreCase(ConstantTool.SHOR_MSG_SEND_SUCCESS)) {
			IspSendHistory ispSendHistory = ispSendHistoryDao.get("applyId", apply.getApplyId());
			if (ispSendHistory == null) {
				ispSendHistory = new IspSendHistory();
				ispSendHistory.setApplyId(apply.getApplyId());
				ispSendHistory.setIsShortmsgSend(1);
				ispSendHistoryDao.save(ispSendHistory);
			}else {
				ispSendHistory.setIsShortmsgSend(1);
				ispSendHistoryDao.update(ispSendHistory);
			}
			
		}
	}
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply){
		String content = "";			//短信内容
		String holderSex = "";
		String holderName = "";
		String blueName = "";
		
		Object templateId = shortMsgParamMap.get(ConstantTool.TEMPLATE_ID);
		Integer type = MapTool.getIntegerFromMap(shortMsgParamMap, ConstantTool.TYPE);
		String partnerApplyId = apply.getPartnerApplyId();
		IspCustomer holder = apply.getHolder(); 
		holderName = holder.getCustName();
		if (holder.getGender() == 1) {
			holderSex = "先生";
		} else {
			holderSex= "女士";
		}
		
		IspBlueprint blueprint = CacheContainer.getByIdFromCache(apply.getBlueId(), IspBlueprint.class);
		if (blueprint != null) {
			blueName = blueprint.getBlueInnerName();
		}
		
		IspShortmsgTemplate shortmsgTemplate = CacheContainer.getShortmsgTemplateFromCache(templateId, type, IspShortmsgTemplate.class);
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put("holderName", holderName);
		context.put("holderSex", holderSex);
		context.put("blueName", blueName);
		context.put("partnerApplyId", partnerApplyId);
		context.put("apply", apply);
		context.put("polno", apply.getPolicyNo());
		context.put("userName", holder.getCustName());
		context.put("wxhome", shortMsgParamMap.get("wxhome"));
		context.put("validateDate", DateTool.convertDataToString(apply.getValidateDate(), DateTool.DATE_MASK));
		context.put("expirationDate", DateTool.convertDataToString(apply.getExpirationDate(), DateTool.DATE_MASK));
		// add by xiluhua 20180809
		String expireDateZH = DateTool.convertDataToString(apply.getExpirationDate(), DateTool.DATE_MASK2);
		context.put("expireDateZH", expireDateZH);
		// add by xiluhua 20181226 to realize extra extensiveness!
		context.put("params", shortMsgParamMap);
		content = TemplateToolV1218.fill(context, shortmsgTemplate.getRequestXmlTemplate()); // 填充模板  得到短信内容
		
		return content;
	}
}

package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspOrgan entity. 
 */
@Entity
@Table(name = "JC_ISP_ORGAN")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspOrgan implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long organId;
	private String organName;
	private String abbrName;
	private String abbrName2;
	private Integer status;
	private String telephone;
	private String fax;
	private String email;
	private String postCode;
	private String address;
	private Long parentId;
	private Integer leafLevel;
	private Long displaySeq;
	private String displaySeq2;

	// Constructors

	/** default constructor */
	public IspOrgan() {
	}

	/** minimal constructor */
	public IspOrgan(Long organId) {
		this.organId = organId;
	}

	/** full constructor */
	public IspOrgan(Long organId, String organName, String abbrName,
			String abbrName2, Integer status, String telephone, String fax,
			String email, String postCode, String address, Long parentId,
			Integer leafLevel, Long displaySeq, String displaySeq2) {
		this.organId = organId;
		this.organName = organName;
		this.abbrName = abbrName;
		this.abbrName2 = abbrName2;
		this.status = status;
		this.telephone = telephone;
		this.fax = fax;
		this.email = email;
		this.postCode = postCode;
		this.address = address;
		this.parentId = parentId;
		this.leafLevel = leafLevel;
		this.displaySeq = displaySeq;
		this.displaySeq2 = displaySeq2;
	}

	// Property accessors
	@Id
	@Column(name = "ORGAN_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getOrganId() {
		return this.organId;
	}

	public void setOrganId(Long organId) {
		this.organId = organId;
	}

	@Column(name = "ORGAN_NAME", length = 200)
	public String getOrganName() {
		return this.organName;
	}

	public void setOrganName(String organName) {
		this.organName = organName;
	}

	@Column(name = "ABBR_NAME", length = 100)
	public String getAbbrName() {
		return this.abbrName;
	}

	public void setAbbrName(String abbrName) {
		this.abbrName = abbrName;
	}

	@Column(name = "ABBR_NAME2", length = 100)
	public String getAbbrName2() {
		return this.abbrName2;
	}

	public void setAbbrName2(String abbrName2) {
		this.abbrName2 = abbrName2;
	}

	@Column(name = "STATUS", precision = 4, scale = 0)
	public Integer getStatus() {
		return this.status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "TELEPHONE", length = 50)
	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	@Column(name = "FAX", length = 50)
	public String getFax() {
		return this.fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	@Column(name = "EMAIL", length = 50)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "POST_CODE", length = 50)
	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	@Column(name = "ADDRESS", length = 500)
	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "PARENT_ID", precision = 10, scale = 0)
	public Long getParentId() {
		return this.parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	@Column(name = "LEAF_LEVEL", precision = 3, scale = 0)
	public Integer getLeafLevel() {
		return this.leafLevel;
	}

	public void setLeafLevel(Integer leafLevel) {
		this.leafLevel = leafLevel;
	}

	@Column(name = "DISPLAY_SEQ", precision = 10, scale = 0)
	public Long getDisplaySeq() {
		return this.displaySeq;
	}

	public void setDisplaySeq(Long displaySeq) {
		this.displaySeq = displaySeq;
	}

	@Column(name = "DISPLAY_SEQ2", length = 200)
	public String getDisplaySeq2() {
		return this.displaySeq2;
	}

	public void setDisplaySeq2(String displaySeq2) {
		this.displaySeq2 = displaySeq2;
	}

}
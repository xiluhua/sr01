package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspCore   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_RMI")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspRmi implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3788522661633768891L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="BLUE_ID")
	private String blueId;
	@Column(name="INTERFACE_ID")
	private String interfaceId;
	@Column(name="SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name="URL")
	private String url;
//	@Column(name="URL_DIAN_SHANG_CORE")
//	private String urlDianShangCore;
	@Column(name="REQUEST_XML_TEMPLATE_FILE")
	private String requestXmlTemplateFile;
//	@Column(name="CHECKBILL_REQUEST_SERVICE")
//	private String checkBillRequestService;
	@Column(name="HTTPCLIENT_SERVICE")
	private String httpclientService;
	@Column(name="STATUS")
	private Integer status;		// 1有效|其他失效
//	@Column(name="SEQ_PRE")
//	private String seqPre;
	@Column(name="HTTP_CLIENT_PARAMS_ID")
	private Long httpclientParamsId;

	@Column(name="REQUEST_XML_TEMPLATE")
	private String requestXmlTemplate; // add by liwei  2019/5/8 3:34 PM  description:模板
	
	public IspRmi() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public String getBlueId() {
		return blueId;
	}
	public void setBlueId(String blueId) {
		this.blueId = blueId;
	}

	public String getInterfaceId() {
		return interfaceId;
	}
	public void setInterfaceId(String interfaceId) {
		this.interfaceId = interfaceId;
	}
	public Integer getSellChannel() {
		return sellChannel;
	}
	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}

	public String getRequestXmlTemplateFile() {
		return requestXmlTemplateFile;
	}
	public void setRequestXmlTemplateFile(String requestXmlTemplateFile) {
		this.requestXmlTemplateFile = requestXmlTemplateFile;
	}
	
//	public String getCheckBillRequestService() {
//		return checkBillRequestService;
//	}
//	public void setCheckBillRequestService(String checkBillRequestService) {
//		this.checkBillRequestService = checkBillRequestService;
//	}
	public String getHttpclientService() {
		return httpclientService;
	}
	public void setHttpclientService(String httpclientService) {
		this.httpclientService = httpclientService;
	}
//	public String getSeqPre() {
//		return seqPre;
//	}
//	public void setSeqPre(String seqPre) {
//		this.seqPre = seqPre;
//	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getHttpclientParamsId() {
		return httpclientParamsId;
	}
	public void setHttpclientParamsId(Long httpclientParamsId) {
		this.httpclientParamsId = httpclientParamsId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
//	public String getUrlDianShangCore() {
//		return urlDianShangCore;
//	}
//	public void setUrlDianShangCore(String urlDianShangCore) {
//		this.urlDianShangCore = urlDianShangCore;
//	}
	@Override
	public String toString() {
		return "IspRmi [Id=" + Id + ", blueId=" + blueId + ", interfaceId="
				+ interfaceId + ", sellChannel=" + sellChannel + ", url=" + url
				+ ", requestXmlTemplateFile=" + requestXmlTemplateFile
				+ ", httpclientService=" + httpclientService + ", status="
				+ status + ", httpclientParamsId=" + httpclientParamsId + "]";
	}

	public String getRequestXmlTemplate() {
		return requestXmlTemplate;
	}

	public void setRequestXmlTemplate(String requestXmlTemplate) {
		this.requestXmlTemplate = requestXmlTemplate;
	}
}





package com.taiping.dianshang.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantSql;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBale;
import com.taiping.dianshang.entity.IspBlueAnnounce;
import com.taiping.facility.tool.MapTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBlueAnnounceDao extends BaseWriteDao<IspBlueAnnounce, Long>{

//	@Resource
//	private SynBlueprintCoreDao synBlueprintCoreDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	
//	public List<IspBlueAnnounce> synBlueAnnounce(List<IspBale> coreBaleList)throws Exception{
//		
//		//1、获得最新保障利益信息 保存至本地数据库
//		List<IspBlueAnnounce> blueAnnounceList = this.getCoreBaleAnnounce(coreBaleList); //获得计划的健康告知列表
//
//		if (blueAnnounceList.size() > 0 ) {
//			for (int i = 0; i < blueAnnounceList.size(); i++) {
//				IspBlueAnnounce blueAnnounce = blueAnnounceList.get(i);
//				blueAnnounce.setId(this.getUniqueSequence());
//				this.save(blueAnnounce); //插入计划的健康告知列表
//			}
//		}
//		//3、返回同步的健康告知列表
//		return blueAnnounceList;
//	}
//	
//	public List<IspBlueAnnounce> getCoreBaleAnnounce(List<IspBale> coreBaleList){
//		List<IspBlueAnnounce> blueAnnounceList = new ArrayList<IspBlueAnnounce>();
//		
//		for (int i = 0; i < coreBaleList.size(); i++) {
//			IspBale bale = coreBaleList.get(i);
//			Integer coreAnnounceId = bale.getCoreAnnounceId();
//			Object[] args = new Object[]{coreAnnounceId};
//			
//			List<Map<String, Object>> listMap = synBlueprintCoreDao.queryForListMap(ConstantSql.SQL_SYN_BLUE_ANNOUNCE, args);
//			if (listMap != null && listMap.size() > 0 ) {
//				
//				for (int j = 0; j < listMap.size(); j++) {
//					Map<String, Object> map = listMap.get(j);
//					IspBlueAnnounce blueAnnounce = new IspBlueAnnounce();
//					blueAnnounce.setAnnounceInf(MapTool.getStringFromMap(map, "DEPICT"));
//					blueAnnounce.setDisplaySeq(MapTool.getIntegerFromMap(map, "SHOW_ORDER"));
//					blueAnnounce.setBlueId(bale.getBlueId());
//					blueAnnounce.setBaleId(bale.getBaleId());	
//					blueAnnounce.setCreateTime(new Date());
//					blueAnnounceList.add(blueAnnounce);
//				}
//			}
//		}
//		
//		return blueAnnounceList;
//	}
	
	private Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_BLUE_ANNOUNCE);
			IspBlueAnnounce blueAnnounce = super.get("id", seq);
			
			if (blueAnnounce == null) {
				return seq;
			}
		}
	}
}

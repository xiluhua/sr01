package com.taiping.dianshang.service.log;

import com.taiping.facility.model.ScIlogMsg;

/**
 * 保存日志文件
 * @author @author xiluhua by 20160119
 *
 */
public interface SaveLogFileService {
	/**
	 * 保存日志文件
	 * @param interfaceId		接口ID
	 * @param operateType		操作类型 1,请求  2,返回
	 * @param logIndex			日志标识
	 */
	public void saveLogFile(ScIlogMsg msg);
	
}

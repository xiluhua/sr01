/**
 * @(#)LogToFileMangage.java
 *       
 * project：taiping-sol-insu-vehicle
 * 
 * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.dianshang.service.log.impl;

import java.io.Serializable;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.opensymphony.xwork2.ActionSupport;
import com.taiping.common.Base64Tool;
import com.taiping.dianshang.service.httpclient.HttpclientService;
import com.taiping.dianshang.service.log.LogPool;
import com.taiping.dianshang.service.log.LogPoolService;
import com.taiping.facility.model.ScIlogBusinessOperateLog;
import com.taiping.facility.model.ScIlogErrorLog;
import com.taiping.facility.model.ScIlogMsg;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;

/**
 * 
 * @author xiluhua by 20160119
 *
 */
@Component 
public class LogPoolImpl implements LogPoolService{
	
	@Resource(name="httpclientImpl")
	private HttpclientService httpclientService;
	/**
	 * json
	 */
	public static final String APPLICATION_JSON = "application/json";
	public static String MESSAGE_LOG_URL = "";
	public static String BUSSINESS_LOG_URL = "";
	public static String MESSAGE_DOC_PATH = "";
	
	public void put(ScIlogBusinessOperateLog businessOperateLog){
		LogPool.busiOpeLogQ.add(businessOperateLog);
	}
	
	public void put(ScIlogMsg msg){
		LogPool.msgLogQ.add(msg);
	}
	
	public void put(ScIlogErrorLog errorLog){
		LogPool.errorLogQ.add(errorLog);
	}
	
	public void clearMsgToLogSystem(){
		LogTool.info(LogPoolImpl.class, "=============================================================");
		LogTool.info(LogPoolImpl.class, "clearMsgToLogSystem:begin!!");
		while(true){
			try {
				if(LogPool.msgLogQ.size() == 0){
					Thread.sleep(1000);
				}else{
					
					ScIlogMsg msg = LogPool.msgLogQ.poll();
					if (msg == null) {
						Thread.sleep(1000);
					}else {
						if (StringUtils.isEmpty(MESSAGE_LOG_URL)) {
							MESSAGE_LOG_URL = PropertyFileTool.get("log.url.dianshang.core")+"/messageLog";
							LogTool.info(LogPoolImpl.class, "=============================================================");
							LogTool.info(LogPoolImpl.class, "MESSAGE_LOG_URL  :"+MESSAGE_LOG_URL);
							MESSAGE_DOC_PATH = PropertyFileTool.get("log.msg.path");
						}
						
						msg.setMsgDocPath(MESSAGE_DOC_PATH);
						String response = this.postLogRest(MESSAGE_LOG_URL,msg);
						if (!response.equalsIgnoreCase(ActionSupport.SUCCESS)) {
							new SaveLogFileImpl().saveLogFile(msg);
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void clearBusinessOpelogToLogSystem(){
		LogTool.info(LogPoolImpl.class, "=============================================================");
		LogTool.info(LogPoolImpl.class, "clearBusinessOpelogToLogSystem:begin!!");
		while(true){
			try {
				ScIlogBusinessOperateLog businessOperateLog = LogPool.busiOpeLogQ.poll();
				if (businessOperateLog == null) {
					Thread.sleep(1000);
				}else {
					if (StringUtils.isEmpty(BUSSINESS_LOG_URL)) {
						BUSSINESS_LOG_URL = PropertyFileTool.get("log.url.dianshang.core")+"/businessLog";
						LogTool.info(LogPoolImpl.class, "=============================================================");
						LogTool.info(LogPoolImpl.class, "BUSSINESS_LOG_URL:"+BUSSINESS_LOG_URL);
					}
					this.postLogRest(BUSSINESS_LOG_URL,businessOperateLog);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
	}
	
	/**
	 * 向日志服务器发送请求，日志服务器写入业务操作日志信息
	 * 写入失败的话，将数据保存到本地日志文件
	 */
	public <T extends Serializable> String postLogRest(String url, T logObj) {
		String response = "";
		String json = JsonTool.toJson(logObj, "yyyy-MM-dd HH:mm:ss SSS");
		try {
			json = Base64Tool.encode(json, "gbk");
			response = httpclientService.post(url, json,"plain/text", "gbk", 6000, 6000, 0);
		} catch (Exception e) {
			LogTool.info(LogPoolImpl.class, "=============================================================");
			LogTool.info(LogPoolImpl.class, "==== Please check whether the log system is in operation ====");
			LogTool.info(LogPoolImpl.class, "==== log system url:"+url+" ====");
			LogTool.info(LogPoolImpl.class, "=============================================================");
			e.printStackTrace();
		}
		return response;
	}
	
	public void clearLogToLogSystem(){
		new Thread() {
			public void run() {
				clearMsgToLogSystem();
			}
		}.start();
		
		new Thread() {
			public void run() {
				clearBusinessOpelogToLogSystem();
			}
		}.start();
	}
	
	public static void main(String[] args) {
		System.out.println(LogPoolImpl.class);
	}
	
}
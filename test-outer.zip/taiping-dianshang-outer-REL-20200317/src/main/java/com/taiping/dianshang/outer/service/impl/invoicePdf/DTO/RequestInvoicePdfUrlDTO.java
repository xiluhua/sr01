package com.taiping.dianshang.outer.service.impl.invoicePdf.DTO;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.taiping.dianshang.outer.DTO.request.RequestDTO;
import com.taiping.dianshang.outer.DTO.request.element.BusinessDTO;

/**
 * @author: xiluhua 
 * @since 20200212
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"business"
})
@XmlRootElement(name = "REQUEST")
public class RequestInvoicePdfUrlDTO implements RequestDTO {
	@XmlElement(name = "BUSINESS")
	protected BusinessDTO business = new BusinessDTO();
	
	public BusinessDTO getBusiness() {
		return business;
	}
	public void setBusiness(BusinessDTO business) {
		this.business = business;
	}

}

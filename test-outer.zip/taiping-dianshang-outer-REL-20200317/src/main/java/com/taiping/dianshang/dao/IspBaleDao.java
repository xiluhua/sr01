package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBale;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBaleDao extends BaseWriteDao<IspBale, Long> implements CacheDaoService{
	
//	@Resource
//	private SynBlueprintCoreDao synBlueprintCoreDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	
	public Map<Object,String> getAllInMap(){
		List<IspBale> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspBale bale = list.get(i);
				String key = KeyTool.get(IspBale.class, bale.getBaleId());
				map.put(key,JsonTool.toJson(bale));
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspBale> getAll(){
		String hql = "from IspBale t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
	
	@SuppressWarnings("unchecked")
	public List<IspBale> getBaleListByBlueId(Long blueId){
		String hql = "from IspBale t where t.blueId = ?";
		return super.getSession().createQuery(hql).setLong(0, blueId).list();
	}
//	public List<IspBale> synBale(IspBlueprint blueprint)throws Exception{
//		//1、定义局部变量
//		List<IspBale> coreBaleList = null;  //定义核心计划列表变量
//		List<IspBale> baleList = new ArrayList<IspBale>(); //需要插入的本地计划列表
//		   
//		//2、查询核心最新计划列表数据	   
//		Long coreBlueId = blueprint.getCoreBlueId();
//		Long blueId = blueprint.getBlueId();
//		String blueCode = blueprint.getBlueCode();
//		coreBaleList = this.getCoreBaleListByCoreBlueId(coreBlueId);  //根据方案ID 获得需要同步的核心计划列表信息		   
//		if(coreBaleList.size() != 0){  //有同步的计划信息 保存到本地数据库
//			for(IspBale coreBale:coreBaleList){
//				IspBale bale = new IspBale();
//				bale.setCoreBaleId(coreBale.getCoreBaleId());
//				bale.setChargeTypeList(coreBale.getChargeTypeList());
//				bale.setCoreBlueId(coreBale.getCoreBlueId());
//				bale.setBaleName(coreBale.getBaleName());
//				bale.setBaleNo(coreBale.getBaleNo());
//				bale.setCoreAnnounceId(coreBale.getCoreAnnounceId());
//				
//				bale.setStatus(1);
//				Long baleId = this.getUniqueSequence();
//				bale.setBaleId(baleId);
//				bale.setBlueId(blueId);
//				bale.setBlueCode(blueCode);
//				bale.setCreateTime(new Date());
//				this.save(bale);
//				baleList.add(bale);
//			}
//		}
//		
//		//3、返回同步的计划信息
//		return baleList;
//	}
//	/**
//	* 根据方案ID 获得核心计划列表信息
//	* @param blueId
//	* @return
//    */
//	public List<IspBale> getCoreBaleListByCoreBlueId(Long coreBlueId) {
//		List<IspBale> baleList = new ArrayList<IspBale>();
//		// 1、定义局部变量
//		Object[] args = new Object[]{coreBlueId};
//		List<Map<String, Object>> list = synBlueprintCoreDao.queryForListMap(ConstantSql.SQL_SYN_BALE, args);
//
//		// 3、根据查询结果重组数据集
//		if (list != null && list.size() != 0) {
//			IspBale bale = null;
//			for (Map<String, Object> map : list) {
//				bale = new IspBale();
//				bale.setCoreBaleId(MapTool.getLongFromMap(map, "BALE_ID"));
//				bale.setChargeTypeList(MapTool.getStringFromMap(map,"CHARGE_LIST"));
//				bale.setCoreBlueId(coreBlueId);
//				bale.setBaleName(MapTool.getStringFromMap(map, "BALE_NAME"));
//				bale.setBaleNo(MapTool.getIntegerFromMap(map, "BALE_NO"));
//				bale.setCoreAnnounceId(MapTool.getIntegerFromMap(map, "ANNC_ID"));
//				baleList.add(bale);
//			}
//		}
//
//		// 4、返回结果集
//		return baleList;
//	}
	
	private Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_BALE);
			IspBale bale = super.get("baleId", seq);
			
			if (bale == null) {
				return seq;
			}
		}
	}
}
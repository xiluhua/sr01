package com.taiping.dianshang.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantSql;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBale;
import com.taiping.dianshang.entity.IspBaleCover;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.facility.tool.MapTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBaleCoverDao extends BaseWriteDao<IspBaleCover, Long> {
//	@Resource
//	private SynBlueprintCoreDao synBlueprintCoreDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	
//	public List<IspBaleCover> synBaleCover(IspBlueprint blue,List<IspBale> baleList){
//		
//		List<IspBaleCover> baleCoverList = this.getCoreIspBaleCover(baleList);
//		
//	    for (int i = 0; i < baleCoverList.size(); i++) {
//	    	IspBaleCover baleCover = baleCoverList.get(i);
//	    	baleCover.setId(this.getUniqueSequence());
//	    	this.save(baleCover);
//		}
//		
//		return baleCoverList;
//	}
	
	public Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_BALE_COVER);
			IspBaleCover baleCover = super.get("id", seq);
			
			if (baleCover == null) {
				return seq;
			}
		}
	}
	
//	public List<IspBaleCover> getCoreIspBaleCover(List<IspBale> baleList){
//		
//		List<Map<String, Object>> listMap = null;
//		List<IspBaleCover> baleCoverList = new ArrayList<IspBaleCover>();
//		
//	    //2、拼接sql 设置查询对象的查询语句 开始查询
//	    for(IspBale bale:baleList){
//		    Long baleId = bale.getCoreBaleId();
//		    Object[] args = new Object[]{baleId};
//	    	listMap = synBlueprintCoreDao.queryForListMap(ConstantSql.SQL_SYN_BALE_COVER, args);
//	    	if(listMap.size() > 0){
//			    for(Map<String,Object> map:listMap){
//			    	IspBaleCover baleCover = new IspBaleCover();
//					baleCover.setBaleId(bale.getBaleId());
//					baleCover.setBlueId(bale.getBlueId());
//					
//					String coverAmount = MapTool.getStringFromMap(map, "CAMOUNT");
//					coverAmount = coverAmount.replaceAll("元", "");
//					baleCover.setCoverBenefit(MapTool.getStringFromMap(map, "COVER_DESC"));
//					baleCover.setCoverAmount(coverAmount);
//					baleCover.setDisplaySequence(MapTool.getIntegerFromMap(map, "SHOW_ORDER"));
//					baleCover.setCreateTime(new Date());
//					baleCoverList.add(baleCover);
//			    }
//	    	}
//		}
//	    
//		return baleCoverList;
//	}
	
	public static void main(String[] args) {
		String sss = "1111,";
		
		System.out.println(sss.toString().substring(0,sss.length()-1));
	}
}

package com.taiping.dianshang.service.httpclient;

import java.util.Map;

public interface JiLiMallHttpclientService {
	
	public String post(String url,Map<String, String> params);
	
	public String postByProxy(String url, Map<String, String> params);
}

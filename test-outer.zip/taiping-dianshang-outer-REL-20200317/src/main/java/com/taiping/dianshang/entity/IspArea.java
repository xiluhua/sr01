package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspArea entity. 
 */
@Entity
@Table(name = "JC_ISP_AREA")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspArea implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long areaId;
	private String areaCode;
	private String areaName;
	private Long parentId;
	private Integer leafLevel;
	private Long displaySeq;
	private String displaySeq2;
	private Long organId;
	private String gbCode;
	private String retrievalDes;

	// Constructors

	/** default constructor */
	public IspArea() {
	}

	/** minimal constructor */
	public IspArea(Long areaId) {
		this.areaId = areaId;
	}

	/** full constructor */
	public IspArea(Long areaId, String areaCode, String areaName,
			Long parentId, Integer leafLevel, Long displaySeq,
			String displaySeq2, Long organId, String gbCode, String retrievalDes) {
		this.areaId = areaId;
		this.areaCode = areaCode;
		this.areaName = areaName;
		this.parentId = parentId;
		this.leafLevel = leafLevel;
		this.displaySeq = displaySeq;
		this.displaySeq2 = displaySeq2;
		this.organId = organId;
		this.gbCode = gbCode;
		this.retrievalDes = retrievalDes;
	}

	// Property accessors
	@Id
	@Column(name = "AREA_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getAreaId() {
		return this.areaId;
	}

	public void setAreaId(Long areaId) {
		this.areaId = areaId;
	}

	@Column(name = "AREA_CODE", length = 10)
	public String getAreaCode() {
		return this.areaCode;
	}

	public void setAreaCode(String areaCode) {
		this.areaCode = areaCode;
	}

	@Column(name = "AREA_NAME", length = 100)
	public String getAreaName() {
		return this.areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	@Column(name = "PARENT_ID", precision = 10, scale = 0)
	public Long getParentId() {
		return this.parentId;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	@Column(name = "LEAF_LEVEL", precision = 3, scale = 0)
	public Integer getLeafLevel() {
		return this.leafLevel;
	}

	public void setLeafLevel(Integer leafLevel) {
		this.leafLevel = leafLevel;
	}

	@Column(name = "DISPLAY_SEQ", precision = 10, scale = 0)
	public Long getDisplaySeq() {
		return this.displaySeq;
	}

	public void setDisplaySeq(Long displaySeq) {
		this.displaySeq = displaySeq;
	}

	@Column(name = "DISPLAY_SEQ2", length = 200)
	public String getDisplaySeq2() {
		return this.displaySeq2;
	}

	public void setDisplaySeq2(String displaySeq2) {
		this.displaySeq2 = displaySeq2;
	}

	@Column(name = "ORGAN_ID", precision = 10, scale = 0)
	public Long getOrganId() {
		return this.organId;
	}

	public void setOrganId(Long organId) {
		this.organId = organId;
	}

	@Column(name = "GB_CODE", length = 10)
	public String getGbCode() {
		return this.gbCode;
	}

	public void setGbCode(String gbCode) {
		this.gbCode = gbCode;
	}

	@Column(name = "RETRIEVAL_DES", length = 200)
	public String getRetrievalDes() {
		return this.retrievalDes;
	}

	public void setRetrievalDes(String retrievalDes) {
		this.retrievalDes = retrievalDes;
	}

}
package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;



/**   
 * @ClassName IspApplyVehicle   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_APPLY_VEHICLE")
public class IspApplyVehicle {

	@Id
	@Column(name="APPLY_ID")
	private Long applyId;
	@Column(name="LICENCE_NO")
	private String licenceNo;
	
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	public String getLicenceNo() {
		return licenceNo;
	}
	public void setLicenceNo(String licenceNo) {
		this.licenceNo = licenceNo;
	}
	
}





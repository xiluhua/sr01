package com.taiping.dianshang.outer.service.impl.autoRegister.sso.entity;

/**
 * Created by GuoShun on 2017-09-11.
 */
public class AccountRequest {
    //请求唯一标识
    private String requestID;

    private AccountInfo accountInfo;

    public String getRequestID() {
        return requestID;
    }

    public void setRequestID(String requestID) {
        this.requestID = requestID;
    }

    public AccountInfo getAccountInfo() {
        return accountInfo;
    }

    public void setAccountInfo(AccountInfo accountInfo) {
        this.accountInfo = accountInfo;
    }

	@Override
	public String toString() {
		return "AccountRequest [requestID=" + requestID + ", accountInfo="
				+ accountInfo + "]";
	}
    
    
   
}

package com.taiping.dianshang.outer.DTO.callback.baidu.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author xiluhua 
 * @since 2017-12-18
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"spNo",
	    "channelId",
	    "responseTime",
	    "responseCode",
	    "responseMessage",
	    "bizType"
})
public class ResponseHeadDTO {
	@XmlElement(name = "SpNo")
	private String spNo;			//商户号：本平台作为服务方时使用，由百度分配给各个保险公司
	@XmlElement(name = "ChannelId")
	private String channelId;		//渠道号：本平台作为请求放时使用，由保险公司分配给百度
	@XmlElement(name = "ResponseTime")
	private String responseTime;		//报文发送时间 格式：yyyyMMddHHmmss
	@XmlElement(name = "ResponseCode")
	private String responseCode;			
	@XmlElement(name = "ResponseMessage")
	private String responseMessage;			
	@XmlElement(name = "BizType")
	private String bizType;			//业务类型 
	
	public String getSpNo() {
		return spNo;
	}
	public void setSpNo(String spNo) {
		this.spNo = spNo;
	}
	public String getChannelId() {
		return channelId;
	}
	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}
	public String getBizType() {
		return bizType;
	}
	public void setBizType(String bizType) {
		this.bizType = bizType;
	}
	public String getResponseTime() {
		return responseTime;
	}
	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}
	public String getResponseCode() {
		return responseCode;
	}
	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}
	public String getResponseMessage() {
		return responseMessage;
	}
	public void setResponseMessage(String responseMessage) {
		this.responseMessage = responseMessage;
	}
	@Override
	public String toString() {
		return "ResponseHeadDTO [spNo=" + spNo + ", channelId=" + channelId
				+ ", responseTime=" + responseTime + ", responseCode="
				+ responseCode + ", responseMessage=" + responseMessage
				+ ", bizType=" + bizType + "]";
	}
	
	
}

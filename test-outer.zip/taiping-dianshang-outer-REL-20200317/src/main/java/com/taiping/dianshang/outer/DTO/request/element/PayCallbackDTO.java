package com.taiping.dianshang.outer.DTO.request.element;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"billId",
		"payAmount",
		"payerTradeNo",
		"merchantNo",
		"payBank",
		"bankCard",
		"businessType",
		"premId",
		"bankCode",
		"payType",
		"payerCodeLv2"
})
public class PayCallbackDTO{
	// billId,payAmount，payerTradeNo，partner，payBank，bankCard
    @XmlElement(name = "BILL_ID")
	private String billId;
    @XmlElement(name = "PAY_AMOUNT")
    private Double payAmount; 	
    @XmlElement(name = "PAYER_TRADE_NO")
	private String payerTradeNo;
    @XmlElement(name = "MERCHANT_NO")
    private String merchantNo; 
    @XmlElement(name = "PAY_BANK")
    private String payBank;
    @XmlElement(name = "BANK_CARD")
    private String bankCard;
    @XmlElement(name = "BUSINESS_TYPE")
    private Integer businessType;			// 业务类型 1.新契约 2.保全 3.理赔 4.续期
    // add by xiluhua 20171124
    @XmlElement(name = "PREM_ID")
	protected String premId;
    @XmlElement(name = "BANK_CODE")
    private String bankCode;
    @XmlElement(name = "PAY_TYPE")
    private Integer payType = 1;//<!-- 1 客户支付, 2公司垫付 -->
 // add by liuhe 20190523 复星支付 添加支付方式
    @XmlElement(name = "PAYER_CODE_LV2")
    private String payerCodeLv2;
    
	public Integer getBusinessType() {
		return businessType;
	}
	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public Double getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(Double payAmount) {
		this.payAmount = payAmount;
	}
	public String getPayerTradeNo() {
		return payerTradeNo;
	}
	public void setPayerTradeNo(String payerTradeNo) {
		this.payerTradeNo = payerTradeNo;
	}
	public String getMerchantNo() {
		return merchantNo;
	}
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	public String getPayBank() {
		return payBank;
	}
	public void setPayBank(String payBank) {
		this.payBank = payBank;
	}
	public String getBankCard() {
		return bankCard;
	}
	public void setBankCard(String bankCard) {
		this.bankCard = bankCard;
	}
	public String getPremId() {
		return premId;
	}
	public void setPremId(String premId) {
		this.premId = premId;
	}
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public Integer getPayType() {
		return payType;
	}
	public void setPayType(Integer payType) {
		this.payType = payType;
	}
	public String getPayerCodeLv2() {
		return payerCodeLv2;
	}
	public void setPayerCodeLv2(String payerCodeLv2) {
		this.payerCodeLv2 = payerCodeLv2;
	} 
}

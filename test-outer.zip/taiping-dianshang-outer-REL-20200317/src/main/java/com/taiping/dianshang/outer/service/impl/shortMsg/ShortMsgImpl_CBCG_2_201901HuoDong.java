package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;

/**
 * @category 201901活动，短信内容：
 * 尊敬的客户，感谢参与活动，请根据提示领取体检套餐，回TD退，链接：http://itp.ink/n/001jXR
 * @author xilh
 * @since 20181122
 * from 徐燕
 */
@Service
public class ShortMsgImpl_CBCG_2_201901HuoDong extends ShortMsgImpl_COMMON_1 {

	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		shortMsgParamMap.put(ConstantTool.TEMPLATE_ID, "201901.huodong");
		shortMsgParamMap.put(ConstantTool.TYPE, ConstantTool.STR_2);
		super.handle(shortMsgParamMap);
	}
}

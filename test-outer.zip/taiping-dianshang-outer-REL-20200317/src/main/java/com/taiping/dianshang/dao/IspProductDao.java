package com.taiping.dianshang.dao;

import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantSql;
import com.taiping.dianshang.entity.IspProduct;
import com.taiping.facility.tool.MapTool;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspProductDao extends BaseWriteDao<IspProduct, Long> {

	@Resource
	private CommonDao commonDao;
//	@Resource
//	private SynBlueprintCoreDao synBlueprintCoreDao;
	
	public IspProduct getIspProductById(Long productId){
		return commonDao.get(IspProduct.class, productId);
	}
	
//	public IspProduct getProductLife(Long productId){
//		IspProduct product = null;
//		Map<String, Object> map = synBlueprintCoreDao.queryForMap(ConstantSql.SQL_SYN_PRODUCT, String.valueOf(productId));
//		if (map.size() > 0) {
//			product = new IspProduct();
//
//			product.setProductId(MapTool.getLongFromMap(map, "PRODUCT_ID"));
//			product.setProductName(MapTool.getStringFromMap(map, "PRODUCT_NAME"));
//			String ma = MapTool.getStringFromMap(map, "INS_TYPE");
//			if (ma.equalsIgnoreCase("1")) {
//				ma= "M";
//			}else {
//				ma= "A";
//			}
//			product.setCreateTime(new Date());
//			product.setMa(ma);
//		}
//		return product;
//	}
}

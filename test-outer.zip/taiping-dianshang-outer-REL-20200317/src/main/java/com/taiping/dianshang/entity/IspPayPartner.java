package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**   
 * @ClassName IspPayPartner   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "DS_ISP_PAY_PARTNER")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspPayPartner implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -7133502128679408348L;
	@Id
	@Column(name="ID")
	private Long id;
	@Column(name="PARTNER_ID")
	private Long partnerId;
	@Column(name="PAY_PARTNER")
	private String payPartner;
	@Column(name="SELL_PLATFORM")
	private String sellPlatForm;
	@Column(name="ISSUE_WAY")
	private String issueWay;
	@Column(name="SELL_WAY")
	private String sellWay;
	@Column(name="STATUS")
	private Integer status;
	
	
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public String getPayPartner() {
		return payPartner;
	}
	public void setPayPartner(String payPartner) {
		this.payPartner = payPartner;
	}
	public String getSellWay() {
		return sellWay;
	}
	public void setSellWay(String sellWay) {
		this.sellWay = sellWay;
	}
	public String getSellPlatForm() {
		return sellPlatForm;
	}
	public void setSellPlatForm(String sellPlatForm) {
		this.sellPlatForm = sellPlatForm;
	}
	public String getIssueWay() {
		return issueWay;
	}
	public void setIssueWay(String issueWay) {
		this.issueWay = issueWay;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}

}

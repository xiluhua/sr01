package com.taiping.dianshang.outer.service.impl.checkBillCallback.sub.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspYqfadDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspYqfad;
import com.taiping.dianshang.outer.DTO.request.RequestCheckBillCallbackDTO356;
import com.taiping.dianshang.outer.DTO.request.element.CheckBillCallbackDTO356;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.dianshang.outer.service.impl.checkBillCallback.sub.CheckBillObjectToXmlService;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.LogTool;

@Component
public class CheckBillObjectToXmlImpl_356 implements CheckBillObjectToXmlService{

	@Resource
	IspYqfadDao ispYqfadDao;
	
	@Resource
	SignService signService;
	
	public String objectToXml(IspApply apply){
		String requestXml = null;
		RequestCheckBillCallbackDTO356 callbackDTO     = new RequestCheckBillCallbackDTO356();
		callbackDTO.getBusiness().setBusiId(apply.getPartnerApplyId());
		Long partnerId = apply.getPartnerId();
		callbackDTO.getBusiness().setPartnerId(partnerId+"");
		callbackDTO.getBusiness().setServiceCode(ConstantTool.CHECKBILL_CALLBACK);
		Date date = new Date();
		callbackDTO.getBusiness().setTransTime(date);
		CheckBillCallbackDTO356 callbackDTO356 = new CheckBillCallbackDTO356(apply);
		callbackDTO.setCallback(callbackDTO356);
		
		// set ad
		IspYqfad ad = ispYqfadDao.getById(apply.getApplyId());
		if (ad != null) {
			callbackDTO.getCallback().getMedium().setWi(ad.getWi());
		}
		
		try {
			String now = DateTool.convertDataToString(date, DateTool.DATE_TIME_MASK2);
			String sig = partnerId+""+callbackDTO.getBusiness().getBusiId()+now;
			LogTool.info(this.getClass(), "sign string: "+sig);
			
			// 签名
			String sign = signService.sign(sig, partnerId);
			// setSign
			callbackDTO.getBusiness().setSign(sign);
			
			requestXml = JAXBTool.marshal(callbackDTO, ConstantTool.UTF8);
			
			LogTool.info(this.getClass(), "requestXml signed: "+requestXml);
			requestXml = JAXBTool.marshal(callbackDTO, ConstantTool.UTF8);
		} catch (Exception e) {
            LogTool.error(this.getClass(), e);
		}
		
		return requestXml;
	}
}

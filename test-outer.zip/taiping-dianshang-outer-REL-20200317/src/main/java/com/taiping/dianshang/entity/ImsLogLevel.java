package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;


/**
 * ImsLogLevel entity. 
 */
@Entity
@Table(name = "IMS_LOG_LEVEL")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsLogLevel implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	
	private Long id;
	private String className;
	private Integer logLevel;
	private Integer status;
	// Constructors

	/** default constructor */
	public ImsLogLevel() {
	}
	
	@Id
	@Column(name = "ID", length = 10)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "CLASS_NAME")
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	
	@Column(name = "LOG_LEVEL")
	public Integer getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(Integer logLevel) {
		this.logLevel = logLevel;
	}

	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}
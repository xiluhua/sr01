package com.taiping.dianshang.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IpayBill;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IpayBillDao extends BaseWriteDao<IpayBill, Long>{
	
	@Resource
	private CommonDao commonDao;
	
	public Long save(IpayBill bill){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_IPAY_BILL);
		bill.setBillId(seq);
		
		return super.save(bill);
	}
	
	public IpayBill getBillByApplyId(Long applyId){
		String hql = "from IpayBill t where t.status = 1 and t.applyId = ?";
		Object[] param = new Object[]{applyId};
		return commonDao.singleResult(hql, param);
	}
}

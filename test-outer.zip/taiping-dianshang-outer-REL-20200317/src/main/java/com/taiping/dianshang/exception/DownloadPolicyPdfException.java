package com.taiping.dianshang.exception;


public class DownloadPolicyPdfException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public DownloadPolicyPdfException(String msg){
		super(msg);
	}
	
	public DownloadPolicyPdfException(){
		super();
	}
}


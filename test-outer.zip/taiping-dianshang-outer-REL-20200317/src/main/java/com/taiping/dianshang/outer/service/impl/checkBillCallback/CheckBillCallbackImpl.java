package com.taiping.dianshang.outer.service.impl.checkBillCallback;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspApplySpecialDao;
import com.taiping.dianshang.dao.IspKeyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspCheckBillCallback;
import com.taiping.dianshang.outer.DTO.request.RequestCheckBillCallbackDTO;
import com.taiping.dianshang.outer.DTO.request.element.CheckBillCallbackDTO;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.service.CheckBillCallbackService;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.dianshang.outer.service.impl.checkBillCallback.sub.CheckBillObjectToXmlService;
import com.taiping.dianshang.outer.service.impl.checkBillCallback.sub.impl.CheckBillObjectToXmlImpl;
import com.taiping.dianshang.outer.service.impl.shortMsg.ShortMsgImpl_ERR_COMMON;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.SpringTool;

/**
 * 出单回调
 * @author xilh
 * @since 20181102
 */
@Service
@Transactional
public class CheckBillCallbackImpl implements CheckBillCallbackService{

	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	BusinesslogService businesslogService;
	@Resource
	SignService signService;
	@Resource
	IspKeyDao ispKeyDao;
	@Resource
	IspApplySpecialDao ispApplySpecialDao;
	
	@Override
	public void handle(Map<String, Object> paramsMap) {
		String partnerBillId = MapTool.getStringFromMap(paramsMap, ConstantTool.OPERATE_NO);
		String errorMsg = "";
		Integer operateStatus = 1;
		
		// 首期
		IspApply apply = ispApplyDao.loadApply(partnerBillId, null, null, null);
		
		if (apply == null) {
			errorMsg = "无对应投保信息，流水号："+partnerBillId;
			LogTool.error(this.getClass(), errorMsg);
			operateStatus = 3;
			// 失败日志，便于排查
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.CHECKBILL_CALLBACK, operateStatus, 1);
			return;
		}
		
		// add by xiluhua 20171201 for partners
		IspCheckBillCallback checkBillCallback = CacheContainer.getByIdFromCache(apply.getPartnerId(), IspCheckBillCallback.class);
		
		if (checkBillCallback == null) {
			errorMsg = "checkBillCallback is null: "+apply.getPartnerId();
			LogTool.error(this.getClass(), errorMsg);
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.CHECKBILL_CALLBACK, operateStatus, 1);
			return;
		}
		
		// 生成回调报文
		CheckBillObjectToXmlService objectToXmlService = this.getCheckBillObjectToXmlService(apply);
		String requestXml = objectToXmlService.objectToXml(apply);
		System.out.println("CheckBillCallbackImpl requestXml: "+requestXml);
		
		String url 		  = this.getUrlByEnv(checkBillCallback,apply);
		
		LogTool.debug(this.getClass(), "CheckBillCallbackImpl url: "+url);
		// 日志（请求）
		businesslogService.postBusinessOpelog_1(apply,url + System.getProperty("line.separator")+requestXml, ConstantTool.CHECKBILL_CALLBACK, 1, 1);
		
		// add by xiluhua 20171201 mock only
		if (LogTool.isFormal && apply.getPartnerApplyId().indexOf("TEST") > -1) {
			LogTool.debug(this.getClass(), "attention!!! mock only: "+apply.getPartnerApplyId());
			// 日志（返回）
			businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ "mock only: "+apply.getPartnerApplyId(), ConstantTool.CHECKBILL_CALLBACK, 2, 1);
			return;
		}
		
		// 回调
		String responseXml = this.callback(url,requestXml,partnerBillId);
		// 报文转对象
		ResponseDTO responseDTO = this.xmlToObject(responseXml, partnerBillId);
		
		boolean isSuccess = (responseDTO != null && responseDTO.getBusiness().isSuccess());
		if (!isSuccess) {
			LogTool.info(this.getClass(), paramsMap.toString());
			operateStatus = 0;
			Integer count = MapTool.getIntegerFromMap(paramsMap, ConstantTool.COUNT);
			if (count != null) {
				count++;
			}else {
				count = 1;
			}
			paramsMap.put(ConstantTool.COUNT, count);
			
			// 回调失败短信通知,模板id:2
			if (count > 30) {
				paramsMap.put(ConstantTool.SHORTMSG_TEMP_ID, 2);
				paramsMap.put(ConstantTool.SERVICE_ID, ShortMsgImpl_ERR_COMMON.class.getSimpleName());
				JedisClient_outer2.rpush(ConstantTool.QUEUE_SHORTMSG, JsonTool.toJson(paramsMap));
			}else {
				// 15分钟后再次执行
				paramsMap.put(ConstantTool.NEXT_CALLBACK_TIME, DateTool.add(new Date(), Calendar.MINUTE, 15));
				this.rpush(paramsMap);
			}
		}
		
		// 日志（返回）
		businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ responseXml, ConstantTool.CHECKBILL_CALLBACK, operateStatus, 1);
	}

	private CheckBillObjectToXmlService getCheckBillObjectToXmlService(IspApply apply) {
		String beanName = "CheckBillObjectToXmlImpl_"+apply.getPartnerId();
		CheckBillObjectToXmlService objectToXmlService = SpringTool.getSpringBean(beanName);
		if (objectToXmlService == null) {
			objectToXmlService = SpringTool.getSpringBean(CheckBillObjectToXmlImpl.class);
		}
		return objectToXmlService;
	}

	private String getUrlByEnv(IspCheckBillCallback checkBillCallback, IspApply apply) {
		String url = checkBillCallback.getProxyUrl();
		// 是测试单的话，调用测试地址
		if (LogTool.isLocal) {
			url = PropertyFileTool.get("checkBill.callback.local");
			LogTool.info(this.getClass(), "LOCAL: "+apply.getPartnerApplyId()+",checkBill.callback.local url: "+url);
		}
		if (LogTool.isUat) {
			if (ispKeyDao.getIspKey(36l) == null) {
				LogTool.debug(this.getClass(), "inner test!!!");
				// 内部测试
				url = PropertyFileTool.get("checkBill.callback.uat");
			}
			LogTool.info(this.getClass(), "UAT: "+apply.getPartnerApplyId()+",checkBill.callback.uat url: "+url);
		}
		if (LogTool.isFormal) {
			LogTool.info(this.getClass(), "FORMAL: "+apply.getPartnerApplyId());
		}

		return url;
	}
	
	@Deprecated
	public String objectToXml(IspApply apply){
		String requestXml = null;
		RequestCheckBillCallbackDTO callbackDTO     = new RequestCheckBillCallbackDTO();
		callbackDTO.getBusiness().setBusiId(apply.getPartnerApplyId());
		Long partnerId = apply.getPartnerId();
		callbackDTO.getBusiness().setPartnerId(partnerId+"");
		callbackDTO.getBusiness().setServiceCode(ConstantTool.CHECKBILL_CALLBACK);
		callbackDTO.getBusiness().setTransTime(new Date());
		CheckBillCallbackDTO orderQueryResponseDTO = new CheckBillCallbackDTO(apply);
		callbackDTO.setCallback(orderQueryResponseDTO);
		
		try {
			requestXml = JAXBTool.marshal(callbackDTO);
			LogTool.info(this.getClass(), "requestXml: "+requestXml);
			
			// 签名
			String sign = signService.sign(requestXml, partnerId);
			// setSign
			callbackDTO.getBusiness().setSign(sign);
			
			requestXml = JAXBTool.marshal(callbackDTO, ConstantTool.UTF8);
			
			LogTool.info(this.getClass(), "requestXml signed: "+requestXml);
			requestXml = JAXBTool.marshal(callbackDTO, ConstantTool.UTF8);
		} catch (Exception e) {
            LogTool.error(this.getClass(), e);
		}
		
		return requestXml;
	}
	
	public String callback(String url,String requestXml,String partnerBillId){
		String responseXml = "";
		try {
			LogTool.debug(this.getClass(), "pay callback url: "+url);
			LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
			responseXml = this.post(url, requestXml, ConstantTool.UTF8,ConstantTool.TEXT_XML);
			
			LogTool.debug(this.getClass(), responseXml);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
		
		return responseXml;
	}
	
	public ResponseDTO xmlToObject(String responseXml,String partnerBillId){
		ResponseDTO responseDTO = null;
		if (responseXml != null) {
			try {
				responseXml = URLDecoder.decode(responseXml, ConstantTool.UTF8);
				LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
				LogTool.debug(this.getClass(), responseXml);
				responseDTO = (ResponseDTO)JAXBTool.unmarshal(responseXml, ResponseDTO.class);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
		return responseDTO;
	}
	
	public void rpush(Map<String, Object> paramsMap){
		if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
			// 本地 localhost
			JedisClient_outer2.rpush(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY_LOCAL, JsonTool.toJson(paramsMap));
		}else {
			JedisClient_outer2.rpush(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY, JsonTool.toJson(paramsMap));
		}
	}
	
	/**
     * 订单状态: 1待支付(核保成功)|6支付成功、承保成功返回支付成功|4承保失败
     * @param checkStatus
     * @param payStatus
     * @param checkBillStatus
     * @return
     * 代码	代码名称
		0	无记录
		1	核保通过（待支付）
		2	核保失败
		3	支付处理中
		4	承保成功
		5	承保失败
		6	退保成功
     */
    public int getStatus(Integer checkStatus,Integer payStatus,Integer checkBillStatus){
    	if (checkStatus == null) {
			checkStatus = 0;
		}
		if (checkBillStatus == null) {
			checkBillStatus = 0;
		}
		if (payStatus == null) {
			payStatus = 0;
		}
		
    	if (checkStatus != 1 && payStatus != 1 && checkBillStatus != 1) {
    		return 2;
    	}
    	if (checkStatus == 1 && (payStatus != 1 && checkBillStatus != 1)) {
    		return 1;
		}
    	
    	if (payStatus == 1 && checkBillStatus != 1) {
    		return 3;
    	}
    	
    	if (checkBillStatus == 1) {
    		return 4;
		}
    	if (checkBillStatus == 2) {
    		return 5;
		}
    	return 0;
    }
    
    
    
    /**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content, String encode,String contentType) throws Exception {
		String trans = "";
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, ConstantTool.UTF8);
		httpPost.setRequestHeader("Content-Type", contentType);  
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(60000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				trans = map.get("trans");
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), ConstantTool.UTF8));
					index++;
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				if (content != null) {
//					int length = content.toString().length();
//					System.out.println(length);
//					httpPost.setRequestHeader("Content-Length", String.valueOf(length+12));  
				}
				httpPost.setRequestEntity(new StringRequestEntity((String)content,contentType, encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			String[] arr = {trans,String.valueOf(statusCode)};
			LogTool.info(this.getClass(),"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:{},statusCode:{}",arr);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}
}

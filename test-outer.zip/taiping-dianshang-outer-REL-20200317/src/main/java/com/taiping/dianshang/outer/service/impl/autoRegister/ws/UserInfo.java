package com.taiping.dianshang.outer.service.impl.autoRegister.ws;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;

/**
 * <p>
 * Java class for userInfo complex type.
 * 
 * <p>
 * The following schema fragment specifies the expected content contained within
 * this class.
 * 
 * <pre>
 * &lt;complexType name="userInfo">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="accessToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="accountId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="address" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="birthday" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="centerId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="centerMId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="certificationNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="certificationTime" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cifNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="city" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cntpFax" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="cntpUserType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="createDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="deliveryAddress" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="deliveryCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="email" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailActivateDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailActivateSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailActived" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="gender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasChild" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="hasHousing" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="idType" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="incomeLevels" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="isAuthenticated" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lv1Area" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="lv2Area" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="marriageStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mobile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mobileActivateDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mobileActivateSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mobileActived" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="nickName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oldEmail" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="oldMobile" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="ownerSystem" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="policyNumber" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="postCode" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="pwdChangeDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="qqId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="realName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="registerFromUrl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="registerSource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="riskLevel" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="serviceId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sinaId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="telephone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tencentAccessToken" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="tencentId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="uid" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="updateDate" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userPassword" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="userStatus" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="writeBack" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "userInfo", propOrder = { "accessToken", "accountId",
		"address", "birthday", "centerId", "centerMId", "certificationNumber",
		"certificationTime", "cifNumber", "city", "cntpFax", "cntpUserType",
		"createDate", "deliveryAddress", "deliveryCode", "email",
		"emailActivateDate", "emailActivateSource", "emailActived", "gender",
		"hasChild", "hasHousing", "idNumber", "idType", "incomeLevels",
		"isAuthenticated", "lv1Area", "lv2Area", "marriageStatus", "mobile",
		"mobileActivateDate", "mobileActivateSource", "mobileActived",
		"nickName", "oldEmail", "oldMobile", "ownerSystem", "policyNumber",
		"postCode", "pwdChangeDate", "qqId", "realName", "registerFromUrl",
		"registerSource", "riskLevel", "serviceId", "sinaId", "telephone",
		"tencentAccessToken", "tencentId", "uid", "updateDate", "userPassword",
		"userStatus", "writeBack" })
public class UserInfo {

	protected String accessToken;
	protected String accountId;
	protected String address;
	protected String birthday;
	protected String centerId;
	protected String centerMId;
	protected String certificationNumber;
	protected String certificationTime;
	protected String cifNumber;
	protected String city;
	protected String cntpFax;
	protected String cntpUserType;
	protected String createDate;
	protected String deliveryAddress;
	protected String deliveryCode;
	protected String email;
	protected String emailActivateDate;
	protected String emailActivateSource;
	protected String emailActived;
	protected String gender;
	protected String hasChild;
	protected String hasHousing;
	protected String idNumber;
	protected String idType;
	protected String incomeLevels;
	protected String isAuthenticated;
	protected String lv1Area;
	protected String lv2Area;
	protected String marriageStatus;
	protected String mobile;
	protected String mobileActivateDate;
	protected String mobileActivateSource;
	protected String mobileActived;
	protected String nickName;
	protected String oldEmail;
	protected String oldMobile;
	protected String ownerSystem;
	protected String policyNumber;
	protected String postCode;
	protected String pwdChangeDate;
	protected String qqId;
	protected String realName;
	protected String registerFromUrl;
	protected String registerSource;
	protected String riskLevel;
	protected String serviceId;
	protected String sinaId;
	protected String telephone;
	protected String tencentAccessToken;
	protected String tencentId;
	protected String uid;
	protected String updateDate;
	protected String userPassword;
	protected String userStatus;
	protected String writeBack;

	/**
	 * Gets the value of the accessToken property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAccessToken() {
		return accessToken;
	}

	/**
	 * Sets the value of the accessToken property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAccessToken(String value) {
		this.accessToken = value;
	}

	/**
	 * Gets the value of the accountId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAccountId() {
		return accountId;
	}

	/**
	 * Sets the value of the accountId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAccountId(String value) {
		this.accountId = value;
	}

	/**
	 * Gets the value of the address property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * Sets the value of the address property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setAddress(String value) {
		this.address = value;
	}

	/**
	 * Gets the value of the birthday property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getBirthday() {
		return birthday;
	}

	/**
	 * Sets the value of the birthday property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setBirthday(String value) {
		this.birthday = value;
	}

	/**
	 * Gets the value of the centerId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCenterId() {
		return centerId;
	}

	/**
	 * Sets the value of the centerId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCenterId(String value) {
		this.centerId = value;
	}

	/**
	 * Gets the value of the centerMId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCenterMId() {
		return centerMId;
	}

	/**
	 * Sets the value of the centerMId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCenterMId(String value) {
		this.centerMId = value;
	}

	/**
	 * Gets the value of the certificationNumber property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCertificationNumber() {
		return certificationNumber;
	}

	/**
	 * Sets the value of the certificationNumber property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCertificationNumber(String value) {
		this.certificationNumber = value;
	}

	/**
	 * Gets the value of the certificationTime property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCertificationTime() {
		return certificationTime;
	}

	/**
	 * Sets the value of the certificationTime property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCertificationTime(String value) {
		this.certificationTime = value;
	}

	/**
	 * Gets the value of the cifNumber property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCifNumber() {
		return cifNumber;
	}

	/**
	 * Sets the value of the cifNumber property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCifNumber(String value) {
		this.cifNumber = value;
	}

	/**
	 * Gets the value of the city property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCity() {
		return city;
	}

	/**
	 * Sets the value of the city property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCity(String value) {
		this.city = value;
	}

	/**
	 * Gets the value of the cntpFax property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCntpFax() {
		return cntpFax;
	}

	/**
	 * Sets the value of the cntpFax property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCntpFax(String value) {
		this.cntpFax = value;
	}

	/**
	 * Gets the value of the cntpUserType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCntpUserType() {
		return cntpUserType;
	}

	/**
	 * Sets the value of the cntpUserType property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCntpUserType(String value) {
		this.cntpUserType = value;
	}

	/**
	 * Gets the value of the createDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getCreateDate() {
		return createDate;
	}

	/**
	 * Sets the value of the createDate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setCreateDate(String value) {
		this.createDate = value;
	}

	/**
	 * Gets the value of the deliveryAddress property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDeliveryAddress() {
		return deliveryAddress;
	}

	/**
	 * Sets the value of the deliveryAddress property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDeliveryAddress(String value) {
		this.deliveryAddress = value;
	}

	/**
	 * Gets the value of the deliveryCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getDeliveryCode() {
		return deliveryCode;
	}

	/**
	 * Sets the value of the deliveryCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setDeliveryCode(String value) {
		this.deliveryCode = value;
	}

	/**
	 * Gets the value of the email property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Sets the value of the email property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEmail(String value) {
		this.email = value;
	}

	/**
	 * Gets the value of the emailActivateDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmailActivateDate() {
		return emailActivateDate;
	}

	/**
	 * Sets the value of the emailActivateDate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEmailActivateDate(String value) {
		this.emailActivateDate = value;
	}

	/**
	 * Gets the value of the emailActivateSource property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmailActivateSource() {
		return emailActivateSource;
	}

	/**
	 * Sets the value of the emailActivateSource property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEmailActivateSource(String value) {
		this.emailActivateSource = value;
	}

	/**
	 * Gets the value of the emailActived property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getEmailActived() {
		return emailActived;
	}

	/**
	 * Sets the value of the emailActived property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setEmailActived(String value) {
		this.emailActived = value;
	}

	/**
	 * Gets the value of the gender property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * Sets the value of the gender property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setGender(String value) {
		this.gender = value;
	}

	/**
	 * Gets the value of the hasChild property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getHasChild() {
		return hasChild;
	}

	/**
	 * Sets the value of the hasChild property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setHasChild(String value) {
		this.hasChild = value;
	}

	/**
	 * Gets the value of the hasHousing property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getHasHousing() {
		return hasHousing;
	}

	/**
	 * Sets the value of the hasHousing property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setHasHousing(String value) {
		this.hasHousing = value;
	}

	/**
	 * Gets the value of the idNumber property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIdNumber() {
		return idNumber;
	}

	/**
	 * Sets the value of the idNumber property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setIdNumber(String value) {
		this.idNumber = value;
	}

	/**
	 * Gets the value of the idType property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIdType() {
		return idType;
	}

	/**
	 * Sets the value of the idType property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setIdType(String value) {
		this.idType = value;
	}

	/**
	 * Gets the value of the incomeLevels property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIncomeLevels() {
		return incomeLevels;
	}

	/**
	 * Sets the value of the incomeLevels property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setIncomeLevels(String value) {
		this.incomeLevels = value;
	}

	/**
	 * Gets the value of the isAuthenticated property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getIsAuthenticated() {
		return isAuthenticated;
	}

	/**
	 * Sets the value of the isAuthenticated property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setIsAuthenticated(String value) {
		this.isAuthenticated = value;
	}

	/**
	 * Gets the value of the lv1Area property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getLv1Area() {
		return lv1Area;
	}

	/**
	 * Sets the value of the lv1Area property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setLv1Area(String value) {
		this.lv1Area = value;
	}

	/**
	 * Gets the value of the lv2Area property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getLv2Area() {
		return lv2Area;
	}

	/**
	 * Sets the value of the lv2Area property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setLv2Area(String value) {
		this.lv2Area = value;
	}

	/**
	 * Gets the value of the marriageStatus property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMarriageStatus() {
		return marriageStatus;
	}

	/**
	 * Sets the value of the marriageStatus property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMarriageStatus(String value) {
		this.marriageStatus = value;
	}

	/**
	 * Gets the value of the mobile property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMobile() {
		return mobile;
	}

	/**
	 * Sets the value of the mobile property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMobile(String value) {
		this.mobile = value;
	}

	/**
	 * Gets the value of the mobileActivateDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMobileActivateDate() {
		return mobileActivateDate;
	}

	/**
	 * Sets the value of the mobileActivateDate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMobileActivateDate(String value) {
		this.mobileActivateDate = value;
	}

	/**
	 * Gets the value of the mobileActivateSource property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMobileActivateSource() {
		return mobileActivateSource;
	}

	/**
	 * Sets the value of the mobileActivateSource property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMobileActivateSource(String value) {
		this.mobileActivateSource = value;
	}

	/**
	 * Gets the value of the mobileActived property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getMobileActived() {
		return mobileActived;
	}

	/**
	 * Sets the value of the mobileActived property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setMobileActived(String value) {
		this.mobileActived = value;
	}

	/**
	 * Gets the value of the nickName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getNickName() {
		return nickName;
	}

	/**
	 * Sets the value of the nickName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setNickName(String value) {
		this.nickName = value;
	}

	/**
	 * Gets the value of the oldEmail property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOldEmail() {
		return oldEmail;
	}

	/**
	 * Sets the value of the oldEmail property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOldEmail(String value) {
		this.oldEmail = value;
	}

	/**
	 * Gets the value of the oldMobile property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOldMobile() {
		return oldMobile;
	}

	/**
	 * Sets the value of the oldMobile property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOldMobile(String value) {
		this.oldMobile = value;
	}

	/**
	 * Gets the value of the ownerSystem property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getOwnerSystem() {
		return ownerSystem;
	}

	/**
	 * Sets the value of the ownerSystem property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setOwnerSystem(String value) {
		this.ownerSystem = value;
	}

	/**
	 * Gets the value of the policyNumber property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPolicyNumber() {
		return policyNumber;
	}

	/**
	 * Sets the value of the policyNumber property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPolicyNumber(String value) {
		this.policyNumber = value;
	}

	/**
	 * Gets the value of the postCode property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPostCode() {
		return postCode;
	}

	/**
	 * Sets the value of the postCode property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPostCode(String value) {
		this.postCode = value;
	}

	/**
	 * Gets the value of the pwdChangeDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getPwdChangeDate() {
		return pwdChangeDate;
	}

	/**
	 * Sets the value of the pwdChangeDate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setPwdChangeDate(String value) {
		this.pwdChangeDate = value;
	}

	/**
	 * Gets the value of the qqId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getQqId() {
		return qqId;
	}

	/**
	 * Sets the value of the qqId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setQqId(String value) {
		this.qqId = value;
	}

	/**
	 * Gets the value of the realName property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRealName() {
		return realName;
	}

	/**
	 * Sets the value of the realName property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRealName(String value) {
		this.realName = value;
	}

	/**
	 * Gets the value of the registerFromUrl property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRegisterFromUrl() {
		return registerFromUrl;
	}

	/**
	 * Sets the value of the registerFromUrl property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRegisterFromUrl(String value) {
		this.registerFromUrl = value;
	}

	/**
	 * Gets the value of the registerSource property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRegisterSource() {
		return registerSource;
	}

	/**
	 * Sets the value of the registerSource property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRegisterSource(String value) {
		this.registerSource = value;
	}

	/**
	 * Gets the value of the riskLevel property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getRiskLevel() {
		return riskLevel;
	}

	/**
	 * Sets the value of the riskLevel property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setRiskLevel(String value) {
		this.riskLevel = value;
	}

	/**
	 * Gets the value of the serviceId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getServiceId() {
		return serviceId;
	}

	/**
	 * Sets the value of the serviceId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setServiceId(String value) {
		this.serviceId = value;
	}

	/**
	 * Gets the value of the sinaId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getSinaId() {
		return sinaId;
	}

	/**
	 * Sets the value of the sinaId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setSinaId(String value) {
		this.sinaId = value;
	}

	/**
	 * Gets the value of the telephone property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTelephone() {
		return telephone;
	}

	/**
	 * Sets the value of the telephone property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setTelephone(String value) {
		this.telephone = value;
	}

	/**
	 * Gets the value of the tencentAccessToken property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTencentAccessToken() {
		return tencentAccessToken;
	}

	/**
	 * Sets the value of the tencentAccessToken property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setTencentAccessToken(String value) {
		this.tencentAccessToken = value;
	}

	/**
	 * Gets the value of the tencentId property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getTencentId() {
		return tencentId;
	}

	/**
	 * Sets the value of the tencentId property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setTencentId(String value) {
		this.tencentId = value;
	}

	/**
	 * Gets the value of the uid property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUid() {
		return uid;
	}

	/**
	 * Sets the value of the uid property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUid(String value) {
		this.uid = value;
	}

	/**
	 * Gets the value of the updateDate property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUpdateDate() {
		return updateDate;
	}

	/**
	 * Sets the value of the updateDate property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUpdateDate(String value) {
		this.updateDate = value;
	}

	/**
	 * Gets the value of the userPassword property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserPassword() {
		return userPassword;
	}

	/**
	 * Sets the value of the userPassword property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUserPassword(String value) {
		this.userPassword = value;
	}

	/**
	 * Gets the value of the userStatus property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getUserStatus() {
		return userStatus;
	}

	/**
	 * Sets the value of the userStatus property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setUserStatus(String value) {
		this.userStatus = value;
	}

	/**
	 * Gets the value of the writeBack property.
	 * 
	 * @return possible object is {@link String }
	 * 
	 */
	public String getWriteBack() {
		return writeBack;
	}

	/**
	 * Sets the value of the writeBack property.
	 * 
	 * @param value
	 *            allowed object is {@link String }
	 * 
	 */
	public void setWriteBack(String value) {
		this.writeBack = value;
	}

	@Override
	public String toString() {
		return "UserInfo [accessToken=" + accessToken + ", accountId="
				+ accountId + ", address=" + address + ", birthday=" + birthday
				+ ", centerId=" + centerId + ", centerMId=" + centerMId
				+ ", certificationNumber=" + certificationNumber
				+ ", certificationTime=" + certificationTime + ", cifNumber="
				+ cifNumber + ", city=" + city + ", cntpFax=" + cntpFax
				+ ", cntpUserType=" + cntpUserType + ", createDate="
				+ createDate + ", deliveryAddress=" + deliveryAddress
				+ ", deliveryCode=" + deliveryCode + ", email=" + email
				+ ", emailActivateDate=" + emailActivateDate
				+ ", emailActivateSource=" + emailActivateSource
				+ ", emailActived=" + emailActived + ", gender=" + gender
				+ ", hasChild=" + hasChild + ", hasHousing=" + hasHousing
				+ ", idNumber=" + idNumber + ", idType=" + idType
				+ ", incomeLevels=" + incomeLevels + ", isAuthenticated="
				+ isAuthenticated + ", lv1Area=" + lv1Area + ", lv2Area="
				+ lv2Area + ", marriageStatus=" + marriageStatus + ", mobile="
				+ mobile + ", mobileActivateDate=" + mobileActivateDate
				+ ", mobileActivateSource=" + mobileActivateSource
				+ ", mobileActived=" + mobileActived + ", nickName=" + nickName
				+ ", oldEmail=" + oldEmail + ", oldMobile=" + oldMobile
				+ ", ownerSystem=" + ownerSystem + ", policyNumber="
				+ policyNumber + ", postCode=" + postCode + ", pwdChangeDate="
				+ pwdChangeDate + ", qqId=" + qqId + ", realName=" + realName
				+ ", registerFromUrl=" + registerFromUrl + ", registerSource="
				+ registerSource + ", riskLevel=" + riskLevel + ", serviceId="
				+ serviceId + ", sinaId=" + sinaId + ", telephone=" + telephone
				+ ", tencentAccessToken=" + tencentAccessToken + ", tencentId="
				+ tencentId + ", uid=" + uid + ", updateDate=" + updateDate
				+ ", userPassword=" + userPassword + ", userStatus="
				+ userStatus + ", writeBack=" + writeBack + "]";
	}

}

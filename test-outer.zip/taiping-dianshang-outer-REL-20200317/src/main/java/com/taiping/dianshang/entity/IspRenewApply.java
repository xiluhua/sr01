package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ScIspRenewApply entity. 
 */
@Entity
@Table(name = "SC_ISP_RENEW_APPLY")
public class IspRenewApply implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long applyId;
	private String policyNo;
	private String appNo;
	private Long blueId;
	private String blueCode;
	private Integer baleNo;
	private Double premium;
	private Integer payStatus;
	private Integer checkBillStatus;
	private Long premiumId;
	private String userAccountId;
	private Date createTime;
	private Date acceptTime;
	private String bankCode;
	private Long payId;
	private Date updateTime;
	private String createAid;
	private String updateAid;

	// Constructors

	/** default constructor */
	public IspRenewApply() {
	}

	/** minimal constructor */
	public IspRenewApply(Long applyId) {
		this.applyId = applyId;
	}

	/** full constructor */
	public IspRenewApply(Long applyId, String policyNo, String appNo,
			Long blueId, String blueCode, Integer baleNo, Double premium,
			Integer payStatus, Integer checkBillStatus, Long premiumId,
			String userAccountId, Date createTime, Date acceptTime,
			String bankCode, Long payId, Date updateTime, String createAid,
			String updateAid) {
		this.applyId = applyId;
		this.policyNo = policyNo;
		this.appNo = appNo;
		this.blueId = blueId;
		this.blueCode = blueCode;
		this.baleNo = baleNo;
		this.premium = premium;
		this.payStatus = payStatus;
		this.checkBillStatus = checkBillStatus;
		this.premiumId = premiumId;
		this.userAccountId = userAccountId;
		this.createTime = createTime;
		this.acceptTime = acceptTime;
		this.bankCode = bankCode;
		this.payId = payId;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
	}

	// Property accessors
	@Id
	@Column(name = "APPLY_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Column(name = "POLICY_NO", length = 20)
	public String getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Column(name = "APP_NO", length = 20)
	public String getAppNo() {
		return this.appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Column(name = "BLUE_CODE", length = 20)
	public String getBlueCode() {
		return this.blueCode;
	}

	public void setBlueCode(String blueCode) {
		this.blueCode = blueCode;
	}

	@Column(name = "BALE_NO", precision = 3, scale = 0)
	public Integer getBaleNo() {
		return this.baleNo;
	}

	public void setBaleNo(Integer baleNo) {
		this.baleNo = baleNo;
	}

	@Column(name = "PREMIUM", precision = 12)
	public Double getPremium() {
		return this.premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	@Column(name = "PAY_STATUS", precision = 3, scale = 0)
	public Integer getPayStatus() {
		return this.payStatus;
	}

	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	@Column(name = "CHECK_BILL_STATUS", precision = 3, scale = 0)
	public Integer getCheckBillStatus() {
		return this.checkBillStatus;
	}

	public void setCheckBillStatus(Integer checkBillStatus) {
		this.checkBillStatus = checkBillStatus;
	}

	@Column(name = "PREMIUM_ID", precision = 10, scale = 0)
	public Long getPremiumId() {
		return this.premiumId;
	}

	public void setPremiumId(Long premiumId) {
		this.premiumId = premiumId;
	}

	@Column(name = "USER_ACCOUNT_ID", length = 32)
	public String getUserAccountId() {
		return this.userAccountId;
	}

	public void setUserAccountId(String userAccountId) {
		this.userAccountId = userAccountId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ACCEPT_TIME")
	public Date getAcceptTime() {
		return this.acceptTime;
	}

	public void setAcceptTime(Date acceptTime) {
		this.acceptTime = acceptTime;
	}

	@Column(name = "BANK_CODE", length = 20)
	public String getBankCode() {
		return this.bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	@Column(name = "PAY_ID", precision = 10, scale = 0)
	public Long getPayId() {
		return this.payId;
	}

	public void setPayId(Long payId) {
		this.payId = payId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

}
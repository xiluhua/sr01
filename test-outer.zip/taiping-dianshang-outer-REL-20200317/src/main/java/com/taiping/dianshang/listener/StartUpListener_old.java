//package com.taiping.dianshang.listener;
//
//import java.text.ParseException;
//import java.util.Date;
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Set;
//import org.apache.commons.lang3.StringUtils;
//import com.taiping.dianshang.constant.ConstantTool;
//import com.taiping.dianshang.outer.service.CancelService;
//import com.taiping.dianshang.outer.service.OuterService;
//import com.taiping.dianshang.outer.service.impl.CancelImpl;
//import com.taiping.facility.cache.container.CacheContainer;
//import com.taiping.facility.redis.JedisClient_outer;
//import com.taiping.facility.tool.DateTool;
//import com.taiping.facility.tool.JsonTool;
//import com.taiping.facility.tool.LogTool;
//import com.taiping.facility.tool.MapTool;
//import com.taiping.facility.tool.SpringTool;
//
///**
// * 系统启动监听器
// * @author xiluhua
// * CreateDate:20160120
// */
//public class StartUpListener_old {
//	
//	public void redisMigrate() {
//		try {
//			// 启动异步服务
//			this.startUp_services_email(ConstantTool.QUEUE_EMAIL);
//			
//			this.startUp_services_giftScore(ConstantTool.QUEUE_GIFTSCORE);
//			this.startUp_services_giftScore(ConstantTool.QUEUE_GIFTSCORE);
//			this.startUp_services_giftScore(ConstantTool.QUEUE_GIFTSCORE);
//			this.startUp_services_giftScore(ConstantTool.QUEUE_GIFTSCORE);
//			this.startUp_services_giftScore(ConstantTool.QUEUE_GIFTSCORE);
//			
//			this.startUp_services(ConstantTool.QUEUE_SHORTMSG);
//			this.startUp_services(ConstantTool.QUEUE_SHORTMSG);
//			this.startUp_services(ConstantTool.QUEUE_SHORTMSG);
//			this.startUp_services(ConstantTool.QUEUE_SHORTMSG);
//			this.startUp_services(ConstantTool.QUEUE_SHORTMSG);
//			
//			this.startUp_services(ConstantTool.QUEUE_AUTO_REGI);
//			this.startUp_services(ConstantTool.QUEUE_AUTO_REGI);
//			// 支付回调
//			this.startUp_services_payCallback(ConstantTool.QUEUE_PAY_CALLBACK);
//			this.startUp_services_payCallback_retry(ConstantTool.QUEUE_PAY_CALLBACK_RETRY);
//			
//			// 支付回调 LOCALHOST
//			this.startUp_services_payCallback_local(ConstantTool.QUEUE_PAY_CALLBACK_LOCAL);
//			this.startUp_services_payCallback_retry_local(ConstantTool.QUEUE_PAY_CALLBACK_RETRY_LOCAL);
//			
//			// add buy xiluhua
//			// 承保回调
//			this.startUp_services_checkBillCallback(ConstantTool.QUEUE_CHECKBILL_CALLBACK);
//			this.startUp_services_checkBillCallback_retry(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY);
//			
//			// 承保回调 LOCALHOST
//			this.startUp_services_checkBillCallback_local(ConstantTool.QUEUE_CHECKBILL_CALLBACK_LOCAL);
//			this.startUp_services_checkBillCallback_retry_local(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY_LOCAL);
//			
//			// 强撤接口
//			// added by xiluhua 20171027
//			this.startUp_services_cancel();
//			
//			LogTool.info(StartUpListener_old.class,"===========================================================================");
//		} catch (Exception e) {
//			LogTool.error(this.getClass(), e);
//		}
//	}
//
//	/**
//	 * 
//	 * 异步服务
//	 */
//	private void startUp_services_email(final String queueName){
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				while(true){
//					String serviceDebug = "";
//					try {
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_EMAIL_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ...");
//	//							Thread.sleep(5*60*1000);
//								Thread.sleep(5*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(30*1000);
//							continue;
//						}
//						
//						// 对队列长度不为零的，进行处理
//						String json = JedisClient_outer.lpop(queueName);
//						if (StringUtils.isEmpty(json)) {
//							continue;
//						}
//						LogTool.info(this.getClass(), "startUp_services_email: "+String.valueOf(json));
//						Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//						String sendTime = MapTool.getStringFromMap(map, "sendTime");
//						if (StringUtils.isEmpty(sendTime)) {
//							String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//							OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//							if (sendService != null) {
//								sendService.handle(map);
//							}
//							continue;
//						}
//						
//						// check the sendTime
//						Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, sendTime);
//						
//						// if now is after the send time,do send email,else push it back to the redis queue
//						if (DateTool.isDate1LateThanDate2(new Date(), date2)) {
//							String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//							serviceDebug = service;
//							OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//							if (sendService != null) {
//								sendService.handle(map);
//							}
//						}else {
//							JedisClient_outer.rpush(queueName, json);
//							String seconds = CacheContainer.getSystemParameterValue(ConstantTool.SYS_CBCG_SEND_EMAIL_SLEEP_SECONDS);
//							Thread.sleep(Long.valueOf(seconds));
//						}
//					} catch (Exception e) {
//						LogTool.error(this.getClass(), e);
//						LogTool.error(this.getClass(), serviceDebug);
//					}
//					// try over
//				}
//				// while over
//			}
//		}.start();
//	}
//
//	/**
//	 * 
//	 * 异步服务
//	 */
//	private void startUp_services(final String queueName){
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				while(true){
//					try {
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_SHORTMSG_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ...");
//	//							Thread.sleep(5*60*1000);
//								Thread.sleep(5*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(30*1000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), "services: "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//								OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//								if (sendService != null) {
//									sendService.handle(map);
//								}
//							}
//						}
//					} catch (Exception e) {
//						LogTool.error(this.getClass(), e);
//					}
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	/**
//	 * 
//	 * 异步服务：送积分
//	 */
//	private void startUp_services_giftScore(final String queueName){
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				while(true){
//					try {
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_GIFTSCORE_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ...");
//								Thread.sleep(5*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(10*6*1000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), "giftScore: "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//								OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//								if (sendService != null) {
//									sendService.handle(map);
//								}
//							}
//						}
//					} catch (Exception e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(5*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					}
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	/**
//	 * 异步服务：出单回调
//	 * @param queueName
//	 */
//	private void startUp_services_payCallback(final String queueName) {
//		for (int i = 0; i < 10; i++) {
//			final int index = i;
//			new Thread() {
//				@SuppressWarnings("unchecked")
//				public void run() {
//					// LOCAL 不跑
//					if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
//						return;
//					}
//					
//					while(true){
//						try {
//							// 0. 作业总开关
//							while(true){
//								String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_PAYNOTIFY_START_END_TIMEOLD);
//								// 在任务暂停时间内，sleep 5 minute a time
//								if (isInTime(startEnd)) {
//									LogTool.debug(this.getClass(), "sleeping ... thread_"+index);
//									Thread.sleep(5*1000);
//									continue;
//								}else {
//									break;
//								}
//							}
//							
//							long length = JedisClient_outer.llen(queueName);
//							
//							LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//							// 所有队列长度总和为零的话，休眠
//							if (length == 0) {
//								Thread.sleep(2000);
//							}else {
//								// 对队列长度不为零的，进行处理
//								String json = JedisClient_outer.lpop(queueName);
//								if (!StringUtils.isEmpty(json)) {
//									LogTool.info(this.getClass(), "payCallback: "+String.valueOf(json));
//									Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//									
//									String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//									if (!service.endsWith("Impl")) {
//										service = service.concat("Impl");
//									}
//									OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//									if (sendService != null) {
//										sendService.handle(map);
//									}
//								}
//							}
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//							try {
//								Thread.sleep(1*1000);
//							} catch (InterruptedException e2) {
//								LogTool.error(this.getClass(), e2);
//							}
//						} catch (ParseException e) {
//							LogTool.error(this.getClass(), e);
//							try {
//								Thread.sleep(1*1000);
//							} catch (InterruptedException e1) {
//								LogTool.error(this.getClass(), e1);
//							}
//						} 
//					}
//					// while over
//				}
//			}.start();
//		}
//	}
//	/**
//	 * 异步服务：出单回调重试
//	 * @param queueName
//	 */
//	private void startUp_services_checkBillCallback_retry(final String queueName) {
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				// LOCAL 不跑
//				if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
//					return;
//				}
//				
//				while(true){
//					try {
//						Thread.sleep(5*1000);
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_PAYNOTIFY_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... ");
//								Thread.sleep(3*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(2000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), "payCallback_retry: "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								// 得到下次回调时间
//								String NEXT_CALLBACK_TIME = MapTool.getStringFromMap(map, ConstantTool.NEXT_CALLBACK_TIME);
//								// check the NEXT_CALLBACK_TIME
//								Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, NEXT_CALLBACK_TIME);
//								
//								// if now is after the NEXT_CALLBACK_TIME,do callback,else push it back to the redis queue
//								if (DateTool.isDate1LateThanDate2(new Date(), date2)) {
//									String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//									if (!service.endsWith("Impl")) {
//										service = service.concat("Impl");
//									}
//									OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//									if (sendService != null) {
//										sendService.handle(map);
//									}
//								}else {
//									JedisClient_outer.rpush(queueName, json);
//								}
//							}
//						}
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	/**
//	 * 异步服务：支付回调
//	 * @param queueName
//	 */
//	private void startUp_services_payCallback_local(final String queueName) {
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				// UAT 或 PRODUCT 不跑
//				if (LogTool.localIp.startsWith("10.1") || LogTool.localIp.startsWith("10.4")) {
//					return;
//				}
//				while(true){
//					try {
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_PAYNOTIFY_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... thread, startUp_services_payCallback_local ");
//								//							Thread.sleep(5*60*1000);
//								Thread.sleep(5*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(2000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), json+": "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//								if (!service.endsWith("Impl")) {
//									service = service.concat("Impl");
//								}
//								OuterService sendService = SpringTool.getSpringBean(StringUtils.uncapitalize(service));
//								sendService.handle(map);
//							}
//						}
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//
//	/**
//	 * 异步服务：支付回调重试 - local
//	 * @param queueName
//	 */
//	private void startUp_services_payCallback_retry_local(final String queueName) {
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				// UAT 或 PRODUCT 不跑
//				if (LogTool.localIp.startsWith("10.1") || LogTool.localIp.startsWith("10.4")) {
//					return;
//				}
//				while(true){
//					try {
//						Thread.sleep(5*1000);
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_PAYNOTIFY_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... ");
//								Thread.sleep(3*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(2000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), json+": "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								// 得到下次回调时间
//								String NEXT_CALLBACK_TIME = MapTool.getStringFromMap(map, ConstantTool.NEXT_CALLBACK_TIME);
//								// check the NEXT_CALLBACK_TIME
//								Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, NEXT_CALLBACK_TIME);
//								
//								// if now is after the NEXT_CALLBACK_TIME,do callback,else push it back to the redis queue
//								if (DateTool.isDate1LateThanDate2(new Date(), date2)) {
//									String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//									if (!service.endsWith("Impl")) {
//										service = service.concat("Impl");
//									}
//									OuterService sendService = SpringTool.getSpringBean(StringUtils.uncapitalize(service));
//									sendService.handle(map);
//								}else {
//									JedisClient_outer.rpush(queueName, json);
//								}
//							}
//						}
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	public boolean isInTime(String startEnd) throws ParseException{
//		if (!StringUtils.isEmpty(startEnd) && startEnd.indexOf(";") > -1) {
//			String start = startEnd.split(";")[0];
//			String end   = startEnd.split(";")[1];
//			Date date1 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, start);
//			Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, end);
//			Date now = new Date();
//			
//			if (now.before(date2) && now.after(date1)) {
//				LogTool.debug(this.getClass(), "now: "+DateTool.convertDataToString(now, DateTool.DATE_TIME_MASK));
//				LogTool.debug(this.getClass(), "task service pause date1: "+date1);
//				LogTool.debug(this.getClass(), "task service pause date2: "+date2);
//				return true;
//			}
//		}
//		return false;
//	}
//	
//	/**
//	 * =================================================================================
//	 * =========================== added by xiluhua 20171026 ===========================
//	 * =================================================================================
//	 * 异步服务：强撤
//	 * @author xilh
//	 * @since 20171026
//	 * 自动强撤规则：
//	 * 1、第三方包括中民、慧择、开心保、保到老等，强撤时间都设为凌晨12点没有支付的投保单
//	 * 2、天猫强撤为核保成功后72小时，蚂蚁金服为2小时。
//	 * 3、网上商城、移动商城为1小时；
//	 * 4、网电为15日；
//	 */
//	private void startUp_services_cancel() {
//		new Thread() {
//			public void run() {
//				while(true){
//					try {
//						Thread.sleep(60*1000);
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_CANCEL_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... ");
//								Thread.sleep(10*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						String time = DateTool.convertDataToString(new Date(), "yyyyMMdd HHmm");
//						
//						// IspCancel:20171111 123835:10:TEST123
//						String pattern = "IspCancel:"+time+"*";
//						// get pattern like "IspCancel:20171111 1238*"
//						Set<String> set = JedisClient_outer.keys(pattern);
//						if (set == null || set.size() == 0) {
//							continue;
//						}
//						
//						for (String key : set) {
//							// 1.3. 增加幂等锁，保证业务幂等性 added by xiluhua 20180308
//							String expireKey = "expire:"+key;
//							if (JedisClient_outer.isExist(expireKey)) {
//								LogTool.debug(this.getClass(), "repeateded request: "+expireKey);
//								continue;
//							}
//							JedisClient_outer.expire(expireKey, 30);
//							// ---------------------------------------------
//							
//							String[] arr = key.split(":");
//							CancelService cancelService = SpringTool.getSpringBean(CancelImpl.class);
//							cancelService.exec(arr[3], Long.valueOf(arr[2]));
//							// remove from cache
//							JedisClient_outer.del(key);
//						}  
//						
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	/**
//	 * =================================================================================
//	 * =========================== added by xiluhua 20171226 ===========================
//	 * =================================================================================
//	 * 异步服务：出单回调
//	 */
//	private void startUp_services_checkBillCallback(final String queueName) {
//		for (int i = 0; i < 10; i++) {
//			final int index = i;
//			new Thread() {
//				@SuppressWarnings("unchecked")
//				public void run() {
//					// LOCAL 不跑
//					if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
//						return;
//					}
//					
//					while(true){
//						try {
//							// 0. 作业总开关
//							while(true){
//								String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_CHECKBILL_START_END_TIMEOLD);
//								// 在任务暂停时间内，sleep 5 minute a time
//								if (isInTime(startEnd)) {
//									LogTool.debug(this.getClass(), "sleeping ... thread_"+index);
//									Thread.sleep(5*1000);
//									continue;
//								}else {
//									break;
//								}
//							}
//							
//							long length = JedisClient_outer.llen(queueName);
//							
//							LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//							// 所有队列长度总和为零的话，休眠
//							if (length == 0) {
//								Thread.sleep(2000);
//							}else {
//								// 对队列长度不为零的，进行处理
//								String json = JedisClient_outer.lpop(queueName);
//								if (!StringUtils.isEmpty(json)) {
//									LogTool.info(this.getClass(), "checkBillCallback: "+String.valueOf(json));
//									Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//									
//									String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//									if (!service.endsWith("Impl")) {
//										service = service.concat("Impl");
//									}
//									OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//									if (sendService != null) {
//										sendService.handle(map);
//									}
//								}
//							}
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//							try {
//								Thread.sleep(1*1000);
//							} catch (InterruptedException e2) {
//								LogTool.error(this.getClass(), e2);
//							}
//						} catch (ParseException e) {
//							LogTool.error(this.getClass(), e);
//							try {
//								Thread.sleep(1*1000);
//							} catch (InterruptedException e1) {
//								LogTool.error(this.getClass(), e1);
//							}
//						} 
//					}
//					// while over
//				}
//			}.start();
//		}
//	}
//	/**
//	 * 异步服务：支付回调重试
//	 * @param queueName
//	 */
//	private void startUp_services_payCallback_retry(final String queueName) {
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				// LOCAL 不跑
//				if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
//					return;
//				}
//				
//				while(true){
//					try {
//						Thread.sleep(5*1000);
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_CHECKBILL_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... ");
//								Thread.sleep(3*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(2000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), "checkBillCallback_retry: "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								// 得到下次回调时间
//								String NEXT_CALLBACK_TIME = MapTool.getStringFromMap(map, ConstantTool.NEXT_CALLBACK_TIME);
//								// check the NEXT_CALLBACK_TIME
//								Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, NEXT_CALLBACK_TIME);
//								
//								// if now is after the NEXT_CALLBACK_TIME,do callback,else push it back to the redis queue
//								if (DateTool.isDate1LateThanDate2(new Date(), date2)) {
//									String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//									if (!service.endsWith("Impl")) {
//										service = service.concat("Impl");
//									}
//									OuterService sendService = SpringTool.getSpringBeanNoThrow(StringUtils.uncapitalize(service));
//									if (sendService != null) {
//										sendService.handle(map);
//									}
//								}else {
//									JedisClient_outer.rpush(queueName, json);
//								}
//							}
//						}
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	/**
//	 * 异步服务：承保回调
//	 * @param queueName
//	 */
//	private void startUp_services_checkBillCallback_local(final String queueName) {
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				// UAT 或 PRODUCT 不跑
//				if (LogTool.localIp.startsWith("10.1") || LogTool.localIp.startsWith("10.4")) {
//					return;
//				}
//				while(true){
//					try {
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_CHECKBILL_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... thread, startUp_services_checkBillCallback_local ");
//								//							Thread.sleep(5*60*1000);
//								Thread.sleep(5*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(2000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), json+": "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//								if (!service.endsWith("Impl")) {
//									service = service.concat("Impl");
//								}
//								OuterService sendService = SpringTool.getSpringBean(StringUtils.uncapitalize(service));
//								sendService.handle(map);
//							}
//						}
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//
//	/**
//	 * 异步服务：承保回调重试 - local
//	 * @param queueName
//	 */
//	private void startUp_services_checkBillCallback_retry_local(final String queueName) {
//		new Thread() {
//			@SuppressWarnings("unchecked")
//			public void run() {
//				// UAT 或 PRODUCT 不跑
//				if (LogTool.localIp.startsWith("10.1") || LogTool.localIp.startsWith("10.4")) {
//					return;
//				}
//				while(true){
//					try {
//						Thread.sleep(5*1000);
//						// 0. 作业总开关
//						while(true){
//							String startEnd = CacheContainer.getSystemParameterValue(ConstantTool.SYS_CHECKBILL_START_END_TIMEOLD);
//							// 在任务暂停时间内，sleep 5 minute a time
//							if (isInTime(startEnd)) {
//								LogTool.debug(this.getClass(), "sleeping ... ");
//								Thread.sleep(3*1000);
//								continue;
//							}else {
//								break;
//							}
//						}
//						
//						long length = JedisClient_outer.llen(queueName);
//						
//						LogTool.warn(this.getClass(), queueName+": "+String.valueOf(length));
//						// 所有队列长度总和为零的话，休眠
//						if (length == 0) {
//							Thread.sleep(2000);
//						}else {
//							// 对队列长度不为零的，进行处理
//							String json = JedisClient_outer.lpop(queueName);
//							if (!StringUtils.isEmpty(json)) {
//								LogTool.info(this.getClass(), json+": "+String.valueOf(json));
//								Map<String, Object> map = (Map<String, Object>)JsonTool.toObject(json, new HashMap<String, Object>().getClass());
//								
//								// 得到下次回调时间
//								String NEXT_CALLBACK_TIME = MapTool.getStringFromMap(map, ConstantTool.NEXT_CALLBACK_TIME);
//								// check the NEXT_CALLBACK_TIME
//								Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, NEXT_CALLBACK_TIME);
//								
//								// if now is after the NEXT_CALLBACK_TIME,do callback,else push it back to the redis queue
//								if (DateTool.isDate1LateThanDate2(new Date(), date2)) {
//									String service = MapTool.getStringFromMap(map, ConstantTool.SERVICE_ID);
//									if (!service.endsWith("Impl")) {
//										service = service.concat("Impl");
//									}
//									OuterService sendService = SpringTool.getSpringBean(StringUtils.uncapitalize(service));
//									sendService.handle(map);
//								}else {
//									JedisClient_outer.rpush(queueName, json);
//								}
//							}
//						}
//					} catch (InterruptedException e1) {
//						LogTool.error(this.getClass(), e1);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e2) {
//							LogTool.error(this.getClass(), e2);
//						}
//					} catch (ParseException e) {
//						LogTool.error(this.getClass(), e);
//						try {
//							Thread.sleep(1*1000);
//						} catch (InterruptedException e1) {
//							LogTool.error(this.getClass(), e1);
//						}
//					} 
//				}
//				// while over
//			}
//		}.start();
//	}
//	
//	
//}

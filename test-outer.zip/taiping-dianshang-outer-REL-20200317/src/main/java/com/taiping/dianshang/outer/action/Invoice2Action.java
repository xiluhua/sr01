package com.taiping.dianshang.outer.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.exception.DownloadInvoicePdfException;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.service.DownloadInvoicePdfService;
import com.taiping.dianshang.outer.service.IspApplyService;
import com.taiping.dianshang.outer.service3.invoicePdf.impl.InvoicePdfCoreImpl;
import com.taiping.dianshang.service.validSqlInject.AntiSqlInjectService;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DesTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.SpringTool;
import com.taiping.framework.action.BaseAction;

/**
 * @author xilh
 * @since 20190918
 * 请使用 Invoice2Action.java
 * 20190918以后的下载功能统一放在 /shop/download 路径下，便于日后维护管理
 * <b>Title: </b>
 * <p>Description: </p>
 * 
 * @author H.Yang
 * @email xhaimail@163.com
 * @date 2019/04/26
 */
@ParentPackage("struts-default")
@Namespace("/shop/download")
public class Invoice2Action extends BaseAction {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Resource
	private IspApplyService ispApplyService;
	@Resource
	private AntiSqlInjectService antiSqlInjectService;
	@Resource
	private InvoicePdfCoreImpl invoicePdfCoreImpl;

	/**
	 * 下载电子保单
	 * http://localhost:7002/taiping-dianshang-outer/shop/downloadInvoicePdfBD.action?sign=xxx
	 * http://10.1.118.45:8001/shop/downloadInvoicePdfBD.action?sign=xxx
	 * @author xilh
	 * @since 20190917
	 */
	@Action(value = "downloadInvoicePdfBD")
	public String downloadInvoicePdfBD() throws Exception {
		String sign = getRequest().getParameter("sign");
		LogTool.debug(this.getClass(), "=== 下载电子发票接口 ===");
		// 1. 获取 sign
		if (StringUtils.isEmpty(sign)) {
			writeResponse("sign error");
			return null;
		}
		// 2. 解密 sign 并解析
		String datas = new DesTool().getDesString(sign);//解密 
		// policyNo-idNo-timestamp
		String[] arr = datas.split("-");  
		if (arr.length != 3) {
			writeResponse("invaid request");
			return null;
		}
		// 3. 过期判断
		String policyNo = arr[0];
		LogTool.info(this.getClass(), "policyNo: "+policyNo);
		
		String end = JedisClient_outer2.get(KeyTool.getDownloadEndTime(policyNo, ConstantTool.INVOICEPDF));
		if (StringUtils.isEmpty(end)) {
			writeResponse("expired request");
			return null;
		}
		// 4. 下载
		return this.downloadInvoicePdf(policyNo,arr[1]);
	}
	
	/**
	 * demo
	 * local: http://localhost:7002/taiping-dianshang-outer/shop/downloadInvoicePdf.action?policyNo=6303130114206190000044&idNo=420101198101018231
	 * uat  : http://10.1.118.45:8001/shop/downloadInvoicePdf.action?policyNo=6303130114206190000012&idNo=420101198101018231
	 * <b>Title: 下载电子发票</b>
	 * <p>Description: </p>
	 * @author H.Yang
	 * @date 2019/04/24
	 * @author xilh
	 * @since 20190430
	 * @return
	 */
	@Action(value = "downloadInvoicePdf")
	public void downloadInvoicePdf() throws Exception {
		String policyNo = getRequest().getParameter("policyNo");
		String idNo 	= getRequest().getParameter("idNo");
		this.downloadInvoicePdf(policyNo, idNo);
	}

	public String downloadInvoicePdf(String policyNo, String idNo) throws Exception {
		boolean flag    = false;
		String response = "download fail";
		LogTool.info(this.getClass(), "申请电子发票: "+policyNo+", "+idNo);
		try {
			// 1. sql注入校验
			antiSqlInjectService.verify(policyNo + idNo);

			// 2. 保单号相关信息校验
			if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
				throw new DownloadInvoicePdfException("保单号或证件号码错误");
			}

			// 1. 保单号相关信息校验
			IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
			if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
				throw new DownloadInvoicePdfException("保单号或证件号码错误");
			}
			
			Busi busi = new Busi();
			ResponseDTO responseDTO = new ResponseDTO();
			busi.setApply(apply);
			busi.setResponseDTO(responseDTO);
			invoicePdfCoreImpl.handleCore(busi);
			
			if (!responseDTO.getBusiness().isSuccess()) {
				return response;
			}

			flag = true;
			LogTool.debug(this.getClass(), "下载电子发票开始： "+policyNo);
			DownloadInvoicePdfService dpps = SpringTool.getSpringBean("DownloadInvoicePdfImpl_" + apply.getSellChannel());
			String fileDownloadPath = dpps.download(policyNo, idNo);
			LogTool.debug(this.getClass(), policyNo+", fileDownloadPath: " + fileDownloadPath);
			
			if (StringUtils.isEmpty(fileDownloadPath)) {
				throw new DownloadPolicyPdfSysException("下载电子发票失败");
			}

			this.upload(fileDownloadPath, policyNo);
			
			response = ConstantTool.SUCCESS;
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally {
			if (!flag) {
				getResponse().getWriter().write(response);
				getResponse().getWriter().flush();
				getResponse().getWriter().close();
			}
		}
		return response;
	}
	
	public void writeResponse(String responseMsg) throws IOException {
		getResponse().setCharacterEncoding(ConstantTool.GBK);
		getResponse().setContentType("application/xml");
		getResponse().getWriter().write(responseMsg);
	}

	public void upload(String fileDownloadPath, String policyNo) {
		BufferedInputStream fis = null;
		OutputStream toClient = null;
		try {
			int BUFFER_SIZE = 8096;
			File newfile = new File(fileDownloadPath);
			fis = new BufferedInputStream(new FileInputStream(fileDownloadPath));
			toClient = new BufferedOutputStream(super.getResponse().getOutputStream());
			byte buf[] = new byte[BUFFER_SIZE];
			int size = 0;
			super.getResponse().reset();
			super.getResponse().addHeader("Content-Disposition",
					(new StringBuilder("attachment;filename=")).append(new String((policyNo + ".pdf").getBytes("gbk"), "ISO-8859-1")).toString());
			super.getResponse().addHeader("Content-Length", (new StringBuilder()).append(newfile.length()).toString());
			super.getResponse().setContentType("application/octet-stream;charset=GBK");

			while ((size = fis.read(buf)) != -1) {
				toClient.write(buf, 0, size);
			}
			fis.close();
			toClient.flush();
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new DownloadPolicyPdfSysException(e.getMessage());
		} finally {
			try {
				File pdfFile = new File(fileDownloadPath);
				if (pdfFile.isFile() && pdfFile.exists()) {
					if (LogTool.isFormal) {
						pdfFile.delete();
					}
				}
				if (fis != null) {
					fis.close();
				}
				if (toClient != null) {
					toClient.close();
				}
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
				throw new DownloadPolicyPdfSysException(e.getMessage());
			}
		}
	}

}

package com.taiping.dianshang.dao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBale;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspBlueprintProperty;
import com.taiping.dianshang.entity.IspProductExt;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBlueprintPropertyDao extends BaseWriteDao<IspBlueprintProperty, Long> implements CacheDaoService{
	
	@Resource
	private IspAreaDao ispAreaDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	
	public Map<Object,String> getAllInMap(){
		List<IspBlueprintProperty> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspBlueprintProperty blueprintProperty = list.get(i);
				String key = KeyTool.get(IspBlueprintProperty.class, blueprintProperty.getBlueId());
				map.put(key,JsonTool.toJson(blueprintProperty));
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspBlueprintProperty> getAll(){
		String hql = "from IspBlueprintProperty";
		return super.getSession().createQuery(hql).list();
	}

	public IspBlueprintProperty init(IspBlueprint blueprint,List<IspBale> baleList, List<IspProductExt> productExtList) {

		String idTypeList = "1,2,3,4,9";	//证件类型列表  逗号分割 1.身份证|2.军人证|3.护照|4.出生证|9.其他
		String insuredAge = "18Y,60Y";
		List<Double> charge_amount_list = new ArrayList<Double>(); // 保额列表
		List<Long> charge_year_list = new ArrayList<Long>(); // 交费期列表
		String holderInstList = "1,2,3,5"; // 1.mate.配偶|2.child.子女|3.parent.父母|5.self.本人
		HashSet<String> charge_type_set = new HashSet<String>(); // 临时交费类型List
		HashSet<Integer> charge_amount_set = new HashSet<Integer>(); // 临时保额列表
		HashSet<Long> charge_year_set = new HashSet<Long>(); // 临时交费期列表

		String propertyChargeTypeList = "";
		String propertyAmountList = "";
		String propertyChargeYearList = "";
		Long coverType = null; // 保障类型
		Long coverYear = null; // 保障年期
		String insuredGender = "1,2";	//1男2女
		Long blueId = blueprint.getBlueId();
		IspBlueprintProperty blueprintProperty = this.get("blueId", blueId); // 方案属性
		Double maxAmount = this.getMaxAmountByBlueId(baleList); // 方案最大保额
		// 获得交费属性配置数据
		for (IspBale bale : baleList) {
			if (bale.getChargeTypeList() != null) {
				charge_type_set.add(bale.getChargeTypeList());
			}
			if (bale.getAmount() != null) {
				charge_amount_set.add(bale.getAmount());
			}
			if (bale.getChargeYear() != null) {
				charge_year_set.add(bale.getChargeYear());
			}

			Long coreBaleId = bale.getCoreBaleId();
			if (coverType == null && coverYear == null) {
				for (IspProductExt proExt : productExtList) {
					Long corePlanBaleId = proExt.getCoreBaleId();
					if (corePlanBaleId != null
							&& corePlanBaleId.equals(coreBaleId)) {
						coverType = proExt.getCoverType();
						coverYear = proExt.getCoverYear();
						break;
					}
				}
			}
		}

		// 排序并转化
		Iterator<String> chargeTypeIT = charge_type_set.iterator();
		String chargeType = "";
		while (chargeTypeIT.hasNext()) {
			String charge_list = (String) chargeTypeIT.next();
			String[] chargeTypeList = charge_list.split(",");
			for (int i = 0; i < chargeTypeList.length; i++) {
				chargeType = chargeTypeList[i];
				if (propertyChargeTypeList.indexOf(chargeType) == -1) {
					propertyChargeTypeList += chargeType;
					propertyChargeTypeList += ",";
				}
			}
		}
		propertyChargeTypeList = propertyChargeTypeList.substring(0,propertyChargeTypeList.length() - 1); // 去掉最后一个逗号

		for (double amount : charge_amount_set) {
			if (amount != 0) {
				charge_amount_list.add(amount);
			}
			Collections.sort(charge_amount_list);
		}
		for (int i = 0; i < charge_amount_list.size(); i++) {
			propertyAmountList += charge_amount_list.get(i);
			if (i != (charge_amount_list.size() - 1)) {
				propertyAmountList += ",";
			}
		}
		
		for (Long chargeYear : charge_year_set) {
			charge_year_list.add(chargeYear);
			Collections.sort(charge_year_list);
		}
		for (int i = 0; i < charge_year_list.size(); i++) {
			propertyChargeYearList += charge_year_list.get(i);
			if (i != (charge_year_list.size() - 1)) {
				propertyChargeYearList += ",";
			}
		}
		// 添加方案属性
		Integer isValidate = 2;
		if (propertyChargeTypeList.indexOf("5") != -1) {
			isValidate = 1;
		}
		String coverOrganList = ispAreaDao.getCoverOrganList();
		propertyChargeTypeList = propertyChargeTypeList.replaceAll(" ", "");
		propertyAmountList = propertyAmountList.replaceAll(" ", "");
		propertyChargeYearList = propertyChargeYearList.replaceAll(" ", "");
		
		boolean isSave = blueprintProperty == null;// 新增
		if (isSave) { 
			blueprintProperty = new IspBlueprintProperty();
			blueprintProperty.setBlueprintPropertyId(this.getUniqueSequence());
		}
		// set
		blueprintProperty.setBlueId(blueprint.getBlueId());
		blueprintProperty.setChargeTypeList(propertyChargeTypeList);
		blueprintProperty.setAmountList(propertyAmountList);
		blueprintProperty.setChargeYearList(propertyChargeYearList);
		blueprintProperty.setCoverType(coverType);
		blueprintProperty.setCoverYear(coverYear);
		blueprintProperty.setIsValidate(isValidate);
		blueprintProperty.setRHolderInstList(holderInstList);
		blueprintProperty.setMaxAmount(maxAmount);
		blueprintProperty.setInsuredGender(insuredGender);
		blueprintProperty.setCoverOrganList(coverOrganList);
		blueprintProperty.setInsuredAge(insuredAge);
		blueprintProperty.setCreateTime(new Date());
		blueprintProperty.setIdTypeList(idTypeList);
		if (blueprint.getInsuranceType() == 1) {
			blueprintProperty.setTrialItemList("5");
		}else {
			// 1.insuredAge.被保人年龄|2.insuredGender.被保人性别|3.chargeTypeList.缴费类型|
			// 4.chargeYearList.缴费期|5.amountList.保额|6.coverPeriodList.保障期限
			blueprintProperty.setTrialItemList("1,2,3,4,5");
		}
		
		if (isSave) {
			this.save(blueprintProperty);
		}else {
			this.update(blueprintProperty);
		}
		
		return blueprintProperty;
	}
	
	public Double getMaxAmountByBlueId(List<IspBale> baleList){
		Double maxAmount = 0d;
		for (int i = 0; i < baleList.size(); i++) {
			double amount = baleList.get(i).getAmount();
			if (amount > maxAmount.doubleValue()) {
				maxAmount = amount;
			}
		}
		
		return maxAmount;
	}
	
	private Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_ISP_BLUEPRINT_PROPERTY);
			IspBlueprintProperty blueprintProperty = super.get("id", seq);
			
			if (blueprintProperty == null) {
				return seq;
			}
		}
	}
}
package com.taiping.dianshang.outer.service.impl.email;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.ImsSystemParameter;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.MailNotifyService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.framework.bean.MailAttachment;
import com.taiping.framework.bean.MailMessageBean;
import com.taiping.framework.bean.MailMessageBean.MailStatus;

@Service
public class MailNotifyImpl implements MailNotifyService{
	
	static{
		emailTemplatePathInit();
	}
	
	/**
	 * 得到邮件模板根目录路径
	 */
	public static void emailTemplatePathInit(){
		LogTool.info(ConstantTool.class, "=== INIT EMAIL TEMPLATE ===");
		String emailTemplate = MailNotifyImpl_CBCG_1.class.getResource("/template/email/KDQTX.html").getPath();
		LogTool.info(ConstantTool.class, "EMAIL TEMPLATE : "+emailTemplate);
		ConstantTool.EMAIL_TEMPLATE_PATH = emailTemplate.substring(0, emailTemplate.lastIndexOf("/")+1);
	}
	
	/**
	 * 邮件发送服务初始化
	 * 什么服务配置什么参数，格式如下：
	 * //#mail_service = iipFromAddress:iipFromName:iipReplayAddress:iipFromId:iipBranchId:iipOrgId:iipChannelId
	 * //mail_service_CBCG = 太平人寿::fw@tplife.com:FROM_WX:1:ORG_TPRS:CHANNEL_WX
	 * @param serviceId
	 * @return
	 */
	public MailMessageBean initMailMessageBean(String serviceId){
		String emailService = null;
		MailMessageBean mmsg = new MailMessageBean();
		try {
			emailService = CacheContainer.getSystemParameterValue(serviceId);
		} catch (SystemParameterNotFoundException e) {
			LogTool.error(this.getClass(), "exception,system_parameter haven't set:"+serviceId);
			return null;
		}
		
		String[] array = emailService.split(":");
		mmsg.setFromAddress(array[0]);
		mmsg.setFromName(array[1]);
		mmsg.setReplyAddress(array[2]);
		mmsg.setFromId(array[3]);
		mmsg.setBranchId(array[4]);
		mmsg.setOrgId(array[5]);
		mmsg.setChannelId(array[6]);
		mmsg.setSubject(array[7]);
		mmsg.setSendStatus(MailStatus.UNTREATED);	//0未处理|1已处理
		mmsg.setServiceId(serviceId);
		
		return mmsg;
	}
	
	/**
	 * 邮件发送服务初始化
	 * to support different sellChannel, different title
	 * @author xilh
	 * @param serviceId
	 * @since 20181112
	 * @return
	 */
	public MailMessageBean initMailMessageBean(String serviceId,IspApply apply){
		String emailService = null;
		MailMessageBean mmsg = new MailMessageBean();
		try {
			// add by xiluhua 20181112 to support different sellChannel, different title
			String serviceId2 = serviceId+"_"+apply.getSellChannel();
			LogTool.debug(this.getClass(), apply.getPartnerApplyId()+": "+serviceId2);
			emailService = CacheContainer.getSystemParameterValue(serviceId2);
		} catch (SystemParameterNotFoundException e) {
			LogTool.error(this.getClass(), "exception,system_parameter haven't set:"+serviceId);
			return null;
		}
		
		String[] array = emailService.split(":");
		mmsg.setFromAddress(array[0]);
		mmsg.setFromName(array[1]);
		mmsg.setReplyAddress(array[2]);
		mmsg.setFromId(array[3]);
		mmsg.setBranchId(array[4]);
		mmsg.setOrgId(array[5]);
		mmsg.setChannelId(array[6]);
		mmsg.setSubject(array[7]);
		mmsg.setSendStatus(MailStatus.UNTREATED);	//0未处理|1已处理
		mmsg.setServiceId(serviceId);
		
		return mmsg;
	}

	@Override
	public void handle(Map<String, Object> emailParamsMap) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getContent(String blueName, String realName, String policyNo,
			String insuredName) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MailAttachment getAttachment(String path, String fileName) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
//	private void sendMail_ZCCG(Map emailParamsMap) {
//		
//	}
//	private void sendMail_QHMM(Map emailParamsMap) {
//			
//	}
//	private void sendMail_ZZKGMCG(Map emailParamsMap) {
//		
//	}
//	
//	private void sendMail_KDQTX(Map emailParamsMap) {
//		
//	}
//	private void sendMail_DSRW(Map emailParamsMap) {
//		
//	}
//	private void sendMail_WTJ(Map emailParamsMap) {
//		
//	}

	
//	@Override
//	public void send(Map<String, Object> emailParamsMap) {
//		// TODO Auto-generated method stub
//		final String sericeId = StringTool.nullToEmpty(emailParamsMap.get(ConstantTool.SERVICE_ID));
//		
//		//承保通知
//		if (sericeId.equalsIgnoreCase(ConstantTool.WX_CBCG)) {
//			
//			this.sendMail_CBCG(emailParamsMap);
//		}
//		// 根据类型判断业务，1:注册，2：为找回密码，
//		if (sericeId.equalsIgnoreCase(ConstantTool.WX_WZZCCG)) {
//			// 10、匿名内部类将数据存入网销数据库
//			
//		}
//		//找回密码
//		if (sericeId.equalsIgnoreCase(ConstantTool.WSFW_QHMM)) {
//					
//		}
//		//自助卡激活与承保(自助卡operateNo为isp_card_apply主键aply_id，承保operateNo为保单号)
//		if (sericeId.equalsIgnoreCase("")) {
//			
//		}
//		
//		//快到期邮件
//		if (sericeId.equalsIgnoreCase(ConstantTool.WX_KDQTX)) {
//			
//		}
//		
//		//定时任务失败
//		if (sericeId.equalsIgnoreCase(ConstantTool.WX_DSRW)) {
//			
//		}
//		//问题件邮件发送
//		if (sericeId.equalsIgnoreCase(ConstantTool.WX_WTJ)) {
//			
//		}
//	}

}

package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**   
 * @ClassName CXIspAcceptProperty   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_RETRY_RECORD")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspRetryRecord {
	@Id
	@Column(name="RETRY_ID")
	private Long retryId;
	@Column(name="CLASS_NAME")
	private String className;
	@Column(name="OPERATE_NO")
	private String operateNo;
	@Column(name="BILL_ID")
	private Long billId;
	@Column(name="PREM_ID")
	private String premId;
	@Column(name="BUSI_TYPE")
	private Integer busiType;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;
	
	public Long getRetryId() {
		return retryId;
	}
	public void setRetryId(Long retryId) {
		this.retryId = retryId;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public IspRetryRecord() {
		super();
		// TODO Auto-generated constructor stub
	}
	public IspRetryRecord(Long retryId, String className,
			String operateNo, Date createTime) {
		super();
		this.retryId = retryId;
		this.className = className;
		this.createTime = createTime;
		this.operateNo = operateNo;
	}
	public Long getBillId() {
		return billId;
	}
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	public Integer getBusiType() {
		return busiType;
	}
	public void setBusiType(Integer busiType) {
		this.busiType = busiType;
	}
	public String getPremId() {
		return premId;
	}
	public void setPremId(String premId) {
		this.premId = premId;
	}
	public String getOperateNo() {
		return operateNo;
	}
	public void setOperateNo(String operateNo) {
		this.operateNo = operateNo;
	}
	@Override
	public String toString() {
		return "IspRetryRecord [retryId=" + retryId + ", className="
				+ className + ", operateNo=" + operateNo + ", billId=" + billId
				+ ", premId=" + premId + ", busiType=" + busiType
				+ ", createTime=" + createTime + "]";
	}
	
	
}

package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspPayPartnerType;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspPayPartnerTypeDao extends BaseWriteDao<IspPayPartnerType, Long> implements CacheDaoService{
	
	@Override
	public Map<Object, String> getAllInMap() {
		List<IspPayPartnerType> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspPayPartnerType obj = list.get(i);
				if (obj.getPartnerId() != null) {
					String key = KeyTool.get(IspPayPartnerType.class,obj.getPartnerId());
					map.put(key, JsonTool.toJson(obj));	
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspPayPartnerType> getAll(){
		String hql = "from IspPayPartnerType t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
}

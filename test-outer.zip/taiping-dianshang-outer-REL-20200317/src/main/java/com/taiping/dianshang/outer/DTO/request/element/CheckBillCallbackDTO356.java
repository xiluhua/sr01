package com.taiping.dianshang.outer.DTO.request.element;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBeneficiary;
import com.taiping.dianshang.outer.DTO.request.RequestCheckBillCallbackDTO356;
import com.taiping.dianshang.outer.DTO.request.RequestMediumDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.ApplyResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.BeneficiaryResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.CustomerResponseDTO;
import com.taiping.dianshang.outer.DTO.response.element.info.RenewInfResponseDTO;
import com.taiping.facility.tool.JAXBTool;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"apply",
		"holder",
		"insured",
		"renewInf",
		"beneficiaryList",
		"medium"
})
public class CheckBillCallbackDTO356{
	@XmlElement(name = "APPLY")
	private ApplyResponseDTO apply = new ApplyResponseDTO();
	@XmlElement(name = "HOLDER")
	private CustomerResponseDTO holder = new CustomerResponseDTO();
	@XmlElement(name = "INSURED")
	private CustomerResponseDTO insured = new CustomerResponseDTO();
	@XmlElement(name = "RENEW")
	private RenewInfResponseDTO renewInf = new RenewInfResponseDTO(); 			// 续期信息
	@XmlElementWrapper(name="BENEFICIARYS")
    @XmlElement(name = "BENEFICIARY")
    private List<BeneficiaryResponseDTO> beneficiaryList = new ArrayList<BeneficiaryResponseDTO>(); 						// 受益人信息
	@XmlElement(name = "MEDIUM")
	private RequestMediumDTO medium = new RequestMediumDTO();
	
	public RequestMediumDTO getMedium() {
		return medium;
	}
	public void setMedium(RequestMediumDTO medium) {
		this.medium = medium;
	}
	public ApplyResponseDTO getApply() {
		return apply;
	}
	public void setApply(ApplyResponseDTO apply) {
		this.apply = apply;
	}
	public CustomerResponseDTO getHolder() {
		return holder;
	}
	public void setHolder(CustomerResponseDTO holder) {
		this.holder = holder;
	}
	public CustomerResponseDTO getInsured() {
		return insured;
	}
	public void setInsured(CustomerResponseDTO insured) {
		this.insured = insured;
	}
	public RenewInfResponseDTO getRenewInf() {
		return renewInf;
	}
	public void setRenewInf(RenewInfResponseDTO renewInf) {
		this.renewInf = renewInf;
	}
	public List<BeneficiaryResponseDTO> getBeneficiaryList() {
		return beneficiaryList;
	}
	public void setBeneficiaryList(List<BeneficiaryResponseDTO> beneficiaryList) {
		this.beneficiaryList = beneficiaryList;
	}
	public CheckBillCallbackDTO356() {
		super();
		// TODO Auto-generated constructor stub
	}
    
	public CheckBillCallbackDTO356(IspApply applyModel) {
		super();
		this.apply = new ApplyResponseDTO(applyModel);
		this.holder = new CustomerResponseDTO(applyModel.getHolder());
		this.insured = new CustomerResponseDTO(applyModel.getInsured());
		
		if (applyModel.getBeneficiaryList()!=null) {
			for (int i = 0; i < applyModel.getBeneficiaryList().size(); i++) {
				IspBeneficiary beneficiary = applyModel.getBeneficiaryList().get(i);
				BeneficiaryResponseDTO beneficiaryResponseDTO = new BeneficiaryResponseDTO(beneficiary);
				this.beneficiaryList.add(beneficiaryResponseDTO);
			}
		}
	}
	
	public static void main(String[] args) throws JAXBException, IOException {
		RequestCheckBillCallbackDTO356 requestCheckBillCallbackDTO = new RequestCheckBillCallbackDTO356();
		requestCheckBillCallbackDTO.getCallback().getMedium().setWi("M12345");
		String sss = JAXBTool.marshal(requestCheckBillCallbackDTO, ConstantTool.UTF8);
		System.out.println(sss);
	}
}

package com.taiping.dianshang.outer.service.impl.policyPdf;

import org.springframework.stereotype.Service;


/**
 * <b>Title: 易安-碎屏险</b>
 * <p>Description: </p>
 * 
 * @author H.Yang.20181029.PM.Add
 * @email xhaimail@163.com
 */
@Service
public class DownloadPolicyPdfImpl_11 extends DownloadPolicyPdfImpl_3{
	
}

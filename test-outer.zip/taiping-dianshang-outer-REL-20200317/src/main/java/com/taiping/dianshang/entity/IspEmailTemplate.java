package com.taiping.dianshang.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspCheckBusinessFlow   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_EMAIL_TEMPLATE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspEmailTemplate implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3852360255317000358L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="BLUE_ID")
	private Long blueId;
	@Column(name="PARTNER_ID")
	private Long partnerId;
	@Column(name="SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name="STATUS")
	private Integer status;
	@Column(name="CONTENT_SERVICE")
	private String contentService;					// 内容服务
	@Column(name="TEMPLATE")
	private String template;							// 模板内容
	@Column(name="TYPE")
	private Integer type;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name="CREATE_TIME")
	private Date createTime;
	// add by liuhe 20190819
	@Column(name="EMAIL_CODE")
	private String emailCode;
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	public Long getBlueId() {
		return blueId;
	}
	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Integer getSellChannel() {
		return sellChannel;
	}
	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getContentService() {
		return contentService;
	}
	public void setContentService(String contentService) {
		this.contentService = contentService;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getEmailCode() {
		return emailCode;
	}
	public void setEmailCode(String emailCode) {
		this.emailCode = emailCode;
	}

}





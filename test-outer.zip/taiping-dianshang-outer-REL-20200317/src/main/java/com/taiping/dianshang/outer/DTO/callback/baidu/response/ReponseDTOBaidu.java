package com.taiping.dianshang.outer.DTO.callback.baidu.response;


public class ReponseDTOBaidu {

}

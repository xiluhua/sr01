package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IpayRegisterTemplateCode;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IpayRegisterTemplateCodeDao extends BaseWriteDao<IpayRegisterTemplateCode, Long> implements CacheDaoService{

	public Map<Object,String> getAllInMap(){
		List<IpayRegisterTemplateCode> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IpayRegisterTemplateCode payRegisterTemplateCode = list.get(i);
				// 策略1. partnerId_blueId_chargeType
				if (payRegisterTemplateCode.getType() == 1) {
					String temp = payRegisterTemplateCode.getPartnerId() + ConstantTool.UNDERLINE + payRegisterTemplateCode.getBlueId()+ConstantTool.UNDERLINE+payRegisterTemplateCode.getChargeType();
					String key = KeyTool.get(IpayRegisterTemplateCode.class, temp);
					map.put(key, JsonTool.toJson(payRegisterTemplateCode));
				}
				// 策略2. partnerId_blueId
				else if (payRegisterTemplateCode.getType() == 2) {
					String temp = payRegisterTemplateCode.getPartnerId() + ConstantTool.UNDERLINE + payRegisterTemplateCode.getBlueId();
					String key = KeyTool.get(IpayRegisterTemplateCode.class, temp);
					map.put(key, JsonTool.toJson(payRegisterTemplateCode));
				}
				// 策略3. blueId
				else if (payRegisterTemplateCode.getType() == 3) {
					String temp = String.valueOf(payRegisterTemplateCode.getBlueId());
					String key = KeyTool.get(IpayRegisterTemplateCode.class, temp);
					map.put(key, JsonTool.toJson(payRegisterTemplateCode));
				}
				// 策略4. partnerId
				else if (payRegisterTemplateCode.getType() == 4) {
					String temp = String.valueOf(payRegisterTemplateCode.getPartnerId());
					String key = KeyTool.get(IpayRegisterTemplateCode.class, temp);
					map.put(key, JsonTool.toJson(payRegisterTemplateCode));
				}
				// 策略5. 全系统默认
				else if (payRegisterTemplateCode.getType() == 5) {
					String temp = String.valueOf(payRegisterTemplateCode.getType());
					String key = KeyTool.get(IpayRegisterTemplateCode.class, temp);
					map.put(key, JsonTool.toJson(payRegisterTemplateCode));
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IpayRegisterTemplateCode> getAll(){
		String hql = "from IpayRegisterTemplateCode t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}

}

package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspSpecialBusi;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspSpecialBusiDao extends BaseWriteDao<IspSpecialBusi, Long> implements CacheDaoService{
	

	public Map<Object,String> getAllInMap(){
		List<IspSpecialBusi> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspSpecialBusi specialBusi = list.get(i);
				if (specialBusi.getBlueId() != null) {
					String key = KeyTool.get(IspSpecialBusi.class, specialBusi.getBlueId());
					map.put(key, JsonTool.toJson(specialBusi));	
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspSpecialBusi> getAll(){
		String hql = "from IspSpecialBusi t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}

//	@Override
//	public Class<?> getByIdFromCache(Long id) {
//		// TODO Auto-generated method stub
//		return null;
//	}
}
package com.taiping.dianshang.dao;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspYqfad;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspYqfadDao extends BaseWriteDao<IspYqfad, Long> {
	public IspYqfad getById(Long applyId){
		return super.get("applyId", applyId);
	}
}
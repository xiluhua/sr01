package com.taiping.dianshang.outer.DTO.response.element.info;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.taiping.dianshang.entity.IspBeneficiary;
import com.taiping.facility.tool.DateTimeAdapter;

/**
 * 受益人信息类
 * @author xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
	    "beneficiaryName",
	    "gender",
	    "birthday",
	    "idType",
	    "idNo",
	    "beneRatio",
	    "beneOrder",
	    "insuredRelationNo",
	    "idNoEndDate"
})
public class BeneficiaryResponseDTO {
	@XmlElement(name = "BENEFICIARY_NAME")
    protected String beneficiaryName;     // 受益人姓名
	@XmlElement(name = "GENDER")
    protected Integer gender;             // 受益人性别
	@XmlElement(name = "BIRTHDAY")
	@XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    protected Date birthday;              // 受益人生日
	@XmlElement(name = "ID_TYPE")
    protected Integer idType;             // 证件类型
	@XmlElement(name = "ID_NO")
    protected String idNo;                // 证件号
	@XmlElement(name = "BENE_RATIO")
    protected Double beneRatio;           // 受益比例
	@XmlElement(name = "BENE_ORDER")
    protected Integer beneOrder;          // 受益顺序
	@XmlElement(name = "INSURED_RELATION_NO")
    protected Integer insuredRelationNo;  // 受益人与被保人的(关系)
	
	@XmlJavaTypeAdapter(value = DateTimeAdapter.class)
	@XmlElement(name = "IDNO_END_DATE")
	private Date idNoEndDate;
	
	public Date getIdNoEndDate() {
		return idNoEndDate;
	}
	public void setIdNoEndDate(Date idNoEndDate) {
		this.idNoEndDate = idNoEndDate;
	}
	public String getBeneficiaryName() {
		return beneficiaryName;
	}
	public void setBeneficiaryName(String beneficiaryName) {
		this.beneficiaryName = beneficiaryName;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public Integer getIdType() {
		return idType;
	}
	public void setIdType(Integer idType) {
		this.idType = idType;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public Double getBeneRatio() {
		return beneRatio;
	}
	public void setBeneRatio(Double beneRatio) {
		this.beneRatio = beneRatio;
	}
	public Integer getBeneOrder() {
		return beneOrder;
	}
	public void setBeneOrder(Integer beneOrder) {
		this.beneOrder = beneOrder;
	}
	public Integer getInsuredRelationNo() {
		return insuredRelationNo;
	}
	public void setInsuredRelationNo(Integer insuredRelationNo) {
		this.insuredRelationNo = insuredRelationNo;
	}
	public BeneficiaryResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BeneficiaryResponseDTO(IspBeneficiary beneficiary) {
		super();
		this.setBeneficiaryName(beneficiary.getBeneficiaryName());
		this.setBeneOrder(beneficiary.getBeneOrder());
		this.setBeneRatio(beneficiary.getBeneRatio());
		this.setBirthday(beneficiary.getBirthday());
		this.setGender(beneficiary.getGender());
		this.setIdNo(beneficiary.getIdNo());
		this.setIdType(beneficiary.getIdType());
		this.setInsuredRelationNo(beneficiary.getInsuredRelationNo());
	}
}
package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * JcImsSystemParameter entity. 
 */
@Entity
@Table(name = "JC_IMS_SYSTEM_PARAMETER")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsSystemParameter implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long parameterId;
	private String parameterCode;
	private String parameterValue;
	private String parameterName;
	private Integer parameterDataType;
	private Integer parameterType;
	private String memo;
	private Long systemId;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;

	// Constructors

	/** default constructor */
	public ImsSystemParameter() {
	}

	/** minimal constructor */
	public ImsSystemParameter(Long parameterId) {
		this.parameterId = parameterId;
	}

	/** full constructor */
	public ImsSystemParameter(Long parameterId, String parameterCode,
			String parameterValue, String parameterName,
			Integer parameterDataType, Integer parameterType, String memo,
			Long systemId, Date createTime, Date updateTime,
			String createAid, String updateAid) {
		this.parameterId = parameterId;
		this.parameterCode = parameterCode;
		this.parameterValue = parameterValue;
		this.parameterName = parameterName;
		this.parameterDataType = parameterDataType;
		this.parameterType = parameterType;
		this.memo = memo;
		this.systemId = systemId;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
	}

	// Property accessors
	@Id
	@Column(name = "PARAMETER_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getParameterId() {
		return this.parameterId;
	}

	public void setParameterId(Long parameterId) {
		this.parameterId = parameterId;
	}

	@Column(name = "PARAMETER_CODE", length = 20)
	public String getParameterCode() {
		return this.parameterCode;
	}

	public void setParameterCode(String parameterCode) {
		this.parameterCode = parameterCode;
	}

	@Column(name = "PARAMETER_VALUE", length = 200)
	public String getParameterValue() {
		return this.parameterValue;
	}

	public void setParameterValue(String parameterValue) {
		this.parameterValue = parameterValue;
	}

	@Column(name = "PARAMETER_NAME", length = 100)
	public String getParameterName() {
		return this.parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	@Column(name = "PARAMETER_DATA_TYPE", precision = 3, scale = 0)
	public Integer getParameterDataType() {
		return this.parameterDataType;
	}

	public void setParameterDataType(Integer parameterDataType) {
		this.parameterDataType = parameterDataType;
	}

	@Column(name = "PARAMETER_TYPE", precision = 3, scale = 0)
	public Integer getParameterType() {
		return this.parameterType;
	}

	public void setParameterType(Integer parameterType) {
		this.parameterType = parameterType;
	}

	@Column(name = "MEMO", length = 500)
	public String getMemo() {
		return this.memo;
	}

	public void setMemo(String memo) {
		this.memo = memo;
	}

	@Column(name = "SYSTEM_ID", precision = 10, scale = 0)
	public Long getSystemId() {
		return this.systemId;
	}

	public void setSystemId(Long systemId) {
		this.systemId = systemId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

}
package com.taiping.dianshang.dao;

import java.math.BigDecimal;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.entity.IspGiftScoreHistory;
import com.taiping.framework.dao.BaseWriteDao;

/**
 * replaced by IspSendHistoryDao
 */
@Deprecated
@Repository
public class IspGiftScoreHistoryDao extends BaseWriteDao<IspGiftScoreHistory, Long>{

	@Transactional
	public Long save(IspGiftScoreHistory ispGiftScoreHistory) {
		long seq = this.getSequnce();
		ispGiftScoreHistory.setId(seq);
		return super.save(ispGiftScoreHistory);
	}

	@Transactional
	public boolean isExist(Long applyId) {
		
		return super.isExist("applyId", applyId);
	}
	
	@Transactional
	public Long getSequnce() {
		SQLQuery query = getSession().createSQLQuery("select SEQ_ISP_GIFT_SCORE_HISTORY.nextval from dual");
		
		return ((BigDecimal)query.uniqueResult()).longValue();
	}
}

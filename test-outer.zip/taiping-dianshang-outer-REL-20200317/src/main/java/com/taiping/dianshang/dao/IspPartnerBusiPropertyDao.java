package com.taiping.dianshang.dao;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.IspPartnerBusiProperty;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspPartnerBusiPropertyDao extends BaseWriteDao<IspPartnerBusiProperty, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<IspPartnerBusiProperty> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspPartnerBusiProperty parIspPartnerBusiProperty = list.get(i);
				String key = KeyTool.get(IspPartnerBusiProperty.class, parIspPartnerBusiProperty.getPartnerId()+"_"+parIspPartnerBusiProperty.getBlueId());
				map.put(key, JsonTool.toJson(parIspPartnerBusiProperty));
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspPartnerBusiProperty> getAll(){
		String hql = "from IspPartnerBusiProperty t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
	
	public BigDecimal getTotalAccept(Long partnerId,Long blueId){
		StringBuilder sql = new StringBuilder();
		sql.append("select count(1) from isp_apply ap ");
		sql.append("where ap.blue_id = '"+blueId+"' ");
		sql.append("  and ap.check_bill_status = 1");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAccept_idNoAcceptNum(Long partnerId,Long blueId,String idNo,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT COUNT(1) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.id_no = '"+idNo+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "idNo      : "+idNo);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAccept_emailAcceptNum(Long partnerId,Long blueId,String email,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT COUNT(1) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.email = '"+email+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "email     : "+email);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAccept_mobileAcceptNum(Long partnerId,Long blueId,String mobile,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT COUNT(1) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.mobile = '"+mobile+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "mobile    : "+mobile);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAccept_addressAcceptNum(Long partnerId,Long blueId,String address,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT COUNT(1) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.address = '"+address+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "address   : "+address);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAmount_mobile(Long partnerId,Long blueId,String mobile,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SUM(AP.AMOUNT) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.mobile = '"+mobile+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "mobile    : "+mobile);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAmount_email(Long partnerId,Long blueId,String email,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SUM(AP.AMOUNT) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.email = '"+email+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "email     : "+email);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalAmount_idNo(Long partnerId,Long blueId,String idNo,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SUM(AP.AMOUNT) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.id_no = '"+idNo+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "idNo      : "+idNo);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);

		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
		
	public BigDecimal getTotalPremium_email(Long partnerId,Long blueId,String email,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SUM(AP.PREMIUM) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.email = '"+email+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "email     : "+email);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalPremium_idNo(Long partnerId,Long blueId,String idNo,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SUM(AP.PREMIUM) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.id_no = '"+idNo+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "idNo      : "+idNo);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
	
	public BigDecimal getTotalPremium_mobile(Long partnerId,Long blueId,String mobile,int custType){
		StringBuilder sql = new StringBuilder();
		sql.append("SELECT SUM(AP.PREMIUM) ");
		sql.append("FROM ISP_APPLY AP,isp_app_customer ac ");
		sql.append("WHERE AP.BLUE_ID = "+blueId);
		sql.append(" AND ap.apply_id = ac.apply_id ");
		sql.append(" AND ac.cust_type = "+custType);
		sql.append(" AND AP.CHECK_BILL_STATUS = 1 ");
		sql.append(" AND ac.mobile = '"+mobile+"' ");
		
		if (partnerId != null) {
			sql.append("  and ap.partner_id = "+partnerId);
		}
		
		LogTool.debug(this.getClass(), sql.toString());
		LogTool.debug(this.getClass(), "blueId    : "+blueId);
		LogTool.debug(this.getClass(), "custType  : "+custType);
		LogTool.debug(this.getClass(), "mobile    : "+mobile);
		LogTool.debug(this.getClass(), "partnerId : "+partnerId);
		
		return ((BigDecimal) getSession().createSQLQuery(sql.toString()).uniqueResult());
	}
}

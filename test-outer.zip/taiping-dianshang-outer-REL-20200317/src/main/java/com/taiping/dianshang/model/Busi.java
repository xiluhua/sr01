package com.taiping.dianshang.model;

import java.util.List;

import org.dom4j.Document;

import com.taiping.dianshang.entity.IpayBill;
import com.taiping.dianshang.entity.IpayBillGoods;
import com.taiping.dianshang.entity.IpayPay;
import com.taiping.dianshang.entity.IpayRegister;
import com.taiping.dianshang.entity.IpayRenew;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspApplyVehicle;
import com.taiping.dianshang.entity.IspPolicy;
import com.taiping.dianshang.entity.IspRenewApply;
import com.taiping.dianshang.entity.IspTwicePrem;
import com.taiping.dianshang.entity.IspYangLaoTrans;
import com.taiping.dianshang.outer.DTO.request.RequestDTO;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;

public class Busi {
	private String busiId;
	private String serviceCode;
	private Long partnerId;
	private boolean isJson;
	private boolean isBatch;
	private String requestMsg;
	private String responseMsg;
	private Document xmlDoc;		
	
	private IspApply apply;
	private IspTwicePrem twicePrem;
	private List<IpayBillGoods> billGoodList;
	private IpayBill bill;
	private IpayPay pay;
	private IpayRenew payRenew;
	private IpayRegister payRegister;
	private IspYangLaoTrans yangLaoTrans;
	private IspApplyVehicle applyVehicle;
	private IspPolicy policy;
	private IspRenewApply renewApply;
	// add by xiluhua 20190430
	private RequestDTO requestDTO;	// 请求对象
	private ResponseDTO responseDTO;// 返回对象
	// add by xilh 2020212
	private Object tmp;
	
	public Object getTmp() {
		return tmp;
	}
	public void setTmp(Object tmp) {
		this.tmp = tmp;
	}
	public IspTwicePrem getTwicePrem() {
		return twicePrem;
	}
	public void setTwicePrem(IspTwicePrem twicePrem) {
		this.twicePrem = twicePrem;
	}
	public String getBusiId() {
		return busiId;
	}
	public void setBusiId(String busiId) {
		this.busiId = busiId;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
//	public String getBaleId() {
//		return baleId;
//	}
//	public void setBaleId(String baleId) {
//		this.baleId = baleId;
//	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public boolean isJson() {
		return isJson;
	}
	public void setJson(boolean isJson) {
		this.isJson = isJson;
	}
	public String getRequestMsg() {
		return requestMsg;
	}
	public void setRequestMsg(String requestMsg) {
		this.requestMsg = requestMsg;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Document getXmlDoc() {
		return xmlDoc;
	}
	public void setXmlDoc(Document xmlDoc) {
		this.xmlDoc = xmlDoc;
	}
	
	public IspApplyVehicle getApplyVehicle() {
		return applyVehicle;
	}
	
	public void setApplyVehicle(IspApplyVehicle applyVehicle) {
		this.applyVehicle = applyVehicle;
	}

	public IpayRegister getPayRegister() {
		return payRegister;
	}


	public void setPayRegister(IpayRegister payRegister) {
		this.payRegister = payRegister;
	}
	public IpayBill getBill() {
		return bill;
	}
	
	public void setBill(IpayBill bill) {
		this.bill = bill;
	}
	public IpayPay getPay() {
		return pay;
	}

	public void setPay(IpayPay pay) {
		this.pay = pay;
	}
	public IpayRenew getPayRenew() {
		return payRenew;
	}

	public void setPayRenew(IpayRenew payRenew) {
		this.payRenew = payRenew;
	}

	public List<IpayBillGoods> getBillGoodList() {
		return billGoodList;
	}

	public void setBillGoodList(List<IpayBillGoods> billGoodList) {
		this.billGoodList = billGoodList;
	}
	public IspYangLaoTrans getYangLaoTrans() {
		return yangLaoTrans;
	}

	public void setYangLaoTrans(IspYangLaoTrans yangLaoTrans) {
		this.yangLaoTrans = yangLaoTrans;
	}
	public IspApply getApply() {
		return apply;
	}
	public void setApply(IspApply apply) {
		this.apply = apply;
	}
	public boolean isBatch() {
		return isBatch;
	}
	public void setBatch(boolean isBatch) {
		this.isBatch = isBatch;
	}
	public IspPolicy getPolicy() {
		return policy;
	}
	public void setPolicy(IspPolicy policy) {
		this.policy = policy;
	}
	public IspRenewApply getRenewApply() {
		return renewApply;
	}
	public void setRenewApply(IspRenewApply renewApply) {
		this.renewApply = renewApply;
	}
	public RequestDTO getRequestDTO() {
		return requestDTO;
	}
	public void setRequestDTO(RequestDTO requestDTO) {
		this.requestDTO = requestDTO;
	}
	public ResponseDTO getResponseDTO() {
		return responseDTO;
	}
	public void setResponseDTO(ResponseDTO responseDTO) {
		this.responseDTO = responseDTO;
	}
	
	
}

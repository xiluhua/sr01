package com.taiping.dianshang.outer.service;

import com.taiping.framework.bean.MailAttachment;
import com.taiping.framework.bean.MailMessageBean;

public interface MailNotifyService extends OuterService{
	
	public MailMessageBean initMailMessageBean(String serviceId);
	/**
	 * @param realNameAndSex	姓名与性别
	 * @param policyNo	保单号
	 * @param insuredName	被保人
	 * @return
	 */
	public String getContent(String blueName,String realName,String policyNo,String insuredName);
	
	/**
	 * 得到邮件的附件
	 * @param path 附件路径
	 * @param fileName 附件名称
	 * @return
	 */
	public MailAttachment getAttachment(String path,String fileName);
}

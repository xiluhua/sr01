package com.taiping.dianshang.outer.service.impl.checkBillCallback;

import java.io.IOException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspApplySpecialDao;
import com.taiping.dianshang.dao.IspKeyDao;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspApplySpecial;
import com.taiping.dianshang.entity.IspCheckBillCallback;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.outer.DTO.callback.baidu.Apply;
import com.taiping.dianshang.outer.DTO.callback.baidu.Holder;
import com.taiping.dianshang.outer.DTO.callback.baidu.Insured;
import com.taiping.dianshang.outer.DTO.callback.baidu.Message;
import com.taiping.dianshang.outer.DTO.callback.baidu.PolicyDetail;
import com.taiping.dianshang.outer.DTO.callback.baidu.response.ResponseCallbackBaiduDTO;
import com.taiping.dianshang.outer.service.CheckBillCallbackService;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.dianshang.outer.service.impl.shortMsg.ShortMsgImpl_ERR_COMMON;
import com.taiping.dianshang.service.httpclient.impl.HttpclientImpl;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.RsaUtil;

/**
 * 支付回调
 * @author xilh
 * @since 2017-06-29
 */
@Service
@Transactional
public class CheckBillCallback36Impl implements CheckBillCallbackService{

	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	BusinesslogService businesslogService;
	@Resource
	SignService signService;
	@Resource
	IspKeyDao ispKeyDao;
	@Resource
	IspApplySpecialDao ispApplySpecialDao;
	
	@Override
	public void handle(Map<String, Object> paramsMap) {
		String partnerBillId = MapTool.getStringFromMap(paramsMap, ConstantTool.OPERATE_NO);
		String errorMsg = "";
		Integer operateStatus = 1;
		
		// 首期
		IspApply apply = ispApplyDao.loadApply(partnerBillId, null, null, null);
		
		if (apply == null) {
			errorMsg = "无对应投保信息，流水号："+partnerBillId;
			LogTool.error(this.getClass(), errorMsg);
			operateStatus = 3;
			// 失败日志，便于排查
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.CHECKBILL_CALLBACK, operateStatus, 1);
			return;
		}
		
		// add by xiluhua 20171201 for partners
		IspCheckBillCallback checkBillCallback = CacheContainer.getByIdFromCache(apply.getPartnerId(), IspCheckBillCallback.class);
		
		System.out.println();
		if (checkBillCallback == null) {
			errorMsg = "checkBillCallback is null: "+apply.getPartnerId();
			LogTool.error(this.getClass(), errorMsg);
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.CHECKBILL_CALLBACK, operateStatus, 1);
			return;
		}
		// 生成回调报文
		String requestXml = this.objectToXml(apply);
		System.out.println("CheckBillCallback36Impl requestXml: "+requestXml);
		
		String url 		  = this.getUrlByEnv(checkBillCallback,apply);
		
		LogTool.debug(this.getClass(), "CheckBillCallbackImpl url: "+url);
		// 日志（请求）
		businesslogService.postBusinessOpelog_1(apply,url + System.getProperty("line.separator")+requestXml, ConstantTool.CHECKBILL_CALLBACK, 1, 1);
		
		// add by xiluhua 20171201 mock only
		if (LogTool.isFormal && apply.getPartnerApplyId().indexOf("TEST") > -1) {
			LogTool.debug(this.getClass(), "attention!!! mock only: "+apply.getPartnerApplyId());
			// 日志（返回）
			businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ "mock only: "+apply.getPartnerApplyId(), ConstantTool.CHECKBILL_CALLBACK, 2, 1);
			return;
		}
		
		// 回调
		String responseXml = this.callback(url,requestXml,partnerBillId);
		// 报文转对象
		ResponseCallbackBaiduDTO responseDTO = this.xmlToObject(responseXml, partnerBillId);
		
		boolean isSuccess = (responseDTO != null && responseDTO.getHead().getResponseCode().equals("000000"));
		if (!isSuccess) {
			LogTool.info(this.getClass(), paramsMap.toString());
			operateStatus = 0;
			Integer count = MapTool.getIntegerFromMap(paramsMap, ConstantTool.COUNT);
			if (count != null) {
				count++;
			}else {
				count = 1;
			}
			paramsMap.put(ConstantTool.COUNT, count);
			
			// 回调失败短信通知,模板id:2
			if (count > 30) {
				paramsMap.put(ConstantTool.SHORTMSG_TEMP_ID, 2);
				paramsMap.put(ConstantTool.SERVICE_ID, ShortMsgImpl_ERR_COMMON.class.getSimpleName());
				JedisClient_outer2.rpush(ConstantTool.QUEUE_SHORTMSG, JsonTool.toJson(paramsMap));
			}else {
				// 15分钟后再次执行
				paramsMap.put(ConstantTool.NEXT_CALLBACK_TIME, DateTool.add(new Date(), Calendar.MINUTE, 15));
				this.rpush(paramsMap);
			}
		}
		
		// 日志（返回）
		businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ responseXml, ConstantTool.CHECKBILL_CALLBACK, operateStatus, 1);
	}

	private String getUrlByEnv(IspCheckBillCallback checkBillCallback, IspApply apply) {
		String url = checkBillCallback.getProxyUrl();
		// 是测试单的话，调用测试地址
		if (LogTool.isLocal) {
			url = PropertyFileTool.get("checkBill.callback.36.local");
			LogTool.info(this.getClass(), "LOCAL: "+apply.getPartnerApplyId());
		}
		if (LogTool.isUat) {
			
			if (ispKeyDao.getIspKey(36l) == null) {
				LogTool.debug(this.getClass(), "inner test!!!");
				// 内部测试
				url = PropertyFileTool.get("checkBill.callback.36.uat");
			}
			LogTool.info(this.getClass(), "UAT: "+apply.getPartnerApplyId());
		}
		if (LogTool.isFormal) {
			LogTool.info(this.getClass(), "FORMAL: "+apply.getPartnerApplyId());
		}

		return url;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String objectToXml(IspApply apply){
		Message message = new Message();
		PolicyDetail policyDetail = new PolicyDetail();
		Apply apply2 = policyDetail.getApply();
		Holder holder2 = policyDetail.getHolder();
		Insured insured2 = new Insured();
		List<Insured> InsuredList = policyDetail.getInsuredList();
		message.getBody().getPolicyList().add(policyDetail);
		InsuredList.add(insured2);
		// 1. apply
		if (apply.getAcceptTime() != null) {
			apply2.setAcceptTime(DateTool.convertDataToString(apply.getAcceptTime(), "yyyyMMddHHmmss"));
		}
		if (!StringUtils.isEmpty(apply.getAppNo())) {
			apply2.setApplicationNo(apply.getAppNo());
		}
		IspApplySpecial special = ispApplySpecialDao.getApplySpecial(apply.getApplyId());
		if (special!= null && !StringUtils.isEmpty(special.getSpecial2())) {
			apply2.setApplyNo(special.getSpecial2());
		}
		if (apply.getExpirationDate() != null) {
			apply2.setExpireDate(DateTool.convertDataToString(apply.getExpirationDate(), "yyyyMMdd"));
		}
		
		// 电商： 5.self.本人|1.mate.配偶|2.child.子女|3.parent.父母 
		// 百度：1本人u其它v配偶w子女x父母
		
		if (apply.getRHolderInst() != null) {
			if (apply.getRHolderInst() == 5) {
				insured2.setInsuredRela(String.valueOf(1));
			}else if (apply.getRHolderInst() == 1) {
				insured2.setInsuredRela("v");
			}else if (apply.getRHolderInst() == 2) {
				insured2.setInsuredRela("w");
			}else if (apply.getRHolderInst() == 3) {
				insured2.setInsuredRela("x");
			}else {
				insured2.setInsuredRela("u");
			}
		}
		
		Double premium = apply.getPremium();
		String premiumStr = null;
		if (premium != null) {
			premiumStr = new DecimalFormat("0.00").format(premium);
			apply2.setPremium(premiumStr);
			apply2.setPayAmount(premiumStr);
		}else {
			apply2.setPremium("0.00");
			apply2.setPayAmount("0.00");
		}
		
		Integer amount = apply.getAmount();
		String amountStr = null;
		if (amount != null) {
			amountStr = new DecimalFormat("0.00").format(amount);
			apply2.setPolicyAmount(amountStr);
		}else {
			apply2.setPolicyAmount("0.00");
		}
		
		if (!StringUtils.isEmpty(apply.getPolicyNo())) {
			apply2.setPolicyNo(apply.getPolicyNo());
		}
		String status = String.valueOf(this.getStatus(apply.getCheckStatus(), apply.getPayStatus(), apply.getCheckBillStatus()));
		apply2.setStatus(status);
		
		if (apply.getUnit() == null || apply.getUnit() == 0) {
			apply.setUnit(1);
		}
		apply2.setUnit(String.valueOf(apply.getUnit()));
		
		if (apply.getValidateDate() != null) {
			apply2.setValidateDate(DateTool.convertDataToString(apply.getValidateDate(), "yyyyMMdd"));
		}
		
		// 2. holder
		// 百度：b身份证 c护照 d军中编号 f司机的驾照 g青少年证件 h出生证件 i其他 j港澳台护照 k港澳通行证
		// 电商：1.身份证|2.军人证|3.护照|4.出生证|9.其他  
		IspCustomer holder = apply.getHolder();
		if (!StringUtils.isEmpty(holder.getAddress())) {
			holder2.setAddress(holder.getAddress());
		}
		if (holder.getBirthday() != null) {
			holder2.setBirth(DateTool.convertDataToString(holder.getBirthday(), "yyyyMMdd"));
		}
		if (!StringUtils.isEmpty(holder.getIdNo())) {
			holder2.setCertNo(holder.getIdNo());
		}
		
		String responseTime = DateTool.convertDataToString(new Date(), "yyyyMMddHHmmss");
		message.getHead().setRequestTime(responseTime);
		
		if (holder.getIdType() != null) {
			if (holder.getIdType() == 1) {
				holder2.setCertType("b");
			}else if (holder.getIdType() == 2) {
				holder2.setCertType("d");
			}else if (holder.getIdType() == 3) {
				holder2.setCertType("c");
			}else if (holder.getIdType() == 4) {
				holder2.setCertType("h");
			}else if (holder.getIdType() == 9) {
				holder2.setCertType("i");
			}
		}
		
		if (!StringUtils.isEmpty(holder.getEmail())) {
			holder2.setEmail(holder.getEmail());
		}
		if (holder.getEndDate() != null) {
			holder2.setIdExpiry(DateTool.convertDataToString(holder.getEndDate(), "yyyyMMdd"));
		}
		if (!StringUtils.isEmpty(holder.getMobile())) {
			holder2.setMobile(holder.getMobile());
		}
		if (!StringUtils.isEmpty(holder.getCustName())) {
			holder2.setName(holder.getCustName());
		}
		if (holder.getGender() != null) {
			if (holder.getGender() == 1) {
				holder2.setSex("M");
			}else {
				holder2.setSex("F");
			}
		}
		if (holder.getPostCode() != null) {
			holder2.setZip(holder.getPostCode());
		}
		
		// 3. insured
		// 百度：b身份证 c护照 d军中编号 f司机的驾照 g青少年证件 h出生证件 i其他 j港澳台护照 k港澳通行证
		// 电商：1.身份证|2.军人证|3.护照|4.出生证|9.其他  
		IspCustomer insured = apply.getInsured();
		if (!StringUtils.isEmpty(insured.getAddress())) {
			insured2.setAddress(insured.getAddress());
		}
		if (insured.getBirthday() != null) {
			insured2.setBirth(DateTool.convertDataToString(insured.getBirthday(), "yyyyMMdd"));
		}
		if (!StringUtils.isEmpty(insured.getIdNo())) {
			insured2.setCertNo(insured.getIdNo());
		}
		if (insured.getIdType() != null) {
			if (insured.getIdType() == 1) {
				insured2.setCertType("b");
			}else if (insured.getIdType() == 2) {
				insured2.setCertType("d");
			}else if (insured.getIdType() == 3) {
				insured2.setCertType("c");
			}else if (insured.getIdType() == 4) {
				insured2.setCertType("h");
			}else if (insured.getIdType() == 9) {
				insured2.setCertType("i");
			}
		}
		if (!StringUtils.isEmpty(insured.getEmail())) {
			insured2.setEmail(insured.getEmail());
		}
		if (insured.getEndDate() != null) {
			insured2.setIdExpiry(DateTool.convertDataToString(insured.getEndDate(), "yyyyMMdd"));
		}
		if (!StringUtils.isEmpty(insured.getMobile())) {
			insured2.setMobile(insured.getMobile());
		}
		if (!StringUtils.isEmpty(insured.getCustName())) {
			insured2.setName(insured.getCustName());
		}
		if (insured.getGender() != null) {
			if (insured.getGender() == 1) {
				insured2.setSex("M");
			}else {
				insured2.setSex("F");
			}
		}
		if (!StringUtils.isEmpty(insured.getPostCode())) {
			insured2.setZip(insured.getPostCode());
		}
		
		String requestXml = null;

        try {
            // 将必要的字段加密
        	String mobile1 = message.getBody().getPolicyList().get(0).getHolder().getMobile();
        	if (!StringUtils.isEmpty(mobile1)) {
				message.getBody().getPolicyList().get(0).getHolder().setMobile(RsaUtil.encryptByPublicKey(mobile1));
			}
            
            String address1 = message.getBody().getPolicyList().get(0).getHolder().getAddress();
            if (!StringUtils.isEmpty(address1)) {
				message.getBody().getPolicyList().get(0).getHolder().setAddress(RsaUtil.encryptByPublicKey(address1));
			}
            
            String email1 = message.getBody().getPolicyList().get(0).getHolder().getEmail();
            if (!StringUtils.isEmpty(email1)) {
            	message.getBody().getPolicyList().get(0).getHolder().setEmail(RsaUtil.encryptByPublicKey(email1));
            }
            
            String certNo1 = message.getBody().getPolicyList().get(0).getHolder().getCertNo();
            if (!StringUtils.isEmpty(certNo1)) {
            	message.getBody().getPolicyList().get(0).getHolder().setCertNo(RsaUtil.encryptByPublicKey(certNo1));
            }
            
            String name1 = message.getBody().getPolicyList().get(0).getHolder().getName();
            if (!StringUtils.isEmpty(name1)) {
            	message.getBody().getPolicyList().get(0).getHolder().setName(RsaUtil.encryptByPublicKey(name1));
            }
            
            // insured
			for (Insured insured3 : message.getBody().getPolicyList().get(0).getInsuredList()) {
				String address3 = insured3.getAddress();
				if (!StringUtils.isEmpty(address3)) {
					insured3.setAddress(RsaUtil.encryptByPublicKey(address3));
				}
				
				String email3 = insured3.getEmail();
				if (!StringUtils.isEmpty(email3)) {
					insured3.setEmail(RsaUtil.encryptByPublicKey(email3));
				}
				
				String certNo3 = insured3.getCertNo();
				if (!StringUtils.isEmpty(certNo3)) {
					insured3.setCertNo(RsaUtil.encryptByPublicKey(certNo3));
				}
				
				String name3 = insured3.getName();
				if (!StringUtils.isEmpty(name3)) {
					insured3.setName(RsaUtil.encryptByPublicKey(name3));
				}
				
				String mobile3 = insured3.getMobile();
				if (!StringUtils.isEmpty(mobile3)) {
					insured3.setMobile(RsaUtil.encryptByPublicKey(mobile3));
				}
			}
        } catch (Exception e) {
            LogTool.error(this.getClass(), e);
        }

		Map sortMap = RsaUtil.getSortMap("Message", message, new HashMap());
		String signString = RsaUtil.map2SortedStr(sortMap);
		System.out.println(signString);
		String sign = RsaUtil.sign(signString, PropertyFileTool.get("priKey.baidu.tpds"));
		message.getBody().setSign(sign);
		try {
			requestXml = JAXBTool.marshal(message,ConstantTool.UTF8);
		} catch (Exception e) {
            LogTool.error(this.getClass(), e);
		}
		
		return requestXml;
	}
	
	public String callback(String url,String requestXml,String partnerBillId){
		String responseXml = "";
		try {
			LogTool.debug(this.getClass(), "pay callback url: "+url);
			LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
			responseXml = this.post(url, requestXml, ConstantTool.UTF8,ConstantTool.TEXT_XML);
			
			LogTool.debug(this.getClass(), responseXml);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
		
		return responseXml;
	}
	
	public ResponseCallbackBaiduDTO xmlToObject(String responseXml,String partnerBillId){
		ResponseCallbackBaiduDTO responseDTO = null;
		if (responseXml != null) {
			try {
				responseXml = URLDecoder.decode(responseXml, ConstantTool.UTF8);
				LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
				LogTool.debug(this.getClass(), responseXml);
				responseDTO = (ResponseCallbackBaiduDTO)JAXBTool.unmarshal(responseXml, ResponseCallbackBaiduDTO.class);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
		return responseDTO;
	}
	
	public void rpush(Map<String, Object> paramsMap){
		if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
			// 本地 localhost
			JedisClient_outer2.rpush(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY_LOCAL, JsonTool.toJson(paramsMap));
		}else {
			JedisClient_outer2.rpush(ConstantTool.QUEUE_CHECKBILL_CALLBACK_RETRY, JsonTool.toJson(paramsMap));
		}
	}
	
	/**
     * 订单状态: 1待支付(核保成功)|6支付成功、承保成功返回支付成功|4承保失败
     * @param checkStatus
     * @param payStatus
     * @param checkBillStatus
     * @return
     * 代码	代码名称
		0	无记录
		1	核保通过（待支付）
		2	核保失败
		3	支付处理中
		4	承保成功
		5	承保失败
		6	退保成功
     */
    public int getStatus(Integer checkStatus,Integer payStatus,Integer checkBillStatus){
    	if (checkStatus == null) {
			checkStatus = 0;
		}
		if (checkBillStatus == null) {
			checkBillStatus = 0;
		}
		if (payStatus == null) {
			payStatus = 0;
		}
		
    	if (checkStatus != 1 && payStatus != 1 && checkBillStatus != 1) {
    		return 2;
    	}
    	if (checkStatus == 1 && (payStatus != 1 && checkBillStatus != 1)) {
    		return 1;
		}
    	
    	if (payStatus == 1 && checkBillStatus != 1) {
    		return 3;
    	}
    	
    	if (checkBillStatus == 1) {
    		return 4;
		}
    	if (checkBillStatus == 2) {
    		return 5;
		}
    	return 0;
    }
    
    
    
    /**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content, String encode,String contentType) throws Exception {
		String trans = "";
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, ConstantTool.UTF8);
		httpPost.setRequestHeader("Content-Type", contentType);  
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(60000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				trans = map.get("trans");
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), ConstantTool.UTF8));
					index++;
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				if (content != null) {
//					int length = content.toString().length();
//					System.out.println(length);
//					httpPost.setRequestHeader("Content-Length", String.valueOf(length+12));  
				}
				httpPost.setRequestEntity(new StringRequestEntity((String)content,contentType, encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			String[] arr = {trans,String.valueOf(statusCode)};
			LogTool.info(this.getClass(),"======================================================= ");
			LogTool.info(HttpclientImpl.class,"trans:{},statusCode:{}",arr);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}
}

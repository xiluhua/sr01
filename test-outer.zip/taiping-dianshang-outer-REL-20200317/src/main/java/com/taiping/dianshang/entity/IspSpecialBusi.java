package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**   
 * @ClassName IspSpecialBusi   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_SPECIAL_BUSI")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspSpecialBusi implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1710666426151570443L;
	@Id
	@Column(name="BLUE_ID")
	private Long blueId;
	@Column(name="VALIDATOR_SERVICE_ARRAY")
	private String validatorServiceArray;
	@Column(name="PERSIST_SERVICE_ARRAY")
	private String persistServiceArray;
	@Column(name="STATUS")
	private int status;
	
	public IspSpecialBusi() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getBlueId() {
		return blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	public String getValidatorServiceArray() {
		return validatorServiceArray;
	}

	public void setValidatorServiceArray(String validatorServiceArray) {
		this.validatorServiceArray = validatorServiceArray;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getPersistServiceArray() {
		return persistServiceArray;
	}

	public void setPersistServiceArray(String persistServiceArray) {
		this.persistServiceArray = persistServiceArray;
	}
	
}





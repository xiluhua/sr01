/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.dianshang.outer.DTO.callback.baidu;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by tianhuang on 17/12/18.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
        "Head",
        "Body"
})
@XmlRootElement(name = "Message")
public class Message {
    @XmlElement(name = "Head")
    private Head Head = new Head();
    @XmlElement(name = "Body")
    private Body Body = new Body();

    public Body getBody() {
        return Body;
    }

    public Head getHead() {
		return Head;
	}

	public void setHead(Head head) {
		Head = head;
	}

	public void setBody(Body body) {
        Body = body;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}

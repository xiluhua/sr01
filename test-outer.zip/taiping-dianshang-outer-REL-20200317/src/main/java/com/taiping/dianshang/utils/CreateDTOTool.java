package com.taiping.dianshang.utils;

import java.text.ParseException;

import javax.xml.bind.JAXBException;

public class CreateDTOTool {

	public static String create(int BUSSINESS_TYPE,String partnerApplyId,boolean isJson,int sellChannel) throws ParseException, JAXBException{
		String dateFormat = "yyyy-MM-dd HH:mm:ss";
		String coreDTOString = null;
		
		return null;
	}
	
	public static void main(String[] args) {
		System.out.println();
	}
}

/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.dianshang.outer.DTO.callback.baidu;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by tianhuang on 17/12/19.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
        "Apply",
        "Holder",
        "InsuredList"
})
public class PolicyDetail {

    @XmlElement(name = "Apply")
    private Apply Apply = new Apply();
    @XmlElement(name = "Holder")
    private Holder Holder = new Holder();
    @XmlElementWrapper(name="InsuredList")
    @XmlElement(name = "Insured")
    private List<Insured> InsuredList = new ArrayList<Insured>();

    public Apply getApply() {
        return Apply;
    }

    public void setApply(Apply apply) {
        Apply = apply;
    }

    public Holder getHolder() {
        return Holder;
    }

    public void setHolder(Holder holder) {
        Holder = holder;
    }


    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    public List<Insured> getInsuredList() {
        return InsuredList;
    }

    public void setInsuredList(List<Insured> insuredList) {
        InsuredList = insuredList;
    }
}

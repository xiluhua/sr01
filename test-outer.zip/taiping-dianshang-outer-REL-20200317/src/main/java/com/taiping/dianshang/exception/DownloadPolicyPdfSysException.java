package com.taiping.dianshang.exception;


public class DownloadPolicyPdfSysException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public DownloadPolicyPdfSysException(String msg){
		super(msg);
	}
	
	public DownloadPolicyPdfSysException(){
		super();
	}
}


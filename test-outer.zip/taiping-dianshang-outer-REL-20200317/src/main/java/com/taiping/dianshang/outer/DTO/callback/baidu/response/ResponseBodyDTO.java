package com.taiping.dianshang.outer.DTO.callback.baidu.response;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * @author xiluhua 
 * @since 2017-12-18
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
	    "downloadUrl"
})
public class ResponseBodyDTO {
	@XmlElement(name = "DownloadUrl")
	private String downloadUrl;			//电子保单下载地址

	public String getDownloadUrl() {
		return downloadUrl;
	}

	public void setDownloadUrl(String downloadUrl) {
		this.downloadUrl = downloadUrl;
	}
	
}

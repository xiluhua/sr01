package com.taiping.dianshang.outer.service;

import com.taiping.dianshang.entity.IspApply;

public interface IspApplyService{

	/**
	 * 加载投保信息
	 * @author xilh
	 * @since 20161207
	 * @return
	 */
	public IspApply loadApply(String partnerApplyId,String policyNo,String appno,Long applyId);
}

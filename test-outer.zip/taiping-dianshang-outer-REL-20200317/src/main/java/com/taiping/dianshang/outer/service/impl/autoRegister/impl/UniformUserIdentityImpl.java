package com.taiping.dianshang.outer.service.impl.autoRegister.impl;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.annotation.Resource;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;
import com.taiping.common.MD5Utils;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.impl.autoRegister.UniformUserIdentityService;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.ActivateUser;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.CNTPWebService;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.CNTPWebServiceImplDelegate;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.RegisterResult;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.UserInfo;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.UserRequest;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.UserResponse;
import com.taiping.dianshang.outer.service.impl.autoRegister.ws.UserSearchResponse;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;

@Component
public class UniformUserIdentityImpl implements UniformUserIdentityService{
	
	@Resource
	public BusinesslogService businesslogService;
	
	final static String SPACE = "FFFFFFFFFFFFFFFFFFFF";// 注意！！！根据文档精神：20个F表示为空（必填）
	/**
	 * 注册接口（该接口最初是为B2B2E开的，商城这边业务一直所以接着用）
	 * @param applyDTO
	 * @return
	 * @throws Exception 
	 */
	public String autoRegister(IspApply applyFinal,String keyWord){
		IspApply apply = new IspApply();
		BeanUtils.copyProperties(applyFinal, apply);
		LogTool.debug(this.getClass(),"=== autoRegister a ===\n"+ToStringBuilder.reflectionToString(apply));
		String uid = this.queryIsUserExist(apply, keyWord);
		
        if(StringUtils.isEmpty(uid)){
        	RegisterResult registerResult = this.register(apply,keyWord);
        	LogTool.debug(this.getClass(),"=== autoRegister b ===\n"+ToStringBuilder.reflectionToString(registerResult));
        	if (registerResult != null) {
        		uid = registerResult.getUserId();
			}
        }
        return uid;
	}
	
	/**
	 * 查询用户是否存在（该接口最初是为B2B2E开的，商城这边业务一直所以接着用）
	 * @param applyDTO
	 * @return
	 * @throws Exception 
	 */
	public String queryIsUserExist(IspApply apply,String keyWord){
		
		String serviceId = "";
		CNTPWebServiceImplDelegate webServiceImplDelegate = null;
		UserRequest userRequest = new UserRequest();
		UserSearchResponse userSearchResponse = null;
		String uid = "";
		String url = null;
		try {
			serviceId = CacheContainer.getSystemParameterValue(ConstantTool.UNIFORMUSERIDENTITY_SERVICEID);
			url = CacheContainer.getSystemParameterValueNoThrows("uniformUserIdentity.url");
			String requestId = getDesignedLengthRandom(6);
			CNTPWebService webService = new CNTPWebService();
			LogTool.debug(this.getClass(),"=== autoRegister c ===\n"+requestId);
			webServiceImplDelegate = webService.getCNTPWebService();
			
			userRequest.setRequestID(requestId);
			UserInfo userInfo = new UserInfo();
			
			if(StringUtils.defaultString(keyWord).contains("@")){
	            userInfo.setEmail(keyWord);
	            userInfo.setMobile(SPACE);	// 注意！！！根据文档精神：20个F表示为空（必填）
	        }else{
	            userInfo.setMobile(keyWord);
	            userInfo.setEmail(SPACE);
	        }
	        userInfo.setCenterId(SPACE);
	        userInfo.setUid(SPACE);
	        userInfo.setServiceId(serviceId);
			userRequest.setUserInfo(userInfo);
			
			String requestXml = userRequest.toString();
			LogTool.debug(this.getClass(),"=== autoRegister d ===\n"+requestXml);
			LogTool.debug(this.getClass(),"=== autoRegister e ===\n"+ToStringBuilder.reflectionToString(userInfo));
			
			businesslogService.postBusinessOpelog_1(apply, url+System.getProperty("line.separator")+requestXml, ConstantTool.INTERFACE_R_104_AUTO_REGI_QUERY, 1, 1);
			
			userSearchResponse = webServiceImplDelegate.selectUser(userRequest);
			if (userSearchResponse == null) {
				userSearchResponse = new UserSearchResponse();
				userSearchResponse.setReturnFlag(false);
				userSearchResponse.setReturnMessage("统一身份管理中心返回为空");
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			userSearchResponse = new UserSearchResponse();
			userSearchResponse.setReturnFlag(false);
			userSearchResponse.setReturnMessage("统一身份管理中心接口异常");
		} finally {
			int operateStatus = 2;
			if (userSearchResponse.isReturnFlag()) {
				operateStatus = 1;
				uid = userSearchResponse.getUserInfo().getUid();
			}
			String responseXml = userSearchResponse.toString();
			businesslogService.postBusinessOpelog_2(apply, url+System.getProperty("line.separator")+responseXml, ConstantTool.INTERFACE_R_104_AUTO_REGI_QUERY, operateStatus, 1);
		}
		
		return uid;
	}
	/**
	 * 注册
	 * @param keyWord
	 * @return
	 * @throws Exception 
	 */
	public RegisterResult register(IspApply apply,String keyWord){
		keyWord = StringUtils.defaultString(keyWord);
		String password = "tp" + getDesignedLengthRandom(6);
        ActivateUser activateUser = new ActivateUser();
        activateUser.setUserName(keyWord);
        activateUser.setPassword(password);
        RegisterResult registerResult  = null;
        registerResult = getRegisterResult(apply,activateUser);
		LogTool.debug(this.getClass(),"=== autoRegister f ===\n"+registerResult.getResponseBusinessCode());
		return registerResult;
	}
	
	/**
	 * 注册
	 * @param keyWord
	 * @return
	 * @throws Exception 
	 */
	public RegisterResult registerNew(IspApply apply,String keyWord){
		keyWord = StringUtils.defaultString(keyWord);
		String password = "tp" + getDesignedLengthRandom(6);
        ActivateUser activateUser = new ActivateUser();
        activateUser.setUserName(keyWord);
        activateUser.setPassword(password);
        RegisterResult registerResult  = null;
        registerResult = getRegisterResult(apply,activateUser);
		LogTool.debug(this.getClass(),"=== autoRegister f ===\n"+registerResult.getResponseBusinessCode());
		registerResult.setUserName(keyWord);
		registerResult.setPassword(password);
		return registerResult;
	}
	
	public String getDesignedLengthRandom(int length) {
		return String.valueOf(Math.random()).substring(2, length + 2);
	}
	
	/**
	 * @param args
	 */
	public RegisterResult getRegisterResult(IspApply apply,ActivateUser activateUser){
		String serviceId = "";
		String registerSource = "";
		UserResponse userResponse = null;
		String url = null;
		try {
			url = CacheContainer.getSystemParameterValueNoThrows("uniformUserIdentity.url");
//			serviceId = runtimeApi.getParameter("uniformUserIdentity.serviceId");
			serviceId = CacheContainer.getSystemParameterValue(ConstantTool.UNIFORMUSERIDENTITY_SERVICEID);
			// added by xiluhua 20170516 for 统一用户需求，朱焓
			registerSource = CacheContainer.getSystemParameterValue(ConstantTool.UNIFORMUSERIDENTITY_SOURCE);
		} catch (SystemParameterNotFoundException e) {
			LogTool.error(this.getClass(), e);
			LogTool.error(this.getClass(), "统一身份管理中心调用地址未配置,applyId:"+apply.getApplyId());
			return null;
		}
		
        RegisterResult registerResult = new RegisterResult();
        registerResult.setResponseBusinessCode("0");
        
        String requestId = getDesignedLengthRandom(6);
        CNTPWebService webService = new CNTPWebService();
        CNTPWebServiceImplDelegate webServiceImplDelegate = webService.getCNTPWebService();
        UserRequest userRequest = new UserRequest();
        userRequest.setRequestID(requestId);
        UserInfo userInfo = new UserInfo();
        userInfo.setRegisterSource(registerSource);
        String userName = activateUser.getUserName();
        String activateDate = getNowTime();
        if(userName.contains("@")){
            userInfo.setEmail(userName);
            userInfo.setOldEmail(userName);
            userInfo.setEmailActivateDate(activateDate);
            userInfo.setEmailActived("1");
        }else{
            userInfo.setMobile(userName);
            userInfo.setOldMobile(userName);
            userInfo.setMobileActivateDate(activateDate);
            userInfo.setMobileActived("1");
        }
        
		try {
			userInfo.setUserPassword(MD5Utils.encrypt(activateUser.getPassword()));
			userInfo.setServiceId(serviceId);
			userRequest.setUserInfo(userInfo);
			LogTool.debug(this.getClass(),"=== autoRegister h ===\n"+ToStringBuilder.reflectionToString(userInfo));

			String requestXml = userRequest.toString();
			businesslogService.postBusinessOpelog_1(apply, url+System.getProperty("line.separator")+requestXml, ConstantTool.INTERFACE_R_105_AUTO_REGI, 1, 1);
			
			userResponse = webServiceImplDelegate.registerUser(userRequest);
			if (userResponse == null) {
				userResponse = new UserResponse();
				userResponse.setReturnFlag(false);
				userResponse.setReturnMessage("统一身份管理中心返回为空");
				registerResult.setErrorMessage("统一身份管理中心返回为空");
			}
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			userResponse = new UserResponse();
			userResponse.setReturnFlag(false);
			userResponse.setReturnMessage("统一身份管理中心系统异常");
			registerResult.setErrorMessage("统一身份管理中心系统异常");
		} finally {
			int operateStatus = 2;
			if (userResponse.getReturnFlag()) {
				registerResult.setResponseBusinessCode("1");
				registerResult.setUserId(userResponse.getReturnMessage());
				registerResult.setResponseBusinessMessage(userResponse.getRequestID());
				operateStatus = 1;
			}
			String responseXml = userResponse.toString();
			businesslogService.postBusinessOpelog_2(apply, url+System.getProperty("line.separator")+responseXml, ConstantTool.INTERFACE_R_105_AUTO_REGI, operateStatus, 1);
		}
		
        return registerResult;
    }
	
	
	/**
	 * 注册
	 * @param keyWord
	 * @return
	 * @throws Exception 
	 */
	public RegisterResult register_test(String keyWord){
		
		String password = "tp" + getDesignedLengthRandom(6);
        ActivateUser activateUser = new ActivateUser();
        activateUser.setUserName(keyWord);
        activateUser.setPassword(password);
        RegisterResult registerResult  = null;
        registerResult = getRegisterResult_test(activateUser);
		LogTool.debug(this.getClass(),"=== autoRegister h ===\n"+registerResult.getResponseCode());
		return registerResult;
	}

	/**
	 * @param args
	 */
	public RegisterResult getRegisterResult_test(ActivateUser activateUser){
		
        RegisterResult registerResult = new RegisterResult();
        registerResult.setResponseBusinessCode("0");
        
        String requestId = getDesignedLengthRandom(6);
        CNTPWebService webService = new CNTPWebService();
        String url = "http://10.1.117.11:9080/CNTPWInterFace/CNTPWebService?wsdl";
		
        CNTPWebServiceImplDelegate webServiceImplDelegate = webService.getCNTPWebService(url);
        UserRequest userRequest = new UserRequest();
        userRequest.setRequestID(requestId);
        UserInfo userInfo = new UserInfo();
        String userName = activateUser.getUserName();
        String activateDate = getNowTime();
        if(userName.contains("@")){
            userInfo.setEmail(userName);
            userInfo.setOldEmail(userName);
            userInfo.setEmailActivateDate(activateDate);
            userInfo.setEmailActived("1");
        }else{
            userInfo.setMobile(userName);
            userInfo.setOldMobile(userName);
            userInfo.setMobileActivateDate(activateDate);
            userInfo.setMobileActived("1");
        }
        
		try {
			userInfo.setUserPassword(MD5Utils.encrypt(activateUser.getPassword()));
			userInfo.setServiceId("81AE02ED-3A41-85F6-7397-8046D797C642");
			userRequest.setUserInfo(userInfo);
			
			UserResponse userResponse = webServiceImplDelegate.registerUser(userRequest);

			if (userResponse == null) {
				registerResult.setErrorMessage("统一身份管理中心返回为空");
			}
			
			if (userResponse.getReturnFlag()) {
				registerResult.setResponseBusinessCode("1");
				registerResult.setUserId(userResponse.getReturnMessage());
				registerResult.setResponseBusinessMessage(userResponse.getRequestID());

			}
			
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			registerResult.setErrorMessage("统一身份管理中心系统异常");
		}
       
        return registerResult;
    }
	
//	public static void main(String[] args) {
//		String userName = "18616023701";
//		String uid = "";
//        String requestId = new UniformUserIdentityImpl().getDesignedLengthRandom(6);
//        CNTPWebService webService = new CNTPWebService();
//        CNTPWebServiceImplDelegate webServiceImplDelegate = webService.getCNTPWebService();
//        UserRequest userRequest = new UserRequest();
//        userRequest.setRequestID(requestId);
//        UserInfo userInfo = new UserInfo();
//        if(userName.contains("@")){
//            userInfo.setEmail(userName);
//            userInfo.setMobile(SPACE);	// 注意！！！根据文档精神：20个F表示为空（必填）
//        }else{
//            userInfo.setMobile(userName);
//            userInfo.setEmail(SPACE);
//        }
//        userInfo.setCenterId(SPACE);
//        userInfo.setUid(SPACE);
//        userInfo.setServiceId("0DCA3C94-C5D2-0DED-7686-49FD8293AF28");
//        userRequest.setUserInfo(userInfo);
//        UserSearchResponse userSearchResponse = webServiceImplDelegate.selectUser(userRequest);
//        if(userSearchResponse.isReturnFlag()){
//            uid = userSearchResponse.getUserInfo().getUid();
//            System.out.println("uid:"+uid);
//        }else {
//        	//register();
//		}
//	}
	
	public String getNowTime(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		return sdf.format(Calendar.getInstance().getTime());
	}
	
	
	public static void main(String[] args) {
		System.out.println(ToStringBuilder.reflectionToString(null).length());
		
//		String userName = "18616023701";
//		String uid = "";
//        String requestId = new UniformUserIdentityImpl().getDesignedLengthRandom(6);
//        CNTPWebService webService = new CNTPWebService();
//        String url = "";
//        url = "http://10.1.117.11:9080/CNTPWInterFace/CNTPWebService?wsdl";
////        url = "http://10.4.232.235:9080/CNTPWInterFace/CNTPWebService?wsdl";
//        CNTPWebServiceImplDelegate webServiceImplDelegate = webService.getCNTPWebService(url);
////        CNTPWebServiceImplDelegate webServiceImplDelegate = webService.getCNTPWebService();
//        UserRequest userRequest = new UserRequest();
//        userRequest.setRequestID(requestId);
//        UserInfo userInfo = new UserInfo();
//        if(userName.contains("@")){
//            userInfo.setEmail(userName);
//            userInfo.setMobile("FFFFFFFFFFFFFFFFFFFF");
//        }else{
//            userInfo.setMobile(userName);
//            userInfo.setEmail("FFFFFFFFFFFFFFFFFFFF");
//        }
//        userInfo.setCenterId("FFFFFFFFFFFFFFFFFFFF");
//        userInfo.setUid("FFFFFFFFFFFFFFFFFFFF");
//        userInfo.setServiceId("81AE02ED-3A41-85F6-7397-8046D797C642");
//        userRequest.setUserInfo(userInfo);
//        UserSearchResponse userSearchResponse = webServiceImplDelegate.selectUser(userRequest);
//        if(userSearchResponse.isReturnFlag()){
//            uid = userSearchResponse.getUserInfo().getUid();
//            System.out.println("uid:"+uid);
//        }else {
//        	new UniformUserIdentityImpl().register_test(userName);
//		}
//		

	}
}

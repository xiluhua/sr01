package com.taiping.dianshang.service.validSqlInject;


public interface AntiSqlInjectService {
	/**
	 * @param str  待验证的字符串
	 * @param reg  正则表达式
	 * @return
	 * @throws Exception 
	 */
	public void verify(String str);
}

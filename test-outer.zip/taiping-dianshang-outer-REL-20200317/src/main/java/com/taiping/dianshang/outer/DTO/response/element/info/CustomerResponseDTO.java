package com.taiping.dianshang.outer.DTO.response.element.info;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.facility.tool.DateTimeAdapter;

/**
 * @author xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
	    "custName",
	    "custType",
	    "gender",
	    "birthday",
	    "idType",
	    "idNo",
	    "occupCode",
	    "mobile",
	    "telephone",
	    "email",
	    "postCode",
	    "address",
})
public class CustomerResponseDTO {

	@XmlElement(name = "CUST_NAME")
    protected String custName;   		// 客户姓名
	@XmlElement(name = "CUST_TYPE")
    protected Integer custType;  		// 客户类型 在InsureConfig中定义 注：自助卡购买人同投保人*
	@XmlElement(name = "GENDER")
    protected Integer gender;    		// 性别 在InsureConfig中定义
	@XmlElement(name = "BIRTHDAY")
	@XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    protected Date birthday;     		// 出生日期
	@XmlElement(name = "ID_TYPE")
    protected Integer idType;    		// 证件类型
	@XmlElement(name = "ID_NO")
    protected String idNo;      		// 证件号
	@XmlElement(name = "OCCUP_CODE")
    protected String occupCode;  		// 职业代码
	@XmlElement(name = "MOBILE")
    protected String mobile;     		// 手机
	@XmlElement(name = "TELEPHONE")
    protected String telephone;  		// 固定电话
	@XmlElement(name = "EMAIL")
    protected String email;      		// 电子邮件
	@XmlElement(name = "POST_CODE")
    protected String postCode;   		// 邮政编码
	@XmlElement(name = "ADDRESS")
    protected String address;    		// 地址
	
	public CustomerResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public Integer getCustType() {
		return custType;
	}
	public void setCustType(Integer custType) {
		this.custType = custType;
	}
	public Integer getGender() {
		return gender;
	}
	public void setGender(Integer gender) {
		this.gender = gender;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public Integer getIdType() {
		return idType;
	}
	public void setIdType(Integer idType) {
		this.idType = idType;
	}
	public String getIdNo() {
		return idNo;
	}
	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}
	public String getOccupCode() {
		return occupCode;
	}
	public void setOccupCode(String occupCode) {
		this.occupCode = occupCode;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPostCode() {
		return postCode;
	}
	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	
	public CustomerResponseDTO(IspCustomer customer) {
		super();
		this.setAddress(customer.getAddress());
		this.setBirthday(customer.getBirthday());
		this.setCustName(customer.getCustName());
		this.setCustType(customer.getCustType());
		this.setEmail(customer.getEmail());
		this.setGender(customer.getGender());
		this.setIdNo(customer.getIdNo());
		this.setIdType(customer.getIdType());
		this.setMobile(customer.getMobile());
		this.setOccupCode(customer.getOccupCode());
		this.setPostCode(customer.getPostCode());
		this.setTelephone(customer.getTelephone());
	}

}

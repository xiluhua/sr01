package com.taiping.dianshang.outer.DTO.response.element;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.taiping.facility.tool.DateTimeAdapter;
/**
 * @author: xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"busiId",
		"serviceCode",
		"partnerId",
		"transTime",
		"isSuccess",
		"returnInfo",
		"returnCode"
})
public class ResponseBusinessDTO {
	@XmlElement(name = "BUSI_ID")
	private String busiId = "";
	@XmlElement(name = "SERVICE_CODE")
	private String serviceCode = "";
	@XmlElement(name = "PARTNER_ID")
	private Long partnerId;
	@XmlElement(name = "TRANS_TIME")
	@XmlJavaTypeAdapter(value = DateTimeAdapter.class)
	private Date transTime = new Date();
	@XmlElement(name = "IS_SUCCESS")
	protected boolean isSuccess = false;  	// 是否成功
	@XmlElement(name = "RETURN_INFO")
	protected String returnInfo = "";  		// 返回信息
	@XmlElement(name = "RETURN_CODE")
	protected String returnCode = ""; 		// 返回代码
	
	public Long getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public Date getTransTime() {
		return transTime;
	}

	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}
	public boolean isSuccess() {
		return isSuccess;
	}

	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}

	public String getReturnInfo() {
		return returnInfo;
	}

	public void setReturnInfo(String returnInfo) {
		this.returnInfo = returnInfo;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public ResponseBusinessDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getBusiId() {
		return busiId;
	}

	public void setBusiId(String busiId) {
		this.busiId = busiId;
	}

	
}

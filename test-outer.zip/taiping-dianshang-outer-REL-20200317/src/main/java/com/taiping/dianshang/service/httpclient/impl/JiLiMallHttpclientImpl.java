package com.taiping.dianshang.service.httpclient.impl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.taiping.dianshang.outer.DTO.callback.jiLiMall.ReturnData;
import com.taiping.dianshang.service.httpclient.JiLiMallHttpclientService;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;

@Service
public class JiLiMallHttpclientImpl implements JiLiMallHttpclientService {

	@Override
	public String post(String url, Map<String, String> params) {
		HttpURLConnection conn = null;
		String responseMsg  = "";
		OutputStream out 	= null;
		InputStream in 	 	= null;
		try {
			if (LogTool.isLocal) {
				System.setProperty("http.proxyHost", "10.4.233.50");
				System.setProperty("http.proxyPort", "31151");
				System.setProperty("http.proxyUserName", "xilh");
				System.setProperty("http.proxyPassword", "Itaiping123");
			}

			URL uri = new URL(url);
			conn = (HttpURLConnection) uri.openConnection();
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			// 是否输入参数
			conn.setDoInput(true);
			conn.setDoOutput(true);
			String param = this.getRequestMsg(params);
			System.out.println("调用接口URL---------------------" + url + "?"+ param);
			byte[] bytes = param.toString().getBytes();
			out = conn.getOutputStream();
			out.write(bytes);// 输入参数
			in = conn.getInputStream();
			responseMsg = this.convertStreamToString(in);
			System.out.println("接口返回信息---------------------" + responseMsg);
			
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
				if (conn != null) {
					conn.disconnect();
				}
			} catch (IOException e) {
				LogTool.error(this.getClass(), e);
			}
		}
		return responseMsg;
	}

	public String getRequestMsg(Map<String, String> params) {
		String param = "";
		int i = 0;
		if (params != null && !params.isEmpty()) {
			for (String key : params.keySet()) {
				if (i == 0) {
					param = param + key + "=" + params.get(key);
				} else {
					param = param + "&" + key + "=" + params.get(key);
				}
				i++;
			}
		}
		return param;
	}

	private String convertStreamToString(InputStream in) throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(in, "utf-8"));
		StringBuffer resBuffer = new StringBuffer();
		String resTemp = "";
		while ((resTemp = br.readLine()) != null)
		{
			resBuffer.append(resTemp);
		}
		return resBuffer.toString();
	}


	public String callback(String url,Map<String, String> params,String partnerBillId){
		String responseXml = "";
		try {
			LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
			responseXml = this.postByProxy(url, params);
			LogTool.debug(this.getClass(), responseXml);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
		
		return responseXml;
	}
	
	public ReturnData xmlToObject(String responseXml,String partnerBillId){
		ReturnData returnData  = null;
		if (responseXml != null) {
			try {
				LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
				LogTool.debug(this.getClass(), responseXml);
				returnData = (ReturnData) JsonTool.toObject(responseXml, ReturnData.class, DateTool.DATE_TIME_MASK);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
		return returnData;
	}
	
	@Override
	public String postByProxy(String url, Map<String, String> params) {
		HttpURLConnection conn = null;
		String responseMsg  = "";
		OutputStream out 	= null;
		InputStream in 	 	= null;
		try {
			if (LogTool.isLocal) {
				System.setProperty("http.proxyHost", "10.4.233.50");
				System.setProperty("http.proxyPort", "31151");
				System.setProperty("http.proxyUserName", "xilh");
				System.setProperty("http.proxyPassword", "Itaiping123");
			}

			URL uri = new URL(url);
			conn = (HttpURLConnection) uri.openConnection(HttpclientTool.getProxy());
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
			// 是否输入参数
			conn.setDoInput(true);
			conn.setDoOutput(true);
			String param = this.getRequestMsg(params);
			System.out.println("调用接口URL---------------------" + url + "?"+ param);
			byte[] bytes = param.toString().getBytes();
			out = conn.getOutputStream();
			out.write(bytes);// 输入参数
			in = conn.getInputStream();
			responseMsg = this.convertStreamToString(in);
			System.out.println("接口返回信息---------------------" + responseMsg);
			
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally {
			try {
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
				if (conn != null) {
					conn.disconnect();
				}
			} catch (IOException e) {
				LogTool.error(this.getClass(), e);
			}
		}
		return responseMsg;
	}
}

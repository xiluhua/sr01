/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.dianshang.outer.DTO.callback.baidu;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlType;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * Created by tianhuang on 17/12/18.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
        "PolicyList",
        "Sign"
})
public class Body {

    @XmlElementWrapper(name="PolicyList")
    @XmlElement(name = "PolicyDetail")
    private List<PolicyDetail> PolicyList = new ArrayList<PolicyDetail>();

    @XmlElement(name = "Sign")
    private String Sign;

    public List<PolicyDetail> getPolicyList() {
        return PolicyList;
    }

    public void setPolicyList(List<PolicyDetail> policyList) {
        PolicyList = policyList;
    }

    public String getSign() {
        return Sign;
    }

    public void setSign(String sign) {
        Sign = sign;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}

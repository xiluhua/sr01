package com.taiping.dianshang.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

@Entity
@Table(name = "ISP_APPLY_JILI_MALL")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspApplyJiLiMall implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -350791378488887403L;
	@Id
	@Column(name = "APPLY_ID", nullable = false, precision = 10, scale = 0)
	private Long applyId;
	@Column(name="COMCODE")
	private String comCode;
	@Column(name = "COMPANY")
	private String company;
	@Column(name = "ORDER_NO")
	private String orderNo;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_TIME")
	private Date createTime;
    @Column(name = "PARTNER_APPLY_ID", length = 50)
    private String partnerApplyId;
    
    public String getPartnerApplyId() {
		return partnerApplyId;
	}

	public void setPartnerApplyId(String partnerApplyId) {
		this.partnerApplyId = partnerApplyId;
	}
    public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

    // Property accessors
    public Long getApplyId() {
        return this.applyId;
    }
	public String getComCode() {
		return comCode;
	}
	public void setComCode(String comCode) {
		this.comCode = comCode;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public IspApplyJiLiMall() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

package com.taiping.dianshang.outer.service3;

import java.util.Map;

import com.taiping.dianshang.entity.IspHttpclientParams;
import com.taiping.dianshang.entity.IspRmi;
import com.taiping.dianshang.model.Busi;

public interface CoreService {
	public void handleCore(Busi busi)throws Exception;
	/**
	 * 对象转报文
	 * @param request
	 * @return
	 */
	public String objectToXml(Busi busi, IspRmi rmi) throws Exception;
	
	/**
	 * 发送请求到核心
	 * @param requestXml
	 * @param url
	 * @param params
	 * @return
	 */
	public String sendMsgToCore(IspRmi rmi, IspHttpclientParams httpclientParams, Map<String, String> paramsMap) throws Exception;
	
	/**
	 * 返回报文转对象
	 * @param responseXml
	 * @return
	 */
	public void xmlToObject(Busi busi, String responseXml) throws Exception;
	
	/**
	 * 根据核心返回结果更新业务信息
	 * @param response
	 * @param apply
	 */
	public void updateAfterCoreBusiness(Busi busi) throws Exception;
}

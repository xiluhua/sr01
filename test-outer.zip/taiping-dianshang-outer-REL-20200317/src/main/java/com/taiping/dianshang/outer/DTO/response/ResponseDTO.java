package com.taiping.dianshang.outer.DTO.response;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.model.Busi;
import com.taiping.dianshang.outer.DTO.response.element.ResponseBusinessDTO;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;

/**
 * 报文返回对象基类
 * @author xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"business"
})
@XmlRootElement(name = "RESPONSE")
public class ResponseDTO {
	@XmlElement(name = "BUSINESS")
	protected ResponseBusinessDTO business = new ResponseBusinessDTO();
	
	public ResponseBusinessDTO getBusiness() {
		return business;
	}

	public void setBusiness(ResponseBusinessDTO business) {
		this.business = business;
	}

	public ResponseDTO() {
		super();
	}
	
	public ResponseDTO(Busi busi) {
		super();
	}
	
	public String getResponseMsgFromDTO(boolean isJson){
		String responseMsg = null;
		try {
			if (isJson) {
				responseMsg = JsonTool.toJson(this, DateTool.DATE_TIME_MASK);
			}else {
				responseMsg = JAXBTool.marshal(this);
			}
			
			LogTool.debug(this.getClass(), responseMsg,true);
		} catch (Exception e2) {
			LogTool.error(this.getClass(), e2);
			return null;
		}
		
		return responseMsg;
	}
	
	public String getResponseMsgFromDTO(Busi busi){
		String responseMsg = null;
		this.getBusiness().setBusiId(busi.getBusiId());
		this.getBusiness().setServiceCode(busi.getServiceCode());
		this.getBusiness().setPartnerId(busi.getPartnerId());
		this.getBusiness().setTransTime(new Date());

		try {
			if (busi.isJson()) {
				responseMsg = JsonTool.toJson(this, DateTool.DATE_TIME_MASK);
			}else {
				responseMsg = JAXBTool.marshal(this);
			}
		} catch (Exception e2) {
			e2.printStackTrace();
			return null;
		}
		
		return responseMsg;
	}
	
	public String getResponseMsgFromDTOEnbase64(boolean isJson){
		String responseMsg = this.getResponseMsgFromDTO(isJson);
		
		return Base64Tool.encode(responseMsg, ConstantTool.UTF8);
	}
	
}

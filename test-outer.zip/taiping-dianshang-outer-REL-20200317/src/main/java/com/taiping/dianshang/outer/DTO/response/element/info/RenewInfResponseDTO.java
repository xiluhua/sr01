package com.taiping.dianshang.outer.DTO.response.element.info;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.taiping.facility.tool.DateTimeAdapter;

/**
 * @author xiluhua by 20180825
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
	    "canRenew",
	    "nextRenewDate"
})
public class RenewInfResponseDTO {
    @XmlElement(name = "CAN_RENEW")
	private int canRenew = 0; 			// 是否可续期
    @XmlElement(name = "NEXT_RENEW_DATE")
    @XmlJavaTypeAdapter(value = DateTimeAdapter.class)
    private Date nextRenewDate; 		// 下次续期日期

    public RenewInfResponseDTO() {
		super();
	}

	public int getCanRenew() {
		return canRenew;
	}

	public void setCanRenew(int canRenew) {
		this.canRenew = canRenew;
	}

	public Date getNextRenewDate() {
		return nextRenewDate;
	}

	public void setNextRenewDate(Date nextRenewDate) {
		this.nextRenewDate = nextRenewDate;
	}

}

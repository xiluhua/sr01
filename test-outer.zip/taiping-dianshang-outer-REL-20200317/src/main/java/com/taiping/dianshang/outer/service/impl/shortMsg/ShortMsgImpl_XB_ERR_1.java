package com.taiping.dianshang.outer.service.impl.shortMsg;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.velocity.VelocityContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSON;
import com.cntaiping.sms.net.rmi.TPSmsMessages;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.ImsAdministratorShortmsgDao;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspSendHistoryDao;
import com.taiping.dianshang.dao.IspSequenceDao;
import com.taiping.dianshang.entity.ImsAdministratorShortmsg;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprint;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.dianshang.outer.service.ShortMsgService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.facility.tool.TemplateToolV1218;

@Service
public class ShortMsgImpl_XB_ERR_1 extends ShortMsgImpl implements ShortMsgService{

	@Resource
	IspSequenceDao ispSequenceDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IspSendHistoryDao ispSendHistoryDao;
	@Resource
	ImsAdministratorShortmsgDao imsAdministratorShortmsgDao;
	
	@Override
	@Transactional
	public void handle(Map<String, Object> shortMsgParamMap) {
		
		try {
			IspBlueprint blueprint = null;
			String wxhome = CacheContainer.getSystemParameterValue(ConstantTool.WXHOME);
			shortMsgParamMap.put("wxhome", wxhome);
		
			// 1,获取短信主键.唯一
			Long shortMsgId = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_IIP_SM_SEND_LIST);
			if (shortMsgId == null) {
				LogTool.error(this.getClass(), "ShortmsgHandler : failed to get shortMsgId,please check its sequence!" , shortMsgParamMap.get(ConstantTool.SERVICE_ID)+":"+shortMsgParamMap.get("shortMsgContent"));
				return;
			}
			shortMsgParamMap.put("shortMsgId", String.valueOf(shortMsgId));
			// 保单号
	        String partnerApplyId = MapTool.getStringFromMap(shortMsgParamMap,"operateNo");
	        
	        LogTool.info(this.getClass(), "partnerApplyId :"+partnerApplyId,true);
	        
	        IspApply apply = ispApplyDao.loadApply(partnerApplyId,null,null,null);
			if (apply != null) {
				blueprint = CacheContainer.getByIdFromCacheThrows(apply.getBlueId(), IspBlueprint.class);
			}else {
				LogTool.error(this.getClass(),"短信发送失败,加载 apply 失败:"+StringUtils.defaultString(partnerApplyId));
				return;
			}
			
			// update: rm by xiluhua 20190814
//			Map<Object, ImsAdministratorShortmsg> map = (Map<Object, ImsAdministratorShortmsg>)CacheContainer.getListByIdFromCache(ImsAdministratorShortmsg.class);
//			for (Map.Entry<Object, ImsAdministratorShortmsg> entry : map.entrySet()) {
//	            LogTool.debug(this.getClass(), entry.getKey() + "--->" + entry.getValue());
//	            if (entry.getValue().getService().equalsIgnoreCase(this.getClass().getSimpleName())) {
//	            	shortMsgParamMap.put("mobile", entry.getValue().getMobile());
//	    			shortMsgParamMap.put("blueName", blueprint.getBlueInnerName());
//	    			apply.setInsuranceType(blueprint.getInsuranceType());
//	    			
//	    			// 2,构造短信内容
//	    			String shortMsgContent = this.getContent(shortMsgParamMap,apply);
//	    			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
//	    			// 3,构造短信对象
//	    			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
//	    			
//	    			//4,启动后台线程，发送短信
//	    			super.send(shortMsg, apply);
//				}
//			}
			
			// update: add by xiluhua 20190814
			List<ImsAdministratorShortmsg> list = imsAdministratorShortmsgDao.getAll();
			for (ImsAdministratorShortmsg imsAdministratorShortmsg : list) {
				LogTool.debug(this.getClass(), JSON.toJSONString(imsAdministratorShortmsg));
				
	            if (imsAdministratorShortmsg.getService().equalsIgnoreCase(this.getClass().getSimpleName())) {
	            	LogTool.info(this.getClass(), "imsAdministratorShortmsg id: "+imsAdministratorShortmsg.getId());
	            	shortMsgParamMap.put("mobile", imsAdministratorShortmsg.getMobile());
	    			shortMsgParamMap.put("blueName", blueprint.getBlueInnerName());
	    			apply.setInsuranceType(blueprint.getInsuranceType());
	    			
	    			// 2,构造短信内容
	    			String shortMsgContent = this.getContent(shortMsgParamMap,apply);
	    			shortMsgParamMap.put("shortMsgContent", shortMsgContent);
	    			// 3,构造短信对象
	    			TPSmsMessages shortMsg = super.initMsg(shortMsgParamMap,ConstantTool.DSWX_TBCBDX);
	    			
	    			//4,启动后台线程，发送短信
	    			super.send(shortMsg, apply);
				}
			}
			// <== over 20190814 
		} catch (SystemParameterNotFoundException e2) {
			LogTool.error(this.getClass(), e2);
		} catch (CacheObjectNotFoundException e3) {
			LogTool.error(this.getClass(), e3);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
	}
	
	/**
	 * 构造短信内容
	 */
	public String getContent(Map<String, Object> shortMsgParamMap,IspApply apply){
		String content = "";			//短信内容
		String holderSex = "";
		String holderName = "";
		String partnerApplyId = apply.getPartnerApplyId();
		IspCustomer holder = apply.getHolder(); 
		holderName = holder.getCustName();
		if (holder.getGender() == 1) {
			holderSex = "先生";
		} else {
			holderSex= "女士";
		}
		
		// 获取一个新的模板上下文,生成短信内容
		VelocityContext context = new VelocityContext();
		context.put("holderName", holderName);
		context.put("holderSex", holderSex);
		context.put("blueName", MapTool.getStringFromMap(shortMsgParamMap, "blueName"));
		context.put("partnerApplyId", partnerApplyId);
		context.put("polno", apply.getPolicyNo());
		context.put("userName", holder.getCustName());
		context.put("wxhome", shortMsgParamMap.get("wxhome"));

		content = TemplateToolV1218.fill(context, ConstantTool.SHORTMSG_TEMPLATE_PATH, ConstantTool.SHORT_MSG_XBSB,"UTF-8","GBK"); // 填充模板  得到短信内容
		
		if (StringUtils.isEmpty(content)) {
			LogTool.error(this.getClass(), ConstantTool.SHORT_MSG_CBSB + " is empty!");
		}
		
		return content;
	}
}

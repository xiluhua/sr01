package com.taiping.dianshang.service;

import com.taiping.dianshang.entity.IspApply;

public interface PersistService {
	
	public void saveOrUpdate(IspApply apply) throws Exception;
	
	public void save(IspApply apply) throws Exception;
	
	public void update(IspApply apply) throws Exception;
	
	public void updateStatus(IspApply apply) throws Exception;
}

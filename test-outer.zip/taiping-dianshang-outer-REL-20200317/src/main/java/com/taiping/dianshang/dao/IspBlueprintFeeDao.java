package com.taiping.dianshang.dao;

import java.math.BigDecimal;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.common.ArithUtils;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspBlueprintFee;
import com.taiping.dianshang.entity.IspCustomer;
import com.taiping.dianshang.entity.ScOverseasTravelRates;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.MapTool;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspBlueprintFeeDao extends BaseWriteDao<IspBlueprintFee, Long>{

	@Resource
	private CommonDao commonDao;
	@Resource
	private IspSequenceDao ispSequenceDao;
	
	public IspBlueprintFee getBlueprintFeeByFeeId(Long feeId) throws Exception{
		
		return super.get("feeId", feeId);
	}

	public IspBlueprintFee getBlueprintFee_1(Long baleId,Double discount) throws Exception{
		
		String hql = "from IspBlueprintFee t where t.baleId = ? and t.discount = ? ";
		Object[] objects = new Object[2];
		objects[0] = baleId;
		objects[1] = discount;

		return commonDao.singleResult(hql, objects);
	}
	
	public IspBlueprintFee getBlueprintFee_2(Long baleId,Integer chargeType, Integer chargeYear, IspCustomer customer,double discount)throws Exception{
		
		IspBlueprintFee blueprintFee = null;
		StringBuffer buffer = new StringBuffer();
		buffer.append("select ");
		buffer.append(" bf.blue_id,  ");
		buffer.append(" bf.blue_code,  ");
		buffer.append(" bf.bale_id,  ");
		buffer.append(" bf.bale_no,  ");
		buffer.append(" bf.age, ");
		buffer.append(" bf.gender,  ");
		buffer.append(" bf.amount,  ");
		buffer.append(" bf.charge_type,  ");
		buffer.append(" bf.charge_year,  ");
		buffer.append(" bf.premium,  ");
		buffer.append(" bf.discount  ");
		buffer.append("from isp_blueprint_fee bf ");
		buffer.append("where bf.BALE_ID = ?  ");
		buffer.append("and bf.charge_type = ?  ");
		buffer.append("and bf.charge_year = ?  ");
		buffer.append("and bf.age = f_get_age(to_date(?,'yyyy-mm-dd')) ");
		buffer.append("and bf.gender = ? ");
		buffer.append("and bf.discount = ?  ");
		

//		Object[] objects = new Object[5];
//		objects[0] = baleId;
//		objects[1] = chargeType;
//		objects[2] = chargeYear;
//		objects[3] = amount;
//		objects[4] = DateTool.convertDataToString(customer.getBirthday(), DateTool.DATE_MASK);
//		objects[5] = customer.getGender();
//		objects[6] = discount;
		
		Query query = commonDao.getSessionRead().createSQLQuery(buffer.toString());
		query.setParameter(0, baleId);
		query.setParameter(1, chargeType);
		query.setParameter(2, chargeYear);
		query.setParameter(3, DateTool.convertDataToString(customer.getBirthday(), DateTool.DATE_MASK));
		query.setParameter(4, customer.getGender());
		query.setParameter(5, discount);
        query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> list = query.list();
        if (list != null && !list.isEmpty()) {
            
        	Map<String, Object> map = list.get(0);
            blueprintFee = this.buildBlueObject(map);
        }
		return blueprintFee;
	}
	
	/**
	 * 根据查询结果map，构造方案信息
	 * @param map 查询结果map
	 * @return 方案信息
	 */
	private IspBlueprintFee buildBlueObject(Map<String, Object> map) {
		// 定义局部变量
		IspBlueprintFee blueprintFee = new IspBlueprintFee();  // 方案信息
		
		// 设置业务对象属性
		blueprintFee.setBlueId(MapTool.getLongFromMap(map, "BLUE_ID"));
		blueprintFee.setBlueCode(MapTool.getStringFromMap(map, "BLUE_CODE"));
		blueprintFee.setBaleId(MapTool.getLongFromMap(map, "BALE_ID"));
		blueprintFee.setBaleNo(MapTool.getIntegerFromMap(map, "BALE_NO"));
		blueprintFee.setAge(MapTool.getIntegerFromMap(map, "AGE"));
		blueprintFee.setGender(MapTool.getIntegerFromMap(map, "GENDER"));
		blueprintFee.setAmount(MapTool.getDoubleFromMap(map, "AMOUNT"));		
		blueprintFee.setChargeType(MapTool.getIntegerFromMap(map, "CHARGE_TYPE"));
		blueprintFee.setChargeYear(MapTool.getIntegerFromMap(map, "CHARGE_YEAR"));
		blueprintFee.setPremium(MapTool.getDoubleFromMap(map, "PREMIUM"));
		blueprintFee.setDiscount(MapTool.getDoubleFromMap(map, "DISCOUNT"));
		// 返回业务对象
		return blueprintFee;
	}
	
	public IspBlueprintFee getBlueprintFee_jingWaiY(IspApply apply) throws Exception{
		IspBlueprintFee ispBlueprintFee = null;
		try {
			String validateDate = DateTool.getDateTime(DateTool.DATE_MASK, apply.getValidateDate());
			String expireDate = DateTool.getDateTime(DateTool.DATE_MASK, apply.getExpirationDate());
			Integer coverDays = DateTool.dateDiff(validateDate, expireDate)+1;
			if (apply.getBaleId() != null) {
				Query query = commonDao.getSessionRead().createQuery("from ScOverseasTravelRates t where t.id = ?");
				query.setLong(0, apply.getBaleId());
				ScOverseasTravelRates rates = (ScOverseasTravelRates) query.uniqueResult();
				String productArea = rates.getProduct_area(); 
				String destination = rates.getDestination();
				String highRiskSports = String.valueOf(rates.getHigh_risk_spors()); 
				String planType = rates.getPlanType(); 
				String insuranceScheme = String.valueOf(coverDays);

				StringBuffer sql = new StringBuffer();
				sql.append(" select min(A.rete) from ");
				sql.append(" ( ");
				sql.append(" select round(retes.amount) as rete from SC_OVERSEAS_TRAVEL_RATES retes ");
				sql.append(" where 1=1 ");
				sql.append(" and retes.product_area="+productArea);
				sql.append(" and retes.destination="+destination);
				sql.append(" and retes.plan_type="+planType);
				sql.append(" and retes.high_risk_sports="+highRiskSports);
				sql.append(" and retes.insurance_scheme_start <="+insuranceScheme);
				sql.append(" and retes.insurance_scheme_end >="+insuranceScheme);
				sql.append(" union all ");
				sql.append(" select (round((ceil("+insuranceScheme+"/7)-4)*retes.four_weeks) + round(retes.amount)) from SC_OVERSEAS_TRAVEL_RATES retes ");
				sql.append(" where 1=1 ");
				sql.append(" and retes.product_area="+productArea);
				sql.append(" and retes.destination="+destination);
				sql.append(" and retes.plan_type="+planType);
				sql.append(" and retes.high_risk_sports="+highRiskSports);
				sql.append(" and retes.insurance_scheme_end > 28 ");
				//sql.append(" and retes.insurance_scheme_end < "+insuranceScheme);
				sql.append(" union all ");
				sql.append(" select distinct round(retes.one_year) from SC_OVERSEAS_TRAVEL_RATES retes ");
				sql.append(" where 1=1 ");
				sql.append(" and retes.product_area="+productArea);
				sql.append(" and retes.destination="+destination);
				sql.append(" and retes.plan_type="+planType);
				sql.append(" and retes.high_risk_sports="+highRiskSports);
				sql.append(" )A ");
				query = commonDao.getSessionRead().createSQLQuery(sql.toString());
				
				Double premium = ((BigDecimal)query.uniqueResult()).doubleValue();
				ispBlueprintFee = new IspBlueprintFee();
				ispBlueprintFee.setPremium(premium);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return ispBlueprintFee;
	}
	
	public IspBlueprintFee getBlueprintFee_unit_1(IspApply apply) throws Exception{
		IspBlueprintFee fee = null;
		Integer unit = 1;
		Double premium = null;
	
		try {
			IspBlueprintFee blueprintFee = this.getBlueprintFee_1(apply.getBaleId(), 1d);
			
			if (blueprintFee == null || blueprintFee.getBaleId() == null) {
				return null;
			}
			Double amountAll = apply.getAmount().doubleValue();
			Double amountPer = blueprintFee.getAmount();

			if (amountAll != null && amountPer != null) {
				premium = blueprintFee.getPremium();
				unit = new BigDecimal(ArithUtils.div(amountAll, amountPer)).intValue();
				premium = ArithUtils.mul(premium, unit);
			}
			
			if (premium != null && premium > 0) {
				fee = new IspBlueprintFee();
				fee.setPremium(premium);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fee;
	}
	
	public IspBlueprintFee getBlueprintFee_unit_2(IspApply apply) throws Exception{
		IspBlueprintFee fee = null;
		Integer unit = 1;
		Double premium = null;
	
		try {
			IspBlueprintFee blueprintFee = this.getBlueprintFee_2(apply.getBaleId(),apply.getChargeType(), apply.getChargeYear(), apply.getInsured(),apply.getDiscount());
			
			if (blueprintFee == null || blueprintFee.getBaleId() == null) {
				return null;
			}
			Double amountAll = apply.getAmount().doubleValue();
			Double amountPer = blueprintFee.getAmount();

			if (amountAll != null && amountPer != null) {
				premium = blueprintFee.getPremium();
				unit = new BigDecimal(ArithUtils.div(amountAll, amountPer)).intValue();
				premium = ArithUtils.mul(premium, unit);
			}
			
			if (premium != null && premium > 0) {
				fee = new IspBlueprintFee();
				fee.setPremium(premium);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return fee;
	}
	@Transactional
	public void delete(Long blueId,Double discount){

		String hql = "from IspBlueprintFee t where t.blueId = ? and t.discount = ? ";

		Query query = super.getSession().createQuery(hql);
		query.setLong(0, blueId);
		query.setDouble(1, discount);
		
		List<IspBlueprintFee> blueprintFees = query.list();
		
		if (blueprintFees.size() > 0) {
			for (int i = 0; i < blueprintFees.size(); i++) {
				super.delete(blueprintFees.get(i));
			}
		}	
	}
	
	/**
	 * 批量保存
	 * @param responseTrialDTOList
	 */
	@Transactional
	public void batchSave(LinkedList<IspBlueprintFee> responseTrialDTOList){
		
		 //打开Session
	    Session session = super.getSession();
	    int size = responseTrialDTOList.size();
	    //循环
	    if (responseTrialDTOList.size() > 0  ) {
		    for (int i = 1 ; i <= size ; i++ ){
		        //创建User实例
		    	IspBlueprintFee blueprintFee = responseTrialDTOList.poll();
		    	Long seq = this.getUniqueSequence();
		    	blueprintFee.setFeeId(seq);
		        session.save(blueprintFee);
	
		        //每当累加器是20的倍数时，将Session中的数据刷入数据库，并清空Session缓存
		        if (i % 50 == 0){
		            session.flush();
		            session.clear();
		        }
		    }
	    }
	}
	
	private Long getUniqueSequence(){
		while(true){
			Long seq = ispSequenceDao.getSequnceWrite(ConstantTool.SEQ_CX_ISP_BLUEPRINT_FEE);
			IspBlueprintFee blueprintFee = super.get("feeId", seq);
			
			if (blueprintFee == null) {
				return seq;
			}
		}
	}
	
	public int getBlueprintFee_idNoTerm(IspApply apply){
		StringBuffer buffer = new StringBuffer();
		buffer.append("SELECT COUNT(1) from  ");
		buffer.append("(  ");
		buffer.append("    SELECT ie.age,ie.gender,ie.bale_id,ie.charge_type,ie.charge_year, decode(ie.charge_type,'4',ie.charge_year * 12 * ie.premium,'1',ie.charge_year  * ie.premium,ie.premium) as premium "); 
		buffer.append("    from isp_blueprint_fee ie  ");
		buffer.append(") tmp  ");
		buffer.append("where tmp.premium >= 200000 "); 
		buffer.append("AND tmp.bale_id = ? ");
		buffer.append("AND tmp.gender = ? ");
		buffer.append("AND tmp.charge_type = ? ");
		buffer.append("AND tmp.charge_year = ? ");
		buffer.append("AND tmp.age = f_get_age(to_date('"+DateTool.convertDataToString(apply.getInsured().getBirthday(), DateTool.DATE_MASK)+"','yyyy-mm-dd')) "); 
		
		Query query = super.getSession().createSQLQuery(buffer.toString());
		query.setParameter(0, apply.getBaleId());
		query.setParameter(1, apply.getInsured().getGender());
		query.setParameter(2, apply.getChargeType());
		query.setParameter(3, apply.getChargeYear());
		
		return ((BigDecimal) query.uniqueResult()).intValue();
	}
}

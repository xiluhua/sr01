package com.taiping.dianshang.outer.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.ParseException;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspPartner;
import com.taiping.dianshang.exception.DownloadPolicyPdfException;
import com.taiping.dianshang.exception.DownloadPolicyPdfSysException;
import com.taiping.dianshang.exception.SignVerifyException;
import com.taiping.dianshang.outer.service.DownloadPolicyPdfService;
import com.taiping.dianshang.outer.service.IspApplyService;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.dianshang.service.validSqlInject.AntiSqlInjectService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DesTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.SpringTool;
import com.taiping.framework.action.BaseAction;

/**
 * @author xilh
 * @since 20190918
 * 请使用 Policy2Action.java
 * 20190918以后的下载功能统一放在 /shop/download 路径下，便于日后维护管理
 * 电子保单下载（各渠道）
 * @author xilh
 * @since 20161208
 */
@ParentPackage("struts-default")
@Namespace("/shop")
@Deprecated
public class PolicyAction  extends BaseAction {
	
	private static final long serialVersionUID = 5849260213064898322L;
	@Resource
	IspApplyService ispApplyService;
	@Resource
	AntiSqlInjectService antiSqlInjectService;
	@Resource
	SignService signService;
	
	/**
	 * 下载电子保单
	 * @author xilh
	 * @since 20161207
	 * 商城    ：http://localhost:7002/taiping-dianshang-outer/shop/downloadPolicyPdfTplife.action?policyNo=001122656919310&idNo=32038119900128603X
	 */
	@Action(value = "downloadPolicyPdfTplife")
	public String downloadPolicyPdfTplife() throws IOException {
		String policyNo = getRequest().getParameter("policyNo");
		String idNo = getRequest().getParameter("idNo");
		String fileDownloadPath = "";
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口 ===");
    	try {
    		// 1. sql注入校验
    		antiSqlInjectService.verify(policyNo+idNo);
    		
    		// 2. 保单号相关信息校验
    		if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
    			throw new DownloadPolicyPdfException();
    		}
    		
    		DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_1");
			fileDownloadPath = dpps.download(policyNo, idNo);
			if (StringUtils.isEmpty(fileDownloadPath)) {
				throw new DownloadPolicyPdfSysException();
			}
			
			this.upload(fileDownloadPath, policyNo);
		} catch (DownloadPolicyPdfSysException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("Exception, for details, please contact the system administrator ...");
		} catch (SignVerifyException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid sign");
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid request");
		}
    	
    	return null;
	}
	
	/**
	 * 下载电子保单
	 * @author xilh
	 * @since 20161207
	 * 商城    ：http://localhost:7002/taiping-dianshang-outer/shop/downloadPolicyPdf.action?policyNo=001122656919310&idNo=32038119900128603X
	 */
	@Action(value = "downloadPolicyPdf")
	public String downloadPolicyPdf() throws IOException {
		String policyNo = getRequest().getParameter("policyNo");
		String idNo = getRequest().getParameter("idNo");
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口 ===");
//		String fileDownloadPath = "";
//    	try {
//    		// 1. sql注入校验
//    		antiSqlInjectService.verify(policyNo+idNo);
//    		
//    		// 2. 保单号相关信息校验
//    		if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
//    			throw new DownloadPolicyPdfException();
//    		}
//    		
//    		IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
//			if (apply == null || !apply.getHolder().getIdNo().equalsIgnoreCase(idNo)) {
//				throw new DownloadPolicyPdfException();
//			}
//			
//    		DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_"+apply.getSellChannel());
//			fileDownloadPath = dpps.download(policyNo, idNo);
//			if (StringUtils.isEmpty(fileDownloadPath)) {
//				throw new DownloadPolicyPdfSysException();
//			}
//			
//			this.upload(fileDownloadPath, policyNo);
//		} catch (DownloadPolicyPdfSysException e) {
//			LogTool.error(this.getClass(), e);
//			this.writeResponse("Exception, for details, please contact the system administrator ...");
//		} catch (SignVerifyException e) {
//			LogTool.error(this.getClass(), e);
//			this.writeResponse("invalid sign");
//		} catch (Exception e) {
//			LogTool.error(this.getClass(), e);
//			this.writeResponse("invalid request");
//		}
    	this.downloadPolicyPdf(policyNo, idNo);
    	return null;
	}
	
	/**
	 * 下载电子保单
	 * http://localhost:7002/taiping-dianshang-outer/shop/policy!downloadPolicyPdfPartner.action?policyNo=001122676747310&idNo=431022197909288589&orderId=20160902_x1&partnerId=164&timestamp=20170122134629&sign=f67f38162f7286634c55187b7a17e030
	 *
	 * @return
	 * @throws IOException
	 */
	@Action(value="downloadPolicyPdfPartner")
	public String downloadPolicyPdfPartner() throws IOException {
		
		String orderId = getRequest().getParameter("orderId");
		String timestamp = getRequest().getParameter("timestamp");
		String policyNo = getRequest().getParameter("policyNo");
		String idNo = getRequest().getParameter("idNo");
		String partnerId = getRequest().getParameter("partnerId");
		String sign = getRequest().getParameter("sign");
		boolean isTest = false;
		String fileDownloadPath = "";
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口-partner ===");
		LogTool.debug(this.getClass(), "orderId: "+orderId);
		LogTool.debug(this.getClass(), "policyNo: "+policyNo);
		LogTool.debug(this.getClass(), "idNo: "+idNo);
		LogTool.debug(this.getClass(), "partnerId: "+partnerId);
    	try {
			if (StringUtils.isEmpty(orderId) || StringUtils.isEmpty(timestamp) || StringUtils.isEmpty(sign)||StringUtils.isEmpty(String.valueOf(partnerId))||StringUtils.isEmpty(policyNo)||StringUtils.isEmpty(idNo)) {
				this.writeResponse("invalid request");
				return null;
			}
			
			// 1. sql注入校验
    		antiSqlInjectService.verify(policyNo+idNo);
    		antiSqlInjectService.verify(partnerId+sign);
    		//add by lk 20180202 wowallat encry
			IspPartner partner = CacheContainer.getByIdFromCache(partnerId, IspPartner.class);
    		if(Long.parseLong(partnerId) == ConstantTool.WO_WALLAT_ID){
    			DesTool desTool = new DesTool();
    			if(partner == null){
					throw new DownloadPolicyPdfException();
				}
				desTool.setKey(partner.getKeyPassword());
    			idNo = desTool.getDesString(idNo);
				antiSqlInjectService.verify(idNo);
			}
    		
			String xmlData = orderId+timestamp;
			signService.verify(xmlData, sign, Long.valueOf(partnerId));
    		
			// add by xiluhua 20180215 for TEST ONLY
			if (policyNo.indexOf("TEST") > -1) {
				policyNo = policyNo.replace("TEST", "");
				isTest = true;
			}
			
    		// 3. 保单号相关信息校验
			IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
    		if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
    			throw new DownloadPolicyPdfException();
    		}
    		
			// 2.2. 非签名方式下载
			if (apply == null) {
				throw new DownloadPolicyPdfException();
			}
			
			if (apply.getCheckBillStatus() == null || apply.getCheckBillStatus() != 1) {
				throw new DownloadPolicyPdfException();
			}
			
			if (!apply.getHolder().getIdNo().equalsIgnoreCase(idNo)) {
				throw new DownloadPolicyPdfException();
			}
    		
			// add by xiluhua 20180215 for TEST ONLY
			if (isTest) {
				fileDownloadPath = PropertyFileTool.get("policy.pdf.dir");
				File newfile = new File(fileDownloadPath+"/"+policyNo+".pdf");
				System.out.println("isTest: "+newfile.getAbsolutePath());
				this.upload(fileDownloadPath+"/"+policyNo+".pdf", policyNo);
				return null;
			}
			
    		DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_"+apply.getSellChannel());
			fileDownloadPath = dpps.download(policyNo, idNo);
			if (StringUtils.isEmpty(fileDownloadPath)) {
				throw new DownloadPolicyPdfSysException();
			}
			
			this.upload(fileDownloadPath, policyNo);
		} catch (DownloadPolicyPdfSysException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("Exception, for details, please contact the system administrator ...");
		} catch (SignVerifyException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid sign");
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid request");
		}
    	
    	return null;
	}
	
	/**
	 * 下载电子保单
	 * http://localhost:7002/taiping-dianshang-outer/shop/policy!downloadPolicyPdfTB.action?spm=a2800.6934985.0.0.2NC5Fk&policyNo=001133498717310&idNo=431381198109106573&orderId=10211223379351005&timestamp=1489395967821&sign=456e1f55e92839b59700b90a2a788f50
	 * @return
	 * @throws IOException
	 */
	public String downloadPolicyPdfTB() throws IOException {
		
		String orderId = getRequest().getParameter("orderId");
		String timestamp = getRequest().getParameter("timestamp");
		String sign = getRequest().getParameter("sign");
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口-TAOBAO ===");
		if (StringUtils.isEmpty(orderId) || StringUtils.isEmpty(timestamp) || StringUtils.isEmpty(sign)) {
			writeResponse("sign error");
			return null;
		}else {
			String xmlData = orderId+timestamp;
			try {
				signService.verify(xmlData, sign,34l);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
				writeResponse("sign error");
				return null;
			}
		}
    	
    	return this.downloadPolicyPdf();
	}
	
	/**
	 * 下载电子保单
	 * http://localhost:7002/taiping-dianshang-outer/shop/policy!downloadPolicyPdfTB.action?spm=a2800.6934985.0.0.2NC5Fk&policyNo=001133498717310&idNo=431381198109106573&orderId=10211223379351005&timestamp=1489395967821&sign=456e1f55e92839b59700b90a2a788f50
	 * @return
	 * @throws IOException
	 * @throws ParseException 
	 * @since 20171229
	 */
	public String downloadPolicyPdfBD() throws IOException, ParseException {
		String sign = getRequest().getParameter("sign");
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口-BAIDU ===");
		// 1. 获取 sign
		if (StringUtils.isEmpty(sign)) {
			writeResponse("sign error");
			return null;
		}
		// 2. 解密 sign 并解析
		String datas = new DesTool().getDesString(sign);//解密 
		// policyNo-idNo-timestamp
		String[] arr = datas.split("-");  
		if (arr.length != 3) {
			writeResponse("invaid request");
			return null;
		}
		// 3. 过期判断
		String policyNo = arr[0];
		String end = JedisClient_outer2.get(KeyTool.getPdfDownloadEndTime(policyNo));
		if (StringUtils.isEmpty(end)) {
			writeResponse("expired request");
			return null;
		}
		// 4. 下载
		return this.downloadPolicyPdf(policyNo,arr[1]);
    	
	}
	
	/**
	 * 下载电子保单
	 * @author xilh
	 * @since 20171219
	 */
	public String downloadPolicyPdf(String policyNo,String idNo) throws IOException {
		String fileDownloadPath = "";
		boolean isTest = false;
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口 ===");
    	try {
    		// 1. sql注入校验
    		antiSqlInjectService.verify(policyNo+idNo);
    		
    		// 2. 保单号相关信息校验
    		if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
    			throw new DownloadPolicyPdfException();
    		}
    		
    		// add by xiluhua 20180215 for TEST ONLY
			if (policyNo.indexOf("TEST") > -1) {
				policyNo = policyNo.replace("TEST", "");
				isTest = true;
			}
			
    		IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
			if (apply == null || !apply.getHolder().getIdNo().equalsIgnoreCase(idNo)) {
				throw new DownloadPolicyPdfException();
			}
			
			// add by xiluhua 20180215 for TEST ONLY
			if (isTest) {
				fileDownloadPath = PropertyFileTool.get("policy.pdf.dir");
				File newfile = new File(fileDownloadPath+"/"+policyNo+".pdf");
				System.out.println("newfile.getAbsolutePath(): "+newfile.getAbsolutePath());
				policyNo = policyNo.replace("TEST", "");
				this.upload(fileDownloadPath+"/"+policyNo+".pdf", policyNo);
				return null;
			}
			
    		DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_"+apply.getSellChannel());
			fileDownloadPath = dpps.download(policyNo, idNo);
			if (StringUtils.isEmpty(fileDownloadPath)) {
				throw new DownloadPolicyPdfSysException();
			}
			
			this.upload(fileDownloadPath, policyNo);
		} catch (DownloadPolicyPdfSysException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("Exception, for details, please contact the system administrator ...");
		} catch (SignVerifyException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid sign");
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid request");
		}
    	
    	return null;
	}
	
	/**
	 * 下载电子保单 for 联通激励商城
	 * http://localhost:7002/taiping-dianshang-outer/shop/policy!downloadPolicySign.action?policyNoEnc=C123AB4A52C3648996D95E62B2C5EFAAEBDB8CA9327F32257B88BBEA0F70FED6168D3EA2625ED7C5
	 * https://baoxian.itaiping.com/shop/policy!downloadPolicySign.action?policyNoEnc=C123AB4A52C3648996D95E62B2C5EFAAEBDB8CA9327F32257B88BBEA0F70FED6168D3EA2625ED7C5
	 * https://baoxian.cntaiping.com/shop/policy!downloadPolicySign.action?policyNoEnc=C123AB4A52C36489D1A0C76A8D49AD0B9C4124BDD1AA90E2DE83E24A177643B50AF9D5820B3A24B4
	 * @author xilh
	 * @since 20181011
	 */
	public String downloadPolicySign() throws IOException {
		String fileDownloadPath = "";
		boolean isTest = false;
		String policyNoEnc = getRequest().getParameter("policyNoEnc");
	
		LogTool.debug(this.getClass(), "=== 下载电子保单新接口 downloadPolicySign ===");
    	try {
    		String policyNo = new DesTool().getDesString(policyNoEnc).split("_")[0];
    		String idNo     = new DesTool().getDesString(policyNoEnc).split("_")[1];
    		// 1. sql注入校验
    		antiSqlInjectService.verify(policyNo+idNo);
    		
    		// 2. 保单号相关信息校验
    		if (StringUtils.isEmpty(policyNo) || StringUtils.isEmpty(idNo)) {
    			throw new DownloadPolicyPdfException();
    		}
    		
    		// add by xiluhua 20180215 for TEST ONLY
			if (policyNo.indexOf("TEST") > -1) {
				policyNo = policyNo.replace("TEST", "");
				isTest = true;
			}
			
    		IspApply apply = ispApplyService.loadApply(null, policyNo, null, null);
			if (apply == null || !apply.getHolder().getIdNo().equalsIgnoreCase(idNo)) {
				throw new DownloadPolicyPdfException();
			}
			
			// add by xiluhua 20180215 for TEST ONLY
			if (isTest) {
				fileDownloadPath = PropertyFileTool.get("policy.pdf.dir");
				File newfile = new File(fileDownloadPath+"/"+policyNo+".pdf");
				System.out.println("newfile.getAbsolutePath(): "+newfile.getAbsolutePath());
				policyNo = policyNo.replace("TEST", "");
				this.upload(fileDownloadPath+"/"+policyNo+".pdf", policyNo);
				return null;
			}
			
    		DownloadPolicyPdfService dpps = SpringTool.getSpringBean("DownloadPolicyPdfImpl_"+apply.getSellChannel());
			fileDownloadPath = dpps.download(policyNo, idNo);
			if (StringUtils.isEmpty(fileDownloadPath)) {
				throw new DownloadPolicyPdfSysException();
			}
			
			this.upload(fileDownloadPath, policyNo);
		} catch (DownloadPolicyPdfSysException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("Exception, for details, please contact the system administrator ...");
		} catch (SignVerifyException e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid sign");
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			this.writeResponse("invalid request");
		}
    	
    	return null;
	}
	
	
	public void writeResponse(String responseMsg) throws IOException{
		getResponse().setCharacterEncoding(ConstantTool.GBK);
		getResponse().setContentType("application/xml");
		getResponse().getWriter().write(responseMsg);
	}
	
	public void upload(String fileDownloadPath,String policyNo){
		BufferedInputStream fis = null;
		OutputStream toClient = null;
		try {
    		int BUFFER_SIZE = 8096;
        	File newfile = new File(fileDownloadPath);
        	fis = new BufferedInputStream(new FileInputStream(fileDownloadPath));
    		toClient = new BufferedOutputStream(super.getResponse().getOutputStream());
    		byte buf[] = new byte[BUFFER_SIZE];
    		int size = 0;
    		super.getResponse().reset();
    		super.getResponse().addHeader("Content-Disposition",(new StringBuilder("attachment;filename=")).append(new String((policyNo+".pdf").getBytes("gbk"), "ISO-8859-1")).toString());
    		super.getResponse().addHeader("Content-Length",(new StringBuilder()).append(newfile.length()).toString());
    		super.getResponse().setContentType("application/octet-stream;charset=GBK");
    		
    		while ((size = fis.read(buf)) != -1){
    			toClient.write(buf, 0, size);
    		}
    		fis.close();
    		toClient.flush();
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new DownloadPolicyPdfSysException(e.getMessage());
		} finally{
			try {
				File pdfFile = new File(fileDownloadPath);
				if (pdfFile.isFile() && pdfFile.exists()) {
					if (LogTool.isFormal) {
						pdfFile.delete();
					}
				}
				if (fis != null){
					fis.close();
				}
				if (toClient != null){
					toClient.close();
				}
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
				throw new DownloadPolicyPdfSysException(e.getMessage());
			}
		}
	}
	
}
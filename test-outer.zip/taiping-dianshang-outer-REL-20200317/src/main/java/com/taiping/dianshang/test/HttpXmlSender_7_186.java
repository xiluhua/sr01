package com.taiping.dianshang.test;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.utils.CreateDTOTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.LogTool;

public class HttpXmlSender_7_186 {

	public static void main(String[] args) throws Exception {
		String encode = "GBK";
		
//		2014111210ORDER00111404
//		2014WY12151
//		E1412011634030083
//		42793502745008214
//		2014083001
//		2014083002
//		2014090203
//		2014090401
//		2014092009
//		2014092105
//		2014092201
//		2014092202
//		2014090505
//		2014090508
//		2014090510
//		2014092203
//		42793502745008212
//		42793502745008213
//		2014111110
//		2014111107

		
		String content = CreateDTOTool.create(7,"2014111210ORDER00111404",false,1);

		LogTool.info(HttpXmlSender_7_186.class, "content:{}", content);
		
		String url = "http://localhost:7788/taiping-dianshang-core/services/rest/core/business/entrance";

		String response = HttpclientTool.post(url, content, encode);
		
		System.out.println("response:"+Base64Tool.decode(response, "utf-8"));
		
	}
}

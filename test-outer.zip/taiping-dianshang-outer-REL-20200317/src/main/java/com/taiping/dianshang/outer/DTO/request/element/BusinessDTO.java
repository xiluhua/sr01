package com.taiping.dianshang.outer.DTO.request.element;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import com.taiping.facility.tool.DateTimeAdapter;
/**
 * @author: xiluhua by 20160119
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
		"busiId",
		"serviceCode",
		"partnerId",
		"transTime",
		"sign"
})
public class BusinessDTO {
	@XmlElement(name = "BUSI_ID")
	private String busiId;
	@XmlElement(name = "SERVICE_CODE")
	private String serviceCode;
	@XmlElement(name = "PARTNER_ID")
	private String partnerId;
	@XmlElement(name = "TRANS_TIME")
	@XmlJavaTypeAdapter(value = DateTimeAdapter.class)
	private Date transTime;
	@XmlElement(name = "SIGN")
	private String sign;
	
	
	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getServiceCode() {
		return serviceCode;
	}

	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public Date getTransTime() {
		return transTime;
	}

	public void setTransTime(Date transTime) {
		this.transTime = transTime;
	}

	public String getBusiId() {
		return busiId;
	}

	public void setBusiId(String busiId) {
		this.busiId = busiId;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	
}

package com.taiping.dianshang.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IpayRegister;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.facility.tool.MapTool;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IpayRegisterDao extends BaseWriteDao<IpayRegister, Long>{

	@Resource
	private CommonDao commonDao;
	
	public Long save(IpayRegister payRegister){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_DS_IPAY_REGISTER);
		payRegister.setId(seq);
		
		return super.save(payRegister);
	}
	
	public IpayRegister getPayRegisterByApplyId(Long applyId){
		String hql = "from IpayRegister t where t.applyId = ? and t.status = 1";
		Object[] param = new Object[]{applyId};
		return commonDao.singleResult(hql, param);
	}
	public IpayRegister getPayRegisterByBillId(Long billId){
		String hql = "from IpayRegister t where t.applyId = 0 and t.status = 1 and t.billId = ?";
		Object[] param = new Object[]{billId};
		return commonDao.singleResult(hql, param);
	}
	// add by xiluhua 20171211 for payCallBAck
	public IpayRegister getPayRegisterByBillId2(Long billId){
		String hql = "from IpayRegister t where t.billId = ?";
		return (IpayRegister)super.getSession().createQuery(hql).setLong(0, billId).uniqueResult();
	}
	public IpayRegister getPayRegisterByPartnerBillId(String partnerBillId){
		String hql = "from IpayRegister t where t.applyId = 0 and t.partnerBillId = ?";
		return (IpayRegister)super.getSession().createQuery(hql).setString(0, partnerBillId).uniqueResult();
	}
	public IpayRegister getPayRegisterByPartnerBillId(String partnerBillId,boolean isMulti){
		String hql = null;
		if (isMulti) {
			hql = "from IpayRegister t where t.payStatus = 1 and t.applyId = 0 and t.partnerBillId = ?";
		}else {
			hql = "from IpayRegister t where t.payStatus = 1 and t.partnerBillId = ?";
		}
		return (IpayRegister)super.getSession().createQuery(hql).setString(0, partnerBillId).uniqueResult();
	}
	
	public void delete(Long billId){
		String hql = "DELETE FROM DS_IPAY_REGISTER T WHERE T.BILL_ID = ?";
		SQLQuery sqlQuery = super.getSession().createSQLQuery(hql);
		sqlQuery.setLong(0, billId);
		sqlQuery.executeUpdate();
	}

	public List<IpayRegister> getPayRegisterList(String busiId) {
		String hql = "from IpayRegister t where t.applyId != 0 and t.status = 1 and t.partnerBillId = ?";
		Object[] param = new Object[]{busiId};
		return commonDao.findListByHql(hql, param);
	}
	
	public List<IspApply> getApplyList(String busiId) {
		StringBuilder sql = new StringBuilder();
		// apply
		sql.append("SELECT AP.APPLY_ID,AP.PARTNER_APPLY_ID,AP.APP_NO,AP.PREMIUM,AP.PARTNER_ID ");
		sql.append("FROM ISP_APPLY   AP,DS_IPAY_REGISTER PR ");
		sql.append("WHERE 1=1 ");
		sql.append("AND AP.APPLY_ID = PR.APPLY_ID ");
		sql.append("AND PR.APPLY_ID = 0 ");
		sql.append("AND PR.PARTNER_BILL_ID = ? ");
		
		Query query = commonDao.getSessionRead().createSQLQuery(sql.toString());
		query.setString(0, busiId);
        query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> list = query.list();
        
		List<IspApply> applyList = new ArrayList<IspApply>();
		for (int i = 0; i < list.size(); i++) {
			IspApply apply = new IspApply();
			Map<String, Object> map = list.get(i);
			String partnerApplyId = MapTool.getStringFromMap(map, "PARTNER_APPLY_ID");
			Long applyId = MapTool.getLongFromMap(map, "APPLY_ID");
			String appno = MapTool.getStringFromMap(map, "APP_NO");
			Double premium = MapTool.getDoubleFromMap(map, "PREMIUM");
			Long partnerId = MapTool.getLongFromMap(map, "PARTNER_ID");
			
			apply.setPartnerApplyId(partnerApplyId);
			apply.setApplyId(applyId);
			apply.setAppNo(appno);
			apply.setPremium(premium);
			apply.setPartnerId(partnerId);
			applyList.add(apply);
		}
		return applyList;
	}
	
	public List<IspApply> getApplyListWrite(String busiId) {
		StringBuilder sql = new StringBuilder();
		// apply
		sql.append("SELECT AP.APPLY_ID,AP.PARTNER_APPLY_ID,AP.APP_NO,AP.PREMIUM,AP.PARTNER_ID ");
		sql.append("FROM ISP_APPLY   AP,DS_IPAY_REGISTER PR ");
		sql.append("WHERE 1=1 ");
		sql.append("AND AP.APPLY_ID = PR.APPLY_ID ");
		sql.append("AND PR.APPLY_ID != 0 ");
		sql.append("AND PR.PARTNER_BILL_ID = ? ");
		
		Query query = super.getSession().createSQLQuery(sql.toString());
		query.setString(0, busiId);
        query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
        @SuppressWarnings("unchecked")
		List<Map<String, Object>> list = query.list();
        
		List<IspApply> applyList = new ArrayList<IspApply>();
		for (int i = 0; i < list.size(); i++) {
			IspApply apply = new IspApply();
			Map<String, Object> map = list.get(i);
			String partnerApplyId = MapTool.getStringFromMap(map, "PARTNER_APPLY_ID");
			Long applyId = MapTool.getLongFromMap(map, "APPLY_ID");
			String appno = MapTool.getStringFromMap(map, "APP_NO");
			Double premium = MapTool.getDoubleFromMap(map, "PREMIUM");
			Long partnerId = MapTool.getLongFromMap(map, "PARTNER_ID");
			
			apply.setPartnerApplyId(partnerApplyId);
			apply.setApplyId(applyId);
			apply.setAppNo(appno);
			apply.setPremium(premium);
			apply.setPartnerId(partnerId);
			applyList.add(apply);
		}
		return applyList;
	}
}

package com.taiping.dianshang.dao;

import java.util.List;

import javax.annotation.Resource;

import org.hibernate.SQLQuery;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IpayBillGoods;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IpayBillGoodsDao extends BaseWriteDao<IpayBillGoods, Long>{
	
	@Resource
	private CommonDao commonDao;
	
	public Long save(IpayBillGoods goods){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_IPAY_BILL_GOODS);
		goods.setGoodId(seq);
		
		return super.save(goods);
	}
	
	public void update(Long billId){
		String hql = "update DS_IPAY_BILL_GOODS t set t.status = 0 where t.bill_id = ?";
		SQLQuery sqlQuery = super.getSession().createSQLQuery(hql);
		sqlQuery.setLong(0, billId);
		sqlQuery.executeUpdate();
	}
	
	public List<IpayBillGoods> getGoodsByApplyId(Long applyId){
		String hql = "from IpayBillGoods t where t.status = 1 and t.applyId = ?";
		Object[] param = new Object[]{applyId};
		return commonDao.findListByHql(hql, param);
	}
}

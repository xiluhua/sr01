package com.taiping.dianshang.test;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.utils.CreateDTOTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.LogTool;

public class HttpXmlSender_21_186 {

	public static void main(String[] args) throws Exception {
		String encode = "GBK";
		
		String content = CreateDTOTool.create(21,"186201603311",false,1);

		LogTool.info(HttpXmlSender_21_186.class, "content:{}", content);
		
		String url = "http://localhost:7788/taiping-dianshang-core/services/rest/core/business/entrance";

		String response = HttpclientTool.post(url, content, encode);
		
		System.out.println("response:"+Base64Tool.decode(response, "utf-8"));
	}
}

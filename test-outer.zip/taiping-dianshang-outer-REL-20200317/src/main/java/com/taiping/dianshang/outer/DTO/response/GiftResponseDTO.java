package com.taiping.dianshang.outer.DTO.response;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "RETURN")
public class GiftResponseDTO {

	private String code;
	protected String returnInfo = "";  		// 返回信息
	private boolean isSuccess;

	public String getCode() {
		return code;
	}

	@XmlElement(name = "CODE")
	public void setCode(String code) {
		this.code = code;
	}

	@XmlElement(name = "RETURN_INFO")
    public String getReturnInfo() {
		return returnInfo;
	}

	public void setReturnInfo(String returnInfo) {
		this.returnInfo = returnInfo;
	}

	@Override
    public String toString() {
        return "ReturnDTO{" +
                "code='" + code + '\'' +
                ", message='" + returnInfo + '\'' +
                ", isSuccess='" + isSuccess + '\'' +
                '}';
    }

	public boolean isSuccess() {
		return isSuccess;
	}
	/**
	 * @return the isSuccess
	 */
	@XmlElement(name="ISSUCESS")
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
}

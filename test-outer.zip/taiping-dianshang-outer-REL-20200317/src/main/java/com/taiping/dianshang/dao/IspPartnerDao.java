package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspPartner;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspPartnerDao extends BaseWriteDao<IspPartner, Long> implements CacheDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<IspPartner> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspPartner partner = list.get(i);
				if (partner.getPartnerId() != null) {
					String key = KeyTool.get(IspPartner.class, partner.getPartnerId());
					map.put(key, JsonTool.toJson(partner));	
				}
				if (partner.getPayerCode() != null) {
					String key = KeyTool.get(IspPartner.class, partner.getPayerCode());
					map.put(key, JsonTool.toJson(partner));	
				}
				String key = KeyTool.get(IspPartner.class, ConstantTool.BANKCODE + partner.getBankCode());
				map.put(key, JsonTool.toJson(partner));
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspPartner> getAll(){
		String hql = "from IspPartner t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
}
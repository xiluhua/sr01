/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.dianshang.outer.DTO.callback.baidu;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * Created by tianhuang on 17/12/19.
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = {
        "Name",
        "CertType",
        "CertNo",
        "Mobile",
        "Address",
        "IdExpiry",
        "Sex",
        "Email",
        "Zip",
        "Birth",
        "InsuredRela",
        "InsuredNameSp"
})
public class Insured {

    @XmlElement(name = "Name")
    private String Name;
    @XmlElement(name = "CertType")
    private String CertType;
    @XmlElement(name = "CertNo")
    private String CertNo;
    @XmlElement(name = "Mobile")
    private String Mobile;
    @XmlElement(name = "Address")
    private String Address;
    @XmlElement(name = "IdExpiry")
    private String IdExpiry;
    @XmlElement(name = "Sex")
    private String Sex;
    @XmlElement(name = "Email")
    private String Email;
    @XmlElement(name = "Zip")
    private String Zip;
    @XmlElement(name = "Birth")
    private String Birth;
    @XmlElement(name = "InsuredRela")
    private String InsuredRela;

    @XmlElement(name = "InsuredRela")
    private String InsuredNameSp;

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getCertType() {
        return CertType;
    }

    public void setCertType(String certType) {
        CertType = certType;
    }

    public String getCertNo() {
        return CertNo;
    }

    public void setCertNo(String certNo) {
        CertNo = certNo;
    }

    public String getMobile() {
        return Mobile;
    }

    public void setMobile(String mobile) {
        Mobile = mobile;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getIdExpiry() {
        return IdExpiry;
    }

    public void setIdExpiry(String idExpiry) {
        IdExpiry = idExpiry;
    }

    public String getSex() {
        return Sex;
    }

    public void setSex(String sex) {
        Sex = sex;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getZip() {
        return Zip;
    }

    public void setZip(String zip) {
        Zip = zip;
    }

    public String getBirth() {
        return Birth;
    }

    public void setBirth(String birth) {
        Birth = birth;
    }

    public String getInsuredRela() {
        return InsuredRela;
    }

    public void setInsuredRela(String insuredRela) {
        InsuredRela = insuredRela;
    }

    public String getInsuredNameSp() {
        return InsuredNameSp;
    }

    public void setInsuredNameSp(String insuredNameSp) {
        InsuredNameSp = insuredNameSp;
    }
}

package com.taiping.dianshang.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ScIspPolicy entity. 
 */
@Entity
@Table(name = "ISP_SEND_HISTORY")
public class IspSendHistory implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	private Long applyId;
	private int isEmailSend = 0;	// 0.初始化|1.发送完成|2.待发送
	private int isShortmsgSend = 0;
	private int isGiftScoreSend = 0;

	// Constructors

	/** default constructor */
	public IspSendHistory() {
	}

	public IspSendHistory(Long applyId) {
		super();
		this.applyId = applyId;
	}
	
	public IspSendHistory(Long applyId, int isEmailSend,
			int isShortmsgSend, int isGiftScoreSend) {
		super();
		this.applyId = applyId;
		this.isEmailSend = isEmailSend;
		this.isShortmsgSend = isShortmsgSend;
		this.isGiftScoreSend = isGiftScoreSend;
	}

	@Override
	public String toString() {
		return "IspSendHistory [applyId=" + applyId + ", isEmailSend="
				+ isEmailSend + ", isShortmsgSend=" + isShortmsgSend
				+ ", isGiftScoreSend=" + isGiftScoreSend + "]";
	}

	// Property accessors
	@Id
	@Column(name = "APPLY_ID")
	public Long getApplyId() {
		return applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	@Column(name = "IS_EMAIL_SEND")
	public int getIsEmailSend() {
		return isEmailSend;
	}

	public void setIsEmailSend(int isEmailSend) {
		this.isEmailSend = isEmailSend;
	}
	@Column(name = "IS_SHORTMSG_SEND")
	public int getIsShortmsgSend() {
		return isShortmsgSend;
	}

	public void setIsShortmsgSend(int isShortmsgSend) {
		this.isShortmsgSend = isShortmsgSend;
	}
	@Column(name = "IS_GIFTSCORE_SEND")
	public int getIsGiftScoreSend() {
		return isGiftScoreSend;
	}

	public void setIsGiftScoreSend(int isGiftScoreSend) {
		this.isGiftScoreSend = isGiftScoreSend;
	}


	
}
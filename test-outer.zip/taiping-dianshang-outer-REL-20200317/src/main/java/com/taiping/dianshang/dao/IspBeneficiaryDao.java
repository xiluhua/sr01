package com.taiping.dianshang.dao;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspBeneficiary;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspBeneficiaryDao extends BaseWriteDao<IspBeneficiary, Long>{
	@Resource
	private CommonDaoWrite commonDaoWrite;
	
	public List<IspBeneficiary> getBeneficiayListByApplyId(Long applyId){
		String hql = "from IspBeneficiary t where t.applyId = ?";
		Object[] params = new Object[1];
		params[0] = applyId;
		return commonDaoWrite.findListByHql(hql, params);
	}
	
	public Long save(IspBeneficiary beneficiary){
		Long seq = commonDaoWrite.getSequnce(ConstantTool.SEQ_BENEFICIARY);
		beneficiary.setAppBeneficiaryId(seq);
		return super.save(beneficiary);
	}
}

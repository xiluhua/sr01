package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IspPayPartner;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class IspPayPartnerDao extends BaseWriteDao<IspPayPartner, Long> implements CacheDaoService{
	
	@Override
	public Map<Object, String> getAllInMap() {
		List<IspPayPartner> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				IspPayPartner ispPayPartner = list.get(i);
				if (ispPayPartner.getPartnerId() != null) {
					String key = KeyTool.get(IspPayPartner.class, ispPayPartner.getPartnerId());
					map.put(key, JsonTool.toJson(ispPayPartner));
					
					key = KeyTool.get(IspPayPartner.class, ispPayPartner.getPartnerId()+ConstantTool.UNDERLINE+ispPayPartner.getPayPartner());
					map.put(key, JsonTool.toJson(ispPayPartner));
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<IspPayPartner> getAll(){
		String hql = "from IspPayPartner t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
}

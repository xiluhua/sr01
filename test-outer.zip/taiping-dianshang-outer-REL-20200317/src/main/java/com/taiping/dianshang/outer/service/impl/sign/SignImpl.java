package com.taiping.dianshang.outer.service.impl.sign;

import java.io.UnsupportedEncodingException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import com.taiping.dianshang.entity.IspPartner;
import com.taiping.dianshang.exception.SignVerifyException;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.Md5EncryptTool;

/**
 * @author xilh
 * @since 20161018
 * @category 签名接口 
 * @version 3.0
 */
@Component
public class SignImpl implements SignService{

	@Override
	public void verify(String xmlData, String sign,Long partnerId) {
		
		String verifySign = sign(xmlData,partnerId);
		LogTool.debug(this.getClass(),"signSource:"+sign);
		LogTool.debug(this.getClass(),"signVerify:"+verifySign);
		
		if (!verifySign.equals(sign)) {
			throw new SignVerifyException("签名错误");
		}
	}
	
	/**
	 * 签名
	 * @param srcString 签名明文
	 * @return
	 */
	public String sign(String xmlData,Long partnerId) {
		String sign = "";
		try {
			IspPartner partner = CacheContainer.getByIdFromCache(partnerId, IspPartner.class);
			String md5key = StringUtils.defaultString(partner.getKeyPassword());
			String source = md5key + xmlData;
			// 淘宝
			if (partnerId == 34) {
				source = xmlData + md5key;
			}
			
			sign = Md5EncryptTool.getMD5(source.getBytes("GBK"));
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new SignVerifyException("签名验证异常");
		}
		
		return sign;
	}
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		String orderId = "103125543021545505";
		String timestamp = "20170314152211";
//		String md5key = "12345";
		String md5key = "TPRS123SAD";	// FORMAL
		String xmlData = orderId+timestamp;
		String source = xmlData + md5key ;
		System.out.println(Md5EncryptTool.getMD5(source.getBytes("GBK")));
	}
}

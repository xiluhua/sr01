package com.taiping.dianshang.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.IpayRenew;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IpayRenewDao extends BaseWriteDao<IpayRenew, Long>{
	
	@Resource
	private CommonDao commonDao;
	
	public Long save(IpayRenew payRenew){
		Long seq = commonDao.getSequnce(ConstantTool.SEQ_IPAY_RENEW);
		payRenew.setId(seq);
		
		return super.save(payRenew);
	}
	
	public IpayRenew getPayRenewByApplyId(Long applyId){
		return commonDao.findUniqueByProperty(IpayRenew.class, "applyId", applyId);
	}
}

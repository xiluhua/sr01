package com.taiping.dianshang.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;



/**   
 * @ClassName IspCheckBusinessFlow   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "ISP_BLUEPRINT_FEE_QUOTE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspBlueprintFeeQuote implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -3852360255317000358L;
	@Id
	@Column(name="ID")
	private Long Id;
	@Column(name="BLUE_ID")
	private Long blueId;
	@Column(name="PARTNER_ID")
	private Long partnerId;
	@Column(name="SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name="STATUS")
	private Integer status;
	@Column(name="QUOTE_SERVICE")
	private String quoteService;

	
	public IspBlueprintFeeQuote() {
		super();
	}


	public Long getId() {
		return Id;
	}


	public void setId(Long id) {
		Id = id;
	}


	public Long getBlueId() {
		return blueId;
	}


	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}


	public Long getPartnerId() {
		return partnerId;
	}


	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Integer getSellChannel() {
		return sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}


	public String getQuoteService() {
		return quoteService;
	}


	public void setQuoteService(String quoteService) {
		this.quoteService = quoteService;
	}


	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

}





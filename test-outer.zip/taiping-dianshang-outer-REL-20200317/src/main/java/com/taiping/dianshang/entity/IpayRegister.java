package com.taiping.dianshang.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * IpayRegister entity. 
 */
@Entity
@Table(name = "DS_IPAY_REGISTER")
public class IpayRegister implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	private Long Id;
	private Long applyId = 0l;
	private Long billId;					// ds_ipay_bill的主键
	private String partnerBillId;			// 为什么不直接起名  partnerApplyId，因为考虑到合并支付业务 by xiluhua
	private Integer status;
	private Integer payStatus;
	private String payCompletePageUrl;		// 支付完成后台订单结果展示页
	private String asynPayResultCallbackUrl;// 异步支付结果后台通知地址
	private String paymentMethod;			// 支付方式,Wap支付：wap|支付宝移动wap支付：alipay|微信公众号支付：wechat|快钱移动wap支付：bill99|电脑PC支付：web
	private Integer payResult;	//预支付结果 1成功
	private Date payTime;		//支付时间
	private Date creteTime;		//支付时间
	private Date updateTime;	//支付时间
	private String payUrl;		//支付地址
	private Double premium;				// 保费
	private Integer businessType;		// 业务类型 1. 新契约 2.保全 3.理赔 4.续期
	private String policyDescUrl;						// 保单信息展示地址 B2B2E渠道用
	private String modifyPolicyUrl;						// 修改保单信息地址 B2B2E渠道用
	private String payTemplateCode;	
	private Long partnerId;
	private Integer isMulti = 0;	// 是否合并支付，默认为非
	private String bankAccount;		// 银行账号，支付宝账号
	private String transferChannel;	// 代扣渠道编号
	private String premId;			// 续期缴费id
	private IpayRegisterTemplateCode payRegisterTemplateCode;
	// added by xiluhua 20170509 for 太财境外游产品，多被保人业务
	private List<IspApply> applyList = new ArrayList<IspApply>();
	// getter & setter
	@Id
	@Column(name = "ID", length = 10)
	
	public Long getId() {
		return Id;
	}
	public void setId(Long id) {
		Id = id;
	}
	
	@Column(name = "BILL_ID", length = 10)
	public Long getBillId() {
		if (billId == null) {
			billId = 0l;
		}
		return billId;
	}
	
	public void setBillId(Long billId) {
		this.billId = billId;
	}
	@Column(name = "APPLY_ID", length = 10)
	public Long getApplyId() {
		return applyId;
	}
	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}
	@Column(name = "PAY_COMPLETE_PAGE_URL")
	public String getPayCompletePageUrl() {
		return payCompletePageUrl;
	}
	public void setPayCompletePageUrl(String payCompletePageUrl) {
		this.payCompletePageUrl = payCompletePageUrl;
	}
	
	@Column(name = "ASYN_PAY_RESULT_CALLBACK_URL")
	public String getAsynPayResultCallbackUrl() {
		return asynPayResultCallbackUrl;
	}
	public void setAsynPayResultCallbackUrl(String asynPayResultCallbackUrl) {
		this.asynPayResultCallbackUrl = asynPayResultCallbackUrl;
	}
	
	@Column(name = "PAYMENT_METHOD")
	public String getPaymentMethod() {
		return paymentMethod;
	}
	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}
	
	@Column(name = "PAY_RESULT")
	public Integer getPayResult() {
		return payResult;
	}
	public void setPayResult(Integer payResult) {
		this.payResult = payResult;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "PAY_TIME")
	public Date getPayTime() {
		return payTime;
	}
	public void setPayTime(Date payTime) {
		this.payTime = payTime;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreteTime() {
		return creteTime;
	}
	public void setCreteTime(Date creteTime) {
		this.creteTime = creteTime;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	@Column(name = "PAY_URL")
	public String getPayUrl() {
		return payUrl;
	}
	public void setPayUrl(String payUrl) {
		this.payUrl = payUrl;
	}
	@Column(name = "PREMIUM")
	public Double getPremium() {
		return premium;
	}
	public void setPremium(Double premium) {
		this.premium = premium;
	}
	@Column(name = "BUSINESS_TYPE")
	public Integer getBusinessType() {
		return businessType;
	}
	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}
	@Column(name = "STATUS")
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	@Column(name = "POLICY_DESC_URL")
	public String getPolicyDescUrl() {
		return policyDescUrl;
	}
	public void setPolicyDescUrl(String policyDescUrl) {
		this.policyDescUrl = policyDescUrl;
	}
	@Column(name = "MODIFY_POLICY_URL")
	public String getModifyPolicyUrl() {
		return modifyPolicyUrl;
	}
	public void setModifyPolicyUrl(String modifyPolicyUrl) {
		this.modifyPolicyUrl = modifyPolicyUrl;
	}
	@Transient
	public IpayRegisterTemplateCode getPayRegisterTemplateCode() {
		return payRegisterTemplateCode;
	}
	public void setPayRegisterTemplateCode(
			IpayRegisterTemplateCode payRegisterTemplateCode) {
		this.payRegisterTemplateCode = payRegisterTemplateCode;
	}
	@Column(name = "PAY_TEMPLATE_CODE")
	public String getPayTemplateCode() {
		return payTemplateCode;
	}
	public void setPayTemplateCode(String payTemplateCode) {
		this.payTemplateCode = payTemplateCode;
	}
	@Transient
	public List<IspApply> getApplyList() {
		return applyList;
	}
	public void setApplyList(List<IspApply> applyList) {
		this.applyList = applyList;
	}
	@Override
	public String toString() {
		return "IpayRegister [Id=" + Id + ", applyId=" + applyId + ", billId="
				+ billId + ", status=" + status + ", payCompletePageUrl="
				+ payCompletePageUrl + ", asynPayResultCallbackUrl="
				+ asynPayResultCallbackUrl + ", paymentMethod=" + paymentMethod
				+ ", payResult=" + payResult + ", payTime=" + payTime
				+ ", creteTime=" + creteTime + ", updateTime=" + updateTime
				+ ", payUrl=" + payUrl + ", premium=" + premium
				+ ", businessType=" + businessType + ", policyDescUrl="
				+ policyDescUrl + ", modifyPolicyUrl=" + modifyPolicyUrl
				+ ", payTemplateCode=" + payTemplateCode
				+ ", payRegisterTemplateCode=" + payRegisterTemplateCode
				+ ", applyList=" + applyList + "]";
	}
	
	@Column(name = "PARTNER_BILL_ID")
	public String getPartnerBillId() {
		return partnerBillId;
	}
	public void setPartnerBillId(String partnerBillId) {
		this.partnerBillId = partnerBillId;
	}
	@Column(name = "PARTNER_ID")
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	@Column(name = "PAY_STATUS")
	public Integer getPayStatus() {
		if (this.payStatus == null) {
			this.payStatus = 0;
		}
		return payStatus;
	}
	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}
	@Column(name = "IS_MULTI")
	public Integer getIsMulti() {
		return isMulti;
	}
	public void setIsMulti(Integer isMulti) {
		this.isMulti = isMulti;
	}
	@Column(name = "BANK_ACCOUNT")
	public String getBankAccount() {
		return bankAccount;
	}
	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
	@Column(name = "TRANSFER_CHANNEL")
	public String getTransferChannel() {
		return transferChannel;
	}
	public void setTransferChannel(String transferChannel) {
		this.transferChannel = transferChannel;
	}
	@Column(name = "PREM_ID")
	public String getPremId() {
		return premId;
	}
	public void setPremId(String premId) {
		this.premId = premId;
	}
	
	
}
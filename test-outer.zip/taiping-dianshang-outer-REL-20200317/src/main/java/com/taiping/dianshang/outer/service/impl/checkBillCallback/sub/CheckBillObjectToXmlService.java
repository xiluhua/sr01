package com.taiping.dianshang.outer.service.impl.checkBillCallback.sub;

import com.taiping.dianshang.entity.IspApply;

public interface CheckBillObjectToXmlService {

	public String objectToXml(IspApply apply);
}

package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Repository;
import com.taiping.dianshang.entity.ImsLogLevel;
import com.taiping.facility.cache.CacheListDaoService;
import com.taiping.framework.dao.BaseWriteDao;

@Repository
public class ImsLogLevelDao extends BaseWriteDao<ImsLogLevel, Long> implements CacheListDaoService{
	
	public Map<Object,String> getAllInMap(){
		List<ImsLogLevel> list = this.getAll();
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				ImsLogLevel logLevel = list.get(i);
				if (logLevel.getClassName() != null) {
					map.put(logLevel.getClassName(), String.valueOf(logLevel.getLogLevel()));   	
				}
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<ImsLogLevel> getAll(){
		String hql = "from ImsLogLevel t where t.status = 1";
		return super.getSession().createQuery(hql).list();
	}
}
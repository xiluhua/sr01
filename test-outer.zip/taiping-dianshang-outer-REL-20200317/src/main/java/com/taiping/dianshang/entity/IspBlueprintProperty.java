package com.taiping.dianshang.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.codehaus.jackson.annotate.JsonIgnoreProperties;

/**
 * IspBlueprintProperty entity. 
 */
@Entity
@Table(name = "CP_ISP_BLUEPRINT_PROPERTY")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class IspBlueprintProperty implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long blueprintPropertyId;
	private String insuredGender;
	private String insuredAge;
	private String chargePeriodList;
	private String chargeTypeList;
	private String chargeYearList;
	private String amountList;
	private String trialItemList;
	private String trialItemFunction;
	private String tifItemList;
	private String bonusModeList;
	private String coverOrganList;
	private Long coverType;
	private Long coverYear;
	private Integer isUnitTrial;
	private Integer isValidate;
	private Double minPremium;
	private Integer deliverType;
	private Long blueId;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private String RHolderInstList;
	private Double maxAmount;
	private String coverPeriodList;
	private String idTypeList;
	private Integer canRenewapply;
	private String validateDateDes;
	private Double premiumUnitVale;
	private Integer defChargeType;
	private Integer isAmountSelfInput;
	private String amountSelfInputDes;
	private String insuredWorkBigType;
	private Integer insuredBuyCount;

	// Constructors

	/** default constructor */
	public IspBlueprintProperty() {
	}

	/** minimal constructor */
	public IspBlueprintProperty(Long blueprintPropertyId) {
		this.blueprintPropertyId = blueprintPropertyId;
	}

	/** full constructor */
	public IspBlueprintProperty(Long blueprintPropertyId,
			String insuredGender, String insuredAge, String chargePeriodList,
			String chargeTypeList, String chargeYearList, String amountList,
			String trialItemList, String trialItemFunction, String tifItemList,
			String bonusModeList, String coverOrganList, Long coverType,
			Long coverYear, Integer isUnitTrial, Integer isValidate,
			Double minPremium, Integer deliverType, Long blueId,
			Date createTime, Date updateTime, String createAid,
			String updateAid, String RHolderInstList, Double maxAmount,
			String coverPeriodList, String idTypeList, Integer canRenewapply,
			String validateDateDes, Double premiumUnitVale,
			Integer defChargeType, Integer isAmountSelfInput,
			String amountSelfInputDes, String insuredWorkBigType,
			Integer insuredBuyCount) {
		this.blueprintPropertyId = blueprintPropertyId;
		this.insuredGender = insuredGender;
		this.insuredAge = insuredAge;
		this.chargePeriodList = chargePeriodList;
		this.chargeTypeList = chargeTypeList;
		this.chargeYearList = chargeYearList;
		this.amountList = amountList;
		this.trialItemList = trialItemList;
		this.trialItemFunction = trialItemFunction;
		this.tifItemList = tifItemList;
		this.bonusModeList = bonusModeList;
		this.coverOrganList = coverOrganList;
		this.coverType = coverType;
		this.coverYear = coverYear;
		this.isUnitTrial = isUnitTrial;
		this.isValidate = isValidate;
		this.minPremium = minPremium;
		this.deliverType = deliverType;
		this.blueId = blueId;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
		this.RHolderInstList = RHolderInstList;
		this.maxAmount = maxAmount;
		this.coverPeriodList = coverPeriodList;
		this.idTypeList = idTypeList;
		this.canRenewapply = canRenewapply;
		this.validateDateDes = validateDateDes;
		this.premiumUnitVale = premiumUnitVale;
		this.defChargeType = defChargeType;
		this.isAmountSelfInput = isAmountSelfInput;
		this.amountSelfInputDes = amountSelfInputDes;
		this.insuredWorkBigType = insuredWorkBigType;
		this.insuredBuyCount = insuredBuyCount;
	}

	// Property accessors
	@Id
	@Column(name = "BLUEPRINT_PROPERTY_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getBlueprintPropertyId() {
		return this.blueprintPropertyId;
	}

	public void setBlueprintPropertyId(Long blueprintPropertyId) {
		this.blueprintPropertyId = blueprintPropertyId;
	}

	@Column(name = "INSURED_GENDER", length = 20)
	public String getInsuredGender() {
		return this.insuredGender;
	}

	public void setInsuredGender(String insuredGender) {
		this.insuredGender = insuredGender;
	}

	@Column(name = "INSURED_AGE", length = 20)
	public String getInsuredAge() {
		return this.insuredAge;
	}

	public void setInsuredAge(String insuredAge) {
		this.insuredAge = insuredAge;
	}

	@Column(name = "CHARGE_PERIOD_LIST", length = 1000)
	public String getChargePeriodList() {
		return this.chargePeriodList;
	}

	public void setChargePeriodList(String chargePeriodList) {
		this.chargePeriodList = chargePeriodList;
	}

	@Column(name = "CHARGE_TYPE_LIST", length = 1000)
	public String getChargeTypeList() {
		return this.chargeTypeList;
	}

	public void setChargeTypeList(String chargeTypeList) {
		this.chargeTypeList = chargeTypeList;
	}

	@Column(name = "CHARGE_YEAR_LIST", length = 1000)
	public String getChargeYearList() {
		return this.chargeYearList;
	}

	public void setChargeYearList(String chargeYearList) {
		this.chargeYearList = chargeYearList;
	}

	@Column(name = "AMOUNT_LIST", length = 1000)
	public String getAmountList() {
		return this.amountList;
	}

	public void setAmountList(String amountList) {
		this.amountList = amountList;
	}

	@Column(name = "TRIAL_ITEM_LIST", length = 1000)
	public String getTrialItemList() {
		return this.trialItemList;
	}

	public void setTrialItemList(String trialItemList) {
		this.trialItemList = trialItemList;
	}

	@Column(name = "TRIAL_ITEM_FUNCTION")
	public String getTrialItemFunction() {
		return this.trialItemFunction;
	}

	public void setTrialItemFunction(String trialItemFunction) {
		this.trialItemFunction = trialItemFunction;
	}

	@Column(name = "TIF_ITEM_LIST", length = 1000)
	public String getTifItemList() {
		return this.tifItemList;
	}

	public void setTifItemList(String tifItemList) {
		this.tifItemList = tifItemList;
	}

	@Column(name = "BONUS_MODE_LIST", length = 1000)
	public String getBonusModeList() {
		return this.bonusModeList;
	}

	public void setBonusModeList(String bonusModeList) {
		this.bonusModeList = bonusModeList;
	}

	@Column(name = "COVER_ORGAN_LIST", length = 1000)
	public String getCoverOrganList() {
		return this.coverOrganList;
	}

	public void setCoverOrganList(String coverOrganList) {
		this.coverOrganList = coverOrganList;
	}

	@Column(name = "COVER_TYPE", precision = 10, scale = 0)
	public Long getCoverType() {
		return this.coverType;
	}

	public void setCoverType(Long coverType) {
		this.coverType = coverType;
	}

	@Column(name = "COVER_YEAR", precision = 10, scale = 0)
	public Long getCoverYear() {
		return this.coverYear;
	}

	public void setCoverYear(Long coverYear) {
		this.coverYear = coverYear;
	}

	@Column(name = "IS_UNIT_TRIAL", precision = 3, scale = 0)
	public Integer getIsUnitTrial() {
		return this.isUnitTrial;
	}

	public void setIsUnitTrial(Integer isUnitTrial) {
		this.isUnitTrial = isUnitTrial;
	}

	@Column(name = "IS_VALIDATE", precision = 3, scale = 0)
	public Integer getIsValidate() {
		return this.isValidate;
	}

	public void setIsValidate(Integer isValidate) {
		this.isValidate = isValidate;
	}

	@Column(name = "MIN_PREMIUM", precision = 12)
	public Double getMinPremium() {
		return this.minPremium;
	}

	public void setMinPremium(Double minPremium) {
		this.minPremium = minPremium;
	}

	@Column(name = "DELIVER_TYPE", precision = 3, scale = 0)
	public Integer getDeliverType() {
		return this.deliverType;
	}

	public void setDeliverType(Integer deliverType) {
		this.deliverType = deliverType;
	}

	@Column(name = "BLUE_ID", precision = 10, scale = 0)
	public Long getBlueId() {
		return this.blueId;
	}

	public void setBlueId(Long blueId) {
		this.blueId = blueId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Column(name = "R_HOLDER_INST_LIST", length = 1000)
	public String getRHolderInstList() {
		return this.RHolderInstList;
	}

	public void setRHolderInstList(String RHolderInstList) {
		this.RHolderInstList = RHolderInstList;
	}

	@Column(name = "MAX_AMOUNT", precision = 12)
	public Double getMaxAmount() {
		return this.maxAmount;
	}

	public void setMaxAmount(Double maxAmount) {
		this.maxAmount = maxAmount;
	}

	@Column(name = "COVER_PERIOD_LIST", length = 1000)
	public String getCoverPeriodList() {
		return this.coverPeriodList;
	}

	public void setCoverPeriodList(String coverPeriodList) {
		this.coverPeriodList = coverPeriodList;
	}

	@Column(name = "ID_TYPE_LIST", length = 1000)
	public String getIdTypeList() {
		return this.idTypeList;
	}

	public void setIdTypeList(String idTypeList) {
		this.idTypeList = idTypeList;
	}

	@Column(name = "CAN_RENEWAPPLY", precision = 3, scale = 0)
	public Integer getCanRenewapply() {
		return this.canRenewapply;
	}

	public void setCanRenewapply(Integer canRenewapply) {
		this.canRenewapply = canRenewapply;
	}

	@Column(name = "VALIDATE_DATE_DES", length = 50)
	public String getValidateDateDes() {
		return this.validateDateDes;
	}

	public void setValidateDateDes(String validateDateDes) {
		this.validateDateDes = validateDateDes;
	}

	@Column(name = "PREMIUM_UNIT_VALE", precision = 12)
	public Double getPremiumUnitVale() {
		return this.premiumUnitVale;
	}

	public void setPremiumUnitVale(Double premiumUnitVale) {
		this.premiumUnitVale = premiumUnitVale;
	}

	@Column(name = "DEF_CHARGE_TYPE", precision = 3, scale = 0)
	public Integer getDefChargeType() {
		return this.defChargeType;
	}

	public void setDefChargeType(Integer defChargeType) {
		this.defChargeType = defChargeType;
	}

	@Column(name = "IS_AMOUNT_SELF_INPUT", precision = 3, scale = 0)
	public Integer getIsAmountSelfInput() {
		return this.isAmountSelfInput;
	}

	public void setIsAmountSelfInput(Integer isAmountSelfInput) {
		this.isAmountSelfInput = isAmountSelfInput;
	}

	@Column(name = "AMOUNT_SELF_INPUT_DES", length = 2000)
	public String getAmountSelfInputDes() {
		return this.amountSelfInputDes;
	}

	public void setAmountSelfInputDes(String amountSelfInputDes) {
		this.amountSelfInputDes = amountSelfInputDes;
	}
	

	@Column(name = "INSURED_WORK_BIG_TYPE", length = 20)
	public String getInsuredWorkBigType() {
		return this.insuredWorkBigType;
	}

	public void setInsuredWorkBigType(String insuredWorkBigType) {
		this.insuredWorkBigType = insuredWorkBigType;
	}

	@Column(name = "INSURED_BUY_COUNT", precision = 2, scale = 0)
	public Integer getInsuredBuyCount() {
		return this.insuredBuyCount;
	}

	public void setInsuredBuyCount(Integer insuredBuyCount) {
		this.insuredBuyCount = insuredBuyCount;
	}

}
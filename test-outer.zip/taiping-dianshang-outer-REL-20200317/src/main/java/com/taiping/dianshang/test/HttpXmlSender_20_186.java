package com.taiping.dianshang.test;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.utils.CreateDTOTool;
import com.taiping.facility.tool.HttpclientTool;
import com.taiping.facility.tool.LogTool;

/**
 * 同步方案
 * @author Administrator
 *
 */
public class HttpXmlSender_20_186 {

	public static void main(String[] args) throws Exception {
		String encode = "GBK";
		
		String content = CreateDTOTool.create(20,"186_LOCAL20160316_10",true,1);

		LogTool.info(HttpXmlSender_20_186.class, "content:{}", content);
		
		String url = "http://localhost:7788/taiping-dianshang-core/services/rest/core/business/entrance";

		String response = HttpclientTool.post(url, content, encode);
		
		System.out.println("response:"+Base64Tool.decode(response, "utf-8"));
	}
}

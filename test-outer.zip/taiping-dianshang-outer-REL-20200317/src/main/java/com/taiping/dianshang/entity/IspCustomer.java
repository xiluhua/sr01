package com.taiping.dianshang.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * IspCustomer entity.
 */
@Entity
@Table(name = "SC_ISP_APP_CUSTOMER")
public class IspCustomer implements java.io.Serializable {

	// Fields
	/**
	 * 
	 */
	private static final long serialVersionUID = 3589346042123254439L;
	private String appCustId;
	private String custName;
	private Integer custType;
	private Integer gender;
	private Date birthday;
	private Integer idType;
	private String idNo;
	private String occupCode;
	private String mobile;
	private String telephone;
	private String email;
	private String postCode;
	private String address;
	private Long applyId;
	private String appNo;
	private String policyNo;
	private Long cardApplyId;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private Date appDate;
	private Date startDate;
	private Date endDate;
	private Integer payCount;
	private BigDecimal payOneAmount;
	private Date IdNoEndDate;
	
	@Column(name = "ID_NO_END_DATE")
	public Date getIdNoEndDate() {
		return IdNoEndDate;
	}

	public void setIdNoEndDate(Date idNoEndDate) {
		IdNoEndDate = idNoEndDate;
	}
	// Constructors

	/** default constructor */
	public IspCustomer() {
	}

	/** minimal constructor */
	public IspCustomer(String appCustId) {
		this.appCustId = appCustId;
	}

	/** full constructor */
	public IspCustomer(String appCustId, String custName, Integer custType,
			Integer gender, Date birthday, Integer idType, String idNo,
			String occupCode, String mobile, String telephone, String email,
			String postCode, String address, Long applyId, String appNo,
			String policyNo, Long cardApplyId, Date createTime,
			Date updateTime, String createAid, String updateAid,
			Date appDate, Date startDate, Date endDate, Integer payCount,
			BigDecimal payOneAmount) {
		this.appCustId = appCustId;
		this.custName = custName;
		this.custType = custType;
		this.gender = gender;
		this.birthday = birthday;
		this.idType = idType;
		this.idNo = idNo;
		this.occupCode = occupCode;
		this.mobile = mobile;
		this.telephone = telephone;
		this.email = email;
		this.postCode = postCode;
		this.address = address;
		this.applyId = applyId;
		this.appNo = appNo;
		this.policyNo = policyNo;
		this.cardApplyId = cardApplyId;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
		this.appDate = appDate;
		this.startDate = startDate;
		this.endDate = endDate;
		this.payCount = payCount;
		this.payOneAmount = payOneAmount;
	}

	// Property accessors
	@Id
	@Column(name = "APP_CUST_ID", unique = true, nullable = false, length = 32)
	public String getAppCustId() {
		return this.appCustId;
	}

	public void setAppCustId(String appCustId) {
		this.appCustId = appCustId;
	}

	@Column(name = "CUST_NAME", length = 200)
	public String getCustName() {
		return this.custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	@Column(name = "CUST_TYPE", precision = 3, scale = 0)
	public Integer getCustType() {
		return this.custType;
	}

	public void setCustType(Integer custType) {
		this.custType = custType;
	}

	@Column(name = "GENDER", precision = 3, scale = 0)
	public Integer getGender() {
		return this.gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "BIRTHDAY", length = 7)
	public Date getBirthday() {
		return this.birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	@Column(name = "ID_TYPE", precision = 3, scale = 0)
	public Integer getIdType() {
		return this.idType;
	}

	public void setIdType(Integer idType) {
		this.idType = idType;
	}

	@Column(name = "ID_NO", length = 30)
	public String getIdNo() {
		return this.idNo;
	}

	public void setIdNo(String idNo) {
		this.idNo = idNo;
	}

	@Column(name = "OCCUP_CODE", length = 20)
	public String getOccupCode() {
		return this.occupCode;
	}

	public void setOccupCode(String occupCode) {
		this.occupCode = occupCode;
	}

	@Column(name = "MOBILE", length = 50)
	public String getMobile() {
		return this.mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Column(name = "TELEPHONE", length = 50)
	public String getTelephone() {
		return this.telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	@Column(name = "EMAIL", length = 100)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "POST_CODE", length = 15)
	public String getPostCode() {
		return this.postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	@Column(name = "ADDRESS", length = 500)
	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "APPLY_ID", precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Column(name = "APP_NO", length = 20)
	public String getAppNo() {
		return this.appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	@Column(name = "POLICY_NO", length = 50)
	public String getPolicyNo() {
		return this.policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	@Column(name = "CARD_APPLY_ID", precision = 10, scale = 0)
	public Long getCardApplyId() {
		return this.cardApplyId;
	}

	public void setCardApplyId(Long cardApplyId) {
		this.cardApplyId = cardApplyId;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "APP_DATE", length = 7)
	public Date getAppDate() {
		return this.appDate;
	}

	public void setAppDate(Date appDate) {
		this.appDate = appDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "START_DATE", length = 7)
	public Date getStartDate() {
		return this.startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "END_DATE", length = 7)
	public Date getEndDate() {
		return this.endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
	@Column(name = "PAY_COUNT", precision = 5, scale = 0)
	public Integer getPayCount() {
		return this.payCount;
	}

	public void setPayCount(Integer payCount) {
		this.payCount = payCount;
	}

	@Column(name = "PAY_ONE_AMOUNT", precision = 12)
	public BigDecimal getPayOneAmount() {
		return this.payOneAmount;
	}

	public void setPayOneAmount(BigDecimal payOneAmount) {
		this.payOneAmount = payOneAmount;
	}

}
package com.taiping.dianshang.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.taiping.dianshang.entity.CXIspBlueprintProperty;
import com.taiping.facility.cache.CacheDaoService;
import com.taiping.framework.dao.BaseWriteDao;
import com.taiping.framework.dao.CommonDao;

@Repository
public class IspBlueprintPropertyCxDao extends BaseWriteDao<CXIspBlueprintProperty, Long> implements CacheDaoService{

	@Resource
	private CommonDao commonDao;
	
	public Map<Object,CXIspBlueprintProperty> getAllInMap(){
		List<CXIspBlueprintProperty> list = this.getAll();
		Map<Object,CXIspBlueprintProperty> map = null;
		if (list != null) {
			map = new HashMap<Object, CXIspBlueprintProperty>();
			for (int i = 0; i < list.size(); i++) {
				CXIspBlueprintProperty blueprintProperty = list.get(i);
				map.put(blueprintProperty.getBlueId(), blueprintProperty);
			}
		}
		
		return map;
	}
	
	@SuppressWarnings("unchecked")
	public List<CXIspBlueprintProperty> getAll(){
		String hql = "from CXIspBlueprintProperty";
		return super.getSession().createQuery(hql).list();
	}
	
	/**
	 * 根据blueId获得CXIspBluePrintProperty
	 * @param blueId
	 * @return
	 */
	public CXIspBlueprintProperty getCxIspBluePrintProperty(Long blueId){
		Query query = commonDao.getSessionRead().createQuery("from CXIspBlueprintProperty t where t.blueId = ?");
		query.setLong(0, blueId);
		CXIspBlueprintProperty blueprintProperty = (CXIspBlueprintProperty) query.uniqueResult();
		return blueprintProperty;
	}
}

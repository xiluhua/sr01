package com.taiping.dianshang.outer.service.impl.payCallback;

import java.io.IOException;
import java.net.URLDecoder;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.xml.bind.JAXBException;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.dao.IpayPayDao;
import com.taiping.dianshang.dao.IpayRegisterDao;
import com.taiping.dianshang.dao.IpayRenewDao;
import com.taiping.dianshang.dao.IspApplyDao;
import com.taiping.dianshang.dao.IspRetryRecordDao;
import com.taiping.dianshang.entity.IpayPay;
import com.taiping.dianshang.entity.IpayRegister;
import com.taiping.dianshang.entity.IpayRenew;
import com.taiping.dianshang.entity.IspApply;
import com.taiping.dianshang.entity.IspPartner;
import com.taiping.dianshang.entity.IspPayCallback;
import com.taiping.dianshang.entity.IspRetryRecord;
import com.taiping.dianshang.outer.DTO.request.RequestPayCallbackDTO;
import com.taiping.dianshang.outer.DTO.response.ResponseDTO;
import com.taiping.dianshang.outer.service.PayCallbackService;
import com.taiping.dianshang.outer.service.SignService;
import com.taiping.dianshang.outer.service.impl.shortMsg.ShortMsgImpl_ERR_COMMON;
import com.taiping.dianshang.service.httpclient.HttpclientService;
import com.taiping.dianshang.service.log.BusinesslogService;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JAXBTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.MapTool;

/**
 * 支付回调
 * @author xilh
 * @since 2017-06-29
 */
@Service
@Transactional
public class PayCallbackImpl implements PayCallbackService{

	@Resource
	IpayRegisterDao ipayRegisterDao;
	@Resource
	IspApplyDao ispApplyDao;
	@Resource
	IpayPayDao ipayPayDao;
	@Resource
	HttpclientService httpclientService;
	@Resource
	BusinesslogService businesslogService;
	@Resource
	SignService signService;
	@Resource
	IspRetryRecordDao ispRetryRecordDao;
	
	@Override
	public void handle(Map<String, Object> paramsMap) {
		String partnerBillId = MapTool.getStringFromMap(paramsMap, ConstantTool.OPERATE_NO);
		String billId = MapTool.getStringFromMap(paramsMap, ConstantTool.BILL_ID);
		String busiType = MapTool.getStringFromMap(paramsMap, ConstantTool.BUSI_TYPE);
		String errorMsg = "";
		Integer operateStatus = 1;
		
		IpayRegister ipayRegister = null;
		if (!StringUtils.isEmpty(busiType) && StringUtils.defaultString(busiType).equals(ConstantTool.STR_4)) {
			ipayRegister = ipayRegisterDao.getPayRegisterByBillId2(Long.valueOf(billId));
		}else {
			busiType = ConstantTool.STR_1;
			ipayRegister = ipayRegisterDao.getPayRegisterByPartnerBillId(partnerBillId,false);
		}
		// 得到回调报文数据
		if (ipayRegister == null) {
			errorMsg = "无对应预支付信息，流水号："+partnerBillId;
			LogTool.error(this.getClass(), errorMsg);
			operateStatus = 2;
			// 失败日志，便于排查
			businesslogService.postBusinessOpelog_2(new IspApply(partnerBillId), errorMsg, ConstantTool.PAY_CALLBACK, operateStatus, 1);
			return;
		}
		
		IspApply apply = null;
		// 首期
		if (ipayRegister.getBusinessType() == 1) {
			apply = ispApplyDao.getApply(null, null, null, ipayRegister.getApplyId());
		}
		
		// 续期 partnerBillId 就是保单号
		else if (ipayRegister.getBusinessType() == 4) {
			String policyNo = ipayRegister.getPartnerBillId();
			apply = ispApplyDao.getApply(null, policyNo, null, null);
		}
		
		if (apply == null) {
			errorMsg = "无对应投保信息，流水号："+partnerBillId;
			LogTool.error(this.getClass(), errorMsg);
			operateStatus = 3;
			// 失败日志，便于排查
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.PAY_CALLBACK, operateStatus, 1);
			return;
		}
		
		// add by xiluhua 20190507
		if (LogTool.isUat) {
			String noCallback = StringUtils.defaultString(CacheContainer.getSysParamValueNoThrows("no.call.back"));
			if (noCallback.indexOf(apply.getPartnerApplyId()+",") > -1) {
				errorMsg = "test only, no callback!!!";
				operateStatus = 3;
				// 失败日志，便于排查
				businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.PAY_CALLBACK, operateStatus, 1);
				return;
			}
		}
		
		IpayPay pay = ipayPayDao.getPayByBillIdWrite(ipayRegister.getBillId());
		
		// 生成回调报文
		String requestXml = this.objectToXml(pay, ipayRegister, partnerBillId, apply.getSellChannel());
		if (StringUtils.isEmpty(requestXml)) {
			// 失败日志，便于排查
			errorMsg = "生成回调请求报文失败";
			businesslogService.postBusinessOpelog_2(apply, errorMsg, ConstantTool.PAY_CALLBACK, operateStatus, 1);
			return;
		}
		
		String url 		  = ipayRegister.getAsynPayResultCallbackUrl();
		// add by xiluhua 20171201 for partners
		IspPayCallback ispPayCallback = CacheContainer.getPayCallbackByIdFromCache(ipayRegister.getPartnerId(), apply.getSellChannel(), IspPayCallback.class);
		LogTool.debug(this.getClass(), "partnerBillId1: "+ispPayCallback);
		
		if (partnerBillId.indexOf("AUTOTEST") < 0) {
			LogTool.debug(this.getClass(), partnerBillId+" :is not AUTOTEST");
			if (!LogTool.isFormal) {
				LogTool.debug(this.getClass(), partnerBillId+" :isUat");
				
				// 不是测试单，并且 ispPayCallback is not null
				String arr   = StringUtils.defaultString(CacheContainer.getSystemParameterValueNoThrows("partners.go.proxy.url"));
				boolean flag = arr.indexOf(apply.getPartnerId().toString()) > -1; 
				if (flag) {
					url = ispPayCallback.getProxyUrl();
				}
				LogTool.debug(this.getClass(), "partner PayCallbackImpl url: "+url);
			} else {
				LogTool.debug(this.getClass(), "partnerBillId2: "+partnerBillId);
				if (ipayRegister.getPartnerBillId().indexOf("TEST") < 0 && ispPayCallback != null) {
					LogTool.debug(this.getClass(), "partner PayCallbackImpl url: "+ispPayCallback.getProxyUrl());
					url = ispPayCallback.getProxyUrl();
				}
			}
		}
		// -------------- 20171201 over --------------
		
		LogTool.debug(this.getClass(), "PayCallbackImpl url: "+url);
		// 日志（请求）
		businesslogService.postBusinessOpelog_1(apply,url + System.getProperty("line.separator")+requestXml, ConstantTool.PAY_CALLBACK, 1, 1);
		
		// add by xiluhua 20171201 mock only
		if (LogTool.isFormal && ipayRegister.getPartnerBillId().indexOf("TEST") > -1) {
			LogTool.debug(this.getClass(), "attention!!! mock only: "+ipayRegister.getPartnerBillId());
			// 日志（返回）
			businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ "mock only: "+ipayRegister.getPartnerBillId(), ConstantTool.PAY_CALLBACK, 2, 1);
			return;
		}
		
		// 回调
		String responseXml = this.callback(url,requestXml,partnerBillId, apply.getPartnerId());
		// 报文转对象
		ResponseDTO responseDTO = this.xmlToObject(responseXml, partnerBillId);
		
		boolean isSuccess = (responseDTO != null && responseDTO.getBusiness().isSuccess());
		if (!isSuccess) {
			LogTool.info(this.getClass(), paramsMap.toString());
			operateStatus = 0;
			Integer count = MapTool.getIntegerFromMap(paramsMap, ConstantTool.COUNT);
			if (count != null) {
				count++;
			}else {
				count = 1;
			}
			paramsMap.put(ConstantTool.COUNT, count);
			
			// 回调失败短信通知,模板id:2
			if (count > 30) {
				paramsMap.put(ConstantTool.SHORTMSG_TEMP_ID, 2);
				paramsMap.put(ConstantTool.SERVICE_ID, ShortMsgImpl_ERR_COMMON.class.getSimpleName());
				JedisClient_outer2.rpush(ConstantTool.QUEUE_SHORTMSG, JsonTool.toJson(paramsMap));
			}else {
				// 15分钟后再次执行
				paramsMap.put(ConstantTool.NEXT_CALLBACK_TIME, DateTool.add(new Date(), Calendar.MINUTE, 15));
				this.rpush(paramsMap);
				
				// 20180305 add by xiluhua
				this.saveRecord4Balance(partnerBillId, billId, busiType,ipayRegister);
			}
		}
		
		// 日志（返回）
		businesslogService.postBusinessOpelog_2(apply, url + System.getProperty("line.separator")+ responseXml, ConstantTool.PAY_CALLBACK, operateStatus, 1);
		
		// 回调结果更新
		if (isSuccess) {
			// added by xiluhua 20170707 ，必须使用此方法，不然会冲掉 core 工程的更新
			ipayPayDao.update(pay.getPayId());
		}
	}
	
	/**
	 * 为对账方便，将当天回调失败，第二天回调成功的单子存起来
	 * @author xilh
	 * @since 20180306
	 * @param partnerBillId
	 * @param billId
	 * @param busiType
	 * @param ipayRegister
	 */
	private void saveRecord4Balance(String partnerBillId, String billId,String busiType, IpayRegister ipayRegister) {
		String logId = partnerBillId+"_"+billId+"_"+busiType+"_"+ipayRegister.getPremId();
		LogTool.warn(this.getClass(), "=== IspRetryRecord start: "+logId+" ===");
		IspRetryRecord record = new IspRetryRecord();
		record.setClassName(this.getClass().getSimpleName());
		record.setOperateNo(partnerBillId);
		record.setBusiType(Integer.valueOf(busiType));
		record.setBillId(0l);
		record.setPremId(ConstantTool.STR_0);
		if (!StringUtils.isEmpty(billId)) {
			record.setBillId(Long.valueOf(billId));
		}
		if (ipayRegister.getPremId() != null) {
			record.setPremId(ipayRegister.getPremId());
		}
		ispRetryRecordDao.saveOrUpdate(record);
		LogTool.warn(this.getClass(), "=== IspRetryRecord end: "+record.toString()+" ===");
	}
	
	public String objectToXml(IpayPay pay,IpayRegister ipayRegister,String busiId,Integer sellChannel){

		RequestPayCallbackDTO requestPayCallbackDTO = new RequestPayCallbackDTO();
		requestPayCallbackDTO.getBusiness().setBusiId(busiId);
		requestPayCallbackDTO.getBusiness().setPartnerId(String.valueOf(ipayRegister.getPartnerId()));
		requestPayCallbackDTO.getBusiness().setServiceCode(ConstantTool.PAY_CALLBACK);
		requestPayCallbackDTO.getBusiness().setTransTime(new Date());
		requestPayCallbackDTO.getCallback().setBankCard(StringUtils.defaultString(pay.getBuyerAccount(),""));
		// modified by xiluhua 20170927 billId
		requestPayCallbackDTO.getCallback().setBillId(String.valueOf(ipayRegister.getBillId()));
		requestPayCallbackDTO.getCallback().setMerchantNo(StringUtils.defaultString(pay.getMerchantNo(),""));
		requestPayCallbackDTO.getCallback().setPayAmount(pay.getAmount());
		requestPayCallbackDTO.getCallback().setPayBank(StringUtils.defaultString(pay.getPayBank(),""));
		requestPayCallbackDTO.getCallback().setPayerTradeNo(StringUtils.defaultString(pay.getPayerTransNo(),""));
		requestPayCallbackDTO.getCallback().setBusinessType(ipayRegister.getBusinessType());
		// 二级支付方式
		requestPayCallbackDTO.getCallback().setPayerCodeLv2(pay.getPayerCodeLv2());
		
		
		// add by xiluhua 20171124
		// -------------------------------------------
		requestPayCallbackDTO.getCallback().setPremId(ipayRegister.getPremId());
		
		if (sellChannel != null) {
			// 太寿、太养
			if (sellChannel != 3) {
				IspPartner partner = CacheContainer.getByIdFromCache(pay.getPayBank(), IspPartner.class);
				if (partner == null) {
					LogTool.error(this.getClass(), "pay.getPayBank() is null: "+busiId);
					LogTool.error(this.getClass(), "pay.getPayBank() is null: "+pay.getPayBank());
					LogTool.error(this.getClass(), "pay.getPayBank() is null: "+pay.getBillId());
					return null;
				}
				requestPayCallbackDTO.getCallback().setBankCode(partner.getBankCode());
			}else {
				// 太财
				requestPayCallbackDTO.getCallback().setBankCode(pay.getMerchantNo());
			}
			
			// 续期
			// add by xiluhua to support renew business use real MERCHANT_NO
			if (ipayRegister.getBusinessType() == 4) {
				String isPayByJinji = CacheContainer.getSystemParameterValueNoThrows("isPayByJinji");
				if (!StringUtils.isEmpty(isPayByJinji)) {
					requestPayCallbackDTO.getCallback().setBankCode(pay.getMerchantNo());
				}
			}
		}
		// -------------- 20171124 over --------------
		
		String requestXml = null;
		Long partnerId 	  = ipayRegister.getPartnerId();
		try {
			requestXml = JAXBTool.marshal(requestPayCallbackDTO);
			// add by xiluhua 20181113 for 232
			if (ipayRegister.getPartnerId() == 232) {
				requestXml = requestXml.replace("<PAY_TYPE>1</PAY_TYPE>", "");
				requestXml = requestXml.replace("<PAY_TYPE>2</PAY_TYPE>", "");
			}
			// add by liuhe 20190430 for 复星支付 添加支付方式
			if (!ConstantTool.PAY_BANK_FOSUN.equals(pay.getPayBank())) {
		    	String payerCodeLv2Node = "<PAYER_CODE_LV2>"+pay.getPayerCodeLv2()+"</PAYER_CODE_LV2>";
		    	requestXml = requestXml.replace(payerCodeLv2Node,"");
			}
			
			LogTool.info(this.getClass(), "requestXml: "+requestXml);
			
			String noSignPartners = CacheContainer.getSystemParameterValue(ConstantTool.SYS_NO_SIGN_PARTNERS);
			LogTool.info(this.getClass(), "noSignPartners: "+noSignPartners);
			// 需要签名
			if (noSignPartners.indexOf(String.valueOf(partnerId)+",") < 0) {
				// 签名
				String sign = signService.sign(requestXml, partnerId);
				// setSign
				requestPayCallbackDTO.getBusiness().setSign(sign);
				
				requestXml = JAXBTool.marshal(requestPayCallbackDTO);
				// add by xiluhua 20181113 for 232
				if (ipayRegister.getPartnerId() == 232) {
					requestXml = requestXml.replace("<PAY_TYPE>1</PAY_TYPE>", "");
					requestXml = requestXml.replace("<PAY_TYPE>2</PAY_TYPE>", "");
				}
				LogTool.info(this.getClass(), "requestXml signed: "+requestXml);
			}
		} catch (JAXBException e) {
			LogTool.error(this.getClass(), e);
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
		}
		return requestXml;
	}
	
	public String callback(String url,String requestXml,String partnerBillId, Long partnerId){
		String responseXml = "";
		try {
			String needProxy = CacheContainer.getSystemParameterValueNoThrows("callback.need.proxy");
			boolean isProxy  = StringUtils.defaultString(needProxy).indexOf(partnerId+",") > -1;
			LogTool.debug(this.getClass(), partnerBillId+", isProxy: "+isProxy);
			responseXml = httpclientService.post(url, requestXml, ConstantTool.UTF8,ConstantTool.TEXT_XML, isProxy);
			
			LogTool.debug(this.getClass(), "pay callback url: "+url);
			LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
			LogTool.debug(this.getClass(), "responseXml："+responseXml);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
		
		return responseXml;
	}
	
	public String callback(String url,String requestXml,String partnerBillId){
		String responseXml = "";
		try {
			responseXml = httpclientService.post(url, requestXml, ConstantTool.UTF8,ConstantTool.TEXT_XML, false);
			
			LogTool.debug(this.getClass(), "pay callback url: "+url);
			LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
			LogTool.debug(this.getClass(), "responseXml:"+responseXml);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		}
		
		return responseXml;
	}
	
	public ResponseDTO xmlToObject(String responseXml,String partnerBillId){
		ResponseDTO responseDTO = null;
		if (responseXml != null) {
			try {
				responseXml = URLDecoder.decode(responseXml, ConstantTool.UTF8);
				LogTool.debug(this.getClass(), "partnerBillId: "+partnerBillId);
				LogTool.debug(this.getClass(), "xmlToObject responseXml:"+responseXml);
				responseDTO = (ResponseDTO)JAXBTool.unmarshal(responseXml, ResponseDTO.class);
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
		return responseDTO;
	}
	
	public void rpush(Map<String, Object> paramsMap){
		if (!LogTool.localIp.startsWith("10.1") && !LogTool.localIp.startsWith("10.4")) {
			// 本地 localhost
			JedisClient_outer2.rpush(ConstantTool.QUEUE_PAY_CALLBACK_RETRY_LOCAL, JsonTool.toJson(paramsMap));
		}else {
			JedisClient_outer2.rpush(ConstantTool.QUEUE_PAY_CALLBACK_RETRY, JsonTool.toJson(paramsMap));
		}
	}
}

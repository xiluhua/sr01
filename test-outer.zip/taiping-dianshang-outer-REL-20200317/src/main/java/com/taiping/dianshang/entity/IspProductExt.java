package com.taiping.dianshang.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

/**
 * CpIspProductExt entity. 
 */
@Entity
@Table(name = "CP_ISP_PRODUCT_EXT")
public class IspProductExt implements java.io.Serializable {
	private static final long serialVersionUID = 1L;
	
	// Fields

	private Long productExtId;
	private Long productId;
	private String productOrder;
	private Long ma;
	private Long unit;
	private Integer amount;
	private Double premium;
	private Long coverLevel;
	private Long coverType;
	private Long coverYear;
	private Integer chargeFreq;
	private Integer chargeType;
	private Long chargeYear;
	private Long drawFreq;
	private Long drawFstType;
	private Long drawFstYear;
	private Long drawLstType;
	private Long drawLstYear;
	private Long drawEnsure;
	private BigDecimal corePrice;
	private BigDecimal costPrice;
	private BigDecimal salesPrice;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;

	
	private Long coreBaleId; //核心计划ID
	// Constructors


	// Property accessors
	@Id
	@Column(name = "PRODUCT_EXT_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getProductExtId() {
		return this.productExtId;
	}

	public IspProductExt() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setProductExtId(Long productExtId) {
		this.productExtId = productExtId;
	}

	@Column(name = "PRODUCT_ID", precision = 10, scale = 0)
	public Long getProductId() {
		return this.productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	@Column(name = "PRODUCT_ORDER", length = 6)
	public String getProductOrder() {
		return this.productOrder;
	}

	public void setProductOrder(String productOrder) {
		this.productOrder = productOrder;
	}

	@Column(name = "MA", precision = 10, scale = 0)
	public Long getMa() {
		return this.ma;
	}

	public void setMa(Long ma) {
		this.ma = ma;
	}

	@Column(name = "UNIT", precision = 10, scale = 0)
	public Long getUnit() {
		return this.unit;
	}

	public void setUnit(Long unit) {
		this.unit = unit;
	}

	@Column(name = "AMOUNT", precision = 12)
	public Integer getAmount() {
		return this.amount;
	}

	public void setAmount(Integer amount) {
		this.amount = amount;
	}

	@Column(name = "PREMIUM", precision = 12)
	public Double getPremium() {
		return this.premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	@Column(name = "COVER_LEVEL", precision = 10, scale = 0)
	public Long getCoverLevel() {
		return this.coverLevel;
	}

	public void setCoverLevel(Long coverLevel) {
		this.coverLevel = coverLevel;
	}

	@Column(name = "COVER_TYPE", precision = 10, scale = 0)
	public Long getCoverType() {
		return this.coverType;
	}

	public void setCoverType(Long coverType) {
		this.coverType = coverType;
	}

	@Column(name = "COVER_YEAR", precision = 10, scale = 0)
	public Long getCoverYear() {
		return this.coverYear;
	}

	public void setCoverYear(Long coverYear) {
		this.coverYear = coverYear;
	}

	@Column(name = "CHARGE_FREQ", precision = 3, scale = 0)
	public Integer getChargeFreq() {
		return this.chargeFreq;
	}

	public void setChargeFreq(Integer chargeFreq) {
		this.chargeFreq = chargeFreq;
	}

	@Column(name = "CHARGE_TYPE", precision = 3, scale = 0)
	public Integer getChargeType() {
		return this.chargeType;
	}

	public void setChargeType(Integer chargeType) {
		this.chargeType = chargeType;
	}

	@Column(name = "CHARGE_YEAR", precision = 10, scale = 0)
	public Long getChargeYear() {
		return this.chargeYear;
	}

	public void setChargeYear(Long chargeYear) {
		this.chargeYear = chargeYear;
	}

	@Column(name = "DRAW_FREQ", precision = 10, scale = 0)
	public Long getDrawFreq() {
		return this.drawFreq;
	}

	public void setDrawFreq(Long drawFreq) {
		this.drawFreq = drawFreq;
	}

	@Column(name = "DRAW_FST_TYPE", precision = 10, scale = 0)
	public Long getDrawFstType() {
		return this.drawFstType;
	}

	public void setDrawFstType(Long drawFstType) {
		this.drawFstType = drawFstType;
	}

	@Column(name = "DRAW_FST_YEAR", precision = 10, scale = 0)
	public Long getDrawFstYear() {
		return this.drawFstYear;
	}

	public void setDrawFstYear(Long drawFstYear) {
		this.drawFstYear = drawFstYear;
	}

	@Column(name = "DRAW_LST_TYPE", precision = 10, scale = 0)
	public Long getDrawLstType() {
		return this.drawLstType;
	}

	public void setDrawLstType(Long drawLstType) {
		this.drawLstType = drawLstType;
	}

	@Column(name = "DRAW_LST_YEAR", precision = 10, scale = 0)
	public Long getDrawLstYear() {
		return this.drawLstYear;
	}

	public void setDrawLstYear(Long drawLstYear) {
		this.drawLstYear = drawLstYear;
	}

	@Column(name = "DRAW_ENSURE", precision = 10, scale = 0)
	public Long getDrawEnsure() {
		return this.drawEnsure;
	}

	public void setDrawEnsure(Long drawEnsure) {
		this.drawEnsure = drawEnsure;
	}

	@Column(name = "CORE_PRICE", scale = 0)
	public BigDecimal getCorePrice() {
		return this.corePrice;
	}

	public void setCorePrice(BigDecimal corePrice) {
		this.corePrice = corePrice;
	}

	@Column(name = "COST_PRICE", scale = 0)
	public BigDecimal getCostPrice() {
		return this.costPrice;
	}

	public void setCostPrice(BigDecimal costPrice) {
		this.costPrice = costPrice;
	}

	@Column(name = "SALES_PRICE", scale = 0)
	public BigDecimal getSalesPrice() {
		return this.salesPrice;
	}

	public void setSalesPrice(BigDecimal salesPrice) {
		this.salesPrice = salesPrice;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Transient
	public Long getCoreBaleId() {
		return coreBaleId;
	}

	public void setCoreBaleId(Long coreBaleId) {
		this.coreBaleId = coreBaleId;
	}

}
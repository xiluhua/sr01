/**
 * @author tarzan
 * 2017年8月9日上午11:28:19
 * 
 */
package com.taiping.facility.tool.fosun.util;

import org.apache.commons.httpclient.methods.PostMethod;

/**
 * @author tarzan
 * 2017年8月9日上午11:28:19
 */
public class UTF8PostMethod extends PostMethod {
	
	public UTF8PostMethod(String url) {
		super(url);
	}

	@Override
	public String getRequestCharSet() {
		
		//return super.getRequestCharSet();
		return "UTF-8";
	}
	

}

package com.taiping.facility.tool;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;

/**
 * 
 * @author xiluhua by 20160119
 *
 */
public class JAXBTool {

	public static <T> Object unmarshal(String xml,Class<?> target) throws Exception{
		StringReader reader = null;
		try {
			JAXBContext context = JAXBContext.newInstance(target);
			Unmarshaller unmarsheller = context.createUnmarshaller();
			reader = new StringReader(xml);
			JAXBElement<? extends Object> root = unmarsheller.unmarshal(new StreamSource(reader),target);
			return root.getValue();
		} catch (Exception e) {
			throw e;
		}finally{
			if (reader != null) {
				reader.close();
			}
		}
	}
	
	public static String marshal(Object obj) throws JAXBException, IOException{
		Writer writer = null;
		try {
			JAXBContext context = JAXBContext.newInstance(obj.getClass());
			Marshaller marsheller = context.createMarshaller();
			
			writer = new StringWriter();
			marsheller.marshal(obj, writer);
			String result = writer.toString();
			writer.close();
			return result;
		} catch (IOException e) {
			throw e;
		}finally{
			if(writer != null){
				writer.close();
			}
		}
	}
	
	public static String marshal(Object obj,String encode) throws JAXBException, IOException{
		Writer writer = null;
		try {
			JAXBContext context = JAXBContext.newInstance(obj.getClass());
			Marshaller marsheller = context.createMarshaller();
			marsheller.setProperty(Marshaller.JAXB_ENCODING, encode);
			writer = new StringWriter();
			marsheller.marshal(obj, writer);
			String result = writer.toString();
			writer.close();
			return result;
		} catch (IOException e) {
			throw e;
		}finally{
			if(writer != null){
				writer.close();
			}
		}
	}
//	public static void main(String[] args) throws ParseException, JAXBException {
//		
//		//convert Object to xml string
//		RequestCheckDTO checkDTO = null;
//		String checkDTOString = CreateDTOTool.create(1,"178_LOCAL201602211",false,1);
//		System.out.println("====================================================");
//		System.out.println("CheckDTO XML is\n"+checkDTOString);
//		
//		checkDTO = (RequestCheckDTO)JAXBTool.unmarshal(checkDTOString,RequestCheckDTO.class);
//		System.out.println(ToStringBuilder.reflectionToString(checkDTO.getApply()));
//		
//	}
}

/*
 * Copyright (C) 2017 Baidu, Inc. All Rights Reserved.
 */
package com.taiping.facility.tool;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;

import org.apache.commons.codec.binary.Base64;


/**
 * 
 * @author tianhuang@baidu.com
 */
public class RsaUtil {

    /**
     * 测试用公钥
     */
    private static String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCNlzEXEONrdtVIgsDj8vo2PnNCeB1+1sf79MRozF5ynKW1/9WTf6o7GzHEEyGhWv757pEjuSUcNBAkb6gx3W5QB/qjIguOY6k3aI6c0pUmpEEhC99je469w4lW9bLTJ4GelDJfdC0rHi8kKf5UvWCTx7Ku2lkJUNh6ut0DG9xmNwIDAQAB";
//    private static String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCgL6KMI0wzTkGZqSZ1uMJlxQCNQT+PdHFiEI6tu4YVvoI/P2cfYN2S7bdthDhexhbbD+XwpzYwMH/v+lOeRN5Sir4PDkyX50U4f2NAJbGwmleZ6ccPiZQno3b21E4enQzIz0tXOqlYLJz21Us1O5oVffCGLtab6HLqditScfUJ+QIDAQAB";
//    private static String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCjEjVhZLgouxtHWy2h761kIC7HZFhKHlnevQtuZsjOD6vMYMIySFeddCyqlHoyYWN7PkIh3QfnQV4UwG7jhb24pd8FnqvDDcRSqFC7QmmLWPOot8L+l21n8oVcGMCtIBk8igWJqTvlnGM6dspBdxefAsUibXvGDxITukJ8PAVVeQIDAQAB";
//        private static String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC52GelDZBsppSBgFhAkgAuC4tulN8n42yaODhBDpMbZpyYgIFwI214XtQdb4Ke4j31umJ+NrQvBIcIMhthJk0M1Q+4GX6WRP1UeexYlpDYDNVLrrnRmqrFznq8oTECVQpT5Fuk+w0VOfoQTJxdgInInpxj5/4m0Mog6jjYT5lE7wIDAQAB";
//    private static String pubKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC6Vau9GG5WmfCuGOyiWhyPAcTR7OlUt1xjj2Z1im4LVDlsoJnQ3KK91tNMrvR/t5ULQYPNIhljXQ2bwECNp0r1GgLKRt0XWSuVmZlWpNy2DiLgd4dnCT0Z4fic6m02geSYIGoMlatxrjXgT0Bz5/rMztDL++ouGuZbUrFec3dpLQIDAQAB";

    /**
     * 测试用私钥
     */
    private static String priKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAI2XMRcQ42t21UiCwOPy+jY+c0J4HX7Wx/v0xGjMXnKcpbX/1ZN/qjsbMcQTIaFa/vnukSO5JRw0ECRvqDHdblAH+qMiC45jqTdojpzSlSakQSEL32N7jr3DiVb1stMngZ6UMl90LSseLyQp/lS9YJPHsq7aWQlQ2Hq63QMb3GY3AgMBAAECgYAsZK8bkEv9sbCFn5li3xfcUhBJUufMkQL62G+MfCdQwBSkz6XjLS/ugERGOcldke5H5qjTDoW4Jgq5odiWadrf/XNUSzeMfh0nyNDdf3ATro/Wv/QDqEWwl1xQC20HUwW96tpTiVYGyHKxVPZfPlak57qm6OHDvTgfssnps3I9YQJBAMNWSjk+yzomgnmjxjUX+JRegRNNngIct3L4RXH3Ot1YkzuvnJVpvbwK8sKWYB3l+aeqd04w43mx8OTuwEOjRQ0CQQC5j/F4kw69jGaeYGtEkIbVlba/eXT88SRNUPBT+lolODttvL0ktit4pfCfksLHkntyg4ZKtzcLxwtE/eculk9TAkEAhkoJZweLcaPN6VA1UIT1SRMbS6j9qtgRKkIShAICfu+I8OyPCo0SendQY4Q7+fIDy0e/E4s6p4w0Xz7gAN/69QJAFLtKRShY60B2bpdjJKPpDI/PfRD6yw+9+I1kbF16GNJxgU8m6qUXskEH4ywoateoxyB+rnZNxhkU3z5mx8OvVQJALayGH6ypYUgPPYbSESDHhGxdHV0K7z74UMjwEkhBuKhi/OkRoZnPByuAYrqH6bVKmGcAHEFVHXlT3JOx+uLhlQ==";

    /**
     * RSA最大加密明文大小
     */
    private static final int MAX_ENCRYPT_BLOCK = 117;

    /**
     * RSA最大解密密文大小
     */
    private static final int MAX_DECRYPT_BLOCK = 128;

    /**
     * 修改初始化随机因子即可获得不同密钥
     *
     * @throws Exception
     */
    public static void genPair() throws Exception {
        KeyPairGenerator keygen = KeyPairGenerator.getInstance("RSA");
        SecureRandom secrand = new SecureRandom();
        secrand.setSeed("baidu123".getBytes()); // 初始化随机产生器
        keygen.initialize(1024, secrand);
        KeyPair keys = keygen.genKeyPair();

        PublicKey pubkey = keys.getPublic();
        PrivateKey prikey = keys.getPrivate();
        System.out.println("pubKey:" + new String(Base64.encodeBase64(pubkey.getEncoded())));
        System.out.println("prikey:" + new String(Base64.encodeBase64(prikey.getEncoded())));
    }

    /**
     * 生成签名使用SHA1-RSA算法
     * @param content
     * @param privateKey
     * @return
     */
    public static String sign(String content, String privateKey)
    {
        try
        {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec( Base64.decodeBase64(privateKey.getBytes()) );
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey priKey = keyf.generatePrivate(priPKCS8);
            java.security.Signature signature = java.security.Signature.getInstance("SHA256WithRSA");
            signature.initSign(priKey);
            signature.update( content.getBytes());
            byte[] signed = signature.sign();
            return new String (Base64.encodeBase64(signed));
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 生成文件签名使用SHA1-RSA算法
     * @param filePath
     * @param privateKey
     * @return
     */
    public static String signFile(String filePath, String privateKey) {
        try {
            PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decodeBase64(privateKey.getBytes()));
            KeyFactory keyf = KeyFactory.getInstance("RSA");
            PrivateKey priKey = keyf.generatePrivate(priPKCS8);
            java.security.Signature signature = java.security.Signature.getInstance("SHA256WithRSA");
            signature.initSign(priKey);
            BufferedReader fileReader = new BufferedReader(new FileReader(filePath));
            String content;
            while ((content = fileReader.readLine()) != null) {
                signature.update(content.getBytes());
            }
            byte[] signed = signature.sign();
            return new String (Base64.encodeBase64(signed));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 密钥验签 使用SHA1-RSA算法
     * @param content
     * @param sign
     * @param publicKey
     * @param encode
     * @return
     */
    public static boolean doCheck(String content, String sign, String publicKey,String encode)
    {
        try
        {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.decodeBase64(publicKey.getBytes());
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));


            java.security.Signature signature = java.security.Signature
                    .getInstance("SHA256WithRSA");

            signature.initVerify(pubKey);
            signature.update( content.getBytes(encode) );

            boolean bverify = signature.verify( Base64.decodeBase64(sign.getBytes()) );
            return bverify;

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }


    /**
     * 密钥验签 使用SHA1-RSA算法
     * @param filePath
     * @param sign
     * @param publicKey
     * @param encode
     * @return
     */
    public static boolean doCheckFile(String filePath, String sign, String publicKey,String encode)
    {
        try
        {
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            byte[] encodedKey = Base64.decodeBase64(publicKey.getBytes());
            PublicKey pubKey = keyFactory.generatePublic(new X509EncodedKeySpec(encodedKey));


            java.security.Signature signature = java.security.Signature
                    .getInstance("SHA256WithRSA");

            signature.initVerify(pubKey);
            BufferedReader fileReader = new BufferedReader(new FileReader(filePath));
            String content;
            while ((content = fileReader.readLine()) != null) {
                signature.update(content.getBytes(encode));
            }

            boolean bverify = signature.verify(Base64.decodeBase64(sign.getBytes()) );
            return bverify;

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        return false;
    }


    /**
     * <p>
     * 公钥解密
     * </p>
     *
     * @param encryptedString 已加密数据
     * @return
     * @throws Exception
     */
    public static String decryptByPublicKey(String encryptedString) throws Exception {

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] encryptedData = Base64.decodeBase64(encryptedString.getBytes());
            byte[] keyBytes = Base64.decodeBase64(pubKey.getBytes());
            X509EncodedKeySpec x509KeySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key publicK = keyFactory.generatePublic(x509KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.DECRYPT_MODE, publicK);
            int inputLen = encryptedData.length;
            int offSet = 0;
            int i = 0;
            // 对数据分段解密
            calcByBlock(out, encryptedData, cipher, inputLen, offSet, i, MAX_DECRYPT_BLOCK);
            byte[] decryptedData = out.toByteArray();
            return new String(decryptedData);
        } catch (Exception e) {
            throw e;
        } finally {
            out.close();
        }
    }

    private static void calcByBlock(ByteArrayOutputStream out, byte[] encryptedData, Cipher cipher, int inputLen,
                                    int offSet, int i, int blockSize) throws IllegalBlockSizeException,
            BadPaddingException {
        byte[] cache;
        while (inputLen - offSet > 0) {
            if (inputLen - offSet > blockSize) {
                cache = cipher.doFinal(encryptedData, offSet, blockSize);
            } else {
                cache = cipher.doFinal(encryptedData, offSet, inputLen - offSet);
            }
            out.write(cache, 0, cache.length);
            i++;
            offSet = i * blockSize;
        }
    }

    /**
     * <p>
     * 私钥加密
     * </p>
     *
     * @param dataString 源数据
     * @return
     * @throws Exception
     */
    public static String encryptByPrivateKey(String dataString) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] data = dataString.getBytes();
            byte[] keyBytes = Base64.decodeBase64(priKey.getBytes());
            PKCS8EncodedKeySpec pkcs8KeySpec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            RSAPrivateKey privateK = (RSAPrivateKey) keyFactory.generatePrivate(pkcs8KeySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, privateK);
            int inputLen = data.length;
            int offSet = 0;
            int i = 0;
            // 对数据分段加密
            calcByBlock(out, data, cipher, inputLen, offSet, i, MAX_ENCRYPT_BLOCK);
            byte[] encryptedData = out.toByteArray();
            return new String(Base64.encodeBase64(encryptedData));
        } catch (Exception e) {
            throw e;
        } finally {
            out.close();
        }
    }



    /**
     * <p>
     * 公钥加密
     * </p>
     *
     * @param dataString
     * @return
     * @throws Exception
     */
    public static String encryptByPublicKey(String dataString) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
        	String pubKeyFromBaidu = PropertyFileTool.get("pubKey.baidu.provide");
            byte[] data = dataString.getBytes("UTF-8");
            byte[] keyBytes = Base64.decodeBase64(pubKeyFromBaidu.getBytes());
            X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PublicKey key = keyFactory.generatePublic(keySpec);
            Cipher cipher = Cipher.getInstance(keyFactory.getAlgorithm());
            cipher.init(Cipher.ENCRYPT_MODE, key);
            int inputLen = data.length;
            int offSet = 0;
            int i = 0;
            // 对数据分段加密
            calcByBlock(out, data, cipher, inputLen, offSet, i, MAX_ENCRYPT_BLOCK);
            byte[] encryptedData = out.toByteArray();
            return new String(Base64.encodeBase64(encryptedData));
        } catch (Exception e) {
            throw e;
        } finally {
            out.close();
        }
    }

    /**
     * <p>
     * 公钥解密
     * </p>
     *
     * @param encryptedDataString 已加密数据
     * @return
     * @throws Exception
     */
    public static String decryptByPrivateKey(String encryptedDataString) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            byte[] encryptedData = Base64.decodeBase64(encryptedDataString.getBytes("UTF-8"));
            byte[] keyBytes = Base64.decodeBase64(priKey.getBytes());
            PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(keyBytes);
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            Key privateK = keyFactory.generatePrivate(pkcs8EncodedKeySpec);
            Cipher cipher = Cipher.getInstance("RSA");
            cipher.init(Cipher.DECRYPT_MODE, privateK);
            int inputLen = encryptedData.length;
            out = new ByteArrayOutputStream();
            int offSet = 0;
            int i = 0;
            // 对数据分段解密
            calcByBlock(out, encryptedData, cipher, inputLen, offSet, i, MAX_DECRYPT_BLOCK);
            byte[] decryptedData = out.toByteArray();
            out.flush();
            return new String(decryptedData,"UTF-8");
        } catch (Exception e) {
          throw e;
        } finally {
            out.close();
        }

    }


    /**
     * 将元素进行排序
     * @param map
     * @return
     */
    public static String map2SortedStr(Map<String, String> map) {
        Map<String, String> tmp = new TreeMap<String, String>(new Comparator<String>() {

            @Override
            public int compare(String o1, String o2) {
                return o1.compareTo(o2);
            }
        });
        tmp.putAll(map);

        return map2Str(tmp, true);

    }

    /**
     * 将排序后的元素转换成字符串
     * @param map
     * @param needEncoding
     * @return
     */
    public static String map2Str(Map<String, String> map, boolean needEncoding) {
        if (map == null) {
            return "";
        }
        StringBuilder sb = new StringBuilder();
        try {
            for (Map.Entry<String, String> entry : map.entrySet()) {
                sb.append(entry.getKey() + "=" + entry.getValue()).append("&");
            }
            if (sb.length() > 0) {
                sb.deleteCharAt(sb.length() - 1);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return sb.toString();
    }


    /**
     * 将排序后的元素转换成字符串
     * @param obj
     * @param map
     * @return
     */
    public static Map<String, String> getSortMap(String prefix, Object obj, Map<String, String> map) {


        Field[] fields = obj.getClass().getDeclaredFields();

        for (Field field : fields) {
            String name = field.getName();
            String value;
            if (field.getType() == String.class) {
                value = (String) getFieldValueByName(name, obj);
                if (value != null) {
                    map.put(prefix + "." + name, value);
                }
            } else if (field.getType() == List.class) {
                List list = (List)getFieldValueByName(name, obj);
                if (list != null && list.size() > 0) {
                    for (int i = 0; i < list.size(); i++) {
                        getSortMap(prefix + "." + name + "." + i, list.get(i), map);
                    }
                }
            } else {
                if (getFieldValueByName(name, obj) != null) {
                    getSortMap(prefix + "." + name, getFieldValueByName(name, obj), map);
                }
            }
        }
        return map;
    }

    /**
     * 根据属性名获取属性值
     * */
    private static Object getFieldValueByName(String fieldName, Object o) {
        try {
            String firstLetter = fieldName.substring(0, 1).toUpperCase();
            String getter = "get" + firstLetter + fieldName.substring(1);
            Method method = o.getClass().getMethod(getter, new Class[] {});
            Object value = method.invoke(o, new Object[] {});
            return value;
        } catch (Exception e) {
//            e.printStackTrace();
//            System.out.println("get field value error");
            return null;
        }
    }

    /**
     * 测试方法
     * @param args
     * @throws Exception
     */
    public static void main(String args[]) throws Exception {
//        Map<String, String> map = new HashMap<String, String>();
//
//        map.put("mobile", RsaUtil.encryptByPrivateKey("18616538137"));
//        map.put("name", null);
//        map.put("certificateCode", "211224198800001111");
//        map.put("deviceId", null);
//        map.put("province", null);
//        map.put("city", null);
//        map.put("villageName", null);
//        map.put("address", null);
//        map.put("longitude", null);
//        map.put("latitude", null);
//
//        System.out.println("===================私钥加签公钥验签======================");
//        String signData = RsaUtil.sign(RsaUtil.map2SortedStr(map), priKey);
//        System.out.println(signData);
//        System.out.println(RsaUtil.doCheck("Message.Body.PolicyList.0.Apply.AcceptTime=20171212144556&Message.Body"
//                + ".PolicyList.0.Apply.ApplicationNo=2017121212100003&Message.Body.PolicyList.0.Apply"
//                + ".ApplyNo=201712121506130000013&Message.Body.PolicyList.0.Apply.ExpireDate=20171219&Message.Body"
//                + ".PolicyList.0.Apply.InsuredRela=1&Message.Body.PolicyList.0.Apply.Memo=111&Message.Body.PolicyList"
//                + ".0.Apply.PayAmount=4&Message.Body.PolicyList.0.Apply.PayTime=20171212134556&Message.Body"
//                + ".PolicyList.0.Apply.PolicyAmount=50000.00&Message.Body.PolicyList.0.Apply"
//                + ".PolicyNo=2017121212100002&Message.Body.PolicyList.0.Apply.Premium=5.67&Message.Body.PolicyList.0"
//                + ".Apply.Status=3&Message.Body.PolicyList.0.Apply.Unit=1&Message.Body.PolicyList.0.Apply"
//                + ".ValidateDate=20171212&Message.Body.PolicyList.0.Holder"
//                + ".Address=GPfjRNlq1HAaJqa896v5bAZSDevSWDdp6uJkRhjPun3DH7FvFglZ6aQly"
//                + "/BNxA9CZ7GjeR62qp0AYvNvzO9tyT7HwsV2u2T5Ik3lMFAP7LNBUBlLifoNpSBqkZqfkyv+oUoybk8R2hAut6F/Ffw60+oT"
//                + "+1GHgxXdR8F1rDA1lO0=&Message.Body.PolicyList.0.Holder.Birth=20171121&Message.Body.PolicyList.0"
//                + ".Holder"
//                + ".CertNo=ar7pgqMRquY8/n1RoDGHWhv4oq+2tqn2Wuschan8zL284QPdl08CLcsSnIecyTb4gYTzZBMdeZY1zY1lJeYsA0Taas"
//                + "+APXvUEdrtUZKlmLGFJbJhOGMiY7IRvBTkPWosVDDjOLPQRzjRyBpQWmAjZy93dXE8xkOxC8G5JHSeMeU=&Message.Body"
//                + ".PolicyList.0.Holder.CertType=1&Message.Body.PolicyList.0.Holder"
//                + ".Email=LflyEae/btQZ9pz4KbyNqG/vHwTvKoUgmD3+hszEt+eeRyPuA1nuMIsu8fdnYd5jUl+eBZUGTVoV7Mvge0dBa1bsphz"
//                + "/ELYWkBgtyUP8npFq+ruhxGDTgy7sl49uTOqQXVR8FBG1Rtqrus7U7iCGeOuVf/rjR1aynNlq2rm4AHc=&Message.Body"
//                + ".PolicyList.0.Holder.IdExpiry=20170101&Message.Body.PolicyList.0.Holder"
//                + ".Mobile=I2tFTzBeYv7DjD5xOGxOMaxwokx5M0q4WjKrFSipFZEjZw3Ee3EcuJ0RIWyhnOFbbIOkFYP9EFFv9504V9LnZ0FF1"
//                + "/E2uo85jAscfloLi0SE6H3tQ/gdUxLYaUq+REb6nCOEv+ztFzdmv0oPkvTa1m5vt1bSvewhzglNcHXQmNU=&Message.Body"
//                + ".PolicyList.0.Holder.Name=PbczLbYiOpHx6d4QBfYIFEFQr7j0YfTEsOHRF/+R3SHtvaGac3WVXsbx1MbSqlBvi"
//                +
//                "/ZuyXZckJR14Oy80uyz9EcVfc4WH44P7cTMAmasjV6rtDI09W4jfo9Ye7vOUvW2DEMHJfUdvFSZFDK6JAUYoYqLA3HbNMVH9Ez9TAFRZlQ=&Message.Body.PolicyList.0.Holder.Sex=1&Message.Body.PolicyList.0.Holder.Zip=0000&Message.Body.PolicyList.0.Insured.Address=R9tVRdHfBkXpyi7R3f4hcNLW7xS2M8YzVOFjlMvhaG5701+tNwEgbJdvEG7sIo3anB7/XnT/qgMObuXQer9XcFybMLNxFcILZpeAwaVun6Vfrp6gF9G07AVPB6+syJ/VYokGHwtaZzuiyPndTw00ocjuzGPI+YLoCaCb7Gl+K2g=&Message.Body.PolicyList.0.Insured.Birth=20171121&Message.Body.PolicyList.0.Insured.CertNo=h9ya63CO9SnXO9sePHeUsHaogM3G/uQg3rIy2zNtWyWNT7jjh2CmOKk8jMsEb2RuLqkJPIqsprIzLnOxTHMJXAvxc9mR31T80prQlgOrJbG2BauyG4vK3nMIcV4jWA7Rrph/Qp/UcKbpmJ5ZDIC4xrHyALGXjANKeBgOsrFqz4k=&Message.Body.PolicyList.0.Insured.CertType=1&Message.Body.PolicyList.0.Insured.Email=fGJvnld9ffyziFsE6Q5QcHB+rYkPwvgWrqx5msrba4BkL37i1ap3+VXE8koZempWKhPZ4y0fUWJabjzcUyO2zRT7pU0y8HZMMqlR7wODublZaJPFdf2X4nrL8rshEgotxEKDz6cYOgHr9ZIFpSQ+D8GMgqLqfaxHYisQHBnASqo=&Message.Body.PolicyList.0.Insured.IdExpiry=20170101&Message.Body.PolicyList.0.Insured.Mobile=XjAI8IXFi89MP8v/GirEt8SEK7+46gWUxN95hguDoJoCVQu6jSQu96deFjvqen4O91Q4qJpf6hnuyqnNNzI8lwXBCuSlTEBra2eUWnzh6N5hpwrYrsZ026Fnn+9Mpjuwd9re2BmOUgT1pIaPf1Eg55sEz6M2Wd/vpCuS4gemm6M=&Message.Body.PolicyList.0.Insured.Name=Wcwvk3AfHqt/eQV49tAmyqc5zaV1Y/dskSyy7ua9WwNtiJHay3lrSVtCzXrC7K4sOl76825yZ4ZWAD8buWzCq7VcfD9n1gzRXT8GEpymyf3ip3viAU1s26H30OBemlFh2WYEpOTxd/BHn9a99Mgek0ZYvRYM+o5iVKoY8FZ5xuM=&Message.Body.PolicyList.0.Insured.Sex=1&Message.Body.PolicyList.0.Insured.Zip=0000&Message.Header.BizType=101&Message.Header.ChannelId=taiping&Message.Header.RequestTime=20171212115515&Message.Header.SpNo=12312312&Message.Header.Version=1.0", "WMVOK64zIQbcpHRU0Y1DpgIVeGH3hET3Dzvu5GyeuicmEf8ZpTzknCv8J3C0SDaUj37i9wIwNeEWvezp7iUKgAJ1REI++JY0nS3Khz6Mdqyr09C5Px6oKmP6luqLGgFiIyuN4VwLaU2VOOhe/qxtbq3PYJ+KvZZW1fmUthQ/Nio="
//                , pubKey, "UTF-8"));
//
//
////        System.out.println(RsaUtil.decryptByPublicKey(map.get("bankCode")));
//        map.put("sign",signData);
//
//        System.out.println("=====================公钥加密私钥解密====================");
//        OutputStreamWriter writer = new OutputStreamWriter(new ByteArrayOutputStream());
//        String enc = writer.getEncoding();
//        System.out.println("Default Charset=" + Charset.defaultCharset());
//        System.out.println("file.encoding=" + System.getProperty("file.encoding"));
//        System.out.println("Default Charset=" + Charset.defaultCharset());
//        System.out.println("Default Charset in Use=" + enc);
//
//
//        String encryptData = RsaUtil.encryptByPublicKey(new String("不要乱码".getBytes("GBK"), "UTF-8"));
//        System.out.println(encryptData);
//        System.out.println(RsaUtil.decryptByPrivateKey(encryptData));


//        System.out.println(new String(Base64.decodeBase64("6Y2a7oSD7oep5rWj54qx6IWR6Y+C5Zum6LSh6ZCu77+9"), "UTF-8"));
//
//
//        System.out.println("===================私钥加密公钥解密======================");
//        encryptData = RsaUtil.encryptByPrivateKey(map.toString());
//        System.out.println(RsaUtil.decryptByPublicKey("X4RGSXXYjd6JSiOhdiZXE7t6oKrdheNdP7GZJGEWGZyYfpMtyDF3R29R7CjsweBf9a2922OjmHqyDNLPh3XsozbSYvw+Ya6zCgWFcdAPP2xlgDjdddatr2jnEmTjZGTBrHeTgI1hcZGzaP9zNB4cux3sBCfapg43E/kKR7kWAwQ="));
//
//
//        System.out.println("=====================文件私钥加签公钥验签====================");
//        String sign = signFile("/Users/baidu/Downloads/curl_payfront.txt", priKey);
//        System.out.println(sign);
//        System.out.println(doCheckFile("/Users/baidu/Downloads/curl_payfront.txt", sign, pubKey, "UTF-8"));
//
//
//        System.out.println("---------------------------------------------------------");
//        Message message = new Message();
//        Body body = new Body();
//        Map sortMap = getSortMap("Message", message, new HashMap());
//        System.out.println(map2SortedStr(sortMap));
//        message.getBody().setSign(sign("123123",priKey));
//        System.out.println(JAXBTool.marshal(message));


//        System.out.println(doCheck("Message.Body.ApplicationNo=103884622&Message.Body.ApplyNo=134211&Message.Body.BeginTime=20180102150822&Message.Body.CertNo=342221&Message.Body.Mobile=342221199&Message.Body.PolicyNo=321423&Message.Body.UserId=342221&Message.Head.BizType=901&Message.Head.ChannelId=baidu&Message.Head.RequestTime=20180102&Message.Head.SpNo=34222&Message.Head.Version=1.0","ELu24effRNNteusGznaPsJw7N6T2uNVMv8e1b8zFbXHrHulfka/afWbPcmFlOT20CvJ3+pdKaS1YfCewX14+hXe4YeC/So5UpOtw9CMtKwEoVjwqhlZzPzvuHXJwo7g7Og841Bqb4vYQn0WIbtsKLyaJ9Ms81R8RFIIqRxz+Bic=",pubKey,"gbk"));
//
//        System.out.println(decryptByPrivateKey("QfAqZCjqU23uPEHkwovfRE+pXvkgJ4KVsNsavslGE0Y5guovCyK247J++bTJTFMAfzTjZO35IX3S56UWHhdo5ZmNKy4M88SIQ4ZthkOyitMYw/ec6xNmI8StvvpIg2ZgGWJPyzhIFrHlh8svDozFyFTegePQPVLbsfHRnpksG5A="));
//        System.out.println( decryptByPrivateKey
//                ("ISmJHwQim3GnoQIYaJucZBJn32u6QvXNklCcNUCjMMnR1RfaKyHSvU0pGX0+CYlFvCU1NpLEY8Tl6xZY2+ot4ThPYGJ8zL0NX2zgm6wH2OopoTkWE1fHnnan52RofhJsCJMfEMlANdWnWDVseCyTwRQ6PXOeFCoq/3E7rh14y+Y="));
//
//        String tttt = new String (Base64.decodeBase64
//                ("TUlHZk1BMEdDU3FHU0liM0RRRUJBUVVBQTRHTkFEQ0JpUUtCZ1FDTmx6RVhFT05yZHRWSWdzRGo4dm8yUG5OQ2VCMSsxc2Y3OU1Sb3pGNXluS1cxLzlXVGY2bzdHekhFRXlHaFd2NzU3cEVqdVNVY05CQWtiNmd4M1c1UUIvcWpJZ3VPWTZrM2FJNmMwcFVtcEVFaEM5OWplNDY5dzRsVzliTFRKNEdlbERKZmRDMHJIaThrS2Y1VXZXQ1R4N0t1MmxrSlVOaDZ1dDBERzl4bU53SURBUUFC"));
//        System.out.println(tttt);
    	
    	RsaUtil.genPair();
    }
}

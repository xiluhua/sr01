package com.taiping.facility.model;

import java.util.List;

public class OverseasKindBean {
    // 业务方式
    private String kindCode;
    // 代理公司编码
    private String kindName;
    // 第三方公司编码
    private String kindInsured;
    // 产品代码
    private String kindPremium;
    // 交易序号
    private String uwCount;
    // 交易时间
    private String quantity;
    // 交易时间
    private String deductible;
    // 特约信息
    private List<OverseasLimitBean> limitList;
    
	public String getKindCode() {
		return kindCode;
	}
	public void setKindCode(String kindCode) {
		this.kindCode = kindCode;
	}
	public String getKindName() {
		return kindName;
	}
	public void setKindName(String kindName) {
		this.kindName = kindName;
	}
	public String getKindInsured() {
		return kindInsured;
	}
	public void setKindInsured(String kindInsured) {
		this.kindInsured = kindInsured;
	}
	public String getKindPremium() {
		return kindPremium;
	}
	public void setKindPremium(String kindPremium) {
		this.kindPremium = kindPremium;
	}
	public String getUwCount() {
		return uwCount;
	}
	public void setUwCount(String uwCount) {
		this.uwCount = uwCount;
	}
	public String getQuantity() {
		return quantity;
	}
	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}
	public String getDeductible() {
		return deductible;
	}
	public void setDeductible(String deductible) {
		this.deductible = deductible;
	}
	public List<OverseasLimitBean> getLimitList() {
		return limitList;
	}
	public void setLimitList(List<OverseasLimitBean> limitList) {
		this.limitList = limitList;
	}
}

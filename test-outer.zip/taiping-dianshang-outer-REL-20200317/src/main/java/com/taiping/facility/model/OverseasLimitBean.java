package com.taiping.facility.model;

public class OverseasLimitBean {
    // 限额代码
    private String limitCode;
    // 限额名称
    private String limitName;
    // 限额类型
    private String limitType;
    // 限额
    private String limit;
    
	public String getLimitCode() {
		return limitCode;
	}
	public void setLimitCode(String limitCode) {
		this.limitCode = limitCode;
	}
	public String getLimitName() {
		return limitName;
	}
	public void setLimitName(String limitName) {
		this.limitName = limitName;
	}
	public String getLimitType() {
		return limitType;
	}
	public void setLimitType(String limitType) {
		this.limitType = limitType;
	}
	public String getLimit() {
		return limit;
	}
	public void setLimit(String limit) {
		this.limit = limit;
	}

    
}

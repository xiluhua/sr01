package com.taiping.facility.tool;

import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.context.i18n.LocaleContextHolder;


public class DateTool {

	private static Logger log = Logger.getLogger(DateTool.class);
	private static String defaultDatePattern = null;
	public static final String DATE_MASK = "yyyy-MM-dd";
	public static final String DATE_MASK2 = "yyyy年MM月dd日";
	public static final String DATE_MASK3 = "yyyyMMdd";
	public static final String DATE_TIME_MASK = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_TIME_MASK1 = "yyyyMMdd HHmmss";
	public static final String DATE_TIME_MASK2 = "yyyyMMddHHmmss";
	public static final String TIME_PATTERN_MASK_1 = "HH:mm:ss";
	public static final String TIME_PATTERN_MASK_2 = "HH:mm";
	public static final String TIME_PATTERN_MASK_3 = "yyyy-MM";

	public static final Pattern DATE_PATTERN_1 = Pattern
			.compile("\\d{4}-\\d{2}-\\d{2}$");
	public static final Pattern DATE_PATTERN_2 = Pattern
			.compile("\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}$");
	public static final Pattern TIME_PATTERN_1 = Pattern
			.compile("\\d{2}:\\d{2}:\\d{2}$");
	public static final Pattern TIME_PATTERN_2 = Pattern
			.compile("\\d{2}:\\d{2}$");

	public static final int DT_LASTDAY_OF_MONTH = 1; // 当前月的最后一天
	public static final int DT_TODAY_IN_LAST_MONTH = 2; // 上一个月的当天
	public static final int DT_FIRSTDAY_OF_MONTH = 3; // 当前月的第一天

	static {
		System.setProperty("user.timezone", "Asia/Shanghai");

	}

	// ~ Methods
	// ================================================================

	/**
	 * Return default datePattern (MM/dd/yyyy)
	 * 
	 * @return a string representing the date pattern on the UI
	 */
	public static synchronized String getDatePattern() {
		Locale locale = LocaleContextHolder.getLocale();
		try {
			defaultDatePattern = "MM/dd/yyyy";
		} catch (MissingResourceException mse) {
			defaultDatePattern = "yyyy-dd-MM";
		}
		return defaultDatePattern;
	}

	/**
	 * This method attempts to convert an Oracle-formatted date in the form
	 * dd-MMM-yyyy to mm/dd/yyyy.
	 * 
	 * @param aDate
	 *            date from database as a string
	 * @return formatted string for the ui
	 */
	public static final String getDate(Date aDate) {
		SimpleDateFormat df = null;
		String returnValue = "";

		if (aDate != null) {
			df = new SimpleDateFormat(getDatePattern());
			returnValue = df.format(aDate);
		}

		return (returnValue);
	}

	/**
	 * This method generates a string representation of a date/time in the
	 * format you specify on input
	 * 
	 * @param aMask
	 *            the date pattern the string is in
	 * @param strDate
	 *            a string representation of a date
	 * @return a converted Date object
	 * @see java.text.SimpleDateFormat
	 * @throws ParseException
	 */
	public static final Date convertStringToDate(String aMask, String strDate)
			throws ParseException {
		SimpleDateFormat df = null;
		Date date = null;
		df = new SimpleDateFormat(aMask);

		try {
			date = df.parse(strDate);
		} catch (ParseException pe) {
			// log.error("ParseException: " + pe);
			throw new ParseException(pe.getMessage(), pe.getErrorOffset());
		}

		return (date);
	}

	/**
	 * This method returns the current date time in the format: MM/dd/yyyy HH:MM
	 * a
	 * 
	 * @param theTime
	 *            the current time
	 * @return the current date/time
	 */
	public static String getTimeNow(Date theTime) {
		return getDateTime(DateTool.DATE_TIME_MASK, theTime);
	}

	/**
	 * This method returns the current date in the format: MM/dd/yyyy
	 * 
	 * @return the current date
	 * @throws ParseException
	 */
	public static Calendar getToday() throws ParseException {
		Date today = new Date();
		SimpleDateFormat df = new SimpleDateFormat(getDatePattern());

		// This seems like quite a hack (date -> string -> date),
		// but it works ;-)
		String todayAsString = df.format(today);
		Calendar cal = new GregorianCalendar();
		cal.setTime(convertStringToDate(todayAsString));

		return cal;
	}

	/**
	 * This method generates a string representation of a date's date/time in
	 * the format you specify on input
	 * 
	 * @param aMask
	 *            the date pattern the string is in
	 * @param aDate
	 *            a date object
	 * @return a formatted string representation of the date
	 * 
	 * @see java.text.SimpleDateFormat
	 */
	public static final String getDateTime(String aMask, Date aDate) {
		SimpleDateFormat df = null;
		String returnValue = "";

		if (aDate == null) {
			log.error("aDate is null!");
		} else {
			df = new SimpleDateFormat(aMask);
			returnValue = df.format(aDate);
		}

		return (returnValue);
	}

	/**
	 * 解析日期字符串至日期类型内容
	 * 
	 * @param date
	 *            日期字符串
	 * @param format
	 *            与日期字符串格式匹配的格式
	 * @return 解析后返回的日期
	 */
	public static java.util.Date parseDate(String date, String format) {
		try {
			SimpleDateFormat formatter;
			if (null == format)
				throw new IllegalArgumentException("错误的日期格式");
			formatter = new SimpleDateFormat(format);
			ParsePosition pos = new ParsePosition(0);
			return formatter.parse(date, pos);
		} catch (Exception e) {
			throw new IllegalArgumentException("错误的日期:" + date + " " + e);
		}
	}

	/**
	 * This method generates a string representation of a date based on the
	 * System Property 'dateFormat' in the format you specify on input
	 * 
	 * @param aDate
	 *            A date to convert
	 * @return a string representation of the date
	 */
	public static final String convertDateToString(Date aDate) {
		return getDateTime(getDatePattern(), aDate);
	}

	/**
	 * 
	 * @param date
	 * @param pattern
	 * @return
	 */
	public static final String convertDataToString(Date date, String pattern) {
		return getDateTime(pattern, date);
	}

	/**
	 * This method converts a String to a date using the datePattern
	 * 
	 * @param strDate
	 *            the date to convert (in format MM/dd/yyyy)
	 * @return a date object
	 * 
	 * @throws ParseException
	 */
	public static Date convertStringToDate(String strDate)
			throws ParseException {
		Date aDate = null;
		try {
			aDate = convertStringToDate(getDatePattern(), strDate);
		} catch (ParseException pe) {
			log.error("Could not convert '" + strDate
					+ "' to a date, throwing exception");
			pe.printStackTrace();
			throw new ParseException(pe.getMessage(), pe.getErrorOffset());

		}
		return aDate;
	}

	/**
	 * 解析日期字符串至日期类型内容,返回java.sql.Date日期类型数据内容
	 * 
	 * @param date
	 *            日期字符串
	 * @param format
	 *            与日期字符串格式匹配的格式
	 * @return 解析后返回的日期
	 */
	public static java.sql.Date parseSqlDate(String date, String format) {
		try {
			SimpleDateFormat formatter;
			if (null == format)
				throw new IllegalArgumentException("错误的日期格式");
			formatter = new SimpleDateFormat(format);
			ParsePosition pos = new ParsePosition(0);
			java.util.Date utilDate = formatter.parse(date, pos);
			return new java.sql.Date(utilDate.getTime());
		} catch (Exception e) {
			throw new IllegalArgumentException("错误的日期:" + date + " " + e);
		}
	}

	/**
	 * 获取日期格式
	 * 
	 * @param date
	 *            日期字符串
	 * @return 日期格式
	 * @throws Exception
	 *             非法参数或不支持格式错误信息
	 */
	public static String getDatePattern(String date) throws Exception {
		if (date == null || "".equals(date)) {
			throw new java.lang.IllegalArgumentException("非法日期参数，无法解析日期");
		}
		if (DateTool.DATE_PATTERN_1.matcher(date).find()) {
			return "yyyy-MM-dd";
		} else if (DATE_PATTERN_2.matcher(date).find()) {
			return "yyyy-MM-dd HH:mm:ss";
		} else if (TIME_PATTERN_1.matcher(date).find()) {
			return "HH:mm:ss";
		} else if (TIME_PATTERN_2.matcher(date).find()) {
			return "HH:mm";
		} else {
			throw new Exception("未知日期格式，无法解析日期");
		}
	}

	/**
	 * 获取系统时间yyyy-MM-dd HH:mm:ss
	 */
	public static String getSystemDateTime() {
		return DateTool.convertDataToString(new Date(), "yyyy-MM-dd HH:mm:ss");
	}

	/**
	 * 获取系统时间yyyy-MM-dd
	 */
	public static String getSystemDate() {
		return DateTool.convertDataToString(new Date(), "yyyy-MM-dd");
	}

	/**
	 * 获取系统年份
	 * 
	 * @return
	 */
	public static String getSystemYear() {
		return DateTool.convertDataToString(new Date(), "yyyy");
	}

	/**
	 * 截取日期,可以截取到年，月，日，时，分，秒
	 * 
	 * @param date
	 * @param truncType：Calendar.YEAR，
	 *            Calendar.YEAR， Calendar.DAY_OF_MONTH， Calendar.HOUR_OF_DAY，
	 *            Calendar.MINUTE， Calendar.SECOND
	 * @return
	 * @author ykbao
	 * @since 2010-1-22
	 */
	public static Date trunc(Date date, int truncType) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int year, month, day, hour, minute, second;
		year = calendar.get(Calendar.YEAR);
		month = calendar.get(Calendar.MONTH);
		day = calendar.get(Calendar.DAY_OF_MONTH);
		hour = calendar.get(Calendar.HOUR_OF_DAY);
		minute = calendar.get(Calendar.MINUTE);
		second = calendar.get(Calendar.SECOND);

		switch (truncType) {
		case Calendar.YEAR:
			month = Calendar.JANUARY;
		case Calendar.MONTH:
			day = 1;
		case Calendar.DAY_OF_MONTH:
			hour = 0;
		case Calendar.HOUR_OF_DAY:
			minute = 0;
		case Calendar.MINUTE:
			second = 0;
		case Calendar.SECOND:
		default:
		}
		calendar.set(year, month, day, hour, minute, second);
		return calendar.getTime();
	}

	/**
	 * 加减日期,可以加减年，月，日，时，分，秒。
	 * 
	 * @param date
	 * @param field：Calendar.YEAR，
	 *            Calendar.YEAR， Calendar.DAY_OF_MONTH， Calendar.HOUR_OF_DAY，
	 *            Calendar.MINUTE， Calendar.SECOND
	 * @param value:
	 *            要加减的值，可以为负
	 * @return
	 * @author ykbao
	 * @since 2010-1-22
	 */
	public static Date add(Date date, int field, int value) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.set(field, calendar.get(field) + value);
		return calendar.getTime();
	}

	/**
	 * 取当前日期(天)的当前周的第一天和最后一天日期
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String[] getWeek(String date, String format) {
		String[] result = new String[2];
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDate(date, format));
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);
		if (dayOfWeek == 1) {
			calendar.set(Calendar.DAY_OF_YEAR, calendar
					.get(Calendar.DAY_OF_YEAR) - 7);
		}
		calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR)
				- dayOfWeek + 2);
		result[0] = getDateTime(format, calendar.getTime());
		calendar.set(Calendar.DAY_OF_YEAR,
				calendar.get(Calendar.DAY_OF_YEAR) + 6);
		result[1] = getDateTime(format, calendar.getTime());

		return result;
	}

	/**
	 * 取当前日期(天)的当前月的第一天和最后一天日期
	 * 
	 * @param date
	 * @param format
	 * @return
	 */
	public static String[] getMonth(String date, String format) {
		String[] result = new String[2];
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDate(date, format));
		calendar.set(Calendar.DAY_OF_MONTH, 1);
		result[0] = getDateTime(format, calendar.getTime());
		calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + 1);
		calendar.set(Calendar.DAY_OF_YEAR,
				calendar.get(Calendar.DAY_OF_YEAR) - 1);
		result[1] = getDateTime(format, calendar.getTime());

		return result;
	}

	/**
	 * 取当前月份第一天日期和最后一天日期 (yyyy-MM-dd)
	 * 
	 * @return String
	 */
	public static String[] getMothByDay(String date) {
		String[] result = new String[2];
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDate(date, "yyyy-MM-dd"));
		Calendar cpcalendar = (Calendar) calendar.clone();
		cpcalendar.set(Calendar.DAY_OF_MONTH, 1);
		result[0] = df.format(new Date(cpcalendar.getTimeInMillis()));
		cpcalendar.add(Calendar.MONTH, 1);
		cpcalendar.add(Calendar.DATE, -1);
		result[1] = df.format(new Date(cpcalendar.getTimeInMillis()));
		return result;
	}

	/**
	 * 取当前月份第一天日期和最后一天日期 (yyyy-MM-dd)
	 * 
	 * @return String
	 */
	public static String[] getMothByDay(String date, String pattern) {
		String[] result = new String[2];
		SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDate(date, pattern));
		Calendar cpcalendar = (Calendar) calendar.clone();
		cpcalendar.set(Calendar.DAY_OF_MONTH, 1);
		result[0] = df.format(new Date(cpcalendar.getTimeInMillis()));
		cpcalendar.add(Calendar.MONTH, 1);
		cpcalendar.add(Calendar.DATE, -1);
		result[1] = df.format(new Date(cpcalendar.getTimeInMillis()));
		return result;
	}

	public static String getTimePoint(int point) {
		long unit = 3600000;
		Calendar calendar = new GregorianCalendar(2000, 0, 1, 0, 0, 0);
		Date date = new Date(calendar.getTimeInMillis() + unit * point);

		return getDateTime(TIME_PATTERN_MASK_2, date);
	}

	public static String getWeekPoint(int point) {
		String result = null;

		switch (point) {
		case 0:
			result = "周一";
			break;
		case 1:
			result = "周二";
			break;
		case 2:
			result = "周三";
			break;
		case 3:
			result = "周四";
			break;
		case 4:
			result = "周五";
			break;
		case 5:
			result = "周六";
			break;
		case 6:
			result = "周日";
			break;
		}

		return result;
	}

	public static String getWeekPoint(Date date) {
		String result = null;

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		int dayOfWeek = calendar.get(Calendar.DAY_OF_WEEK);

		switch (dayOfWeek) {
		case 1:
			result = "周日";
			break;
		case 2:
			result = "周一";
			break;
		case 3:
			result = "周二";
			break;
		case 4:
			result = "周三";
			break;
		case 5:
			result = "周四";
			break;
		case 6:
			result = "周五";
			break;
		case 7:
			result = "周六";
			break;
		}

		return result;
	}

	public static int getDays4Month(String[] date, String format) {
		int result = 0;
		for (String day : date) {
			if (day != null && !day.equals("") && !day.equalsIgnoreCase("null")) {
				Calendar calendar = Calendar.getInstance();
				calendar.setTime(parseDate(day, format));
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.set(Calendar.MONTH, calendar.get(Calendar.MONTH) + 1);
				calendar.set(Calendar.DAY_OF_YEAR, calendar
						.get(Calendar.DAY_OF_YEAR) - 1);

				int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

				result = dayOfMonth > result ? dayOfMonth : result;
			}
		}

		return result;
	}

	public static String getMonthPoint(Date date) {
		String result = null;

		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);

		result = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));

		return result;
	}

	public static String getLastWeek(String date, String format) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDate(date, format));
		calendar.set(Calendar.DAY_OF_YEAR,
				calendar.get(Calendar.DAY_OF_YEAR) - 7);

		return getDateTime(format, calendar.getTime());
	}

	public static String getLastDay(String date, String format) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(parseDate(date, format));
		calendar.set(Calendar.DAY_OF_YEAR,
				calendar.get(Calendar.DAY_OF_YEAR) - 1);

		return getDateTime(format, calendar.getTime());
	}

	/**
	 * 获取特定日期的格式化日期，以当前日期为基准
	 * 
	 * @param mode
	 *            int
	 *            指定的格式：DT_LASTDAY_OF_MONTH，DT_TODAY_IN_LAST_MONTH，DT_FIRSTDAY_OF_MONTH
	 * @return String
	 */
	public static String formatDate(int mode) {
		String retStr = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar cal = Calendar.getInstance();
		switch (mode) {
		case DateTool.DT_LASTDAY_OF_MONTH:
			cal.set(Calendar.DAY_OF_MONTH, cal
					.getActualMaximum(Calendar.DAY_OF_MONTH));
			break;
		case DateTool.DT_TODAY_IN_LAST_MONTH:
			cal.add(Calendar.MONTH, -1);
			break;
		case DateTool.DT_FIRSTDAY_OF_MONTH:
			cal.set(Calendar.DAY_OF_MONTH, 1);
			break;
		default:
			break;
		}
		retStr = sdf.format(cal.getTime());
		return retStr;
	}

	/**
	 * @see 是否闰年
	 */
	public static boolean isLeapYear(int year) {
		if ((year % 4 == 0) && ((year % 100 != 0) | (year % 400 == 0))) {
			return true;
		} else {
			return false;
		}
	}

	public static Date getYesterday() {
		Date currentTime = new Date();
		return DateTool.getDateAdd(currentTime, Calendar.DATE, -1);
	}

	public static Date getTomorrow() {
		Date currentTime = new Date();
		return DateTool.getDateAdd(currentTime, Calendar.DATE, 1);
	}

	/**
	 * 
	 * @param date
	 * @param i
	 * @see 获取date前i天的日期
	 * @return
	 */
	public static Date getPreviousDay(Date date, int i) {
		return DateTool.getDateAdd(date, Calendar.DATE, (-1) * i);
	}

	/**
	 * 
	 * @param date
	 * @param i
	 * @see 获取date后i天的日期
	 * @return
	 */
	public static Date getNextDay(Date date, int i) {
		return DateTool.getDateAdd(date, Calendar.DATE, i);
	}

	public static String getFormatDate(String format, Date date) {
		String dateString = "";
		if (date != null) {
			SimpleDateFormat formatter = DateFormat.initFormat(format);
			dateString = formatter.format(date);
		}
		return dateString;
	}

	public static Date getDate(String date) throws ParseException {
		SimpleDateFormat formatter = DateFormat.initFormat("yyyy-MM-dd");
		return formatter.parse(date);
	}

	public static Date getDateTime(String date) throws ParseException {
		Date date1;

		try {
			date1 = DateFormat.initFormat("yyyy-MM-dd HH:mm:ss:SSS").parse(date);
		} catch (Exception e) {
			try {
				date1 = DateFormat.initFormat("yyyy-MM-dd HH:mm").parse(date);
			} catch (ParseException e1) {
				try {
					date1 = DateFormat.initFormat("yyyy-MM-dd").parse(date);
				} catch (ParseException e2) {
					date1 = DateFormat.initFormat("yyyy MM dd").parse(date);
				}
			}
		}
		return date1;
	}

	public static Date getDateTime(String date, String format)
			throws ParseException {
		return (DateFormat.initFormat(format)).parse(date);
	}

	public static Date getTime(String time) throws ParseException {
		return (DateFormat.initFormat("HH:mm:ss")).parse(time);
	}

	public static int getAge(Date birthDay) throws Exception {
		Calendar cal = Calendar.getInstance();

		if (cal.before(birthDay)) {
			throw new IllegalArgumentException(
					"The birthDay is before Now.It's unbelievable!");
		}

		int yearNow = cal.get(Calendar.YEAR);
		int monthNow = cal.get(Calendar.MONTH);
		int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);
		cal.setTime(birthDay);

		int yearBirth = cal.get(Calendar.YEAR);
		int monthBirth = cal.get(Calendar.MONTH);
		int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);

		int age = yearNow - yearBirth;

		if (monthNow <= monthBirth) {
			if (monthNow == monthBirth) {
				if (dayOfMonthNow < dayOfMonthBirth) {
					age--;
				} else {
					// do nothing
				}
			} else {
				age--;
			}
		} else {
		}

		return age;
	}

	/**
	 * 
	 * @param date1
	 * @param calendarEx
	 *            like:Calendar.DATE
	 * @param time
	 * @return
	 */
	public static Date getDateAdd(Date date1, int calendarEx, int time) {
		Date endday = date1;
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(endday);
		calendar.add(calendarEx, time);
		return calendar.getTime();

	}

	/**
	 * @see 获取某年月的所有日期
	 * @param year
	 * @param month
	 * @return List<Date>
	 */
	public static List getDateList(String year, String month) {
		List datelist = new ArrayList();
		String bigMonth[] = { "01", "03", "05", "07", "08", "10", "12" };
		String smallMonth[] = { "04", "06", "09", "11" };
		Date tempdate;
		try {
			// 大月
			if (StringTool.isInArray(month, bigMonth)) {
				for (int i = 1; i <= 31; i++) {
					tempdate = DateTool.getDate(year + "-" + month + "-" + i);
					datelist.add(tempdate);
				}
			}
			// 小月
			else if (StringTool.isInArray(month, smallMonth)) {
				for (int i = 1; i <= 30; i++) {
					tempdate = DateTool.getDate(year + "-" + month + "-" + i);
					datelist.add(tempdate);
				}
			}
			// 闰年2月
			else if (DateTool.isLeapYear(Integer.parseInt(year))) {
				for (int i = 1; i <= 29; i++) {
					tempdate = DateTool.getDate(year + "-" + month + "-" + i);
					datelist.add(tempdate);
				}
			}
			// 平年2月
			else {
				for (int i = 1; i <= 28; i++) {
					tempdate = DateTool.getDate(year + "-" + month + "-" + i);
					datelist.add(tempdate);
				}
			}

		} catch (Exception e) {
			LogTool.error(DateTool.class, e);
		}

		return datelist;

	}
	/**
	 * 取得两个日期的差值
	 * @param startTime 开始日期
	 * @param endTime 结束日期
	 * @param 适用于yyyy-MM-dd，精确到日
	 * @return 差值日
	 */
	public static int dateDiff(String startTime, String endTime) {
		SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
		long nd = 1000 * 24 * 60 * 60;
		long diff;
		long day = 0l;
		try {
			diff = sd.parse(endTime).getTime() - sd.parse(startTime).getTime();
			day = diff / nd;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return (int)day;
	}
	
	/**
	 * 取得两个日期的差值
	 * @param startTime 开始日期
	 * @param endTime 结束日期
	 * @param 适用于yyyy-MM-dd，精确到日
	 * @return 差值日
	 */
	public static int dateDiff(Date startTime, Date endTime) {

		long nd = 1000 * 24 * 60 * 60;
		long diff;
		long day = 0l;
		diff = endTime.getTime() - startTime.getTime();
		day = diff / nd;
		return (int)day;
	}
	/**
	 * 
	 * @param validDate
	 * @param insuredBirthday
	 * @param coverageType   1.one.终身|2.two.保多少年|3.three.保至多少岁|4.four.保多少月|5.five.保多少天';
	 * @param coverageYear
	 * @return
	 * @throws ParseException 
	 */
	public static Date calcExpirationDate(Date validDate, Date insuredBirthday,
			int coverageType, int coverageYear) throws ParseException {
		Date expirationDate = new Date();
		if (coverageType == 1)
			try {
				expirationDate = DateTool.getDate("9999-09-09");
			} catch (ParseException e) {
				LogTool.error(DateTool.class, e);
			}
		else if (coverageType == 2)
			expirationDate = DateTool.add(
					DateTool.getPreviousDay(validDate, 1), 1, coverageYear);
		else if (coverageType == 3)
			expirationDate = DateTool.add(
					DateTool.getPreviousDay(insuredBirthday, 1), 1,
					coverageYear + 1);
		else if (coverageType == 4)
			expirationDate = DateTool.getDateAdd(
					DateTool.getPreviousDay(validDate, 1), 2, coverageYear);
		else if (coverageType == 5) {
			expirationDate = DateTool.getNextDay(
					DateTool.getPreviousDay(validDate, 1), coverageYear);
		}
		String strDate = DateTool.getDateTime(DateTool.DATE_MASK, expirationDate);
		expirationDate = DateTool.convertStringToDate(DateTool.DATE_MASK, strDate);
		return expirationDate;
	 }
	/**
	 * 根据日期类型,比较日期差 startDate,endDate
	 * @params: dateFormat : yyyy-MM-dd HH:mm:ss
	 * @params: type : 比较对象,SECOND,MINUTE,HOUR,DAY,WEEK,MONTH,YEAR
	 */
	public static long getDateDiff(Date startDate, Date endDate, String type)
	{
		long diff = 0;
		try {
			type = type.trim().toUpperCase();
			diff = endDate.getTime() - startDate.getTime(); //毫秒
			
			Calendar c = Calendar.getInstance();
			c.setTimeInMillis(diff);
			System.out.print(c.getTime());
			if (type.equals("SECOND")) {
				diff = diff / 1000; //秒
			} else if (type.equals("MINUTE")) {
				diff = diff / 60000; //分钟
			} else if (type.equals("HOUR")) {
				diff = diff / 3600000; //小时
			} else if (type.equals("DAY")) {
				diff = diff / 86400000; //天
			} else if (type.equals("WEEK")) {
				diff = diff / (86400000 * 7); //星期
			} else if (type.equals("MONTH")) {
				System.out.println(endDate.getMonth() + 1 + "\t" + startDate.getMonth() + 1);
				diff = (endDate.getMonth() + 1) + ((endDate.getYear() - startDate.getYear()) * 12) - (startDate.getMonth() + 1);
			} else if (type.equals("YEAR")) { //年
				diff = endDate.getYear() - startDate.getYear();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return diff;
	}
	/**
	 * 比较2个日期哪个前,哪个后
	 */
	public static boolean isDate1LateThanDate2(Date date1, Date date2)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date1);
		Date date11 = calendar.getTime();
		boolean flag = date11.after(date2);
		return flag;
	}
	
	public static boolean isInTime(String startEnd) throws ParseException{
		if (!StringUtils.isEmpty(startEnd) && startEnd.indexOf(";") > -1) {
			String start = startEnd.split(";")[0];
			String end   = startEnd.split(";")[1];
			Date date1 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, start);
			Date date2 = DateTool.convertStringToDate(DateTool.DATE_TIME_MASK, end);
			Date now = new Date();
			
			if (now.before(date2) && now.after(date1)) {
				LogTool.debug(DateTool.class.getClass(), "now: "+DateTool.convertDataToString(now, DateTool.DATE_TIME_MASK));
				LogTool.debug(DateTool.class.getClass(), "service pause date1: "+date1);
				LogTool.debug(DateTool.class.getClass(), "service pause date2: "+date2);
				return true;
			}
		}
		return false;
	}
	/**
	 * 计算下期续期时间
	 * @author liuhe
	 * @param validateDate
	 * @param chargeType
	 * @param term
	 * @return
	 */
	public static Date calcuNextPremiumDate(Date validateDate,int chargeType,int term) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(validateDate);
		if(chargeType==1) {
			calendar.add(Calendar.YEAR, term);
		}
		if(chargeType==4) {
			calendar.add(Calendar.MONTH, term);
		}
		return calendar.getTime();
	}
	
	public static void main(String[] args) throws Exception {
		Date date = new Date();
//		String today = DateTool.convertDataToString(date, DateTool.DATE_MASK);
		String today = DateTool.convertDataToString(date, "yyyy年MM月dd日");
		System.out.println(today);
//		Date date2 = DateTool.parseDate(today, DateTool.DATE_MASK);
//		System.out.println(date2);
//		today = DateTool.convertDataToString(date, DateTool.DATE_MASK);
//		System.out.println(today);
//		
//		SimpleDateFormat sd = new SimpleDateFormat("yyyy年MM月dd日");
//		String startTime = "2015-10-01 00:00:00";
//		String endTime = "2015-10-02 59:59:59";
//		
//		Date date1 = sd.parse(startTime);
//		Date date3 = sd.parse(endTime);
//		
//		System.out.println(DateTool.dateDiff(date1, date2));
//		
//		String start = "2015-10-01";
//		String end = "2015-10-02";
//		System.out.println(DateTool.dateDiff(start, end));
	}
}

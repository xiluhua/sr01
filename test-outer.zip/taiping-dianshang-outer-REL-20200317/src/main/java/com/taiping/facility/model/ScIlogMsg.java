package com.taiping.facility.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ScIlogMsg entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "SC_ILOG_MSG")
public class ScIlogMsg implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long msgId;
	private String msgDocPath;
	private Long templateId;
	private Long receiverId;
	private Long senderId;
	private String ip;
	private String interfaceLogId;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private String createdatetime;
	private String updatedatetime;
	private String msgContent;
	private Long logIndex;		//日志标识
	
	
	
	
	
	// Constructors

	public Long getLogIndex() {
		return logIndex;
	}

	public void setLogIndex(Long logIndex) {
		this.logIndex = logIndex;
	}

	/** default constructor */
	public ScIlogMsg() {
	}

	/** minimal constructor */
	public ScIlogMsg(Long msgId) {
		this.msgId = msgId;
	}

	/** full constructor */
	public ScIlogMsg(Long msgId, String msgDocPath, Long templateId,
			Long receiverId, Long senderId, String ip, String interfaceLogId,
			Date createTime, Date updateTime, String createAid,
			String updateAid) {
		this.msgId = msgId;
		this.msgDocPath = msgDocPath;
		this.templateId = templateId;
		this.receiverId = receiverId;
		this.senderId = senderId;
		this.ip = ip;
		this.interfaceLogId = interfaceLogId;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
	}

	// Property accessors
	@Id
	@Column(name = "MSG_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getMsgId() {
		return this.msgId;
	}

	public void setMsgId(Long msgId) {
		this.msgId = msgId;
	}

	@Column(name = "MSG_DOC_PATH", length = 200)
	public String getMsgDocPath() {
		return this.msgDocPath;
	}

	public void setMsgDocPath(String msgDocPath) {
		this.msgDocPath = msgDocPath;
	}

	@Column(name = "TEMPLATE_ID", precision = 10, scale = 0)
	public Long getTemplateId() {
		return this.templateId;
	}

	public void setTemplateId(Long templateId) {
		this.templateId = templateId;
	}

	@Column(name = "RECEIVER_ID", precision = 10, scale = 0)
	public Long getReceiverId() {
		return this.receiverId;
	}

	public void setReceiverId(Long receiverId) {
		this.receiverId = receiverId;
	}

	@Column(name = "SENDER_ID", precision = 10, scale = 0)
	public Long getSenderId() {
		return this.senderId;
	}

	public void setSenderId(Long senderId) {
		this.senderId = senderId;
	}

	@Column(name = "IP", length = 30)
	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	@Column(name = "INTERFACE_LOG_ID", length = 30)
	public String getInterfaceLogId() {
		return this.interfaceLogId;
	}

	public void setInterfaceLogId(String interfaceLogId) {
		this.interfaceLogId = interfaceLogId;
	}

	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	public String getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(String createdatetime) {
		this.createdatetime = createdatetime;
	}

	public String getUpdatedatetime() {
		return updatedatetime;
	}

	public void setUpdatedatetime(String updatedatetime) {
		this.updatedatetime = updatedatetime;
	}

	public String getMsgContent() {
		return msgContent;
	}

	public void setMsgContent(String msgContent) {
		this.msgContent = msgContent;
	}

}
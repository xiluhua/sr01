package com.taiping.facility.cache.container;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.opensymphony.oscache.util.StringUtil;
import com.taiping.dianshang.constant.ConstantTool;
import com.taiping.dianshang.entity.DsImsDictionary;
import com.taiping.dianshang.entity.ImsDictionary;
import com.taiping.dianshang.entity.ImsSysParamList;
import com.taiping.dianshang.entity.ImsSystemParameter;
import com.taiping.dianshang.exception.CacheObjectNotFoundException;
import com.taiping.dianshang.exception.DictionaryNotFoundException;
import com.taiping.dianshang.exception.SystemParameterNotFoundException;
import com.taiping.facility.model.DictItem;
import com.taiping.facility.model.DictItems;
import com.taiping.facility.redis.JedisClient2;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.facility.tool.SerializeTool;

public class CacheContainer {

	public static Map<Object,Map<Object,?>> cacheMap = new HashMap<Object,Map<Object,?>>();
	
	public static Map<Object, Map<Object, ?>> getCacheMap() {
		return cacheMap;
	}
	
	public static void setCacheMap(Map<Object, Map<Object, ?>> cacheMap) {
		CacheContainer.cacheMap = cacheMap;
	}
	public static void init(Map<Object,Map<Object,?>> cacheMap){
		CacheContainer.cacheMap = cacheMap;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getByIdFromCacheThrows(Object id,Class<T> t) throws CacheObjectNotFoundException{
		
		String key = KeyTool.get(t, id);
		String value = JedisClient2.get(key);
		if (value == null) {
			throw new CacheObjectNotFoundException(t.getSimpleName()+" is not inited");
		}
		return (T)JsonTool.toObject(value,t);
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T getByIdFromCache(Object id,Class<T> t){
		
		String key = KeyTool.get(t, id);
		String value = JedisClient2.get(key);
		if (value == null) {
			return null;
		}
		return (T)JsonTool.toObject(value,t);
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T getIspRmiByIdFromCache(Object id,int sellChannel,String interfaceId,Class<T> t) throws CacheObjectNotFoundException{
		
		String key = KeyTool.get(t, id);
		String value = JedisClient2.get(key);
		if (value != null) {
			return (T)JsonTool.toObject(value,t);
		}else {
			key = KeyTool.get(t, sellChannel+ConstantTool.UNDERLINE+interfaceId);
			value = JedisClient2.get(key);
			if (value != null) {
				T obj =(T)JsonTool.toObject(value,t);
				return obj;
			}else {
				throw new CacheObjectNotFoundException(t.getSimpleName()+" is not available by id:"+id);
			}
		}
	}
	
	@SuppressWarnings("unchecked") 
	public static <T> T getIspRmiByIdFromCache_Refund(Object id,int sellChannel,String interfaceId,Class<T> t) throws CacheObjectNotFoundException{
		
		String key = KeyTool.get(t, id + ConstantTool.UNDERLINE + interfaceId);
		String value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}else {
			throw new CacheObjectNotFoundException(t.getSimpleName()+" is not available by id:"+id);
		}
	}
	
	public static DictItems getDictionary(String dictCode) throws DictionaryNotFoundException{
		
		String key = KeyTool.get(ImsDictionary.class, dictCode);
		String value = JedisClient2.get(key);
		
		if (value != null) {
			DictItems obj = (DictItems)JsonTool.toObject(value, DictItems.class);
			return obj;
		}else {
			throw new DictionaryNotFoundException(ImsDictionary.class.getSimpleName()+" is not available by:"+dictCode);
		}
	}
	
	/**
	 * @author xilh
	 * @since 20180809
	 * @category get code by dictCode + dictValue 
	 * @param dictCode
	 * @param dictValue
	 * @return
	 */
	public static String getDictionaryItemByValue(String dictCode, Object dictValue){
		
		String key = KeyTool.get(DsImsDictionary.class, dictCode);
		String value = JedisClient2.get(key);
		
		if (value != null) {
			DictItems items = (DictItems)JsonTool.toObject(value, DictItems.class);
		    DictItem item = items.getItemByValue(String.valueOf(dictValue));
			return item.getCode();
		}else {
			return null;
		}
	}

	public static ImsSystemParameter getSystemParameter(String parameterCode) throws SystemParameterNotFoundException{
	
		String key = KeyTool.get(ImsSystemParameter.class, parameterCode);
		String value = JedisClient2.get(key);
		if (value != null) {
			ImsSystemParameter obj = (ImsSystemParameter)JsonTool.toObject(value, ImsSystemParameter.class);
			return obj;
		}else {
			throw new SystemParameterNotFoundException(ImsSystemParameter.class.getSimpleName()+" is not available by:"+parameterCode);
		}
	}
	
	public static String getSystemParameterValue(String parameterCode) throws SystemParameterNotFoundException{
		
		String key = KeyTool.get(ImsSystemParameter.class, parameterCode);
		String value = JedisClient2.get(key);
		if (value != null) {
			ImsSystemParameter obj = (ImsSystemParameter)JsonTool.toObject(value, ImsSystemParameter.class);
			return obj.getParameterValue();
		}else {
			throw new SystemParameterNotFoundException(ImsSystemParameter.class.getSimpleName()+" is not available by:"+parameterCode);
		}
	}
	
	public static String getSystemParameterValueNoThrows(String parameterCode) throws SystemParameterNotFoundException{
		
		String key = KeyTool.get(ImsSystemParameter.class, parameterCode);
		String value = JedisClient2.get(key);
		if (value != null) {
			ImsSystemParameter obj = (ImsSystemParameter)JsonTool.toObject(value, ImsSystemParameter.class);
			return obj.getParameterValue();
		}else {
			return null;
		}
	}
	
	public static boolean isInSysparamRange(String sysParamCode,Object key){
		String partnerEnumNotForInnerPay = CacheContainer.getSystemParameterValue(sysParamCode);
		List<String> list = Arrays.asList(partnerEnumNotForInnerPay.split(","));
		return list.contains(String.valueOf(key));
	}
	
	// rm by xiluhua 20190814
	@SuppressWarnings("unchecked")
	@Deprecated
	public static <T> T getListByIdFromCache(Class<T> t) throws CacheObjectNotFoundException{
		
		Map<Object, T> map = (Map<Object, T>) SerializeTool.unserialize(JedisClient2.get(t.getSimpleName().getBytes()));
		if (map == null) {
			throw new CacheObjectNotFoundException(t.getSimpleName()+" is not inited");
		}
		
		return (T) map;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T getShortmsgTemplateFromCache(Object id,int type,Class<T> t){
		
		String key =  KeyTool.get(t, id + ConstantTool.UNDERLINE + type);
		String value = JedisClient2.get(key);
		if (value == null) {
			throw new RuntimeException("短信模板未配置："+key);
		}
		return (T)JsonTool.toObject(value,t);
	}
	
	/**
	 * 
	 * @author xilh
	 * @param <T>
	 * @param id
	 * @param partnerId
	 * @param sellChannel
	 * @param t
	 * @return
	 * @throws CacheObjectNotFoundException
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getEmailTemplateByIdFromCache(Object id,Long partnerId,int sellChannel,Class<T> t) throws CacheObjectNotFoundException{
		
		String key = KeyTool.get(t, "1_"+partnerId+ConstantTool.UNDERLINE+id);
		String value = JedisClient2.get(key);
		// --1，合作方+方案
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}
		
		// --4，专业公司+合作方
		key = KeyTool.get(t, "4_"+sellChannel+ConstantTool.UNDERLINE+partnerId);
		value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}

		// --2，方案
		key = KeyTool.get(t, "2_"+id);
		value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}
		
		// --3，默认-专业公司
		// key = KeyTool.get(t, "3");
		key = KeyTool.get(t, sellChannel);
		value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}else {
			throw new CacheObjectNotFoundException(t.getSimpleName()+" is not available by:"+id);
		}
	}
	/**
	 * add by liuhe 20190819  邮件模板
	 * @param <T>
	 * @param id
	 * @param partnerId
	 * @param sellChannel
	 * @param t
	 * @return
	 * @throws CacheObjectNotFoundException
	 */
    public static <T> T getEmailTemplateByIdFromCache(Object id,Long partnerId,int sellChannel,String emailCode,Class<T> t) throws CacheObjectNotFoundException{
		
    	String key = KeyTool.get(t, "5_"+id+"_"+emailCode);
    	String value = JedisClient2.get(key);
		// --1，合作方+方案
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}
    	
    	key = KeyTool.get(t, "1_"+partnerId+ConstantTool.UNDERLINE+id);
		value = JedisClient2.get(key);
		// --1，合作方+方案
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}
		
		// --4，专业公司+合作方
		key = KeyTool.get(t, "4_"+sellChannel+ConstantTool.UNDERLINE+partnerId);
		value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}

		// --2，方案
		key = KeyTool.get(t, "2_"+id);
		value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}
		
		// --3，默认-专业公司
		// key = KeyTool.get(t, "3");
		key = KeyTool.get(t, sellChannel);
		value = JedisClient2.get(key);
		if (value != null) {
			T obj = (T)JsonTool.toObject(value,t);
			return obj;
		}else {
			throw new CacheObjectNotFoundException(t.getSimpleName()+" is not available by:"+id);
		}
	}
	
	/**
	 * for jinChengGuoJi 
	 * @author xilh
	 * @since 20181113
	 * @param <T>
	 * @param partnerId
	 * @param sellChannel
	 * @param t
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getPayCallbackByIdFromCache(Object partnerId, int sellChannel, Class<T> t){
		// "2_"+partnerId+"_"+sellChannel;
		String key = KeyTool.get(t, "2_"+partnerId+"_"+sellChannel);
		String value = JedisClient2.get(key);
		if (value != null) {
			return (T)JsonTool.toObject(value,t);
		}
		key = KeyTool.get(t, partnerId);
		value = JedisClient2.get(key);
		if (value == null) {
			return null;
		}
		return (T)JsonTool.toObject(value,t);
	}
	
	/**
	 * @author xilh
	 * @since 20181122
	 */
	public static String getSysParamValueNoThrows(String parameterCode) throws SystemParameterNotFoundException{
		
		String key = KeyTool.get(ImsSysParamList.class, parameterCode);
		String value = JedisClient2.get(key);
		if (value != null) {
			ImsSysParamList obj = (ImsSysParamList)JsonTool.toObject(value, ImsSysParamList.class);
			return obj.getParamValue();
		}else {
			return null;
		}
	}
}

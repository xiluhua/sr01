package com.taiping.facility.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * ScIlogErrorLog entity. 
 */
@Entity
@Table(name = "SC_ILOG_ERROR_LOG")
public class ScIlogErrorLog implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long errorLogId;
	private String errorCode;
	private String systemCode;
	private String className;
	private String functionName;
	private Long lineNum;
	private String errorInfo;
	private Date createTime;
	private Date updateTime;
	private String createAid;
	private String updateAid;
	private Date createdatetime;
	private Date updatedatetime;

	/* add 20131010 start*/
	private String licenseNo;// 车牌号 
	private String frameNo;// 车架号 
	/* add 20131010 end*/
	
	// Constructors

	/** default constructor */
	public ScIlogErrorLog() {
	}

	/** minimal constructor */
	public ScIlogErrorLog(Long errorLogId) {
		this.errorLogId = errorLogId;
	}

	/** full constructor */
	public ScIlogErrorLog(Long errorLogId, String errorCode, String systemCode,
			String className, String functionName, Long lineNum,
			String errorInfo, Date createTime, Date updateTime,
			String createAid, String updateAid) {
		this.errorLogId = errorLogId;
		this.errorCode = errorCode;
		this.systemCode = systemCode;
		this.className = className;
		this.functionName = functionName;
		this.lineNum = lineNum;
		this.errorInfo = errorInfo;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.createAid = createAid;
		this.updateAid = updateAid;
	}

	
	public Long getErrorLogId() {
		return this.errorLogId;
	}

	public void setErrorLogId(Long errorLogId) {
		this.errorLogId = errorLogId;
	}

	@Column(name = "ERROR_CODE", length = 20)
	public String getErrorCode() {
		return this.errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@Column(name = "SYSTEM_CODE", length = 50)
	public String getSystemCode() {
		return this.systemCode;
	}

	public void setSystemCode(String systemCode) {
		this.systemCode = systemCode;
	}

	@Column(name = "CLASS_NAME", length = 1000)
	public String getClassName() {
		return this.className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	@Column(name = "FUNCTION_NAME", length = 1000)
	public String getFunctionName() {
		return this.functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	@Column(name = "LINE_NUM", precision = 10, scale = 0)
	public Long getLineNum() {
		return this.lineNum;
	}

	public void setLineNum(Long lineNum) {
		this.lineNum = lineNum;
	}

	@Column(name = "ERROR_INFO", length = 4000)
	public String getErrorInfo() {
		return this.errorInfo;
	}

	public void setErrorInfo(String errorInfo) {
		this.errorInfo = errorInfo;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME", length = 7)
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME", length = 7)
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATEDATETIME", length = 765)
	public Date getCreatedatetime() {
		return this.createdatetime;
	}

	public void setCreatedatetime(Date createdatetime) {
		this.createdatetime = createdatetime;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATEDATETIME", length = 765)
	public Date getUpdatedatetime() {
		return this.updatedatetime;
	}

	public void setUpdatedatetime(Date updatedatetime) {
		this.updatedatetime = updatedatetime;
	}

	@Column(name = "LICENSE_NO", length = 32)
	public String getLicenseNo() {
		return licenseNo;
	}

	@Column(name = "FRAME_NO", length = 32)
	public String getFrameNo() {
		return frameNo;
	}

	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}

	public void setFrameNo(String frameNo) {
		this.frameNo = frameNo;
	}
	
}
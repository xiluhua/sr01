package com.taiping.facility.action;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.struts2.convention.annotation.Action;
import org.apache.struts2.convention.annotation.Namespace;
import org.apache.struts2.convention.annotation.ParentPackage;
import org.apache.struts2.convention.annotation.Result;
import com.taiping.dianshang.entity.ImsLogLevel;
import com.taiping.dianshang.entity.ImsSystemParameter;
import com.taiping.facility.cache.CacheService;
import com.taiping.facility.tool.LogTool;
import com.taiping.framework.action.BaseAction;

@ParentPackage("struts-default")
@Namespace("/cache")
public class CacheAction  extends BaseAction {
	
	/**
	 * 缓存查询，用于查看缓存是否已更新到系统
	 */
	private static final long serialVersionUID = 5849260213064898322L;

	@Resource
	private CacheService cacheService;
	
	// http://localhost:7001/taiping-ali-mall/cache/query.action?simpleName=ImsSystemParameter
	@Action(value = "query", results = { 
	@Result(name = "success", location = "/WEB-INF/content/cache.ftl")})
	public String query() {
		String simpleName = getRequest().getParameter("simpleName");
		
		LogTool.info(this.getClass(), "===========================================================================");
		LogTool.info(this.getClass(), "cache class:{}", simpleName);
		try {
			if (StringUtils.isEmpty(simpleName)) {
				simpleName = ImsSystemParameter.class.getSimpleName();
				// getRequest().setAttribute("list", CacheContainer.getListFromCache(simpleName));
				return SUCCESS;
			}else {
				if (simpleName.equalsIgnoreCase("log")) {
					simpleName = ImsLogLevel.class.getSimpleName();
				}
				
				// getRequest().setAttribute("list", CacheContainer.getListFromCache(simpleName));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		getRequest().setAttribute(SUCCESS, SUCCESS);
		return SUCCESS;
	}
	
	@Action(value = "refreshLog", results = { 
	@Result(name = "success", location = "/WEB-INF/content/cache.ftl")})
	public String refreshLog() throws Exception {
		
		LogTool.info(this.getClass(), "===========================================================================");
		LogTool.info(this.getClass(), "cache class: log");
		
		cacheService.refreshLogLevel();
		getRequest().setAttribute(SUCCESS, SUCCESS);
		return SUCCESS;
	}

	// http://localhost:7001/taiping-ali-mall/cache/query/pool/size.action
	@Action(value = "queryPoolSize")
    public String queryPoolSize()
	{
//		ajaxText(Pool.size()+","+Pool.issueQ.size()+","+Pool.reportQ.size()+","+Pool.reviseQ.size());
		ajaxText("");
		return null;
	}
}
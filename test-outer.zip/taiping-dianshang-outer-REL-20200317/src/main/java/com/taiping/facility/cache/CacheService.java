package com.taiping.facility.cache;


public interface CacheService {
	
	public void init();
	
	public void refreshLogLevel();
}

package com.taiping.facility.tool;

import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.params.ConnRoutePNames;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.impl.client.DefaultHttpClient;

import com.taiping.dianshang.constant.ConstantTool;

/**
 * 
 * @author xilh
 * @since 20200212
 */
public class PdfDownloadHttpsTool {
	
	public void persistentPDF(String policyNo, String proxyPort, String path, String policyUrl){
		HttpPost httpost = null;
		DefaultHttpClient httpclient = new DefaultHttpClient();
		if (!StringUtils.isEmpty(proxyPort)) {
			// 代理的设置  
			String value = proxyPort;
			if (LogTool.isLocal) {
				value = PropertyFileTool.get(ConstantTool.INTERNET_PROXY_1);
			}
			String[] arr = value.split(":");
	        HttpHost proxy = new HttpHost(arr[0], Integer.valueOf(arr[1]));
	        httpclient.getParams().setParameter(ConnRoutePNames.DEFAULT_PROXY, proxy);
		}
		
		try {
			// Secure Protocol implementation.
			SSLContext ctx = SSLContext.getInstance("TLS");
			// Implementation of a trust manager for X509 certificates
			X509TrustManager tm = new X509TrustManager() {
				public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
				}

				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}
			};
			ctx.init(null, new TrustManager[] { tm }, null);
			SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			ClientConnectionManager ccm = httpclient.getConnectionManager();
			// register https protocol in httpclient's scheme registry
			SchemeRegistry sr = ccm.getSchemeRegistry();
			sr.register(new Scheme("https", 443, ssf));
			httpclient = new DefaultHttpClient(ccm, httpclient.getParams());
			httpost = new HttpPost(policyUrl);
			HttpResponse response = httpclient.execute(httpost);

			HttpEntity entity = response.getEntity();
			byte buffer[] = FileStreamTool.read(entity.getContent());
			System.out.println(policyNo+", pdf size: "+buffer.length);
			FileStreamTool.write(path, buffer);
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally{
			if (httpost != null) {
				// 关闭请求
				httpost.releaseConnection();
			}
		}
		
	}
}

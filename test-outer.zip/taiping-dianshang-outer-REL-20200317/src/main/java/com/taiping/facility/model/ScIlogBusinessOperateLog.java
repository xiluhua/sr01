package com.taiping.facility.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * ScIlogBusinessOperateLog entity.
 */
@Entity
@Table(name = "SC_ILOG_BUSINESS_OPERATE_LOG")
public class ScIlogBusinessOperateLog implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields

	private Long businessOperateLogId;
	private Long applyId;
	private Long payId;
	private Integer businessType;
	private Integer businessOperateType;
	private Integer operateStatus;
	private String operateNo;
	private Double premium;
	private String userId;
	private String holderName;
	private String holderIdno;
	private String cardBuyerName;
	private String cardBuyerIdno;
	private Long linkId;
	private Long partnerId;
	private String partnerName;
	private String partnerTransCode;
	private Long payerId;
	private String payerName;
	private String ip;
	private Long msgId;
	private String disposeTime;
	private String businessApplyTime;
	private String businessDes;
	private Date createTime;
	private Date updateTime;
	private String updateAid;
	private String createAid;
	private String createdatetime;
	private String updatedatetime;

	// Constructors

	/** default constructor */
	public ScIlogBusinessOperateLog() {
	}

	/** minimal constructor */
	public ScIlogBusinessOperateLog(Long businessOperateLogId) {
		this.businessOperateLogId = businessOperateLogId;
	}

	/** full constructor */
	public ScIlogBusinessOperateLog(Long businessOperateLogId, Long applyId,
			Long payId, Integer businessType, Integer businessOperateType,
			Integer operateStatus, String operateNo, Double premium,
			String userId, String holderName, String holderIdno,
			String cardBuyerName, String cardBuyerIdno, Long linkId,
			Long partnerId, String partnerName, String partnerTransCode,
			Long payerId, String payerName, String ip, Long msgId,
			String disposeTime, String businessApplyTime, String businessDes,
			Date createTime, Date updateTime, String updateAid,
			String createAid) {
		this.businessOperateLogId = businessOperateLogId;
		this.applyId = applyId;
		this.payId = payId;
		this.businessType = businessType;
		this.businessOperateType = businessOperateType;
		this.operateStatus = operateStatus;
		this.operateNo = operateNo;
		this.premium = premium;
		this.userId = userId;
		this.holderName = holderName;
		this.holderIdno = holderIdno;
		this.cardBuyerName = cardBuyerName;
		this.cardBuyerIdno = cardBuyerIdno;
		this.linkId = linkId;
		this.partnerId = partnerId;
		this.partnerName = partnerName;
		this.partnerTransCode = partnerTransCode;
		this.payerId = payerId;
		this.payerName = payerName;
		this.ip = ip;
		this.msgId = msgId;
		this.disposeTime = disposeTime;
		this.businessApplyTime = businessApplyTime;
		this.businessDes = businessDes;
		this.createTime = createTime;
		this.updateTime = updateTime;
		this.updateAid = updateAid;
		this.createAid = createAid;
	}

	// Property accessors
	@Id
	@Column(name = "BUSINESS_OPERATE_LOG_ID", unique = true, nullable = false, precision = 10, scale = 0)
	public Long getBusinessOperateLogId() {
		return this.businessOperateLogId;
	}

	public void setBusinessOperateLogId(Long businessOperateLogId) {
		this.businessOperateLogId = businessOperateLogId;
	}

	@Column(name = "APPLY_ID", precision = 10, scale = 0)
	public Long getApplyId() {
		return this.applyId;
	}

	public void setApplyId(Long applyId) {
		this.applyId = applyId;
	}

	@Column(name = "PAY_ID", precision = 10, scale = 0)
	public Long getPayId() {
		return this.payId;
	}

	public void setPayId(Long payId) {
		this.payId = payId;
	}

	@Column(name = "BUSINESS_TYPE", precision = 3, scale = 0)
	public Integer getBusinessType() {
		return this.businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	@Column(name = "BUSINESS_OPERATE_TYPE", precision = 3, scale = 0)
	public Integer getBusinessOperateType() {
		return this.businessOperateType;
	}

	public void setBusinessOperateType(Integer businessOperateType) {
		this.businessOperateType = businessOperateType;
	}

	@Column(name = "OPERATE_STATUS", precision = 3, scale = 0)
	public Integer getOperateStatus() {
		return this.operateStatus;
	}

	public void setOperateStatus(Integer operateStatus) {
		this.operateStatus = operateStatus;
	}

	@Column(name = "OPERATE_NO", length = 50)
	public String getOperateNo() {
		return this.operateNo;
	}

	public void setOperateNo(String operateNo) {
		this.operateNo = operateNo;
	}

	@Column(name = "PREMIUM", precision = 12)
	public Double getPremium() {
		return this.premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	@Column(name = "USER_ID", length = 32)
	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Column(name = "HOLDER_NAME", length = 100)
	public String getHolderName() {
		return this.holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	@Column(name = "HOLDER_IDNO", length = 20)
	public String getHolderIdno() {
		return this.holderIdno;
	}

	public void setHolderIdno(String holderIdno) {
		this.holderIdno = holderIdno;
	}

	@Column(name = "CARD_BUYER_NAME", length = 100)
	public String getCardBuyerName() {
		return this.cardBuyerName;
	}

	public void setCardBuyerName(String cardBuyerName) {
		this.cardBuyerName = cardBuyerName;
	}

	@Column(name = "CARD_BUYER_IDNO", length = 20)
	public String getCardBuyerIdno() {
		return this.cardBuyerIdno;
	}

	public void setCardBuyerIdno(String cardBuyerIdno) {
		this.cardBuyerIdno = cardBuyerIdno;
	}

	@Column(name = "LINK_ID", precision = 10, scale = 0)
	public Long getLinkId() {
		return this.linkId;
	}

	public void setLinkId(Long linkId) {
		this.linkId = linkId;
	}

	@Column(name = "PARTNER_ID", precision = 10, scale = 0)
	public Long getPartnerId() {
		return this.partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	@Column(name = "PARTNER_NAME", length = 100)
	public String getPartnerName() {
		return this.partnerName;
	}

	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}

	@Column(name = "PARTNER_TRANS_CODE", length = 50)
	public String getPartnerTransCode() {
		return this.partnerTransCode;
	}

	public void setPartnerTransCode(String partnerTransCode) {
		this.partnerTransCode = partnerTransCode;
	}

	@Column(name = "PAYER_ID", precision = 10, scale = 0)
	public Long getPayerId() {
		return this.payerId;
	}

	public void setPayerId(Long payerId) {
		this.payerId = payerId;
	}

	@Column(name = "PAYER_NAME", length = 100)
	public String getPayerName() {
		return this.payerName;
	}

	public void setPayerName(String payerName) {
		this.payerName = payerName;
	}

	@Column(name = "IP", length = 40)
	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	@Column(name = "MSG_ID", precision = 10, scale = 0)
	public Long getMsgId() {
		return this.msgId;
	}

	public void setMsgId(Long msgId) {
		this.msgId = msgId;
	}

	@Column(name = "DISPOSE_TIME")
	public String getDisposeTime() {
		return this.disposeTime;
	}

	public void setDisposeTime(String disposeTime) {
		this.disposeTime = disposeTime;
	}

	@Column(name = "BUSINESS_APPLY_TIME")
	public String getBusinessApplyTime() {
		return this.businessApplyTime;
	}

	public void setBusinessApplyTime(String businessApplyTime) {
		this.businessApplyTime = businessApplyTime;
	}

	@Column(name = "BUSINESS_DES", length = 1000)
	public String getBusinessDes() {
		return this.businessDes;
	}

	public void setBusinessDes(String businessDes) {
		this.businessDes = businessDes;
	}

	@Column(name = "CREATE_TIME")
	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	@Column(name = "UPDATE_TIME")
	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	@Column(name = "UPDATE_AID", length = 32)
	public String getUpdateAid() {
		return this.updateAid;
	}

	public void setUpdateAid(String updateAid) {
		this.updateAid = updateAid;
	}

	@Column(name = "CREATE_AID", length = 32)
	public String getCreateAid() {
		return this.createAid;
	}

	public void setCreateAid(String createAid) {
		this.createAid = createAid;
	}

	public String getCreatedatetime() {
		return createdatetime;
	}

	public void setCreatedatetime(String createdatetime) {
		this.createdatetime = createdatetime;
	}

	public String getUpdatedatetime() {
		return updatedatetime;
	}

	public void setUpdatedatetime(String updatedatetime) {
		this.updatedatetime = updatedatetime;
	}

}
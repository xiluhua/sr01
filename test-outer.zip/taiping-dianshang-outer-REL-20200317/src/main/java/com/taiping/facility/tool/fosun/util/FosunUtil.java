package com.taiping.facility.tool.fosun.util;

import com.taiping.facility.tool.PropertyFileTool;

import java.util.HashMap;
import java.util.Map;

/**
 * Title:
 *      复星辅助工具类
 * @Author Li.Wei
 * @Date 2019/4/11 10:27 AM
 * @Description:  一般用于报文封装，代码复用等问题。
 */
public class FosunUtil {

    /**
     * 根据请求报文，生成复星的post参数
     * @param requestXml
     * @return
     */
    public static Map<String, String> postMap(String requestXml) throws Exception {
        //组装请求数据
        Map<String, String> paramsMap = new HashMap<String, String>();
        String signKey = PropertyFileTool.get("fx_sign_key");
        String requetXmlKey = PropertyFileTool.get("fx_request_key");
        String greatSignKey = SecurityUtil.Md5(requestXml + signKey); //签名
        requestXml = SecurityUtil.aesEncrypt(requestXml, requetXmlKey); //加密后的报文
        paramsMap.put("request_xml", requestXml);
        paramsMap.put("ebiz_sign", greatSignKey);//签名

        return paramsMap;
    }

}

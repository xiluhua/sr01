package com.taiping.facility.tool;

import com.taiping.dianshang.constant.ConstantTool;

public class KeyTool {

	public static String get(Class<?> clazz,Object columns){
		StringBuilder builder = new StringBuilder();
		builder.append(clazz.getSimpleName());
		builder.append(":");
		builder.append(String.valueOf(columns));
		return builder.toString();
	}
	
	public static String getPdfDownloadEndTime(String policyNo){
		StringBuilder builder = new StringBuilder();
		builder.append(ConstantTool.POLICYPDF);
		builder.append(":");
		builder.append(policyNo);
		return builder.toString();
	}
	
	public static String getDownloadEndTime(String policyNo, String targetService){
		StringBuilder builder = new StringBuilder();
		builder.append(targetService);
		builder.append(":");
		builder.append(policyNo);
		return builder.toString();
	}
}

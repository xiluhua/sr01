package com.taiping.facility.cache;

import java.util.Map;

public interface CacheDaoService {
	public Map<Object,?> getAllInMap();
	
//	public Object getByIdFromCache(Long id);
}

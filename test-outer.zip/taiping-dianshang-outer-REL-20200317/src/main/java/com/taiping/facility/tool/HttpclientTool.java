package com.taiping.facility.tool;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.Proxy;
import java.net.SocketException;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.Map;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.log4j.Logger;

import com.taiping.common.Base64Tool;
import com.taiping.dianshang.utils.CreateDTOTool;
import com.taiping.facility.cache.container.CacheContainer;

public class HttpclientTool {

	public static void main(String[] args) throws Exception {
		// =============================== 读报文 =============================== 
//		String file = "test.xml";
//		String path = HttpclientTool.class.getResource("/template/test/"+file).getPath();
//		System.out.println("path : "+path);
//		String xml = IOTool.readFile(path, "utf-8");  //请确认编码方式
		
		
		// =============================== 自己封装 =============================== 		
		String xml = CreateDTOTool.create(3,"178_LOCAL20160301_1",false,3);
		

		System.out.println("requestXml:"+xml);
		String encode = "gbk";
		String url = "http://localhost:7776/taiping-svc-api/rest/core/business/entrance";
		String response = HttpclientTool.post(url, xml, encode);
		System.out.println("responseXml:"+Base64Tool.decode(response, "utf-8"));
	}
	
	
	
	
	public static Logger log = Logger.getLogger(HttpclientTool.class);

	public static String localIp = null;
	
	static{
		localIp = getLocalIp();
	}
	
	/**
	 * get 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public static String get(String url, Object content, String encode) throws Exception {
		DataInputStream in = null;
		BufferedReader reader = null;
		String responseMsg = "";
		HttpClient httpclient = new HttpClient();
		GetMethod httpGet = new GetMethod(url);
		httpGet.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
		
		//（1）、这里可以设置自己想要的编码格式
		httpGet.getParams().setContentCharset("GB2312"); 
			 
		//（3）、还可以如下这样设置
		httpGet.addRequestHeader("Content-Type", "application/x-www-form-urlencoded");  
			  
		//（4）、当然同样可以直接设置 httpClient 对象的编码格式
		httpclient.getParams().setContentCharset("GB2312");
		
		//（5）、设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(60000);
		//（6）、设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(60000);
		try {
			// get
			int statusCode = httpclient.executeMethod(httpGet);
			System.out.println("statusCode:"+statusCode);
			
			// success
			if (statusCode == HttpStatus.SC_OK) {
				StringBuffer rspContent = new StringBuffer();
				in = new DataInputStream(httpGet.getResponseBodyAsStream());
				reader = new BufferedReader(new InputStreamReader(in, "gbk"));
				String aLine = "";
				while ((aLine = reader.readLine()) != null) {
					rspContent.append(aLine);
				}
				responseMsg = rspContent.toString();
				System.out.println("responseMsg:"+responseMsg);
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpGet.releaseConnection();
			if (reader != null) {
				reader.close();
			}
			if (in != null) {
				in.close();
			}
		}
	
		return responseMsg;
	}
	
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public static String post(String url, Object content, String encode) throws Exception {
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(6000000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(6000000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), "GBK"));
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				httpPost.setRequestEntity(new StringRequestEntity((String)content,"plain/text", encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			System.out.println("statusCode:"+statusCode);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = Base64Tool.encode(String.valueOf("statusCode:"+statusCode), "utf-8");
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}

	/**
	 * 获取本机IP地址
	 * @return
	 */
	public static String getLocalIp(){
		String localIp = "";
		Enumeration allNetInterfaces = null;
		try {
			allNetInterfaces = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			e.printStackTrace();
		}
		InetAddress ip = null;
		while (allNetInterfaces.hasMoreElements()) {
			NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
//			System.out.println(netInterface.getName());
			Enumeration addresses = netInterface.getInetAddresses();
			while (addresses.hasMoreElements()) {
				ip = (InetAddress) addresses.nextElement();
				
				if (ip != null && ip instanceof Inet4Address) {

//					System.out.println("local IP address = " + ip.getHostAddress());
					localIp = ip.getHostAddress();
					if (!localIp.equals("127.0.0.1")) {
						return localIp;
					}
					
				}
			}
		}
		return localIp;
	}
	
	/** 
	* 设置代理 
	* @author xilh
	* @since 20180517 
	*/  
	public static void setProxy(HttpClient client) {  
		// 设置代理  
		//设置代理服务器的ip地址和端口  
		if (LogTool.isLocal) {
			String proxy = PropertyFileTool.get("internet.proxy");
			String[] arr1 = proxy.split(":");
			String auth  = PropertyFileTool.get("internet.auth");
			String[] arr2 = auth.split(":");
			client.getHostConfiguration().setProxy(arr1[0], Integer.valueOf(arr1[1]));  
			//使用抢先认证  
			client.getParams().setAuthenticationPreemptive(true);
			if (LogTool.isLocal) {
				client.getState().setProxyCredentials(AuthScope.ANY, new UsernamePasswordCredentials(arr2[0],arr2[1])); 
			}
			return;
		}
		
		String value = CacheContainer.getSystemParameterValue("internet.proxy");
		String[] arr = value.split(":");
		client.getHostConfiguration().setProxy(arr[0], Integer.valueOf(arr[1]));  
	}  
	

	public static Proxy getProxy(){
		String value = CacheContainer.getSystemParameterValue("internet.proxy");
		String[] arr = value.split(":");
		InetSocketAddress address = new InetSocketAddress(arr[0], Integer.valueOf(arr[1]));
		Proxy proxy = new Proxy(Proxy.Type.HTTP, address);
		return proxy;
	}
	
//	public static void main(String[] args) throws IOException
//	{
//		String path = ClientTestRest6.class.getResource("/request_rest.xml").getPath();
//		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"));
//		String xml = IOUtils.toString(reader);
//		int threadNum = 200;
//		final int concurrentNum = 20;
//		final String requestXmlSrc = new String(xml);
//
//		// localhost本地
//		final String url = "http://localhost:9000/ws-9-my-rest/rest/boss/employee/register";
//		// 请确认编码方式
//		final String encode = "utf-8";
//		
//		for (int i = 0; i < threadNum; i++) {
//			new Thread(){
//				public void run(){
//				
//					String requestXml = "";
//					String responseXml = "";
//					
//					EmployeeDTO employeeDTO_Req = null;
//					
//					for (int j = 0; j < concurrentNum; j++) {
//						requestXml = new String(requestXmlSrc);
//						try {
//							employeeDTO_Req = (EmployeeDTO) JAXBUtil.unmarshal(requestXml, EmployeeDTO.class);
//							employeeDTO_Req.setADDRESS(String.valueOf(new HttpClient().getRandom()));
//							employeeDTO_Req.setAGE(new HttpClient().getRandom());
//							employeeDTO_Req.setEMAIL(String.valueOf(new HttpClient().getRandom()+"@163.com"));
//							employeeDTO_Req.setID(new HttpClient().getRandom());
//							employeeDTO_Req.setNAME(String.valueOf(new HttpClient().getRandom()));
//							employeeDTO_Req.setZIP(String.valueOf(new HttpClient().getRandom()));
//							requestXml = JAXBUtil.marshal(employeeDTO_Req);
//							
//							requestXml = Base64Tool.encode(requestXml, encode);
//							responseXml = HttpClient.post(url, requestXml,"utf-8");
//							responseXml = Base64Tool.decode(responseXml, encode);
//
//							EmployeeDTO employeeDTO_Resp = (EmployeeDTO) JAXBUtil.unmarshal(responseXml, EmployeeDTO.class);
//							
//							String requ = ToStringBuilder.reflectionToString(employeeDTO_Req,ToStringStyle.SIMPLE_STYLE);
//							String resp = ToStringBuilder.reflectionToString(employeeDTO_Resp,ToStringStyle.SIMPLE_STYLE);
//
//							if (!requ.equals(resp)) {
//								log.info("falsefalsefalsefalsefalse:"+ToStringBuilder.reflectionToString(employeeDTO_Req,ToStringStyle.SIMPLE_STYLE));
//							}else {
//								log.info(ToStringBuilder.reflectionToString(employeeDTO_Req,ToStringStyle.SIMPLE_STYLE));
//							}
//						} catch (JAXBException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//							log.error("false:"+ToStringBuilder.reflectionToString(employeeDTO_Req,ToStringStyle.SIMPLE_STYLE));
//						} catch (Exception e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//							log.error("false:"+ToStringBuilder.reflectionToString(employeeDTO_Req,ToStringStyle.SIMPLE_STYLE));
//						}
//					}
//					
//					try {
//						Thread.sleep(1000);
//					} catch (InterruptedException e) {
//						e.printStackTrace();
//					}
//				}
//			}.start();
//		}
//	}
//	
//	private int getRandom(){
//		int random = 0;
//		while (true) {
//			random = (int)((Math.random()*10000000));
//			if (random != 11) {
//				break;
//			}
//		}
//		return random;
//	}
//	public static void main(String[] args) throws Exception {
//		String url = "http://localhost:9000/ws-9-my-rest/rest/boss/employee/register";
//		String path = ClientTestRest6.class.getResource("/request_rest.xml").getPath();
//		BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(path), "utf-8"));
//		String requestXml = IOUtils.toString(reader);
//		String xml = new String(requestXml);
//		System.out.println("requestXml:"+requestXml);
//		EmployeeDTO employeeDTO_Req = (EmployeeDTO) JAXBUtil.unmarshal(requestXml, EmployeeDTO.class);
//		
//		requestXml = Base64Tool.encode(requestXml, "utf-8");
//		
//		System.out.println(requestXml);
//		String responseXml = HttpClient.post(url, requestXml, false);
//		responseXml = Base64Tool.decode(responseXml, "utf-8");
//		System.out.println("responseXml:"+responseXml);
//		EmployeeDTO employeeDTO_Resp = (EmployeeDTO) JAXBUtil.unmarshal(responseXml, EmployeeDTO.class);
//		
//		System.out.println("---------------------------");
//		String requ = ToStringBuilder.reflectionToString(employeeDTO_Req,ToStringStyle.SIMPLE_STYLE);
//		String resp = ToStringBuilder.reflectionToString(employeeDTO_Resp,ToStringStyle.SIMPLE_STYLE);
//		System.out.println(requ);
//		System.out.println(resp);
//		if (!requ.equals(resp)) {
//			log.info("false:"+xml);
//		}
//	}
}
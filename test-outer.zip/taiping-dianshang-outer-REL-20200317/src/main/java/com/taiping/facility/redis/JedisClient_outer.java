//package com.taiping.facility.redis;
//
//import java.util.Set;
//import org.apache.commons.lang3.StringUtils;
//import redis.clients.jedis.Jedis;
//import redis.clients.jedis.JedisPool;
//import redis.clients.jedis.JedisPoolConfig;
//import com.taiping.facility.tool.LogTool;
//import com.taiping.facility.tool.PropertyFileTool;
//
//public class JedisClient_outer {
//	
//	public static JedisPool pool = null;
//	
//	static{
//		
//		// 生成连接池配置信息
//		JedisPoolConfig config = new JedisPoolConfig();
//		config.setMaxIdle(10);
//		config.setMaxTotal(30);
//		config.setMaxWaitMillis(3*1000);
//		String redisServer = "";
//		String redisPort = "";
//		
//		String redisUrl = PropertyFileTool.get("redis.url.outer");
//		String[] array = redisUrl.split(":");
//		LogTool.debug(JedisClient_outer.class, "=== redisUrl:"+redisUrl+" ===");
//		redisServer = array[0];
//		redisPort = array[1];
//    	LogTool.warn(JedisClient_outer.class, "redis.url.outer:"+redisServer, true);
//    	LogTool.warn(JedisClient_outer.class, "redis.port:"+redisPort, true);
//		// 在应用初始化的时候生成连接池
//		pool = new JedisPool(config, array[0], Integer.valueOf(array[1]));
//		
//		LogTool.debug(JedisClient_outer.class, "=== JedisPool init:"+pool+" ===");
//	}
//	
//	public static void redis_pool(){
//		// 生成连接池配置信息
//		JedisPoolConfig config = new JedisPoolConfig();
//		config.setMaxIdle(10);
//		config.setMaxTotal(30);
//		config.setMaxWaitMillis(3*1000);
//
//		// 在应用初始化的时候生成连接池
//		JedisPool pool = new JedisPool(config, "10.1.17.97", 6379);
//
//		// 在业务操作时，从连接池获取连接
//		Jedis client = pool.getResource();
//		try {
//		    // 执行指令
//		    String result = client.set("key-string", "Hello, Redis pool!");
//		    System.out.println( String.format("set指令执行结果:%s", result) );
//		    String value = client.get("key-string");
//		    System.out.println( String.format("get指令执行结果:%s", value) );
//		} catch (Exception e) {
//		    LogTool.error(JedisClient_outer.class, e);
//		} finally {
//		    // 业务操作完成，将连接返回给连接池
//		    if (null != client) {
//		        pool.returnResource(client);
//		    }
//		}
//
//		// 应用关闭时，释放连接池资源
//		pool.destroy();
//	}
//	
//	public static byte[] get(byte[] bytes){
//		Jedis client = null;
//		byte[] value = null;
//	    try {
//	    	client = pool.getResource();
//	    	value = client.get(bytes);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//			release(client);
//		}
//		
//		return value;
//	}
//	
//	public static String get(String bytes){
//		Jedis client = null;
//		String value = null;
//	    try {
//	    	client = pool.getResource();
//	    	value = client.get(bytes);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//			release(client);
//		}
//		
//		return value;
//	}
//	
//	public static boolean isCachedInited(String bytes){
//		Jedis client = null;
//	    try {
//	    	client = pool.getResource();
//	    	String value = client.get(bytes);
//	    	
//	    	if (StringUtils.isEmpty(value)) {
//	    		LogTool.debug(JedisClient_outer.class, "isCachedInited："+value);
//				return false;
//			}else {
//				LogTool.debug(JedisClient_outer.class, "isCachedInited："+true);
//			}
//		} catch (Exception e) {
//			return false;
//		} finally {
//			release(client);
//		}
//		
//		return true;
//	}
//	
//	public static void set(byte[] bytes,byte[] valuebytes){
//		Jedis client = null;
//		try {
//			client = pool.getResource();
//			client.set(bytes,valuebytes);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//			release(client);
//		}
//	}
//	
//	public static void set(String key,String value){
//		Jedis client = null;
//		try {
//			client = pool.getResource();
//			client.set(key,value);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//			release(client);
//		}
//	}
//	
//	public static long llen(byte[] bytes){
//		Jedis client = null;
//		long size = 0;
//		try {
//			client = pool.getResource();
//			size = client.llen(bytes);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//			release(client);
//		}
//		return size;
//	}
//	
//	public static long llen(String bytes){
//		Jedis client = null;
//		long size = 0;
//		try {
//			client = pool.getResource();
//			size = client.llen(bytes);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//			release(client);
//		}
//		return size;
//	}
//	
//	public static long rpush(byte[] bytes,byte[] bytesValue){
//		Jedis client = null;
//		long value = 0;
//	    try {
//	    	client = pool.getResource();
//	    	value = client.rpush(bytes, bytesValue);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//			release(client);
//		}
//		
//		return value;
//	}
//	
//	public static long rpush(String key,String string){
//		Jedis client = null;
//		long value = 0;
//	    try {
//	    	client = pool.getResource();
//	    	value = client.rpush(key, string);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//			release(client);
//		}
//		
//		return value;
//	}
//	
//	public static byte[] lpop(byte[] bytes){
//		Jedis client = null;
//		byte[] bytesValue = null;
//	    try {
//	    	client = pool.getResource();
//	    	bytesValue = client.lpop(bytes);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//			release(client);
//		}
//		
//		return bytesValue;
//	}
//	
//	public static String lpop(String key){
//		Jedis client = null;
//		String bytesValue = null;
//	    try {
//	    	client = pool.getResource();
//	    	bytesValue = client.lpop(key);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//			release(client);
//		}
//		
//		return bytesValue;
//	}
//	
//	public static Set<String> keys(String pattern){
//		Jedis client = null;
//		Set<String> set = null;
//	    try {
//	    	client = pool.getResource();
//	    	set = client.keys(pattern);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//			release(client);
//		}
//		return set;
//	}
//	/**
//	 * added by xiluhua
//	 * 增加业务幂等性验证
//	 */
//	public static boolean isExist(String key){
//		Jedis client = null;
//		boolean isExist = false;
//	    try {
//	    	client = pool.getResource();
//	    	// 如果数据存在则返回0，不存在返回1
//	    	if (client.setnx(key,key) == 0) {
//				return true;
//			}
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		}finally{
//		    release(client);
//		}
//		return isExist;
//	}
//	
//	public static void del(String key){
//		Jedis client = null;
//	    try {
//	    	client = pool.getResource();
//	    	client.del(key);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//		    release(client);
//		}
//	}
//	
//	public static void expire(String key,int second){
//		Jedis client = null;
//		try {
//			client = pool.getResource();
//			client.expire(key,second);
//		} catch (Exception e) {
//			LogTool.error(JedisClient_outer.class, e);
//		} finally {
//			release(client);
//		}
//	}
//	
//	/**
//	 *  业务操作完成，将连接返回给连接池
//	 * @param client
//	 */
//	public static void release(Jedis client){
//		// 业务操作完成，将连接返回给连接池
//	    if (null != client) {
//	        pool.returnResource(client);
//	    }
//	}
//	
//	public static void main(String[] args) {
//		JedisClient_outer.redis_pool();
//	}
//}

package com.taiping.facility.tool;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang3.StringUtils;

import com.taiping.common.Base64Tool;

public class ZipFileTool {

	public static void unzip(String zipFilePath, String outputDirectory) {
		try {
			ZipInputStream in = new ZipInputStream(new FileInputStream(zipFilePath));
			ZipEntry z = in.getNextEntry();
			while (z != null) {
				System.out.println("old name:"+z.getName());
				String zipName=z.getName().replaceAll("/", "\\\\");
				System.out.println("unziping " + z.getName());
				//创建以zip包文件名为目录名的根目录
				File f = new File(outputDirectory);
				f.mkdir();
				//如果是目录
				if (z.isDirectory()) {
					String name = zipName;
					System.out.println("dpath " + name);
					name = name.substring(0, name.length() - 1);
					System.out.println("name " + name);
					f = new File(outputDirectory + File.separator + name);
					f.mkdir();
				}
				//如果是文件
				else {
					try{
					System.out.println("fileName: " + zipName);
					String dirpath=ZipFileTool.getDirPath(zipName);
					System.out.println("dirpath " + dirpath);
					f = new File(outputDirectory+File.separator+dirpath);
					f.mkdirs();//构造文件的目录结构
					}
					catch(Exception e){
						e.printStackTrace();
					}
					
					String path=outputDirectory + File.separator + zipName;
					f = new File(path);
					f.createNewFile();
					FileOutputStream out = new FileOutputStream(f);
					int b;
					while ((b = in.read()) != -1) {
						out.write(b);
					}
					out.close();
				}
				//读取下一个ZipEntry
				z = in.getNextEntry();
			}
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//压缩文件夹
    public static void zip(String source,String zipFile) throws IOException { 
        List fileList=loadFilename(new File(source)); 
        ZipOutputStream zos=new ZipOutputStream(new FileOutputStream(new File(zipFile))); 
        
        byte[] buffere=new byte[8192]; 
        int length; 
        BufferedInputStream bis; 
        
        for(int i=0;i<fileList.size();i++) { 
            File file=(File) fileList.get(i); 
            zos.putNextEntry(new ZipEntry(getEntryName(source,file))); 
            bis=new BufferedInputStream(new FileInputStream(file)); 
            
            while(true) { 
                length=bis.read(buffere); 
                if(length==-1) break; 
                zos.write(buffere,0,length); 
            } 
            bis.close(); 
            zos.closeEntry(); 
        } 
        zos.close(); 
    } 
    //压缩单个文件
    public static void zip(String source) throws IOException { 
 
        ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(new File(source + ".zip")));
        byte[] buffere = new byte[8192];
		int length;
		BufferedInputStream bis;
		File file = new File(source);
		zos.putNextEntry(new ZipEntry(getEntryName(source, file)));
		bis = new BufferedInputStream(new FileInputStream(file));

		while (true) {
			length = bis.read(buffere);
			if (length == -1)
			break;
			zos.write(buffere, 0, length);
		}
		bis.close();
		zos.closeEntry();
		zos.close(); 
    } 
    /** *//**
			 * 递归获得该文件夹下所有文件名(不包括目录名)
			 * 
			 * @param file
			 * @return
			 */ 
    private static List loadFilename(File file) { 
        List filenameList=new ArrayList(); 
        if(file.isFile()) { 
            filenameList.add(file); 
        } 
        if(file.isDirectory()) { 
        	File f;
            //for(File f:file.listFiles())
            for(int i=0;i<file.listFiles().length;i++)
            { 
            	f=file.listFiles()[i];
                filenameList.addAll(loadFilename(f)); 
            } 
        } 
        return filenameList; 
    } 
    /** *//** 
     * 获得zip entry 字符串 
     * @param base 
     * @param file 
     * @return 
     */ 
    private static String getEntryName(String base,File file) { 
        File baseFile=new File(base); 
        String filename=file.getPath(); 
        if(baseFile.getParentFile().getParentFile()==null) 
            return filename.substring(baseFile.getParent().length()); 
        return filename.substring(baseFile.getParent().length()+1); 
    } 
    
    private static String getDirPath(String filePath){
    	 int i=filePath.lastIndexOf("\\");
    	 String dirPath=filePath.subSequence(0, i).toString();

    	return dirPath;
    }
 
	public static void main(String[] args) throws Exception {
		ZipFileTool.zip("F:\\test","f:\\test.zip");
		ZipFileTool.unzip("F:\\test.zip", "F:\\unzipTest"); 
        ZipFileTool.unzip("F:\\logs.zip", "F:\\unzipLog"); 

	}
//	public static void main(String[] args) throws Exception {
//		String dir=args[0];
//		String zip=args[1];
//		ZipFileTool.zip(dir,zip);
//        //ZipFileTool.unzip("F:\\test.zip", "F:\\unzip"); 
//
//	}
	/**
	 * GZip工具类
	 * zip压缩解压并使用Base64进行编码工具类
	 * 调用：
	 * 压缩
	 *  GZipUtil.compress(str)
	 * 解压
	 * GZipUtil.uncompressToString(bytes)
	 */
    private static final String TAG = "GzipUtil";
    /**
     * 将字符串进行gzip压缩
     *
     * @param data
     * @return
     */
    public static String compress(String data) {
        if (data == null || data.length() == 0) {
            return null;
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        GZIPOutputStream gzip;
        try {
            gzip = new GZIPOutputStream(out);
            gzip.write(data.getBytes("utf-8"));
            gzip.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return Base64Tool.encode(out.toByteArray());
    }

    public static String uncompress(String data) {
        if (StringUtils.isEmpty(data)) {
            return null;
        }
        byte[] decode = Base64Tool.decode(data);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ByteArrayInputStream in = new ByteArrayInputStream(decode);
        GZIPInputStream gzipStream = null;
        try {
            gzipStream = new GZIPInputStream(in);
            byte[] buffer = new byte[256];
            int n;
            while ((n = gzipStream.read(buffer)) >= 0) {
                out.write(buffer, 0, n);
            }
        } catch (IOException e) {
        	LogTool.error(ZipFileTool.class, e);
        } finally {
            try {
                out.close();
                if (gzipStream != null) {
                    gzipStream.close();
                }
            } catch (IOException e) {
                LogTool.error(ZipFileTool.class, e);
            }
        }
        return new String(out.toByteArray(), Charset.forName("utf-8"));
    }

}

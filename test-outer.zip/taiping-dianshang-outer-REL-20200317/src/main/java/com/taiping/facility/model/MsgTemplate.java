package com.taiping.facility.model;


/**
 * 报文模板对象
 * @author Administrator
 *
 */
public class MsgTemplate {
	private Long requestTemplateId; 		// 请求模版ID
	private Long responseTemplateId; 		// 返回模版ID
	
	public static void main(String[] args) {
		for (int i = 1; i < 10; i++) {
			int k = Math.abs(i*2 - 1);
			System.out.print(k+",");
			System.out.println(k+1);
		}
	}
	/**
	 * @param requestTemplateId
	 * @param responseTemplateId
	 */
	public MsgTemplate(int interfaceId,int phase) {
		super();
		int request = Math.abs(phase*2 - 1);
		int response = request +1;
		this.requestTemplateId = Long.valueOf(interfaceId+""+request);
		this.responseTemplateId = Long.valueOf(interfaceId+""+response);
	}
	
	
	public Long getRequestTemplateId() {
		return requestTemplateId;
	}
	public void setRequestTemplateId(Long requestTemplateId) {
		this.requestTemplateId = requestTemplateId;
	}
	public Long getResponseTemplateId() {
		return responseTemplateId;
	}
	public void setResponseTemplateId(Long responseTemplateId) {
		this.responseTemplateId = responseTemplateId;
	}
	
	
}

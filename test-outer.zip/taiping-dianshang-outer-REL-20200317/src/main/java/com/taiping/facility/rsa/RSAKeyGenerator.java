package com.taiping.facility.rsa;

import java.io.IOException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import sun.misc.BASE64Encoder;

@SuppressWarnings("restriction")
public class RSAKeyGenerator {
    
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException{
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA"); //创建‘密匙对’生成器
        kpg.initialize(1024); //指定密匙长度（取值范围：512～2048）
        KeyPair kp = kpg.genKeyPair(); //生成‘密匙对’，其中包含着一个公匙和一个私匙的信息
        PublicKey public_key = kp.getPublic(); //获得公匙
        PrivateKey private_key = kp.getPrivate(); //获得私匙
        
        //输出公匙
        System.out.println("public key:");
        String publicKey = new BASE64Encoder().encode(public_key.getEncoded());
        System.out.println(publicKey);
        
        //输出私匙
        System.out.println("private key:");
        String privateKey = new BASE64Encoder().encode(private_key.getEncoded());
        System.out.println(privateKey);
        
        /**
         * 验证
         */
        String data = "龚";
        String encrypt = AsymmtricCryptoUtil.encrypt(data, publicKey);
        String decrypt = AsymmtricCryptoUtil.decrypt(encrypt, privateKey);
        System.out.println(decrypt.equals(data));
    }
}

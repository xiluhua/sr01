package com.taiping.facility.tool;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;




public class PdfDownloadTool {
	private Map parameters = new HashMap();
	private String url;
	private String service;
	private String sendEncode = "UTF-8";
	private String receiceEncode = "UTF-8";
	private String host;
	private int port;
	

	@SuppressWarnings("unchecked")
	public void addParameter(String name, String value) {
		this.parameters.put(name, value);
	}
	public void setProxy(String host, String port) {
		/*System.getProperties().put("proxySet","true");   
        System.getProperties().setProperty("http.proxyHost",host);   
        System.getProperties().setProperty("http.proxyPort",port); */
		// modify by liuhe 20190531 天安产品电子保单下载设置代理请求，避免全局的代理影响其他业务
		this.host = host;
		this.port = Integer.parseInt(port);
	}
	public String post() throws Exception{
		String response="";
		try {
			response=this.send();
		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception("PostFailure,Url:"+url, e);
		}
		return response;
	}
	public String get(String httpUrl,String encode) throws Exception{
		String html = "";
		try {
			System.out.println("Http Access Url:" + httpUrl);
			URL url = new URL(httpUrl);
			URLConnection c = url.openConnection();
			InputStream inputs = c.getInputStream();
			int all = inputs.available();
			byte[] b = new byte[all];
			inputs.read(b);
			html = new String(b, encode);
			inputs.close();
		}

		catch (Exception e) {
			e.printStackTrace();
			throw new Exception("getFailure,Url:"+httpUrl);

		}
		String returnContent=html.toString();
		System.out.println("Url return:\n" + returnContent);
		return returnContent;
	}

	/**
	 * 发送对帐请求，适用于返回xml的请求
	 * @return Document 结果
	 * @throws Exception 
	 * @throws Exception
	 */
	private String send() throws Exception {	
		String paramStr = "";
		Object[] services = parameters.keySet().toArray();
		StringBuffer rspContent = null;
		BufferedReader reader = null;
		DataInputStream in = null;
		URLConnection con;
		URL url; 
		String response;
		for (int i = 0; i < services.length; i++) {
			if (i == 0) {
				paramStr += services[i]
						+ "="
						+ URLEncoder.encode(parameters.get(services[i]).toString(), this.getSendEncode());
			} else {
				paramStr += "&"
						+ services[i]
						+ "="
						+ URLEncoder.encode(parameters.get(services[i]).toString(), this.getSendEncode());
			}
		}
		try {
			url = new URL(this.getUrl());
			con = url.openConnection();
			con.setUseCaches(false);
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setRequestProperty("Content-type","application/x-www-form-urlencoded");
			byte[] sendParamByte = paramStr.toString().getBytes("iso8859_1");
			con.setRequestProperty("Content-length", String.valueOf(sendParamByte.length));
			DataOutputStream dataOut = new DataOutputStream(con.getOutputStream());
			dataOut.write(sendParamByte);
			dataOut.flush();
			dataOut.close();
			rspContent = new StringBuffer();
			in = new DataInputStream(con.getInputStream());
			reader = new BufferedReader(new InputStreamReader(in, this.getReceiceEncode()));
			String aLine;
			while ((aLine = reader.readLine()) != null) {
				rspContent.append(aLine+"\n");
			}
			response = rspContent.toString();
			in.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		 
		} finally {
			if (reader != null)
				reader.close();
			if (in != null)
				in.close();
		}
		return response;
	}
	
	public String sendStream(String content) throws Exception {
		String paramStr = URLEncoder.encode(content, this.getSendEncode());
		StringBuffer rspContent = null;
		BufferedReader reader = null;
		DataInputStream in = null;
		URLConnection con;
		URL url; 
		String response;
		try {
			url = new URL(this.getUrl());
			con = url.openConnection();
			con.setUseCaches(false);
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setRequestProperty("Content-type","application/x-www-form-urlencoded");
			byte[] sendParamByte = paramStr.toString().getBytes("iso8859_1");
			con.setRequestProperty("Content-length", String.valueOf(sendParamByte.length));
			con.setRequestProperty("Keep-alive", "false");
			
			DataOutputStream dataOut = new DataOutputStream(con.getOutputStream());
			dataOut.write(sendParamByte);
			dataOut.flush();
			dataOut.close();
			rspContent = new StringBuffer();
			in = new DataInputStream(con.getInputStream());
			reader = new BufferedReader(new InputStreamReader(in, this.getReceiceEncode()));
			String aLine;
			while ((aLine = reader.readLine()) != null) {
				rspContent.append(aLine+"\n");
			}
			response = rspContent.toString();
			in.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		 
		} finally {
			if (reader != null)
				reader.close();
			if (in != null)
				in.close();
		}
		return response;
	}
	public String sendObjStream(Object content) throws Exception {
		StringBuffer rspContent = null;
		BufferedReader reader = null;
		DataInputStream in = null;
		URLConnection con;
		URL url; 
		String response;
		try {
			url = new URL(this.getUrl());
			con = url.openConnection();
			con.setUseCaches(false);
			con.setDoOutput(true);
			con.setDoInput(true);
			//con.setRequestProperty("Content-type","application/x-www-form-urlencoded");
			//byte[] sendParamByte = content.getBytes("iso8859_1");
			//con.setRequestProperty("Content-length", String.valueOf(sendParamByte.length));
			//con.setRequestProperty("Keep-alive", "false");
			
			//ObjectInputStream ins = new ObjectInputStream(in);
			ObjectOutputStream dataOut = new ObjectOutputStream(con.getOutputStream());
			dataOut.writeObject(content);
			//write(sendParamByte);
			dataOut.flush();
			dataOut.close();
			rspContent = new StringBuffer();
			in = new DataInputStream(con.getInputStream());
			reader = new BufferedReader(new InputStreamReader(in, this.getReceiceEncode()));
			String aLine;
			while ((aLine = reader.readLine()) != null) {
				rspContent.append(aLine+"\n");
			}
			response = rspContent.toString();
			in.close();

		} catch (Exception e) {
			e.printStackTrace();
			throw new Exception(e);
		 
		} finally {
			if (reader != null)
				reader.close();
			if (in != null)
				in.close();
		}
		return response;
	}
	

	public void persistentPDF(String conurl, String fileName)
			throws IOException {
		String paramStr = "";
		Object[] services = parameters.keySet().toArray();
		DataInputStream in = null;
		java.net.URL url;
		URLConnection con;
		int totalSize = 0;
		try {
			for (int i = 0; i < services.length; i++) {
				if (i == 0) {
					paramStr += services[i]
							+ "="
							+ URLEncoder.encode(parameters.get(services[i])
									.toString(), this.getSendEncode());
				} else {
					paramStr += "&"
							+ services[i]
							+ "="
							+ URLEncoder.encode(parameters.get(services[i])
									.toString(), this.getSendEncode());
				}
			}
			LogTool.debug(this.getClass(), "\nServiceName:" + this.service
					+ "\n" + "Request URL:" + conurl);
			LogTool.debug(this.getClass(), "=== paramStr === "+paramStr);

			url = new URL(conurl);
			// add by liuhe 20190531 设置代理请求
			if(!StringUtils.isEmpty(host)) {
				InetSocketAddress addr = new InetSocketAddress(host,port); 
	            Proxy proxy = new Proxy(Proxy.Type.HTTP, addr); // http 代理 
	            con = url.openConnection(proxy);
			}else {
				con = url.openConnection();
			}
			
			con.setUseCaches(false);
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setRequestProperty("Content-type",
					"application/x-www-form-urlencoded");
			byte[] sendParamByte = paramStr.toString().getBytes("ISO8859-1");
			con.setRequestProperty("Content-length", String
					.valueOf(sendParamByte.length));
			DataOutputStream dataOut = new DataOutputStream(con
					.getOutputStream());
			dataOut.write(sendParamByte);
			dataOut.flush();
			dataOut.close();
			in = new DataInputStream(con.getInputStream());
			if (in != null) {
				OutputStream outPDFStream = new FileOutputStream(fileName);
				int readSize = 0;
				int blockSize = 15360;
				byte[] buffer = new byte[blockSize];
				while ((readSize = in.read(buffer, 0, buffer.length)) > 0) {
					outPDFStream.write(buffer, 0, readSize);
					totalSize = totalSize+readSize;
				}
				outPDFStream.close();
			}
			LogTool.info(this.getClass(), "conurl:"+conurl);
			LogTool.info(this.getClass(), "fileName:"+fileName);
			LogTool.info(this.getClass(), "totalSize:"+totalSize);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (in != null)
				in.close();
		}

	}

	public String getSendEncode() {
		return sendEncode;
	}

	public void setSendEncode(String sendEncode) {
		this.sendEncode = sendEncode;
	}

	public String getReceiceEncode() {
		return receiceEncode;
	}

	public void setReceiceEncode(String receiceEncode) {
		this.receiceEncode = receiceEncode;
	}

	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public Map getParameters() {
		return parameters;
	}
	public void setParameters(Map parameters) {
		this.parameters = parameters;
	}
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}

	public static void main(String[] args) throws Exception {
		PdfDownloadTool client=new PdfDownloadTool();
		client.setProxy("10.100.11.148", "909");
		client.setUrl("http://www.baidu.com");
		client.addParameter("test1", "1");
		String returnContent=client.post();
		System.out.println(returnContent);
	}

}

/**
 * Created by sinosoft on 2017/8/28.
 */
/**
 * 公共js
 * Created by sinosoft on 2017/7/26.
 */

//公用表单校验插件初始化
function initDefaultValidator(form) {
    return $(form).validate({
        errorElement: "p",
        errorPlacement:function(err, e) {
            err.text(e.attr('tip-title'));
            var label = e.parent();
            var errAfterDiv = label.attr("err-after-div");
            if(errAfterDiv){
                var errMsgDiv = label.nextAll(".err-msg-div");
                err.addClass("text-error").appendTo(errMsgDiv);
            }else{
                err.addClass("text-error").insertAfter(e);
            }
        },
        showErrors: function (errorMap, errorList) {
            this.defaultShowErrors();
            $.each(errorList, function () {
                var element = $(this.element);
                var err = element.nextAll(".text-error");
                var message = this.message.replace(/{tip-title}/g, element.attr('tip-title') ? element.attr('tip-title') : '该字段');
                err.text(message);
            });
        }
    });
}
//邮箱验证
jQuery.validator.addMethod("validEmail", function (value, element) {
    return (/^([a-z0-9A-Z]+[-_]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\.)+[a-zA-Z]{2,}$/).test(value);
}, $.validator.format("请输入正确的邮箱"));
$.validator.addClassRules("isEmail",{
    required:true,
    validEmail: true
});

//微信号验证
jQuery.validator.addMethod("validWechat", function (value, element) {
    return (/^[a-zA-Z\d_]{5,}$/).test(value);
}, $.validator.format("请输入正确的微信号"));
$.validator.addClassRules("isWechat",{
    required:true,
    validWechat: true
});

//手机号码
jQuery.validator.addMethod("validPhone", function (value, element) {
    return (/^1[3|4|5|8][0-9]\d{4,8}$/).test(value);
}, $.validator.format("请输入正确的手机号"));
$.validator.addClassRules("isPhone",{
    required:true,
    validPhone: true
});

//校验账户名 : 字母开头，允许6-16字节，允许字母数字下划线
jQuery.validator.addMethod("enNum", function (value, element) {
    return this.optional(element) || (/^[a-zA-Z][a-zA-Z0-9_]{5,15}$/).test(value);
}, $.validator.format("字母开头，允许6-16字节，允许字母数字下划线"));
$.validator.addClassRules("isAccount",{
    required: true,
    enNum: true
});
//密码:只允许输入英文、数字、符号
jQuery.validator.addMethod("validPassword", function (value, element) {
    return this.optional(element) ||  (/^[A-Za-z0-9`~!@#$%^&*()-_=+\[\]{}\\|;:'",./<>?]+$/).test(value);
}, $.validator.format("只能输入英文、数字、非中文符号"));
$.validator.addClassRules("isPassword", {
    required: true,
    validPassword: true
});
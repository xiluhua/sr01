$( document ).ready(function(){
	//$('#carRadio').prop("checked");
	$("input[type=radio]").click(function(){
		if($('#carRadio').prop("checked")){
			$('#con1').show();
			$('#con2').hide();
		}else{
			$('#con1').hide();
			$('#con2').show();
		}
	});

	//add by JIAN 20170825
    initDefaultValidator($('#form1'));
    initDefaultValidator($('#form2'));

	//日期控件
	$('#createTime').datetimepicker(
	{
			// onGenerate : function(ct) {
			// 	$(this).find('.xdsoft_today').addClass('xdsoft_disabled');
			// },
			//minDate : 0,
			lang : 'ch',
			format : 'Y-m-d',
			formatTime : 'H:i',
			formatDate : 'Y-m-d',
			//value: dateValueBiz,
			onSelectDate : timechange,
			timepicker : false,
			scrollInput : false,
			yearStart:2005,     //设置最小年份
			yearEnd:2030,
        	// todayBtn:true,
	});

	// $('#createTime1').datetimepicker(
	// {
	// 	onGenerate : function(ct) {
	// 		$(this).find('.xdsoft_today').addClass('xdsoft_disabled');
	// 	},
	// 	//minDate : 0,
	// 	lang : 'ch',
	// 	format : 'Y-m-d',
	// 	formatTime : 'H:i',
	// 	formatDate : 'Y-m-d',
	// 	//value: dateValueBiz,
	// 	onSelectDate : timechange,
	// 	timepicker : false,
	// 	scrollInput : false,
	// 	yearStart:1995,     //设置最小年份
	// 	yearEnd:2030,
	// });

	$('input[data-reveal-id]').click(function(e) {
		e.preventDefault();
		var path = $(this).parent().prev().val();
		
		var modalLocation = $(this).attr('data-reveal-id');
		$('#'+modalLocation).reveal($(this).data());
	});
	
	$(".list1,.list2").mouseover(function(){
		var originClass = $(this).attr("class");
		$(this).attr("class","list3");
		$(this).attr("originClass",originClass);
	});
	$(".list1,.list2").mouseout(function(){
		var originClass = $(this).attr("originClass");
	    $(this).attr("class",originClass);
	});
});


function savetxt(fileURL){
	window.open(downloadUrl+fileURL);
}

function readTxt1(path){
	var a = $('#createTime').val();
	$.ajax({
		url: base + "/openLogTxt.action",
		type: "post",
		data: {"path": path},
		dataType:"text",
		success: function (data) {
			if (data == null || data == '') {
				var str = "查不到该文件";
				alert(str);
                $('#showData').val(str);
			} else {
				$('#showData').val(data)
			}

		},
		error: function (data) {
			alert("后台错误");
		},
	})
}
// add by liuhe 20190321 下载数据库日志
function savetxt2(logId,busiOperateType,logType){
	window.open(downloadUrl2+"?logId="+logId+"&busiOperateType="+busiOperateType+"&logType="+logType);
}
//add by liuhe 20190321 打开数据库日志
function readTxt2(logId,logType){
	var a = $('#createTime').val();
	$.ajax({
		url: "/openLogTxt.action",
		type: "post",
		data: {"logId": logId,"logType":logType},
		dataType:"json",
		success: function (data) {
			if (data == null || data == '') {
				var str = "查不到该文件";
				alert(str);
                $('#showData').val(str);
			} else {
				$('#showData').val(data.data)
			}
		},
		error: function (data) {
			alert("后台错误");
		},
	});
}

function timechange(date) {
	$(".xdsoft_datetimepicker").hide();
	//toggleBtnNext("none", "inline-block");
}

/**
 * 查询后台日志信息
 * @returns {Boolean}
 */
function toQuery(){
    var flag = false;
    var values, i;
	if($('#carRadio').prop("checked")){
        values = $('#form1').serializeArray();
		for(i = 0; i <values.length; i++){
		    if(values[i].value != ""){
                flag = true;
                break;
            }
        }
        if(flag){
            $('#form1').submit();
        }else{
           alert("请至少输入一项查询条件");
           return;
        }

    }else{
        values = $('#form2').serializeArray();
        for(i = 0; i <values.length; i++){
            if(values[i].value != ""){
                flag = true;
                break;
            }
        }
        if(flag){
            $('#form2').submit();
        }else{
            alert("请至少输入一项查询条件");
            return;
        }
	}
}

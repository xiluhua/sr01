require([ "jQuery/jquery.min", "i18n!taiping/locale/nls/Language", "taiping/widget/logDataGrid" ],
		function(undefined, language, _logDataGrid) {
			// 创建log datagrid
			var logDataGrid = new _logDataGrid({
				autoLoad : false,
				currentLogType : 0,
				showIdColumn : true,
				sortMethod : "desc"
			});
			logDataGrid.show("#page_body");
		});
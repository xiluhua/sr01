define(({
	Header : {
		labelSet : {
			"title_app" : "中国太平"
		}
	}
}));
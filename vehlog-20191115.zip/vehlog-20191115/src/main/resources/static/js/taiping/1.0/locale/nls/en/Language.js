define(({
	Header : {
		labelSet : {
			"title_app" : "CHINA TAIPING"
		}
	}
}));
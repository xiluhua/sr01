/**
 * author: Neusoft MATTDAMON
 *
 * 日志信息查询datagrid
 *
 */
(function (window, undefined) {
    define(
        [ "easyUI/easyui.min", "text!./templates/logDataGrid.html" ],
        function (undefined, template) {

            // define Header object
            var _logDataGrid = function (opts) {
                return new _logDataGrid.prototype.initialize(opts);
            };

            _logDataGrid.prototype = {
                constructor: _logDataGrid,
                /** **可在这里添加实例属性*** */
                selector: "", // 选择器
                autoLoad: false,// 是否自动加载数据
                showIdColumn: true,
                sortMethod: "desc",
                /** *内部使用属性** */
                columnsConfig: new Array(), // 日志表列
                currentLogType: 0,// 日志类型，默认为业务操作日志
                currentTitle: "Log信息列表",
                currentLogName: "",
                startDateTime: (new Date()).dateAdd("d", -1).Format("yyyy-MM-dd"),
                endDateTime: (new Date()).Format("yyyy-MM-dd"),
                /** **可在这里添加实例方法*** */
                /** ************************ </INSTANCE-FUNCTION-START>*** */
                // 初始化
                initialize: function (opts) {
                    $.extend(true, this, opts);
                    dateGridConfig(this);
                },
                // 显示datagrid
                show: function (_selector) {
                    this.selector = _selector;
                    // 创建DataGrid
                    dateGrid(this);
                    // 是否自动加载数据
                    if (this.autoLoad) {
                        // 需要自动加在数据时，执行 datagrid toolbar click handler函数
                        toolbarClickHandler(this, this.currentLogType);
                    }
                }
                /** ************************ </INSTANCE-FUNCTION-END>*** */

            };

            _logDataGrid.prototype.initialize.prototype = _logDataGrid.prototype;

            /** ************************ </FUNCTION-START>*** */
                // 加载log表结构配置
            dateGridConfig = function (_self) {
                // 查找所有配置的表名
                var tables = $($(template).find("#table_list")).text().split(",");
                // 创建每个表结构对象
                $.each(tables, function (index, tableName) {

                    // 格式正确
                    if ($(template).find("#" + tableName).length == 1) {
                        // json 字符串转为Object
                        var tableColumnsJson = "{";
                        // 表名
                        tableColumnsJson = tableColumnsJson + "'tableName':'" + tableName
                            + "',";
                        // ID 列
                        var idColumnName = $(
                            $(template).find("#" + tableName + ">div[id='idColumn']"))
                            .text();
                        tableColumnsJson = tableColumnsJson + "'idColumn':'" + idColumnName
                            + "',";

                        tableColumnsJson = tableColumnsJson + "'columns':[["; // 注意两层[]
                        // 判断是否显示ID列
                        if (_self.showIdColumn) {
                            tableColumnsJson = tableColumnsJson + "{";
                            tableColumnsJson = tableColumnsJson + "'field':'" + idColumnName
                                + "',";
                            tableColumnsJson = tableColumnsJson + "'title':'" + idColumnName
                                + "',";
                            tableColumnsJson = tableColumnsJson + "'sortable':" + true + "";
                            tableColumnsJson = tableColumnsJson + "},";
                        }

                        var columnsNode = $(template).find(
                                "#" + tableName + ">div[id='column']");
                        var columnCount = columnsNode.length;
                        $.each(columnsNode, function (index, columnNode) {
                            var columnName = $(columnNode).text();
                            tableColumnsJson = tableColumnsJson + "{";
                            tableColumnsJson = tableColumnsJson + "'field':'" + columnName
                                + "',";
                            tableColumnsJson = tableColumnsJson + "'title':'" + columnName
                                + "',";
                            tableColumnsJson = tableColumnsJson + "'sortable':" + true + "";
                            tableColumnsJson = tableColumnsJson + "}";
                            if (index + 1 != columnCount) {
                                tableColumnsJson = tableColumnsJson + ",";
                            }
                        });
                        tableColumnsJson = tableColumnsJson + "]]";
                        tableColumnsJson = tableColumnsJson + "}";
                        _self.columnsConfig.push(eval("(" + tableColumnsJson + ")"));
                    }

                });
            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
                // 从columnsConfig中取得当前的表结构
            getCurrentTableStructure = function (_self) {
                return _self.columnsConfig[_self.currentLogType];
            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
                // 更新当前日志类型
            modifyCurrentLogType = function (_self, logType) {
                _self.currentLogType = logType;
                var _title = "LOG信息列表";
                if (_self.currentLogType == 0) {
                    _self.currentLogName = "BusinessLog";
                    _title = _title + " - " + "BusinessLog";
                } else if (_self.currentLogType == 1) {
                    _self.currentLogName = "ErrorLog";
                    _title = _title + " - " + "ErrorLog";
                } else if (_self.currentLogType == 2) {
                    _self.currentLogName = "InterfaceLog";
                    _title = _title + " - " + "InterfaceLog";
                } else if (_self.currentLogType == 3) {
                    _self.currentLogName = "MsgLog";
                    _title = _title + " - " + "MsgLog";
                } else if (_self.currentLogType == 4) {
                    _self.currentLogName = "OperateLog";
                    _title = _title + " - " + "OperateLog";
                } else if (_self.currentLogType == 5) {
                    _self.currentLogName = "WebLog";
                    _title = _title + " - " + "WebLog";
                } else if (_self.currentLogType == 6) {
                    _self.currentLogName = "PayLog";
                    _title = _title + " - " + "PayLog";
                }
                _self.currentTitle = _title;
                return _self.currentLogType;
            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
            loadLogData = function (_self) {
                window.setTimeout(function () {

                    $(_self.selector).datagrid({
                        url: 'LogService/query/condition',
                        // 数据加载设置
                        queryParams: { // 请求参数
                            logType: _self.currentLogType,
                            startDateTime: _self.startDateTime,
                            endDateTime: _self.endDateTime
                        },
                        columns: getCurrentTableStructure(_self)['columns'],// 列定义
                        sortName: getCurrentTableStructure(_self)['idColumn'], // 初始化时默认的排序列
                        sortOrder: _self.sortMethod, // 降序排列desc
                        idField: getCurrentTableStructure(_self)['idColumn'],// id列
                        /*
                         * frozenColumns : [ [ { field :
                         * getCurrentTableStructure(_self)['idColumn'],
                         * checkbox : true } ] ],
                         */
                        // 界面Title
                        title: _self.currentTitle
                    });
                    generateToolBar(_self);
                }, 100); // 解决easy ui 发送两次请求的bug

            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
                // 创建DataGrid
            dateGrid = function (_self) {
                $(_self.selector).datagrid({
                    method: "post",// 请求远程数据的方法类型
                    title: _self.currentTitle,
                    iconCls: 'icon-face',// 图标
                    width: 'auto',// 宽度
                    height: 'auto',// 高度
                    autoRowHeight: false,// 自动设置行高
                    loadMsg: '数据装载中......',// processbar
                    nowrap: false, // 文字自动换行
                    striped: true,// 背景交替
                    border: true,// 边框
                    collapsible: false,// 是否可折叠的
                    fit: true,// 自动大小
                    showFooter: false,// 是否显示行底
                    remoteSort: false,// 定义是否通过远程服务器对数据排序
                    rownumbers: true,// 行号
                    singleSelect: true,// 是否单选
                    onLoadSuccess: function (data) { // 数据加载成功
                        if (data && data.rows && data.rows.length > 0) {
                            // 数据加载成功
                        } else {
                            // 无数据
                            $.messager.alert('Info', '无数据');
                        }
                    },
                    onLoadError: function (data) {
                        $.messager.alert('Error', '数据加载失败');
                    },
                    // 分页控件相关设置
                    pagination: true,// 是否显示分页控件
                    pageNumber: 1,
                    pageSize: 10,
                    pageList: [ 10, 50, 100 ],
                    pagePosition: "bottom",// 分页控件显示的位置 top bottom
                    toolbar: []
                });

                generateToolBar(_self);
            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
                // 生成工具栏
            generateToolBar = function (_self) {

                // 拼接logTypeMenu dom
                var logTypeMenuBarDom = "<label style='margin-left:50px;'>请选择日志类型：</label>"
                    + "<a href='javascript:void(0)' id='log_type_bar'>";
                logTypeMenuBarDom = logTypeMenuBarDom + _self.currentLogName;
                logTypeMenuBarDom = logTypeMenuBarDom + "</a>";
                logTypeMenuBarDom = logTypeMenuBarDom
                    + "<div id='log_type_selector' style='width: 150px;'>";
                for (var tableIndex = 0; tableIndex < _self.columnsConfig.length; tableIndex++) {
                    var tableName = _self.columnsConfig[tableIndex]["tableName"];

                    logTypeMenuBarDom = logTypeMenuBarDom
                        + "<div data-options=\"iconCls:'icon-search'\" id='log_type_meun_option' logType='"
                        + tableIndex + "' >";
                    logTypeMenuBarDom = logTypeMenuBarDom + tableName;
                    logTypeMenuBarDom = logTypeMenuBarDom + "</div>";
                }
                logTypeMenuBarDom = logTypeMenuBarDom + "</div>";

                // 添加到datagrid toolbar区域，并创建菜单项
                $(".datagrid-toolbar").append(logTypeMenuBarDom);
                $('#log_type_bar').menubutton({
                    iconCls: 'icon-search',
                    menu: '#log_type_selector'
                });

                // 注册menu option on click handler
                $("div[id=log_type_selector]>div[id=log_type_meun_option]").each(
                    function (index, optionNode) {
                        $(optionNode).click(function () {
                            toolbarClickHandler(_self, $(this).attr("logType"));
                        });
                    });

                /* ===================起始时间 start======================== */
                var startDateDom = "<label style='margin-left:20px;'>起始时间：</label>"
                    + "<input id='startDateBar' type='text' style='width:150px;'></input>";
                $(".datagrid-toolbar").append(startDateDom);
                $('#startDateBar').datebox({
                    required: false,
                    formatter: function (_date) {
                        return _date.Format("yyyy-MM-dd");
                    },
                    onSelect: function (_date) {
                        // 修改时间
                        _self.startDateTime = _date.Format("yyyy-MM-dd");
                        // 加载数据
                        toolbarClickHandler(_self, _self.currentLogType);
                    }
                });
                // Date.format为application.js中扩展的方法
                $('#startDateBar').datebox("setValue", _self.startDateTime);
                /* ===================起始时间 end======================== */

                /* ===================结束时间 start======================== */
                var startDateDom = "<label style='margin-left:20px;'>截至时间：</label>"
                    + "<input id='endDateBar' type='text' style='width:150px;'></input>";
                $(".datagrid-toolbar").append(startDateDom);
                $('#endDateBar').datebox({
                    required: false,
                    formatter: function (_date) {
                        return _date.Format("yyyy-MM-dd");
                    },
                    onSelect: function (_date) {
                        // 修改时间
                        _self.endDateTime = _date.Format("yyyy-MM-dd");
                        // 加载数据
                        toolbarClickHandler(_self, _self.currentLogType);
                    }
                });
                // Date.format为application.js中扩展的方法
                $('#endDateBar').datebox("setValue", _self.endDateTime);
                /* ===================结束时间 end======================== */
            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
                // toolbar 点击事件处理
            toolbarClickHandler = function (_self, logType) {
                // 清除之前创建的菜单选项
                clearToolBarTemp();
                // 修改当前的log类型
                modifyCurrentLogType(_self, parseInt(logType));
                // 加载数据
                loadLogData(_self);
            };
            /** ************************ </FUNCTION-END>*** */

            /** ************************ </FUNCTION-START>*** */
                // 清除之前被创建的菜单选项
            clearToolBarTemp = function () {
                // *重要* 清楚之前创建的menu dom，否则事件会重复被注册
                $("div[id='log_type_selector']").remove();
                $("div[class='menu-shadow']").remove();
                $("div[class='panel combo-p']").remove();
            };
            /** ************************ </FUNCTION-END>*** */

            return _logDataGrid;
        });
})(window);
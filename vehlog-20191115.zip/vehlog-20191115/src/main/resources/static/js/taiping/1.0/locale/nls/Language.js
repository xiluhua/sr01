define({
	root : ({
		Header : {
			labelSet : {
				"title_app" : "中国太平"
			}
		}
	}),
	"zh" : true,
	"en" : true
});
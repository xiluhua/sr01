/**
 * Created by sinosoft on 2017/6/20.
 */
function backHome(){
    window.location = "at-index.action";
}

function detail(partnerApplyId){
    $.ajax({
        url: "at-detail.action",// 跳转到 action
        data: {
            "partnerApplyId": partnerApplyId,
        },
        type: 'post',
        cache: false,
        success: function (data) {
            creatPopUpDom(data);
        }
    })
}

function creatPopUpDom(data){
    ///popHtml是要显示的内容
//                var $txt = $("<p>").html(popHtml);//弹窗文本dom
//                var $txt = $("<p>").html("测试中！！");//弹窗文本dom
//                var $tt = $("<span>").addClass("tt").text(config.title);//标题
    var $tt = $("<span>").addClass("tt").text("详细信息");//标题
    var $icon =  $("<div>").addClass("bigIcon").css("backgroundPosition","") ;
//                var btn = config.btn;//按钮组生成参数

    var popId = creatPopId();//弹窗索引
    var $box = $("<div>").addClass("xcConfirm");//弹窗插件容器
    var $layer = $("<div>").addClass("xc_layer");//遮罩层
    var $popBox = $("<div>").addClass("popBox");//弹窗盒子
    var $ttBox = $("<div>").addClass("ttBox");//弹窗顶部区域
    // var $ttBox = $("<div>").addClass("");//弹窗顶部区域
    var $txtBox = $("<div>").addClass("txtBox");//弹窗内容主体区
    var $btnArea = $("<div>").addClass("btnArea");//按钮区域

    var $ok = $("<a>").addClass("sgBtn").addClass("ok").text("确定");//确定按钮
    var $cancel = $("<a>").addClass("sgBtn").addClass("cancel").text("取消");//取消按钮
    var $input = $("<input>").addClass("inputBox");//输入框
    var $clsBtn = $("<a>").addClass("clsBtn");//关闭按钮

    var $table = $("<table>").addClass("xcTable");
    var $bgp = $("<div>").addClass("btnGroup");

    //chrome对map遍历按照ECMAScript-5.1,结果不按照顺序
    $.each(data,function (key,value) {
        var str = "<tr><td>"+key +"</td><td>" + value +"</td></tr>";
        $table.append(str);
    })

//        data.model.forEach(function (value, key) {
//            var str = "<tr><td>"+key +"</td><td>" + value +"</td></tr>";
//            $table.append(str);
//        })

    $popBox.append(
        $ttBox.append($clsBtn
        ).append($tt
        )
    ).append(
        $txtBox.append($icon).append($table)
    ).append(
        $btnArea.append($bgp.append($ok))
    );
    $box.attr("id", popId).append($layer).append($popBox);
    $("body").append($box);

    $ok.bind("click",function(){doClose(popId)});
    $clsBtn.bind("click",function(){doClose(popId)});

    $(window).bind("keydown", function(e){
        if(e.keyCode == 13 || e.keyCode == 27) {
            if($("#" + popId).length == 1){
                doClose(popId);
            }
        }
    });
}

function doClose(popId){
    $("#" + popId).remove();
}

//重生popId,防止id重复
function creatPopId(){
    var i = "pop_" + (new Date()).getTime()+parseInt(Math.random()*100000);//弹窗索引
    if($("#" + i).length > 0){
        return creatPopId();
    }else{
        return i;
    }
}
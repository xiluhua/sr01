
/** 获取form表单 */
function getTableForm() {
	return document.getElementById('tableForm');
}

/**翻页脚本*/
function pageNumber(pageNum){
	$(".pageNumber").val(pageNum);
	var f = getTableForm();
	f.submit();
}
function pageGo(){
	var mathW = /^[0-9]\d*$/;
	var pageNum = $("#pageNumber").val();
	var pageCount = $(".pageCount").val();
	if(pageNum==null||pageNum==""){
		$("#pageNumber").focus();
		alert("翻页页数不能为空！");
		return;
	}
	if(!mathW.test(pageNum)){
		$("#pageNumber").focus();
		alert("翻页页数类型有误！");
		return;
	}
	if((parseInt(pageNum) > parseInt(pageCount))||(pageNum < 0)){
		$("#pageNumber").focus();
		alert("翻页页数有误！");
		return;
	}
	pageNumber(pageNum);
}
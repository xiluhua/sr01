// navi
var iframe = null;
var    nav = null;
$(function () {
    iframe = document.getElementById('iframe');
       nav = $("#nav");
    setTimeout("out()",5000);
});

function toggle(){
	var height = $(nav).css("min-height");
	if(height == '12px'){
		$(nav).css("min-height","50px");
		$(nav).attr("title","还原");
		$("#nav2,#nav3").css("display","block");
		$("#sidebar").css("min-height","50px").css("height","50px");
	}else{
		$(nav).css("min-height","12px");
		$("#sidebar").css("min-height","12px").css("height","12px").css("padding-top","0px").css("padding-bottom","0px");
		$("#nav2,#nav3").css("display","none");
		$(nav).attr("title","最小化");
	}
}

function hover(){
	
}

function out(){
	$(nav).css("min-height","12px");
	$("#sidebar").css("min-height","12px").css("height","12px").css("padding-top","0px").css("padding-bottom","0px");
	$("#nav2,#nav3").css("display","none");
	$(nav).attr("title","还原");
}

// menu
function forward(menu,num){
	if(menu == 'test'){
		testMenu(num);
	}
	if(menu == 'bs'){
		bsMenu(num);
	}
	if(menu == 'co'){
		cooperMenu(num);
	}
}
// 自动测试
function testMenu(num){
	if(num == 1){
		iframe.src=base+"/at-index.action";
	}
	if(num == 2){
		iframe.src=base+"/history/index.action";
	}
}
// 业务
function bsMenu(num){
	if(num == 1){
		iframe.src=base+"/bs-partners.action";
	}
	if(num == 2){
		iframe.src=base+"/history/index.action";
	}
}
// 合作方
function cooperMenu(num){
	if(num == 0){
		iframe.src=base+"/bs-partners.action";
	}
	if(num == 1){
		iframe.src=base+"/co-1-test-choose.action";
	}
	if(num == 2){
		iframe.src=base+"/history/index.action";
	}
}


package com.taiping.jinfu.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * 投保请求实体类
 * @author xilh
 * @since 20191119
 */
@Entity
@Table(name = "TP_QUOTE")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class TpQuote implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	@Id
	@Column(name = "ID")
	private String id;
	@Column(name = "PARTNER_QT_ID")
	private String partnerQtId;
	@Column(name = "QUOTE_NO")
	private String quoteNo;
	@Column(name = "PREMIUM")
	private Double premium;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "VALIDATE_DATE")
	private Date validateDate;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "EXPIRE_DATE")
	private Date expireDate;
	@Column(name = "SELL_CHANNEL")
	private Integer sellChannel;
	@Column(name = "ORDER_NO_SC")
	private String orderNoSc;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "QUOTE_TIME")
	private Date quoteTime;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CHECK_TIME")
	private Date checkTime;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "ACCEPT_TIME")
	private Date acceptTime;
	@Column(name = "QUOTE_STATUS")
	private Integer quoteStatus;
	@Column(name = "CHECK_STATUS")
	private Integer checkStatus;
	@Column(name = "ACCEPT_STATUS")
	private Integer acceptStatus;
	@Column(name = "PAY_STATUS")
	private Integer payStatus;
	@Column(name = "PAY_ID")
	private String payId;
	@Column(name = "PACKAGE_CODE")
	private String packageCode;
	@Column(name = "CITY_CODE")
	private String cityCode;
	@Column(name = "CITY_NAME")
	private String cityName;
	@Column(name = "BUSINESS_TYPE")
	private Integer businessType;
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "PARTNER_ID", unique = true, nullable = false, precision = 10, scale = 0)
	private Long partnerId;
	@Column(name = "MEDIUM_NUMBER")
	private String mediumNumber;
	@Column(name = "MEDIUM_NUMBER_INNER")
	private String mediumNumberInner;
	@Column(name = "CHANNEL_NUMBER")
	private String channelNumber;
	@Column(name = "SALES_PERSON_ORGCODE")
	private String salesPersonOrgcode;
	@Column(name = "SALES_PERSON_ORGNAME")
	private String salesPersonOrgname;
	@Column(name = "ACTIVITY_ID")
	private String activityId;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "CREATE_TIME")
	private Date createTime;
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "UPDATE_TIME")
	private Date updateTime;

	// Constructors

	/** default constructor */
	public TpQuote() {
	}

	// Property accessors
	public Long getPartnerId() {
		return this.partnerId;
	}

	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return this.updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPartnerQtId() {
		return partnerQtId;
	}

	public void setPartnerQtId(String partnerQtId) {
		this.partnerQtId = partnerQtId;
	}
	
	public String getQuoteNo() {
		return quoteNo;
	}

	public void setQuoteNo(String quoteNo) {
		this.quoteNo = quoteNo;
	}
	
	public Double getPremium() {
		return premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	public Date getValidateDate() {
		return validateDate;
	}

	public void setValidateDate(Date validateDate) {
		this.validateDate = validateDate;
	}

	public Date getExpireDate() {
		return expireDate;
	}

	public void setExpireDate(Date expireDate) {
		this.expireDate = expireDate;
	}

	public Integer getSellChannel() {
		return sellChannel;
	}

	public void setSellChannel(Integer sellChannel) {
		this.sellChannel = sellChannel;
	}

	public Date getQuoteTime() {
		return quoteTime;
	}

	public void setQuoteTime(Date quoteTime) {
		this.quoteTime = quoteTime;
	}
	
	public Date getCheckTime() {
		return checkTime;
	}

	public void setCheckTime(Date checkTime) {
		this.checkTime = checkTime;
	}

	public Date getAcceptTime() {
		return acceptTime;
	}

	public void setAcceptTime(Date acceptTime) {
		this.acceptTime = acceptTime;
	}

	public Integer getQuoteStatus() {
		return quoteStatus;
	}

	public void setQuoteStatus(Integer quoteStatus) {
		this.quoteStatus = quoteStatus;
	}

	public Integer getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}

	public Integer getAcceptStatus() {
		return acceptStatus;
	}

	public void setAcceptStatus(Integer acceptStatus) {
		this.acceptStatus = acceptStatus;
	}

	public Integer getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(Integer payStatus) {
		this.payStatus = payStatus;
	}

	public String getPayId() {
		return payId;
	}

	public void setPayId(String payId) {
		this.payId = payId;
	}

	public String getPackageCode() {
		return packageCode;
	}

	public void setPackageCode(String packageCode) {
		this.packageCode = packageCode;
	}

	public String getCityCode() {
		return cityCode;
	}

	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Integer getBusinessType() {
		return businessType;
	}

	public void setBusinessType(Integer businessType) {
		this.businessType = businessType;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getMediumNumber() {
		return mediumNumber;
	}

	public void setMediumNumber(String mediumNumber) {
		this.mediumNumber = mediumNumber;
	}

	public String getMediumNumberInner() {
		return mediumNumberInner;
	}

	public void setMediumNumberInner(String mediumNumberInner) {
		this.mediumNumberInner = mediumNumberInner;
	}

	public String getChannelNumber() {
		return channelNumber;
	}

	public void setChannelNumber(String channelNumber) {
		this.channelNumber = channelNumber;
	}

	public String getSalesPersonOrgcode() {
		return salesPersonOrgcode;
	}

	public void setSalesPersonOrgcode(String salesPersonOrgcode) {
		this.salesPersonOrgcode = salesPersonOrgcode;
	}

	public String getSalesPersonOrgname() {
		return salesPersonOrgname;	
	}

	public void setSalesPersonOrgname(String salesPersonOrgname) {
		this.salesPersonOrgname = salesPersonOrgname;
	}

	public String getActivityId() {
		return activityId;
	}

	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}

	public String getOrderNoSc() {
		return orderNoSc;
	}

	public void setOrderNoSc(String orderNoSc) {
		this.orderNoSc = orderNoSc;
	}

}
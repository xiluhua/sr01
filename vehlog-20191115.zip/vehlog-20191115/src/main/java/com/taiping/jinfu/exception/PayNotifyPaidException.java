package com.taiping.jinfu.exception;

public class PayNotifyPaidException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public PayNotifyPaidException(String msg){
		super(msg);
	}
	
	public PayNotifyPaidException(){
		super("该单支付完成承保中，详情请与商家联系");
	}

	public PayNotifyPaidException(String msg, String code) {
		super(msg, code);
	}
}


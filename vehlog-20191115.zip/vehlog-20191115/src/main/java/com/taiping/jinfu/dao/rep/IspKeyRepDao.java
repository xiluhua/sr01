package com.taiping.jinfu.dao.rep;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.taiping.jinfu.entity.IspKey;

/**
 * @author liuhe
 * @since 20190306
 */
public interface IspKeyRepDao extends PagingAndSortingRepository<IspKey, Long> {

	@Query(value="SELECT t from IspKey t where t.keyID = ?1")
	public IspKey getIspKey(Long keyID);
	
	@Query(value="SELECT t from IspKey t where t.keyName = ?1")
	public IspKey getIspKeyByName(String keyName);
	
}

/**
 * @(#)LogToFileMangage.java
 *       
 * project：taiping-sol-insu-vehicle
 * 
 * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.jinfu.log.service;

/**
 *<p>Description : </p>
 *<p>Date        : Nov 13, 2015</p>
 *<p>Remark      : </p>
 * @version
 * @author xiluhua by 20160125
 */
public interface LogClearService {

	public void clearDsBusiOpeLog_batch(String threadx);
	
}
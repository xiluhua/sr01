package com.taiping.jinfu.service.validSqlInject.impl;

import org.springframework.stereotype.Component;

import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.jinfu.constant.Ret;
import com.taiping.jinfu.exception.SqlInjectException;
import com.taiping.jinfu.service.validSqlInject.AntiSqlInjectService;

@Component
public class AntiSqlInjectImpl implements AntiSqlInjectService{
	
	/**
	 * @param str  待验证的字符串
	 * @param reg  正则表达式
	 * @author xilh
	 * @since 20190301
	 * DEMO:String reg = "select|update|delete|insert|trancate|substr|ascii|exec|master|drop|execute";
	 * @return
	 * @throws Exception 
	 */
	public void verify(String str){
		
		String reg = CacheContainer.getSysParamValue("anti.sql.inject", true);
		String[] array = reg.split("\\|");
		for (int i = 0; i < array.length; i++) {
			String temp = array[i].toLowerCase();
			if (str.toLowerCase().indexOf(temp) > -1) {
				throw new SqlInjectException("请求包含非法敏感字符", Ret.C1011);
			}
		}
	}
}

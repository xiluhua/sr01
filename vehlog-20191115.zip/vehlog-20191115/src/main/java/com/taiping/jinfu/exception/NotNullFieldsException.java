package com.taiping.jinfu.exception;

public class NotNullFieldsException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public NotNullFieldsException(String msg){
		super(msg);
	}

	public NotNullFieldsException(String msg, String code) {
		super(msg, code);
	}

	public NotNullFieldsException() {
	}

}


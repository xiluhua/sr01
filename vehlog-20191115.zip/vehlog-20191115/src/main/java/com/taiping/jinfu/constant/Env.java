package com.taiping.jinfu.constant;

import com.taiping.facility.tool.LogTool;

/**
 * 环境工具
 * @author xilh by 20160119
 *
 */
public class Env {
	
	// add by xiluhua 20190409
	public static String DATABASE 	= null;
	public static String ENV		= null;
	
	public static String localIp = null;
	public static boolean isLocal = false;
	public static boolean isUat = false;
	public static boolean isFormal = false;
	
	static{
		localIp = LogTool.getLocalIp();
		isUat = localIp.equals("172.31.20.236");
		isFormal = localIp.equals("172.31.10.62") || localIp.equals("172.31.20.239");
		isLocal = !isUat && !isFormal;
	}
}

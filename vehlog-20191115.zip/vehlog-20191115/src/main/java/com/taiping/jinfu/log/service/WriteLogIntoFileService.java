package com.taiping.jinfu.log.service;

import com.taiping.common.bean.ScIlogMsg;

public interface WriteLogIntoFileService {
	public void saveLogFile(ScIlogMsg msg);
}

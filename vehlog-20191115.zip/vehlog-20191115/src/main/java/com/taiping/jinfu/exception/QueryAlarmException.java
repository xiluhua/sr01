package com.taiping.jinfu.exception;

public class QueryAlarmException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public QueryAlarmException(String msg){
		super(msg);
	}

	public QueryAlarmException(String msg, String code) {
		super(msg, code);
	}

	public QueryAlarmException() {
	}

}


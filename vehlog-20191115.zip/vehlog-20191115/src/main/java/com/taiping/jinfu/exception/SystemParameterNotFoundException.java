package com.taiping.jinfu.exception;

public class SystemParameterNotFoundException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public SystemParameterNotFoundException(String msg){
		super(msg);
	}

	public SystemParameterNotFoundException(String msg, String code) {
		super(msg, code);
	}

	public SystemParameterNotFoundException() {
	}

}


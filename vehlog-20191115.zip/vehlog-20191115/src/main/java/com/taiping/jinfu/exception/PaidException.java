package com.taiping.jinfu.exception;

public class PaidException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public PaidException(String msg){
		super(msg);
	}
	
	public PaidException(){
		super("该单支付完成承保中，详情请与商家联系");
	}

	public PaidException(String msg, String code) {
		super(msg, code);
	}
}


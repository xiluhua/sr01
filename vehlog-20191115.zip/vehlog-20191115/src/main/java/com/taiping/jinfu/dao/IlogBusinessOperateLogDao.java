package com.taiping.jinfu.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Repository;

import com.taiping.facility.tool.DateTool;
import com.taiping.jinfu.dao.rep.IlogBusinessOperateLogRepDao;
import com.taiping.jinfu.entity.IlogBusinessLogContent;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;

@Repository
public class IlogBusinessOperateLogDao {
	
	@PersistenceContext
	private EntityManager entityManager;
	@Resource
	private IlogBusinessOperateLogRepDao ilogBusinessOperateLogRepDao;

	public List<IlogBusinessOperateLog> queryLog(IlogBusinessOperateLog iLog) {
		StringBuilder hql = new StringBuilder(" from  IlogBusinessOperateLog l where 1=1 ");
		if(StringUtils.isNotEmpty(iLog.getApplyId())) {
			hql.append(" and l.applyId='"+iLog.getApplyId()+"'");
		}
		if(StringUtils.isNotEmpty(iLog.getPartnerTransCode())) {
			hql.append(" and l.partnerTransCode='"+iLog.getPartnerTransCode()+"'");
		}
		if(StringUtils.isNotEmpty(iLog.getOperateNo1())) {
			hql.append(" and l.operateNo1='"+iLog.getOperateNo1()+"'");
		}
		if(StringUtils.isNotEmpty(iLog.getHolderName())) {
			hql.append(" and l.holderName='"+iLog.getHolderName()+"'");
		}
		if(StringUtils.isNotEmpty(iLog.getHolderIdno())) {
			hql.append(" and l.holderIdno='"+iLog.getHolderIdno()+"'");
		}
		if(iLog.getCreateTime()!=null) {
			hql.append(" and DATE_FORMAT(l.createTime, '%Y-%m-%d')='"+DateTool.getFormatDate("yyyy-MM-dd", iLog.getCreateTime())+"'");
		}
		hql.append(" order by l.createTime");
		
		@SuppressWarnings("unchecked")
		List<IlogBusinessOperateLog> list = entityManager.createQuery(hql.toString()).getResultList();
		return list;
	}
	
	public IlogBusinessLogContent getLogFileContentByLogId(String logId,Integer logType) {
		return ilogBusinessOperateLogRepDao.getLogFileContentByLogId(logId,logType);
	}
}

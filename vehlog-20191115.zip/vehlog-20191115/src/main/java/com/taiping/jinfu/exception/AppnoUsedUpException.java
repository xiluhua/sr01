package com.taiping.jinfu.exception;

public class AppnoUsedUpException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public AppnoUsedUpException(String msg){
		super(msg);
	}
	
	public AppnoUsedUpException(){
		super("投保单号不足，如有疑问，请与商家联系");
	}

	public AppnoUsedUpException(String msg, String code) {
		super(msg, code);
		// TODO Auto-generated constructor stub
	}
}


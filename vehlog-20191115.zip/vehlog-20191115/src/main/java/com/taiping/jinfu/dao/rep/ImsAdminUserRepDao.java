package com.taiping.jinfu.dao.rep;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.taiping.jinfu.entity.ImsAdminUser;

/**
 * @author xilh
 * @since 20170920
 */
public interface ImsAdminUserRepDao extends PagingAndSortingRepository<ImsAdminUser, Long>{

    @Query(value="SELECT t from ImsAdminUser t where t.status = ?1")
	public List<ImsAdminUser> getAllUser();
    
    @Query(value="SELECT t from ImsAdminUser t where t.status = 1 and username = ?1 and password = ?2")
    public ImsAdminUser getUser(String userName,String password);

    @Query(value="SELECT t from ImsAdminUser t where t.status = 1 and username = ?1")
	public List<ImsAdminUser> findByUserName(String username);
}

package com.taiping.jinfu.exception;

public class MockCheckBillException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public MockCheckBillException(String msg){
		super(msg);
	}

	public MockCheckBillException(String msg, String code) {
		super(msg, code);
	}

	public MockCheckBillException() {
	}
}


package com.taiping.jinfu.constant;

public interface Ret {

	/**
	 * 报文解析出错 - 解析外部核心系统返回的报文
	 */
	public static final String ErrorDocParse 			= "1104";
	/**
	 * 报文解析出错 - 解析响应报文（我们请求第三方，第三方响应我们)
	 */
	public static final String C2001		 			= "2001";
	/**
	 * 报文解析出错 - 第三方请求我们
	 */
	public static final String C2003 					= "2003";
	/**
	 * 报文解析出错 - 第三方请求我们
	 */
	public static final String C3000 					= "3000";
 	/**
 	 * 成功
 	 */
	public static final String RETURN_SUCC 				= "1001";
 	/**
 	 * 成功
 	 */
	public static final String C1001 					= "1001";
 	/**
 	 * 失败
 	 */
	public static final String RETURN_FAIL 				= "1002";
 	/**
 	 * 失败
 	 */
	public static final String C1002 					= "1002";
 	/**
 	 * 批量操作部分成功的情况
 	 */
	public static final String RETURN_PART_SUCC 		= "1009";
 	/**
 	 * 批量操作部分成功的情况
 	 */
	public static final String C1009					= "1009";
	/**
	 * 已承保
	 */
	public static final String RETURN_ACCEPTED 			= "1003";
	/**
	 * 已承保
	 */
	public static final String C1003 					= "1003";
	/**
	 * 未承保
	 */
	public static final String RETURN_ACCEPTED_NOT		= "1004";
	/**
	 * 未承保
	 */
	public static final String C1004					= "1004";
	/**
	 * 已支付
	 */
	public static final String RETURN_PAID 				= "1005";
	/**
	 * 已支付
	 */
	public static final String C1005 					= "1005";
	/**
	 * 未支付
	 */
	public static final String RETURN_PAID_NOT			= "1006";
	/**
	 * 未支付
	 */
	public static final String C1006					= "1006";
	/**
	 * 订单不存在
	 */
	public static final String RETURN_NOT_EXIST			= "1007";
	/**
	 * 订单不存在
	 */
	public static final String C1007					= "1007";
	/**
	 * 新用户核保失败（用户网电渠道判断是新用户核保失败）
	 */
	public static final String RETURN_FAIL_NEW			= "1008";
	/**
	 * 新用户核保失败（用户网电渠道判断是新用户核保失败）
	 */
	public static final String C1008					= "1008"; 	
	/**
	 * anti sql inject
	 */
	public static final String C1011					= "1011";
	/**
	 * 报价失败
	 */
	public static final String C1012					= "1012";
	/**
	 * 持久化失败，对外显示为'内部系统异常'
	 */
	public static final String C1013					= "1013";
	/**
	 * 订单已撤销
	 */
	public static final String C1014					= "1014";
	/**
	 * 其他（比如：商户号未配置，等等）
	 */
	public static final String C1015					= "1015";
	/**
	 * 业务逻辑校验失败
	 */
	public static final String C1016					= "1016";
	/**
	 * 产品已下线
	 */
	public static final String C1017					= "1017";
	/**
	 * 正在处理中
	 */
	public static final String C1018					= "1018";
	/**
	 * 保单状态有误
	 */
	public static final String C1019                    = "1019";
	/**
	 * 其他错误
	 */
	public static final String C9999                    = "9999";

}

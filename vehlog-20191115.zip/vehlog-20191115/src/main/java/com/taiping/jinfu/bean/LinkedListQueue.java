/**
 * @(#)LinkedListQueue.java
 *       
 * project：taiping-common
 * 
 * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.jinfu.bean;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * 
 *<p>Description : 队列LinkedList同步实现类</p>
 *<p>Date        : May 4, 2013</p>
 *<p>Remark      : </p>
 * @version
 */
public class LinkedListQueue<E> {
	
	private LinkedList<E> list = new LinkedList<E>();  
      
    public synchronized void add(E e) {
    	list.addLast(e);
    }
    
    public synchronized E poll() {
    	return list.pollFirst();
    }
    
    public synchronized List<E> pollAll() {
    	List<E> objectList = new ArrayList<E>();
    	while (!list.isEmpty()) {
    		objectList.add(list.removeFirst());
    	}
    	return objectList;
    }
    
    public synchronized boolean isEmpty() {  
    	return list.isEmpty();
    }  
      
    public synchronized int size(){
    	return list.size();
    }
    
    public synchronized void clear() {
    	list.clear();
    }  
      
}

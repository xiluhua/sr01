package com.taiping.jinfu.dao;

import java.math.BigDecimal;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

@Repository
public class IspSequenceDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	public Long getSequnce(String sequence) {
		
		return this.getSequnceWrite(sequence);
	}
	
	public Long getSequnceWrite(String sequence) {
		String sql = "select " + sequence + ".nextval as key from dual";
		BigDecimal seq = (BigDecimal)entityManager.createNativeQuery(sql).getSingleResult();
		return seq.longValue();
	}	

}

/**
 * @(#)LogPool.java
 *
 * project：taiping-svc-log
 *
 * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.jinfu.log.pool;

import com.taiping.jinfu.bean.LinkedListQueue;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;

/**
 * <p>Description : log队列池</p>
 * <p>Date        : May 29, 2013</p>
 * <p>Remark      : </p>
 */
public class LogPool {

    
    // 业务操作日志队列
    public static LinkedListQueue<IlogBusinessOperateLog> dsBusiOpeLogQ = new LinkedListQueue<IlogBusinessOperateLog>();
    

}

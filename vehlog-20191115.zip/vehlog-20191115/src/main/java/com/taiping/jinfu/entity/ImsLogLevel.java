package com.taiping.jinfu.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * ImsLogLevel entity. 
 */
@Entity
@Table(name = "IMS_LOG_LEVEL")
@JsonIgnoreProperties(ignoreUnknown = true) 
public class ImsLogLevel implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	private Long id;
	private String className;
	private Integer logLevel;
	private Integer status;
	private String sysCode;
	// Constructors

	/** default constructor */
	public ImsLogLevel() {
	}
	
	@Id
	@Column(name = "ID", length = 20)
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	@Column(name = "CLASS_NAME", length=100)
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	
	@Column(name = "LOG_LEVEL", length=10)
	public Integer getLogLevel() {
		return logLevel;
	}

	public void setLogLevel(Integer logLevel) {
		this.logLevel = logLevel;
	}

	@Column(name = "STATUS",length=3)
	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	@Column(name = "SYS_CODE", length=20)
	public String getSysCode() {
		return sysCode;
	}

	public void setSysCode(String sysCode) {
		this.sysCode = sysCode;
	}
}
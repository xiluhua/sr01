package com.taiping.jinfu.exception;

public class QuoteException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public QuoteException(String msg){
		super(msg);
	}

	public QuoteException(String msg, String code) {
		super(msg, code);
	}

	public QuoteException() {
	}

}


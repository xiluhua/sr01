package com.taiping.jinfu.constant;

/**
 * 常量定义工具
 * @author xilh by 20160119
 *
 */
public class Cons {
	
	public static final String GBK 						= "GBK";
	public static final String UTF8 					= "UTF-8";
	//核心返回
	public static final String RETURN_SUCC 				= "1001"; //成功
	public static final String RETURN_FAIL 				= "1002"; //失败
	public static final String RETURN_ACCEPTED 			= "1003"; //已承保
	public static final String RETURN_ACCEPTED_NOT		= "1004"; //未承保
	public static final String RETURN_PAID 				= "1005"; //已支付
	public static final String RETURN_PAID_NOT			= "1006"; //未支付
	public static final String RETURN_FAIL_NEW			= "1008"; //新用户核保失败（用户网电渠道判断是新用户核保失败）
	
	public static final String ErrorDocParse 			= "1104";          // 报文解析出错

	public static String DATE_TIME_MASK_SSS = "yyyy-MM-dd HH:mm:ss SSS";
	public static String QUEUE_DS_BUSI_LOG 			= "QUEUE_DS_BUSI_LOG";
	public static String QUEUE_MSG_LOG 				= "QUEUE_MSG_LOG";
	
	public static final String PRE_PAGE					= "PAGE_";
	public static final String PRE_PAGE_INDEX			= "PAGE_INDEX_";
	// add by xiluhua 20190409
	public static final String MYSQL					= "mysql";
	public static final String ORACLE					= "oracle";
	public static final String DB_JDBC_URL				= "db1.jdbc.url";
	public static final String SEQUENCE_GEN_URL			= "sequence.gen.url";
	public static final String DEV						= "dev";
	public static final String PROD						= "prod";
	public static final String PROJECT_NAME				= "jinfu-vehicle-log";
	public static final String PROJECT_WHOLE_NAME		= "taiping-jinfu-vehicle-log";
	
	public static String STR_0 							= "0";
	public static String STR_1 							= "1";
	public static String STR_2 							= "2";
	public static String STR_3 							= "3";
	public static String STR_4 							= "4";
	public static String STR_5 							= "5";
	public static String STR_6 							= "6";
	public static String STR_7 							= "7";
	public static String STR_8 							= "8";
	public static String STR_9 							= "9";
}

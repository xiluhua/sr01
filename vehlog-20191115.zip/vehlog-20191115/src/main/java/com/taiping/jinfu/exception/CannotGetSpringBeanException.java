package com.taiping.jinfu.exception;

public class CannotGetSpringBeanException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;


	public CannotGetSpringBeanException(String msg) {
		super(msg);
	}

	public CannotGetSpringBeanException(String msg, String code) {
		super(msg, code);
	}

	public CannotGetSpringBeanException() {
	}

}


package com.taiping.jinfu.service.seq;

public interface SeqService {

	public Long getSequnce(String sequence);
}

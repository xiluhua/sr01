package com.taiping.jinfu.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.springframework.format.annotation.DateTimeFormat;

/**
 * @author xilh
 * @since 20191121
 */
@Entity
@Table(name = "ILOG_BUSINESS_OPERATE_LOG")
public class IlogBusinessOperateLog implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	@Id
	@Column(name = "ID", unique = true, nullable = false)
	private String id;
	@Column(name = "APPLY_ID")
	private String applyId;
	@Column(name = "PARTNER_TRANS_CODE")
	private String partnerTransCode;
	@Column(name = "APP_NO")
	private String appNo;
	@Column(name = "PAY_ID")
	private String payId;
	@Column(name = "BUSINESS_OPERATE_TYPE")
	private String businessOperateType;
	@Column(name = "OPERATE_STATUS")
	private int operateStatus;
	@Column(name = "PREMIUM")
	private Double premium;
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "HOLDER_NAME")
	private String holderName;
	@Column(name = "HOLDER_IDNO")
	private String holderIdno;
	@Column(name = "PARTNER_ID")
	private Long partnerId;
	@Column(name = "FROM_IP")
	private String fromIp;
	@Column(name = "MSG_FILE_IP")
	private String msgFileIp;
	@Column(name = "MSG_PATH")
	private String msgPath;
	@Transient
	private String msg;
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	@Column(name = "CREATE_TIME")
	private Date createTime;
	@Column(name = "OPERATE_NO_1")
	private String operateNo1;
	@Column(name = "OPERATE_NO_2")
	private String operateNo2;
	@Column(name = "OPERATE_NO_3")
	private String operateNo3;
	
	// Constructors

	/** default constructor */
	public IlogBusinessOperateLog() {
	}


	// Property accessors
	
	
	public String getApplyId() {
		return this.applyId;
	}

	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}

	public String getPayId() {
		return this.payId;
	}

	public void setPayId(String payId) {
		this.payId = payId;
	}

	public void setOperateStatus(int operateStatus) {
		this.operateStatus = operateStatus;
	}

	public int getOperateStatus() {
		return this.operateStatus;
	}

	public String getBusinessOperateType() {
		return businessOperateType;
	}

	public Double getPremium() {
		return this.premium;
	}

	public void setPremium(Double premium) {
		this.premium = premium;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getHolderName() {
		return this.holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getHolderIdno() {
		return this.holderIdno;
	}

	public void setHolderIdno(String holderIdno) {
		this.holderIdno = holderIdno;
	}

	public Long getPartnerId() {
		return this.partnerId;
	}

	public String getPartnerTransCode() {
		return this.partnerTransCode;
	}

	public void setPartnerTransCode(String partnerTransCode) {
		this.partnerTransCode = partnerTransCode;
	}

	public String getFromIp() {
		return fromIp;
	}


	public void setFromIp(String fromIp) {
		this.fromIp = fromIp;
	}


	public String getMsgFileIp() {
		return msgFileIp;
	}


	public void setMsgFileIp(String msgFileIp) {
		this.msgFileIp = msgFileIp;
	}

	public void setBusinessOperateType(String businessOperateType) {
		this.businessOperateType = businessOperateType;
	}


	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}

	public Date getCreateTime() {
		return this.createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getOperateNo1() {
		return operateNo1;
	}
	public void setOperateNo1(String operateNo1) {
		this.operateNo1 = operateNo1;
	}
	public String getOperateNo2() {
		return operateNo2;
	}

	public void setOperateNo2(String operateNo2) {
		this.operateNo2 = operateNo2;
	}

	public String getOperateNo3() {
		return operateNo3;
	}
	public void setOperateNo3(String operateNo3) {
		this.operateNo3 = operateNo3;
	}

	public String getAppNo() {
		return appNo;
	}

	public void setAppNo(String appNo) {
		this.appNo = appNo;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMsgPath() {
		return msgPath;
	}

	public void setMsgPath(String msgPath) {
		this.msgPath = msgPath;
	}
}
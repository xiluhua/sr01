package com.taiping.jinfu.service.httpclient;

import java.util.Map;

public interface HttpclientService {
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content,String contentType, String encode,int connectionTimeout,int soTimeout,int retryTime) throws Exception;
	
	/**
	 * 发送请求，适用于返回xml的请求
	 * @return Document 结果
	 * @throws Exception 
	 * @throws Exception
	 */
	public String post(String urlString, Map<String, Object> parameters) throws Exception;
	
	public String postYlx(String urlString, Map<String, Object> parameters);
	
}

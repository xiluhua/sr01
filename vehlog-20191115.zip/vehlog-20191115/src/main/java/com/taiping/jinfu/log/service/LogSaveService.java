package com.taiping.jinfu.log.service;

import java.util.LinkedList;

public interface LogSaveService {
	
	public Long getSequnce(String sequnceName);
	
	public <T> void save(T entity);
	
	public <T> void saveBatch(LinkedList<T> list)throws Exception;
}

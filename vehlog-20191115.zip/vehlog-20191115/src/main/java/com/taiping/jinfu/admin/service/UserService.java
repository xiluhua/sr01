package com.taiping.jinfu.admin.service;

import java.util.List;

import com.taiping.jinfu.entity.ImsAdminUser;

/**
 * Created by Jian on 2017/6/21.
 */
public interface UserService {

    public List<ImsAdminUser> getAllUser();
    
    public ImsAdminUser getUser(String userName,String password);
    
    public void saveUser(ImsAdminUser ispAutotestUser);

    public List<ImsAdminUser> findByUsername(String username);
}

package com.taiping.jinfu.log.service.impl;

import java.util.LinkedList;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.jinfu.log.service.LogSaveService;
import com.taiping.jinfu.service.seq.impl.SeqImpl;

@Service
@Transactional
public class LogSaveImpl implements LogSaveService{

	@PersistenceContext
	private EntityManager entityManager;
	@Resource
	private SeqImpl seqImpl;
	
	/**
	 * 获取序列号
	 * @author xilh
	 * @since 20191115
	 * @param sequnceName
	 * @return
	 */
	public Long getSequnce(String sequnceName) {
		Long seq = seqImpl.getSequnce(sequnceName);
		return seq;
	}
	
	/**
	 * @author xilh
	 * @since 20191115
	 */
	public <T> void saveBatch(LinkedList<T> list) throws Exception {
		int i = 0;
		while (list.size() > 0) {
			entityManager.persist(list.poll());
			i++;
			if (i % 20 == 0){
				entityManager.flush();
				entityManager.clear();
			}
			//再批量保存一次
			entityManager.flush();
			entityManager.clear();
		}
	}

	/**
	 * @author xilh
	 * @since 20191115
	 */
	@Override
	public <T> void save(T entity) {
		entityManager.persist(entity);
	}
}

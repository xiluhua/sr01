/**
 * 
 */
/**
 * @author xilh
 *
 */
package com.taiping.jinfu.service.httpclient;
package com.taiping.jinfu.exception;

public class ReadRequestMsg2ObjectException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public ReadRequestMsg2ObjectException(String msg){
		super(msg);
	}

	public ReadRequestMsg2ObjectException(String msg, String code) {
		super(msg, code);
	}

	public ReadRequestMsg2ObjectException() {
	}

}


package com.taiping.jinfu.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**   
 * @ClassName CXIspAcceptProperty   
 * @Description 
 * @Version 
 */
@Entity
@Table(name = "SX_ISP_KEY")
public class IspKey {
	@Id
	@Column(name="KEY_ID")
	private Long keyID;
	@Column(name="KEY_NAME")
	private String keyName;
	@Column(name="KEY_VALUE")
	private Integer keyValue;
	
	public Long getKeyID() {
		return keyID;
	}
	public void setKeyID(Long keyID) {
		this.keyID = keyID;
	}
	public String getKeyName() {
		return keyName;
	}
	public void setKeyName(String keyName) {
		this.keyName = keyName;
	}
	public Integer getKeyValue() {
		return keyValue;
	}
	public void setKeyValue(Integer keyValue) {
		this.keyValue = keyValue;
	}
	
	
	
}

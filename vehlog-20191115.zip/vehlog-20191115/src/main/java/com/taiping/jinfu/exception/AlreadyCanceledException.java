package com.taiping.jinfu.exception;

public class AlreadyCanceledException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public AlreadyCanceledException(String msg){
		super(msg);
	}
	
	public AlreadyCanceledException(){
		super("已强撤");
	}

	public AlreadyCanceledException(String msg, String code) {
		super(msg, code);
		// TODO Auto-generated constructor stub
	}
	
}


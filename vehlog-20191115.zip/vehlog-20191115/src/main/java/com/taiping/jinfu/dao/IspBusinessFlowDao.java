package com.taiping.jinfu.dao;

import org.springframework.stereotype.Repository;

@Repository
public class IspBusinessFlowDao {

}

package com.taiping.jinfu.service.httpclient.impl;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.net.*;
import java.net.Proxy.Type;
import java.util.HashMap;
import java.util.Map;

/**
 * http请求类
 * from 邰耀平
 * @author amo
 *         注：parameters设值后，data将不被发送
 *         CreateDate:May 25, 2012
 */
public class HttpClient {
    private Map<String, String> parameters = new HashMap<String, String>();  // 发送参数
    private Map<String, String> headers = new HashMap<String, String>();
    private String url;
    private String sendEncode = "UTF-8";
    private String receiceEncode = "UTF-8";
    private String data;  // 发送内容
    private String errorMsg = "";
    private Proxy proxy;
    private String contentType = "application/x-www-form-urlencoded";
    private static final Integer MS = 1000;


    public void addParameter(String name, String value) {
        if (value == null) value = "";
        this.parameters.put(name, value);
    }

    public void setSendData(String data) {
        this.data = data;
    }

    public void setProxy(String host, int port) {
        proxy = new Proxy(Type.HTTP, new InetSocketAddress(host, port));
    }

    public String post() throws Exception {
        String response = "";
        try {
            response = this.send();
        } catch (Exception e) {
            throw e;
        }

        return response;
    }

    /**
     * 发送请求，适用于返回xml的请求
     *
     * @return Document 结果
     * @throws Exception
     * @throws Exception
     */
    private String send() throws Exception {
        String paramStr = "";
        Object[] services = parameters.keySet().toArray();
        StringBuffer rspContent = null;
        BufferedReader reader = null;
        DataInputStream in = null;
        URLConnection con = null;
        URL url;
        String response;
        String sendData = "";
        try {
            for (int i = 0; i < services.length; i++) {
                if (i == 0) {
                    paramStr += services[i]
                            + "="
                            + URLEncoder.encode(parameters.get(services[i]).toString(), this.getSendEncode());
                } else {
                    paramStr += "&"
                            + services[i]
                            + "="
                            + URLEncoder.encode(parameters.get(services[i]).toString(), this.getSendEncode());
                }
            }
            if (data != null) {
                sendData = URLEncoder.encode(data, this.getSendEncode());
            }
        } catch (UnsupportedEncodingException e) {
            errorMsg = "不支持的编码格式。";
            throw e;
        }
        try {
            url = new URL(this.getUrl());
            if (proxy == null) {
                con = url.openConnection();
            } else {
                con = url.openConnection(this.proxy);
            }
            con.setUseCaches(false);
            con.setDoOutput(true);
            con.setDoInput(true);
            con.setRequestProperty("Content-type", this.contentType);
            con.setRequestProperty("", "");
            byte[] sendParamByte = null;
            if (!"".equals(paramStr)) {
                sendParamByte = paramStr.getBytes("iso8859_1");
            } else {
                sendParamByte = sendData.getBytes("iso8859_1");
            }

            con.setRequestProperty("Content-length", String
                    .valueOf(sendParamByte.length));

            //设置Header信息
            if (this.headers != null) {
                for (String key : this.headers.keySet()) {
                    String value = this.headers.get(key);
                    con.setRequestProperty(key, value);
                }
            }

            DataOutputStream dataOut = new DataOutputStream(con.getOutputStream());
            dataOut.write(sendParamByte);
            dataOut.flush();
            dataOut.close();
            rspContent = new StringBuffer();
            in = new DataInputStream(con.getInputStream());
            reader = new BufferedReader(new InputStreamReader(in, this
                    .getReceiceEncode()));
            String aLine;
            while ((aLine = reader.readLine()) != null) {
                rspContent.append(aLine);
            }
            response = rspContent.toString();
            in.close();
        } catch (MalformedURLException e1) {
            e1.printStackTrace();
            errorMsg = "网址格式错误。";
            throw new Exception(e1);
        } catch (NoRouteToHostException e2) {
            e2.printStackTrace();
            errorMsg = "连接失败。";
            throw new Exception(e2);
        } catch (ConnectException e3) {
            e3.printStackTrace();
            // 判断异常信息
            if ("Connection timed out: connect".equals(e3.getMessage())) {
                errorMsg = "连接超时。";
            } else {
                errorMsg = "连接异常。";
            }
            throw new Exception(e3);
        } catch (Exception e) {
            e.printStackTrace();
            errorMsg = "未知错误。";
            throw e;
        } finally {
            if (reader != null) {
                reader.close();
            }
            if (in != null) {
                in.close();
            }
        }

        return response;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    public void setParameters(Map<String, String> parameters) {
        this.parameters = parameters;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public String getSendEncode() {
        return sendEncode;
    }

    public void setSendEncode(String sendEncode) {
        this.sendEncode = sendEncode;
    }

    public String getReceiceEncode() {
        return receiceEncode;
    }

    public void setReceiceEncode(String receiceEncode) {
        this.receiceEncode = receiceEncode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }

    public void setErrorMsg(String errorMsg) {
        this.errorMsg = errorMsg;
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    // AJAX输出文本，返回null
    public static String ajaxText(String text, HttpServletResponse response) {
        return ajax(text, "text/plain", response);
    }

    // AJAX输出，返回null
    public static String ajax(String content, String type, HttpServletResponse response) {
        try {
            response.setContentType(type + ";charset=UTF-8");
            response.setHeader("Pragma", "No-cache");
            response.setHeader("Cache-Control", "no-cache");
            response.setDateHeader("Expires", 0);
            response.getWriter().write(content);
            response.getWriter().flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String sendXml(String url, String context, String Unicode) throws IOException {
        StringBuffer buffer = new StringBuffer();
        String tmp = "";
        URL sendUrl = new URL(url);
        HttpURLConnection conn = (HttpURLConnection) sendUrl.openConnection();
        conn.setRequestMethod("POST");
        conn.setDoOutput(true);
        conn.setDoInput(true);
        conn.setRequestProperty("Content-Language", Unicode);
        //设置链接超时时间
        conn.setConnectTimeout(10 * MS);
        //设置读取数据超时时间
        conn.setReadTimeout(180 * MS);
        // 获取URLConnection对象对应的输出流
        PrintWriter stream = new PrintWriter(conn.getOutputStream());
        stream.print(context);

        stream.flush();
        stream.close();
        // 获取返回的数据
        InputStream inputStream = conn.getInputStream();
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, Unicode));
        while ((tmp = reader.readLine()) != null) {
            buffer.append(tmp);
        }
        return buffer.toString();
    }

}

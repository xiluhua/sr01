package com.taiping.jinfu.exception;

public class InnerPayException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public InnerPayException(String msg){
		super(msg);
	}
	
	public InnerPayException(){
		super("订单生成异常");
	}

	public InnerPayException(String msg, String code) {
		super(msg, code);
	}
}


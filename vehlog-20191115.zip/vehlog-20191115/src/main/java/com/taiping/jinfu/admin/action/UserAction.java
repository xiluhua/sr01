//package com.taiping.jinfu.admin.action;
//
//import java.io.UnsupportedEncodingException;
//import java.security.NoSuchAlgorithmException;
//
//import javax.annotation.Resource;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.context.annotation.Scope;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//import com.taiping.facility.tool.LogTool;
//import com.taiping.facility.tool.Md5EncryptTool;
//import com.taiping.jinfu.action.BaseAction;
//import com.taiping.jinfu.admin.service.impl.UserImpl;
//import com.taiping.jinfu.constant.Cons;
//import com.taiping.jinfu.entity.ImsAdminUser;
//
///**
// * @Description: 用户控制器
// * @author JIAN
// * @version 1.0
// * @date 2017年6月21日
// */
//@Scope("prototype")
//@RequestMapping("admin")
//public class UserAction extends BaseAction{
//
//	private static final long serialVersionUID = 1L;
//	@Resource
//    UserImpl userImpl;
//
//    @RequestMapping(value="login")
//    public void login(HttpServletRequest request, HttpServletResponse response) throws UnsupportedEncodingException, NoSuchAlgorithmException {
//        String name = StringUtils.defaultString(request.getParameter("userName")).toLowerCase();
//        String password = request.getParameter("password");
//        String captcha  = request.getParameter("captcha");
//        String sessionCaptcha = (String) request.getSession().getAttribute("captcha");
//
//        LogTool.debug(this.getClass(), "name: "+name);
//        LogTool.debug(this.getClass(), "password: "+password);
//        LogTool.debug(this.getClass(), "captcha: "+captcha);
//        LogTool.debug(this.getClass(), "sessionCaptcha: "+sessionCaptcha);
//        String msg;
//        if(!captcha.equalsIgnoreCase(sessionCaptcha)){
//            msg = Cons.WRONG_CAPTCHA;
//            ajaxText(msg, response);
//            return;
//        }
//        password = Md5EncryptTool.getMd5(password);
//        ImsAdminUser user = userImpl.getUser(name, password);
//
//        int type= 0;
//        if(user!=null){
//           type = user.getType();
//        }
//        switch (type){
//            case 1://管理员
//                msg = Cons.STR_1;
//                setSession(request, Cons.USER_SESSION, user);
//                break;
//            case 2://业务员
//                msg = Cons.STR_2;
//                setSession(request, Cons.USER_SESSION, user);
//                break;
//            case 3://第三方
//                msg = Cons.STR_3;
//                setSession(request, Cons.USER_SESSION, user);
//                break;
//            default:
//                msg = Cons.WRONG_LOGIN_INFO;
//        }
//        ajaxText(msg, response);
//    }
//
//    @RequestMapping("logout")
//    public String logoutUser(HttpServletRequest request){
//        clearSession(Cons.USER_SESSION, request);
//        return "redirect:/tologin.action";
//    }
//
////    @Action(value="tologin", results={
////            @Result(location = "/login.ftl")
////    })
//    @RequestMapping("tologin")
//    public String tologin(){
//        return "login";
//    }
//    
////    @Action(value="cooper",results={
////            @Result(location = "/login.ftl")
////    })
//    @RequestMapping("cooper")
//    public String tologin2(){
//    	return "login";
//    }
//    
////    @Action(value="navi",results={
////            @Result(location = "/1-navi.ftl")
////    })
//    @RequestMapping("navi")
//    public String navi(){
//        return "1-navi";
//    }
//    
//    public static void main(String[] args) {
//        String code = "123";
//        String result = Md5EncryptTool.getMd5(code);
////
////        String a ="ydyn";
////        String b = "yDYN";
////        System.out.println("结果："+a.equalsIgnoreCase(b));
//        System.out.println(result);
//        
//    }
//}

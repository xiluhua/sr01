package com.taiping.jinfu.exception;

public class ReadPayNotifyRequestMsg2ObjectException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public ReadPayNotifyRequestMsg2ObjectException(String msg){
		super(msg);
	}

	public ReadPayNotifyRequestMsg2ObjectException(String msg, String code) {
		super(msg, code);
	}

	public ReadPayNotifyRequestMsg2ObjectException() {
	}

}


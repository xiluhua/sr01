package com.taiping.jinfu.core.model;

import org.dom4j.Document;

public class Busi {
	private String busiId;
	private String serviceCode;
	private String version;
	private Long partnerId;
	private boolean isJson;
	private boolean isMock;
	private boolean isBatch;
	private String requestMsg;
	private String responseMsg;
	private Document xmlDoc;		
	

	private Exception runtimeException;
	
	public boolean isMock() {
		return isMock;
	}
	public void setMock(boolean isMock) {
		this.isMock = isMock;
	}
	
	public String getBusiId() {
		return busiId;
	}
	public void setBusiId(String busiId) {
		this.busiId = busiId;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	public String getServiceCode() {
		return serviceCode;
	}
	public void setServiceCode(String serviceCode) {
		this.serviceCode = serviceCode;
	}
	public boolean isJson() {
		return isJson;
	}
	public void setJson(boolean isJson) {
		this.isJson = isJson;
	}
	public String getRequestMsg() {
		return requestMsg;
	}
	public void setRequestMsg(String requestMsg) {
		this.requestMsg = requestMsg;
	}
	public Long getPartnerId() {
		return partnerId;
	}
	public void setPartnerId(Long partnerId) {
		this.partnerId = partnerId;
	}
	public Document getXmlDoc() {
		return xmlDoc;
	}
	public void setXmlDoc(Document xmlDoc) {
		this.xmlDoc = xmlDoc;
	}
	
	public boolean isBatch() {
		return isBatch;
	}
	public void setBatch(boolean isBatch) {
		this.isBatch = isBatch;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public Exception getRuntimeException() {
		return runtimeException;
	}
	public void setRuntimeException(Exception runtimeException) {
		this.runtimeException = runtimeException;
	}
	public Busi(String busiId, String serviceCode, Long partnerId) {
		super();
		this.busiId = busiId;
		this.serviceCode = serviceCode;
		this.partnerId = partnerId;
	}
	public Busi() {
		super();
		// TODO Auto-generated constructor stub
	}

}

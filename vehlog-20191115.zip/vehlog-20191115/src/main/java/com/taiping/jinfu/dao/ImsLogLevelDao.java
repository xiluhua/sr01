package com.taiping.jinfu.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.facility.cache.CacheListDaoService;
import com.taiping.jinfu.dao.rep.ImsLogLevelRepDao;
import com.taiping.jinfu.entity.ImsLogLevel;

/**
 * 
 * @author xilh
 * @since 20190222
 */
@Repository
public class ImsLogLevelDao implements CacheListDaoService{
	
	@Resource
	private ImsLogLevelRepDao imsLogLevelRepDao;

	public Map<Object,String> getAllInMap(){
		return this.getAllInMap(1);
	}
	
	public Map<Object,String> getAllInMap(int status){
		List<ImsLogLevel> list = imsLogLevelRepDao.getAll(status);
		Map<Object,String> map = null;
		if (list != null) {
			map = new HashMap<Object, String>();
			for (int i = 0; i < list.size(); i++) {
				ImsLogLevel logLevel = list.get(i);
				if (logLevel.getClassName() != null) {
					map.put(logLevel.getClassName(), String.valueOf(logLevel.getLogLevel()));   	
				}
			}
		}
		
		return map;
	}
	
}

package com.taiping.jinfu.service.query;

import java.util.List;

import com.taiping.jinfu.entity.IlogBusinessLogContent;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;

/**
 * @author liuhe
 * @since 20191121
 */
public interface LogFilesQueryService {
	
    List<IlogBusinessOperateLog> queryLog(IlogBusinessOperateLog ilog);
    
    public IlogBusinessLogContent getLogFileContent(String logId,String logType);
    
}

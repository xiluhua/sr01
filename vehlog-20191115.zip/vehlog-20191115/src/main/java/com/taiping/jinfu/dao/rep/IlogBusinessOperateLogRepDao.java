package com.taiping.jinfu.dao.rep;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.taiping.jinfu.entity.IlogBusinessLogContent;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;

public interface IlogBusinessOperateLogRepDao extends PagingAndSortingRepository<IlogBusinessOperateLog, Long> {

	@Query(value="SELECT t from IlogBusinessLogContent t where t.logId = ?1 ")
	IlogBusinessLogContent getLogFileContentByLogId(String logId,Integer logType);
	
}

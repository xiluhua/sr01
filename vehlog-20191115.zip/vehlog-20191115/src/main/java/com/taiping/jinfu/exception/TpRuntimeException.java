package com.taiping.jinfu.exception;

/**
 * 太平运行时异常类
 * @author xilh
 * @since 20190228
 */
public class TpRuntimeException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;
	
	private String code = null;
	
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public TpRuntimeException(String msg){
		super(msg);
	}
	
	public TpRuntimeException(String msg, String code){
		super(msg);
		this.code = code;
	}
	
	public TpRuntimeException(){
		super();
	}
}


package com.taiping.jinfu.exception;

public class OfflineException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public OfflineException(String msg){
		super(msg);
	}

	public OfflineException(String msg, String code) {
		super(msg, code);
	}

	public OfflineException() {
	}
}


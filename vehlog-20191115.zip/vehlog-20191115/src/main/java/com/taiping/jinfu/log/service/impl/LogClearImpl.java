
package com.taiping.jinfu.log.service.impl;

import java.util.Date;
import java.util.LinkedList;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.constant.Env;
import com.taiping.jinfu.entity.IlogBusinessLogContent;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;
import com.taiping.jinfu.log.pool.LogPool;
import com.taiping.jinfu.log.service.LogClearService;

/**
 * @author xilh
 * @since 20191115
 */
@Service
public class LogClearImpl implements LogClearService{
	
	@Resource
	private LogSaveImpl logSaveImpl;
	
	/**
	 * @author xilh
	 * @since 20191115
	 */
	public void clearDsBusiOpeLog_batch(String threadx){
		System.out.println("=============================================================");
		System.out.println("clearDsBusiOpeLog_batch!!");
		LinkedList<IlogBusinessOperateLog> list = new LinkedList<IlogBusinessOperateLog>();
		int count = 0;
		int end = 5;
		while(true){
			
			try {
		 		LogTool.warn(LogClearImpl.class, threadx+",LogPool.dsBusiOpeLogQ: "+LogPool.dsBusiOpeLogQ.size());
				String systemParameter = CacheContainer.getSysParamValue("log.batch_num", true);	
		 		int batchNum = Integer.valueOf(systemParameter);
		 		LogTool.warn(LogClearImpl.class, threadx+",list.size: "+list.size()+", batchNum:"+batchNum);
		 		
		 		IlogBusinessOperateLog log = LogPool.dsBusiOpeLogQ.poll();
				if (log == null && list.size()< batchNum && count < end) {
					int secondmil = 5000;
					if (!Env.isFormal) {
						secondmil = secondmil*3;
					}
					Thread.sleep(secondmil);
					count++;
				}else {
					// 99999为测试
					if (log!=null){
						LogTool.debug(this.getClass(), "-------------- 111 --------------");
						long id = logSaveImpl.getSequnce("SEQ_BUSINESS_OPERATE_LOG");
						log.setId(String.valueOf(id));
						String absolutePath = "";
						LogTool.debug(this.getClass(), "-------------- 222 --------------");
						if (!StringUtils.isEmpty(log.getMsg())) {
							absolutePath = "DBLog";
						    // 保存到数据库
						    long contentId = logSaveImpl.getSequnce("SEQ_BUSINESS_LOG_CONTENT");
						    IlogBusinessLogContent content = new IlogBusinessLogContent();
						    content.setId(String.valueOf(contentId));
						    content.setLogId(String.valueOf(id));
						    content.setLogMessage(log.getMsg());
						    content.setLogType(1);
						    content.setCreateTime(new Date());
						    logSaveImpl.save(content);
						}
						log.setMsgFileIp(Env.localIp);
						// 解析项目名称   add by liuhe 20190515
						String msgPath = parsePathForProjectName(log.getMsgPath());
						log.setMsgPath(absolutePath+"(IP:"+log.getFromIp()+",项目:"+msgPath+")");
						// 为增加主键索引
						if (StringUtils.isEmpty(log.getApplyId())) {
							log.setApplyId("1");
						}
						if (StringUtils.isEmpty(log.getPartnerTransCode())) {
							log.setPartnerTransCode("1");
						}
						if (StringUtils.isEmpty(log.getAppNo())) {
							log.setAppNo("1");
						}
						
						list.add(log);
						
						LogTool.info(LogClearImpl.class, threadx+",set dsbusiness_operate_log id: {}, partnerTransCode: {}", id, log.getPartnerTransCode());
						LogTool.debug(this.getClass(), "-------------- 333 --------------");
						if (list.size() % batchNum == 0) {
							logSaveImpl.saveBatch(list);
						}
					}
					
					if (count >= end) {
						if (list.size() > 0) {
							logSaveImpl.saveBatch(list);
						}
						count = 0;
					}
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	public void init(){

		for (int i = 1; i <= 30; i++) {
			final int index = i;
			new Thread() {
				public void run() {
					clearDsBusiOpeLog_batch("thread-"+index);
				}
			}.start();
		}

		// 2
		new Thread() {
			public void run() {
//				clearErrorLog();
			}
		}.start();

		// 3
		new Thread() {
			public void run() {
				clearInterfaceLog();
			}
		}.start();

		// 4
		new Thread() {
			public void run() {
				clearOpeLog();
			}
		}.start();

		// 5
		new Thread() {
			public void run() {
				clearPayLogLog();
			}
		}.start();

		// 6
		new Thread() {
			public void run() {
				clearWebLog();
			}
		}.start();

	}
	

	public void clearInterfaceLog(){
		
	}
	
	public void clearOpeLog(){
		
	}
	
	
	public void clearWebLog(){
		
	}
	
	
	public void clearPayLogLog(){
		
	}
	
	/**
	 * 从字符串中解析出工程名称
	 * @param msgDocPath
	 * @return
	 */
	private String parsePathForProjectName(String msgDocPath) {
		if(StringUtils.isEmpty(msgDocPath)) {
			return "";
		}
		String projectName = "";
		String [] arrs = msgDocPath.split("/");
		if(arrs.length>3) {
			projectName = arrs[3];
		}
		return projectName;
	}
	
	public static void main(String[] args) {
		System.out.println(LogClearImpl.class);
		
		StringBuffer buffer = new StringBuffer();
		buffer.append("// #index#\n");
		buffer.append("new Thread() {\n");
		buffer.append("public void run() {\n");
		//buffer.append("clearBusiOpeLog_batch(\"thread-10\");\n");
		buffer.append("clearMsgLog_batch(\"thread-10\");\n");
		buffer.append("	}\n");
		buffer.append("}.start();");
		
		
		for (int i = 11; i <= 20; i++) {
			String temp = new String(buffer.toString()).replaceAll("#index#", String.valueOf(i));
			System.out.println(temp);
		}
	}
	
}
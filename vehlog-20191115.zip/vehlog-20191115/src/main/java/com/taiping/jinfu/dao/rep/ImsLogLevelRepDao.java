package com.taiping.jinfu.dao.rep;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.taiping.jinfu.constant.Cons;
import com.taiping.jinfu.entity.ImsLogLevel;

/**
 * 
 * @author xilh
 * @since 20190222
 */
public interface ImsLogLevelRepDao extends PagingAndSortingRepository<ImsLogLevel, Long>{
	
	@Query(value="SELECT t from ImsLogLevel t where t.status = ?1 and t.sysCode = '"+Cons.PROJECT_NAME+"'")
	public List<ImsLogLevel> getAll(int status);
}
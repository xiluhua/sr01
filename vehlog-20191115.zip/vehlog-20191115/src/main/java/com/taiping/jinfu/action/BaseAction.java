package com.taiping.jinfu.action;

import java.io.IOException;
import java.io.Serializable;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class BaseAction {

	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	
	public static final String VIEW = "view";
	public static final String LIST = "list";
	public static final String STATUS = "status";
	public static final String WARN = "warn";
	public static final String ERROR = "error";
	public static final String MESSAGE = "message";
	public static final String CONTENT = "content";
	public static final String CONST_CAS_ASSERTION="_const_cas_assertion_";
	public static final String USER_INFO = "userInfo";
	
	// 设置Session
	public static void setSession(HttpServletRequest request, String name, Serializable obj){
	    HttpSession session = request.getSession();
	    session.setAttribute(name, obj);
	}
	
	// 清空Session
	@SuppressWarnings({ "rawtypes" })
	public static void clearSession(String name, HttpServletRequest request) {
		HttpSession session = request.getSession();
		Enumeration en = request.getSession().getAttributeNames();
		while (en.hasMoreElements()) {
		    String key = (String) en.nextElement();
		    session.removeAttribute(key);
		}		    
	}
	
	// AJAX输出文本，返回null
	public String ajaxText(String text, HttpServletResponse response) {
		return ajax(text, "text/plain", response);
	}
	
	// AJAX输出，返回null
	public String ajax(String content, String type, HttpServletResponse response) {
		try {
			response.setContentType(type + ";charset=UTF-8");
			response.setHeader("Pragma", "No-cache");
			response.setHeader("Cache-Control", "no-cache");
			response.setDateHeader("Expires", 0);
			response.getWriter().write(content);
			response.getWriter().flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
	
//	// AJAX输出HTML，返回null
//	public String ajaxHtml(String html) {
//		return ajax(html, "text/html");
//	}
//
//	// AJAX输出XML，返回null
//	public String ajaxXml(String xml) {
//		return ajax(xml, "text/xml");
//	}
//
//	// 根据字符串输出JSON，返回null
//	public String ajaxJson(String jsonString) {
//		return ajax(jsonString, "application/json");
//	}
//	
//	// 根据Map输出JSON，返回null
//	public String ajaxJson(Map<String, String> jsonMap) {
//		//JSONObject jsonObject = JSONObject.fromObject(jsonMap);
//		return ajax(mapToJson(jsonMap), "application/json");
//	}
//	
//	// 输出JSON
//	public String ajaxJsonObject(Map<String, Object> jsonMap){
//		return ajax(JSON.toJSONString(jsonMap), "application/json");
//	}
//	
//	// 输出JSON
//	public String ajaxJsonMap(Map<String, Map<String,String>> jsonMap){
//		return ajax(JSON.toJSONString(jsonMap), "application/json");
//	}
//	
//	// 输出JSON警告消息，返回null
//	public String ajaxJsonWarnMessage(String message) {
//		Map<String, String> jsonMap = new HashMap<String, String>();
//		jsonMap.put(STATUS, WARN);
//		jsonMap.put(MESSAGE, message);
//		return ajax(mapToJson(jsonMap), "application/json");
//	}
//	
//	// map转化为json数据
//	public String mapToJson(Map<String,String> map){
//		ObjectMapper mapper = new ObjectMapper();
//		Writer sw = new StringWriter();
//		try {
//			JsonGenerator json = mapper.getJsonFactory().createJsonGenerator(sw);
//			json.writeObject(map);
//			sw.close();
//		} catch (JsonProcessingException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//		return sw.toString();
//	}
//	
//	// 输出JSON成功消息，返回null
//	public String ajaxJsonSuccessMessage(String message) {
//		Map<String, String> jsonMap = new HashMap<String, String>();
//		jsonMap.put(STATUS, SUCCESS);
//		jsonMap.put(MESSAGE, message);
//		//JSONObject jsonObject = JSONObject.fromObject(jsonMap);
//		return ajax(mapToJson(jsonMap), "application/json");
//	}
//	
//	// 输出JSON错误消息，返回null
//	public String ajaxJsonErrorMessage(String message) {
//		Map<String, String> jsonMap = new HashMap<String, String>();
//		jsonMap.put(STATUS, ERROR);
//		jsonMap.put(MESSAGE, message);
//		//JSONObject jsonObject = JSONObject.fromObject(jsonMap);
//		return ajax(mapToJson(jsonMap), "application/json");
//	}
//	
//	// 设置页面不缓存
//	public void setResponseNoCache() {
//		getResponse().setHeader("progma", "no-cache");
//		getResponse().setHeader("Cache-Control", "no-cache");
//		getResponse().setHeader("Cache-Control", "no-store");
//		getResponse().setDateHeader("Expires", 0);
//	}
}

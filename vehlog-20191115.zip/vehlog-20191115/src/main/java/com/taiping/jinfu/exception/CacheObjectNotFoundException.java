package com.taiping.jinfu.exception;

import com.taiping.jinfu.constant.Ret;

public class CacheObjectNotFoundException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public CacheObjectNotFoundException(String msg){
		super(msg);
		super.setCode(Ret.C3000);
	}


	public CacheObjectNotFoundException(String msg, String code) {
		super(msg, code);
	}

	public CacheObjectNotFoundException() {
	}

}


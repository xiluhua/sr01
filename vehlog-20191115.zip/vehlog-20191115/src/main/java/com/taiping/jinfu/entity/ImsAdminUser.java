package com.taiping.jinfu.entity;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

/**
 * 账户类
 * Created by Jian on 2017/6/21.
 */
@Entity
@Table(name = "IMS_ADMIN_USER")
public class ImsAdminUser  implements Serializable{

	private static final long serialVersionUID = 1L;

    @Id
//    @GeneratedValue(generator="increment")
//    @GenericGenerator(name="increment", strategy = "increment")
    @Column(name= "ID")
    private String id;
    @Column(name= "USERNAME")
    private String  username;
    @Column(name= "PASSWORD")
    private String password;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CREATE_TIME")
    private Date createTime;
    @Column(name="TYPE")
    private Integer type;
    @Column(name="STATUS")
    private Integer status;

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
            return username;
        }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public Date getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Integer getType() {
        return type;
    }
    public void setType(Integer type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "IspAutotestUser{" +
                "id='" + id + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", createTime=" + createTime +
                ", type='" + type + '\'' +
                '}';
    }
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
    
}



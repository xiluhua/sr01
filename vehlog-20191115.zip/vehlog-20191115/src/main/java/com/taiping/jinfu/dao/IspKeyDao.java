package com.taiping.jinfu.dao;

import javax.annotation.Resource;

import org.springframework.stereotype.Repository;

import com.taiping.jinfu.dao.rep.IspKeyRepDao;
import com.taiping.jinfu.entity.IspKey;

/**
 * @author liuhe
 * @since 20190306
 */
@Repository
public class IspKeyDao {
	
	@Resource
	private IspKeyRepDao ispKeyRepDao;

	public IspKey getIspKey(Long keyID) {
		return ispKeyRepDao.getIspKey(keyID);
	}
	
	public IspKey getIspKey2(Long keyID) {
		return this.getIspKey(keyID);
	}
	
	public IspKey getIspKeyByName(String keyName) {
		return ispKeyRepDao.getIspKeyByName(keyName);
	}

}

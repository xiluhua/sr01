package com.taiping.jinfu.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author xilh
 * @since 20191121
 */
@Entity
@Table(name = "ILOG_BUSINESS_LOG_CONTENT")
public class IlogBusinessLogContent implements java.io.Serializable {
	private static final long serialVersionUID = 1L;

	// Fields
	@Id
	@Column(name = "ID", unique = true, nullable = false)
	private String id;
	@Column(name = "LOG_ID")
	private String logId;
	@Column(name = "LOG_MESSAGE")
	private String logMessage;
	@Column(name = "LOG_TYPE")
	private Integer logType;
	@Column(name = "CREATE_TIME")
	private Date createTime;
	
	/** default constructor */
	public IlogBusinessLogContent() {
	}

	public String getLogMessage() {
		return logMessage;
	}

	public void setLogMessage(String logMessage) {
		this.logMessage = logMessage;
	}

	public Integer getLogType() {
		return logType;
	}

	public void setLogType(Integer logType) {
		this.logType = logType;
	}

	public String getLogId() {
		return logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
}
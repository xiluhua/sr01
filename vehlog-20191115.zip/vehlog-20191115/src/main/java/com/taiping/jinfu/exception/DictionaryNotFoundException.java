package com.taiping.jinfu.exception;

public class DictionaryNotFoundException extends TpRuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public DictionaryNotFoundException(String msg){
		super(msg);
	}

	public DictionaryNotFoundException(String msg, String code) {
		super(msg, code);
	}

	public DictionaryNotFoundException() {
	}

}


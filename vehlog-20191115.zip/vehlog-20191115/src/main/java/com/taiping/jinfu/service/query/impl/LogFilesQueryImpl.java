package com.taiping.jinfu.service.query.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.taiping.jinfu.dao.IlogBusinessOperateLogDao;
import com.taiping.jinfu.entity.IlogBusinessLogContent;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;
import com.taiping.jinfu.service.query.LogFilesQueryService;

/**
 * 日志查询
 * @author liuhe
 * @since 20191121
 */
@Service
@Transactional
public class LogFilesQueryImpl implements LogFilesQueryService {

	@Resource
	private IlogBusinessOperateLogDao ilogBusinessOperateLogDao;
	
    @Override
    public List<IlogBusinessOperateLog> queryLog(IlogBusinessOperateLog iLog) {
        List<IlogBusinessOperateLog> list = ilogBusinessOperateLogDao.queryLog(iLog);
        return list;
    }
    
    /**
	 * 查询日志内容
	 * @author liuhe
	 * @Date 20190320
	 */
	@Override
	public IlogBusinessLogContent getLogFileContent(String logId,String logType) {
		IlogBusinessLogContent contentLog = ilogBusinessOperateLogDao.getLogFileContentByLogId(logId,Integer.parseInt(logType));
		return contentLog;
	}
}

//package com.taiping.jinfu.service.httpclient.impl;
//
//import java.security.cert.CertificateException;
//import java.security.cert.X509Certificate;
//import java.util.Iterator;
//import java.util.Map;
//import java.util.Map.Entry;
//import java.util.TreeMap;
//
//import javax.net.ssl.SSLContext;
//import javax.net.ssl.SSLSocketFactory;
//import javax.net.ssl.TrustManager;
//import javax.net.ssl.X509TrustManager;
//
//import org.apache.commons.lang3.StringUtils;
//import org.apache.http.HttpResponse;
//import org.apache.http.client.methods.HttpGet;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.conn.ClientConnectionManager;
//import org.apache.http.conn.scheme.Scheme;
//import org.apache.http.conn.scheme.SchemeRegistry;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.DefaultHttpClient;
//import org.apache.http.message.BasicHeader;
//import org.apache.http.util.EntityUtils;
//import org.springframework.context.annotation.Scope;
//import org.springframework.http.HttpEntity;
//import org.springframework.stereotype.Component;
//
//import com.taiping.facility.tool.LogTool;
///**
// * https请求
// * @author liuhe
// * @since 20190226
// */
//@Component
//@Scope("prototype")
//public class HttpsClientImpl {
//
//    public String doPost(String url,String jsonstr,String charset){
//        HttpClient httpClient = null;
//        HttpPost httpPost = null;
//        String result = null;
//        try{
//            httpClient = new SSLClient();
//            httpPost = new HttpPost(url);
//            httpPost.addHeader("Content-Type", "application/json");
//            StringEntity se = new StringEntity(jsonstr);
//            se.setContentType("text/json");
//            se.setContentEncoding(new BasicHeader("Content-Type", "application/json"));
//            httpPost.setEntity(se);
//            HttpResponse response = httpClient.execute(httpPost);
//            if(response != null){
//                HttpEntity resEntity = response.getEntity();
//                if(resEntity != null){
//                    result = EntityUtils.toString(resEntity,charset);
//                }
//                EntityUtils.consume(resEntity);
//            }
//        }catch(Exception ex){
//            ex.printStackTrace();
//        }finally {
//        	if(httpClient!=null) {
//        		httpClient.getConnectionManager().shutdown();
//        	}
//		}
//        return result;
//    }
//    
//    public String get(String url) throws Exception {
//		HttpClient httpclient = null;
//	    String result = null;
//	    try{
//	        httpclient = new SSLClient();
//	        HttpGet httpGet = new HttpGet(url);
//	            
//	        HttpResponse response = httpclient.execute(httpGet);
//	        if(response != null){
//	            HttpEntity resEntity = response.getEntity();
//	            if(resEntity != null){
//	                 result = EntityUtils.toString(resEntity,"UTF-8");
//	            }
//	             EntityUtils.consume(resEntity);
//	         }
//	    }catch(Exception e){
//	        LogTool.error(this.getClass(), e);
//	    }finally {
//	        if(httpclient!=null) {
//	        	httpclient.getConnectionManager().shutdown();
//	        }
//		}
//	   return result;
//	}
//
//	public String get(String url,Map<String,Object> param) throws Exception {
//		
//		if (param != null && !param.isEmpty()) {
//			// 转为treeMap
//			Map<String, Object> sortMap = new TreeMap<String, Object>(param);
//			StringBuffer buffer = new StringBuffer();
//			Iterator<Entry<String, Object>> iterator = sortMap.entrySet().iterator();
//			while (iterator.hasNext()) {
//				Entry<String, Object> entry = iterator.next();
//				if (StringUtils.isEmpty(buffer.toString())) {
//					buffer.append("?");
//				} else {
//					buffer.append("&");
//				}
//				buffer.append(entry.getKey()).append("=").append(entry.getValue());
//			}
//			url += buffer.toString();
//		}
//		
//		HttpClient httpclient = null;
//	    String result = null;
//	    try{
//	        httpclient = new SSLClient();
//	        HttpGet httpGet = new HttpGet(url);
//	            
//	        HttpResponse response = httpclient.execute(httpGet);
//	        if(response != null){
//	            HttpEntity resEntity = response.getEntity();
//	            if(resEntity != null){
//	                 result = EntityUtils.toString(resEntity,"UTF-8");
//	            }
//	             EntityUtils.consume(resEntity);
//	         }
//	    }catch(Exception e){
//	        LogTool.error(this.getClass(), e);
//	    }finally {
//	        if(httpclient!=null) {
//	        	httpclient.getConnectionManager().shutdown();
//	        }
//		}
//	   return result;
//	}
//	
//	class SSLClient extends DefaultHttpClient {
//		public SSLClient() throws Exception{
//	        super();
//	        SSLContext ctx = SSLContext.getInstance("TLS");
//	        X509TrustManager tm = new X509TrustManager() {
//	                @Override
//	                public void checkClientTrusted(X509Certificate[] chain,
//	                        String authType) throws CertificateException {
//	                }
//	                @Override
//	                public void checkServerTrusted(X509Certificate[] chain,
//	                        String authType) throws CertificateException {
//	                }
//	                @Override
//	                public X509Certificate[] getAcceptedIssuers() {
//	                    return null;
//	                }
//	        };
//	        ctx.init(null, new TrustManager[]{tm}, null);
//	        SSLSocketFactory ssf = new SSLSocketFactory(ctx,SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
//	        ClientConnectionManager ccm = this.getConnectionManager();
//	        SchemeRegistry sr = ccm.getSchemeRegistry();
//	        sr.register(new Scheme("https", 443, ssf));
//	    }
//	}
//}

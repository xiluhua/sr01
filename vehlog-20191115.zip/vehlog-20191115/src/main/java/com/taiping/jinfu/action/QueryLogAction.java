package com.taiping.jinfu.action;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.entity.IlogBusinessLogContent;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;
import com.taiping.jinfu.service.query.impl.LogFilesQueryImpl;

/**
 * 
 * @author liuhe
 * @since 20191121
 */
@Controller
@RequestMapping(value = "/")
public class QueryLogAction extends BaseAction {

	@Resource
	private LogFilesQueryImpl logFilesQueryImpl;
	
	@RequestMapping(value="log.action")
	public String toVehicleLog(HttpServletRequest request) {
		IlogBusinessOperateLog vlog = new IlogBusinessOperateLog();
		request.setAttribute("vlog", vlog);
		return "logQuery_vehicle";
	}
	
	/**
	 * 车险日志查询
	 * @author liuhe
	 * @since 2019/11/21
	 * @return
	 */
	@RequestMapping(value="query-vehicle.action",method = RequestMethod.POST)
    public String queryVehicleLogs(HttpServletRequest request,IlogBusinessOperateLog vlog) {
		List<IlogBusinessOperateLog> list;
		list = logFilesQueryImpl.queryLog(vlog);

		if(list != null){
			for (IlogBusinessOperateLog ilogVehicleOperateLog : list) {
				if(ilogVehicleOperateLog.getMsgPath()!=null){
					ilogVehicleOperateLog.setMsgPath(ilogVehicleOperateLog.getMsgPath().replace("\\","/"));
				}
			}
		}
		
		request.setAttribute("vlogList", list);
		request.setAttribute("count", list.size());
		request.setAttribute("vlog", vlog);

    	return "logQuery_vehicle";
	}
	
	 /**
     * 打开txt文档：前段传logId,查询数据库
     * add by liuhe
     * @since 2019/03/18
     */
    @RequestMapping(value="openLogTxt.action")
    @ResponseBody
    public Map<String, Object> openLogTxt2(HttpServletRequest request){
    	String data = "";
    	String logId = request.getParameter("logId");
    	String logType = request.getParameter("logType");
    	IlogBusinessLogContent logContent = logFilesQueryImpl.getLogFileContent(logId,logType);
        if(logContent!=null) {
        	data = logContent.getLogMessage();
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("data", data);
    	return map;
    }
    
    /**
     * 下载
     * add by liuhe
     * @since 20190320
     */
    @RequestMapping(value="downloadLogMsg2.action")
    @ResponseBody
    public void downloadLogMsg2(HttpServletRequest request,HttpServletResponse response){
    	String data = null;
    	String logId = request.getParameter("logId");
    	String busiOperateType = request.getParameter("busiOperateType");
    	String logType = request.getParameter("logType");
    	String date = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date());
    	String fileName = busiOperateType + "-"+ date;
    	IlogBusinessLogContent logContent = logFilesQueryImpl.getLogFileContent(logId,logType);
    	if(logContent!=null) {
    		data = logContent.getLogMessage();
    	}
    	
    	this.upload(response,data, fileName);
    }
    
    /**
     * 打开
     * add by liuhe
     * @since 20190320
     */
    public void upload(HttpServletResponse response,String source,String fileName){
		BufferedInputStream fis = null;
		OutputStream toClient = null;
		try {
    		int BUFFER_SIZE = 8096;
    		InputStream is = new ByteArrayInputStream(source.getBytes());
        	fis = new BufferedInputStream(is);
    		toClient = new BufferedOutputStream(response.getOutputStream());
    		byte buf[] = new byte[BUFFER_SIZE];
    		int size = 0;
    		response.reset();
    		response.addHeader("Content-Disposition",(new StringBuilder("attachment;filename=")).append(new String((fileName+".txt").getBytes("gbk"), "ISO-8859-1")).toString());
    		response.addHeader("Content-Length",(new StringBuilder()).append(source.length()).toString());
    		response.setContentType("application/msdownload;charset=GBK");
    		
    		while ((size = fis.read(buf)) != -1){
    			toClient.write(buf, 0, size);
    		}
    		fis.close();
    		toClient.flush();
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
		} finally{
			try {
				if (fis != null){
					fis.close();
				}
				if (toClient != null){
					toClient.close();
				}
			} catch (Exception e) {
				LogTool.error(this.getClass(), e);
			}
		}
	}
}

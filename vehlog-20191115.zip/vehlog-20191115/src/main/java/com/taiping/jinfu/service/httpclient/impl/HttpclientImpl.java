package com.taiping.jinfu.service.httpclient.impl;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.ConnectException;
import java.net.MalformedURLException;
import java.net.NoRouteToHostException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.util.Map;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.springframework.stereotype.Component;

import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.TaipingDailizhilianDemo;
import com.taiping.jinfu.service.httpclient.HttpclientService;

@Component
public class HttpclientImpl implements HttpclientService{


	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public String post(String url, Object content,String contentType, String encode,int connectionTimeout,int soTimeout,int retryTime) throws Exception {
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "GBK");
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset=GBK");
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(connectionTimeout);
		// 设置读数据超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(soTimeout);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(retryTime, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];

				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), "GBK"));
//					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(, "GBK"));
			    }

				httpPost.setRequestBody(param);
			}
			// rest
			else {
				httpPost.setRequestEntity(new StringRequestEntity((String)content,contentType, encode));
			}

			// post
			int statusCode = httpclient.executeMethod(httpPost);

			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = String.valueOf("statusCode:"+statusCode);
			}
		} catch (HttpException e) {
			LogTool.error(this.getClass(), e);
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			LogTool.error(this.getClass(), e);
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			LogTool.error(this.getClass(), e);
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}

		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}

	/**
	 * 发送请求，适用于返回xml的请求
	 * @return Document 结果
	 * @throws Exception
	 * @throws Exception
	 */
	public String post(String urlString, Map<String, Object> parameters) throws Exception {
		String paramStr = "";
		String errorMsg = "";
		Object[] services = parameters.keySet().toArray();
		StringBuffer rspContent = null;
		BufferedReader reader = null;
		DataInputStream in = null;
		URLConnection con = null;
		URL url;
		String response = "";
		String sendData = "";
		try {
			for (int i = 0; i < services.length; i++) {
				if (i == 0) {
					paramStr += services[i]
							+ "="
							+ URLEncoder.encode(parameters.get(services[i]).toString(), "utf-8");
				} else {
					paramStr += "&"
							+ services[i]
							+ "="
							+ URLEncoder.encode(parameters.get(services[i]).toString(), "utf-8");
				}
			}
		} catch (UnsupportedEncodingException e) {
			LogTool.error(this.getClass(), e);
			return null;
		}
		try {
			url = new URL(urlString);
			con = url.openConnection();
			con.setUseCaches(false);
			con.setDoOutput(true);
			con.setDoInput(true);
			con.setRequestProperty("Content-type", "application/x-www-form-urlencoded");
			byte[] sendParamByte = null;
			if (!"".equals(paramStr)) {
				sendParamByte = paramStr.getBytes("iso8859_1");
			} else {
				sendParamByte = sendData.getBytes("iso8859_1");
			}

			con.setRequestProperty("Content-length", String
					.valueOf(sendParamByte.length));

			DataOutputStream dataOut = new DataOutputStream(con.getOutputStream());
			dataOut.write(sendParamByte);
			dataOut.flush();
			dataOut.close();
			rspContent = new StringBuffer();
			in = new DataInputStream(con.getInputStream());
			reader = new BufferedReader(new InputStreamReader(in, "gbk"));
			String aLine;
			while ((aLine = reader.readLine()) != null) {
				rspContent.append(aLine);
			}
			response = rspContent.toString();
			in.close();
		} catch (MalformedURLException e1) {
			LogTool.error(this.getClass(), e1);
			errorMsg = "网址格式错误。";
			throw new Exception(e1);
		} catch (NoRouteToHostException e2) {
			e2.printStackTrace();
			errorMsg = "连接失败。";
			throw new Exception(e2);
		} catch (ConnectException e3) {
			e3.printStackTrace();
			// 判断异常信息
			if ("Connection timed out: connect".equals(e3.getMessage())) {
				errorMsg = "连接超时。";
			} else {
				errorMsg = "连接异常。";
			}
		} catch (Exception e) {
			e.printStackTrace();
			errorMsg = "未知错误。";
			throw e;
		} finally {
			if (reader != null) {
				reader.close();
			}
			if (in != null) {
				in.close();
			}
		}

		LogTool.error(this.getClass(), errorMsg);
		LogTool.error(this.getClass(), response);
		return response;
	}

	public String postYlx(String url, Map<String, Object> parameters){
		 // 测试地址
//		String url = "http://116.236.245.194/eservice/gp/servlet/PublicGpBatchOnlineServlet";
//		String url = "http://localhost:8080/eservice/servlet/PublicGpBatchOnlineServlet";
//		String url = "http://10.1.14.43:7001/eservice/gp/servlet/PublicGpBatchOnlineServlet";
		String response = "";
		PostMethod post = new PostMethod(url);
		try {
			String requestXml = (String)parameters.get("xmlstr");
		    // 投保报文样例
		    System.out.println(requestXml);
		    NameValuePair message1 = new NameValuePair("dlbh", (String)parameters.get("dlbh"));  //中介代码
		    NameValuePair message2 = new NameValuePair("xmlstr", requestXml);  //请求报文

		    String key = (String)parameters.get("md5key");
//		    String key = "995k9s71muc2p87c7x9hg4f6e3xx97cs";
		    String hf_md5 = TaipingDailizhilianDemo.md5(requestXml + key);//MD5 = 加密(请求报文+key)

		    NameValuePair message3 = new NameValuePair("md5", hf_md5);  //MD5值
		    post.setRequestBody(new NameValuePair[]{message1,message2,message3});
		    post.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET,"gbk");  //编码GBK
			//
	    	HttpClient client = new HttpClient();
	        // 使用POST方式提交数据
	        HttpMethod method = post;
	        client.executeMethod(post);
	        // 打印服务器返回的状态
	        System.out.println(method.getStatusLine());
	        // 打印结果页面
	        response = new String(method.getResponseBodyAsString());
	        // 打印返回的信息
//	        System.out.println(response);
	        method.releaseConnection();
		} catch (Exception e) {
			LogTool.error(HttpclientImpl.class, e);
		} finally {
			post.releaseConnection();
		}

		return response;
	}
}

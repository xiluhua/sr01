package com.taiping.jinfu.exception;

public class PartnerBusiPropertyVerifyExceptioin extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public PartnerBusiPropertyVerifyExceptioin(String msg){
		super(msg);
	}
	
	public PartnerBusiPropertyVerifyExceptioin(){
		super();
	}

	public PartnerBusiPropertyVerifyExceptioin(String msg, String code) {
		super(msg, code);
	}
}

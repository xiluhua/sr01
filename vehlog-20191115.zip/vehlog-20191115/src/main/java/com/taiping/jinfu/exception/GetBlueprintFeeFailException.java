package com.taiping.jinfu.exception;

public class GetBlueprintFeeFailException extends TpRuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7262170912527027980L;

	public GetBlueprintFeeFailException(String msg){
		super(msg);
	}

	public GetBlueprintFeeFailException(String msg, String code) {
		super(msg, code);
	}

	public GetBlueprintFeeFailException() {
	}
}


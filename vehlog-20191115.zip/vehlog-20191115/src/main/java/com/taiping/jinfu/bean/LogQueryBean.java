/**
 * @(#)LogQueryBean.java
 *
 * project：taiping-svc-log
 *
 * Copyright ?2013 - 2014 太平电子商务有限公司.  All rights reserved.
 * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
 */
package com.taiping.jinfu.bean;

public class LogQueryBean {

    private String logType;
    private int page;
    private int rows;
    private String startDateTime;
    private String endDateTime;

    public String getLogType() {
        return logType;
    }

    public void setLogType(String logType) {
        this.logType = logType;
    }

    public int getPage() {
        return page;
    }

    public void setPage(int page) {
        this.page = page;
    }

    public int getRows() {
        return rows;
    }

    public void setRows(int rows) {
        this.rows = rows;
    }

    public String getStartDateTime() {
        return startDateTime;
    }

    public void setStartDateTime(String startDateTime) {
        this.startDateTime = startDateTime;
    }

    public String getEndDateTime() {
        return endDateTime;
    }

    public void setEndDateTime(String endDateTime) {
        this.endDateTime = endDateTime;
    }

    public enum LogType {
        ILOG_TYPE_BUSINESS_OPERATE {
            @Override
            public String toString() {
                return "0";
            }
        },
        ILOG_TYPE_ERROR {
            @Override
            public String toString() {
                return "1";
            }
        },
        ILOG_TYPE_INTERFACE {
            @Override
            public String toString() {
                return "2";
            }
        },
        ILOG_TYPE_MSG {
            @Override
            public String toString() {
                return "3";
            }
        },
        ILOG_TYPE_OPERATE {
            @Override
            public String toString() {
                return "4";
            }
        },
        ILOG_TYPE_WEB {
            @Override
            public String toString() {
                return "5";
            }
        },
        ILOG_TYPE_PAY {
            @Override
            public String toString() {
                return "6";
            }
        },

    }
}

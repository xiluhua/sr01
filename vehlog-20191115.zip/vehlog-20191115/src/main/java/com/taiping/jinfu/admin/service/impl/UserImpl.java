//package com.taiping.jinfu.admin.service.impl;
//
//import java.util.List;
//
//import javax.annotation.Resource;
//
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.taiping.jinfu.admin.service.UserService;
//import com.taiping.jinfu.dao.ImsAdminUserDao;
//import com.taiping.jinfu.entity.ImsAdminUser;
//
///**
// * @author xilh
// * @since 20170920
// */
//@Service
//@Transactional
//public class UserImpl implements UserService{
//
//    @Resource
//    ImsAdminUserDao imsAdminUserDao;
//
//    @Override
//    public List<ImsAdminUser> getAllUser() {
//        return imsAdminUserDao.getAllUser();
//    }
//
//    @Override
//    public ImsAdminUser getUser(String userName,String password){
//		return imsAdminUserDao.getUser(userName, password);
//	}
//
//    @Override
//    public void saveUser(ImsAdminUser ispAutotestUser) {
//        imsAdminUserDao.saveUser(ispAutotestUser);
//    }
//
//    @Override
//    public List<ImsAdminUser> findByUsername(String username) {
//        return imsAdminUserDao.findByUserName(username);
//    }
//}

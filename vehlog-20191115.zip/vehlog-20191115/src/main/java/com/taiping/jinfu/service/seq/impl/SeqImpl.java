package com.taiping.jinfu.service.seq.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.taiping.facility.redis.JedisClient2;
import com.taiping.jinfu.dao.IspSequenceDao;
import com.taiping.jinfu.service.seq.SeqService;

/**
 * use redis sequence
 * @author xilh
 * @since 20191115
 */
@Component
public class SeqImpl implements SeqService{

	static int AMOUNT = 100000; 
	
	@Resource
	private IspSequenceDao ispSequenceDao;
	
	/**
	 * @author xilh
	 * @since 20191115
	 */
	@Override
	public Long getSequnce(String sequence) {
		
		String key = "SEQ:"+sequence;
		// oracle
		Long seq = JedisClient2.incr(key);
		if (seq >= AMOUNT) {
			System.out.println("--- get sequence from redis, "+sequence+" : "+seq);
			return seq;
		}
		
		seq = seq + AMOUNT;
		JedisClient2.set(key, seq+"");
		return seq;
	}

//	/**
//	 * 远程获取sequence
//	 * @return Long
//	 * @author liux
//	 */
//	private Long getRemoteSeq(String sequence){
//		String paramCode = Cons.SEQUENCE_GEN_URL;
//		String url = CacheContainer.getSysParamValue(paramCode, false); 
//		if (!StringUtils.isEmpty(PropertyFileTool.get(paramCode))) {
//			url = PropertyFileTool.get(paramCode);
//		}
//		StringBuffer sbf = new StringBuffer(url);
//		sbf.append("?name=").append(sequence);
//		System.out.println(sbf.toString());
//		
//		RestTemplate restTemplate = new RestTemplate();
//		restTemplate.getMessageConverters().add(new FastJsonHttpMessageConverter());
//		HttpHeaders requestHeaders = new HttpHeaders();
//		requestHeaders.setContentType(MediaType.APPLICATION_FORM_URLENCODED);
//		HttpEntity<String> requestEntity = new HttpEntity<String>(null, requestHeaders);
//		ResponseEntity<Long> response = restTemplate.exchange(sbf.toString(), HttpMethod.GET, requestEntity, Long.class);
//
//		return response.getBody();
//	}
	
}

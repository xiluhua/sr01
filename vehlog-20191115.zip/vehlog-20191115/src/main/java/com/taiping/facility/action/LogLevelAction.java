//package com.taiping.facility.action;
//
//import org.apache.commons.lang3.StringUtils;
//import org.apache.struts2.convention.annotation.Action;
//import org.apache.struts2.convention.annotation.Namespace;
//import org.apache.struts2.convention.annotation.ParentPackage;
//import org.apache.struts2.convention.annotation.Result;
//
//import com.taiping.facility.tool.LogTool;
//import com.taiping.framework.action.BaseAction;
//
//@ParentPackage("struts-default")
//@Namespace("/log")
//public class LogLevelAction  extends BaseAction {
//	
//	/**
//	 * 日志输出控制
//	 */
//	private static final long serialVersionUID = 1L;
//
//	
//	// http://localhost:7001/taiping-ali-mall/log/level.action?className=com.taiping.partners.ali.V10.service.impl.PartnerImpl_issue&level=ERROR
//	@Action(value = "level", results = { 
//	@Result(name = "success", location = "/WEB-INF/content/log.ftl")})
//	public String level() {
//		getRequest().setAttribute(SUCCESS, ERROR);
//		
//		String className = getRequest().getParameter("className");
//
//		String level = getRequest().getParameter("level");
//
//		if (!StringUtils.isEmpty(className) && !StringUtils.isEmpty(level)) {
//			level = LogTool.getLevel(level.toUpperCase());
//			LogTool.renewLogLevel(className, level);
//			getRequest().setAttribute(SUCCESS, SUCCESS);
//		}
//
//		return SUCCESS;
//	}
//}
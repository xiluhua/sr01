//package com.taiping.facility.aop.log.advice;
//
//import java.lang.reflect.Method;
//
//import javax.annotation.Resource;
//
//import org.springframework.aop.AfterReturningAdvice;
//import org.springframework.stereotype.Component;
//
//import com.taiping.facility.aop.log.Log1;
//import com.taiping.facility.aop.log.impl.BusinesslogImpl;
//import com.taiping.facility.tool.LogTool;
//import com.taiping.jinfu.core.model.Busi;
//import com.taiping.jinfu.entity.IspRmi3;
//
///**
// * 
// * @author xilh
// * @since 20190410
// */
//@Component
//public class Log1Advice implements AfterReturningAdvice{
//
//	@Resource
//	BusinesslogImpl businesslogImpl;
//	
//	/**
//	 * 
//	 * @author xilh
//	 * @since 20190410
//	 */
//	@Override
//	public void afterReturning(Object result, Method method, Object[] args, Object target) throws Throwable {
//		LogTool.info(this.getClass(), "isAnnotationPresent(Log1.class): "+method.isAnnotationPresent(Log1.class));
//		LogTool.info(this.getClass(), "class: "+method.getDeclaringClass().getSimpleName()+", method: "+method.getName());
//		
//		Busi busi = (Busi)args[0];
//		IspRmi3 ispRmi = busi.getRmi();
//
//		String packet = String.valueOf(result); 
//		if (ispRmi != null) {
//			packet = busi.getServiceCode()+" url: "+ ispRmi.getUrl() +System.getProperty("line.separator")+ packet;
//		}
//		
//		LogTool.info(this.getClass(),busi.getServiceCode() + " requestXml:\n"+packet);
//		// 存报文
//		businesslogImpl.postBusinessOpelog_1(busi, packet, busi.getServiceCode(), 1, 1);
//	}
//}
//	

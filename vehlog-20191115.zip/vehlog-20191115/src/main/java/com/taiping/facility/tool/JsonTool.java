package com.taiping.facility.tool;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.xml.bind.JAXBException;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * 
 * @author xiluhua by 20160119
 *
 */
public class JsonTool {
	
	public static String toJson(Object target,String format) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setDateFormat(new SimpleDateFormat(format));
		try {
			return mapper.writeValueAsString(target);
		} catch (Exception e) {
			LogTool.error(JsonTool.class, e);
		}
		return null;
	}
	
	public static String toJson(Object target) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		try {
			return mapper.writeValueAsString(target);
		} catch (Exception e) {
			LogTool.error(JsonTool.class, e);
		}
		return null;
	}
	
	/**
	 * @param json
	 * @param clazz
	 * @param dateFormat "yyyy-MM-dd HH:mm:ss"
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public static <T> T toObject(String json, Class<?> clazz,String dateFormat) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setDateFormat(new SimpleDateFormat(dateFormat));
		try {
			return (T) mapper.readValue(json, clazz);
		} catch (Exception e) {
			LogTool.error(JsonTool.class, e);
		}
		return null;
	}
	
	@SuppressWarnings("unchecked")
	public static <T> T toObject(String json, Class<?> clazz) {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setDateFormat(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"));
		try {
			return (T) mapper.readValue(json, clazz);
		} catch (Exception e) {
			LogTool.error(JsonTool.class, e);
		}
		return null;
	}

	public static JsonNode readValue(String json,String nodeName) throws JsonProcessingException, IOException{
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode rootNode = objectMapper.readTree(json);
		return rootNode.path(nodeName);
	}
	
	/**
	 * 读取文件内容字符串
	 * @param path 文件路径
	 * @param encode 编码
	 * @return 文件内容
	 */
	public static String readFile(String path,String encode){
		String content = "";
		InputStream inputStream = null;
		try {
			inputStream = new FileInputStream(new File(path));
			content = new String(read(inputStream),encode);
		} catch (FileNotFoundException e) {
			LogTool.error(JsonTool.class, e);
		} catch (UnsupportedEncodingException e) {
			System.out.println("UnsupportedEncodingException encode:"+encode+"\n");
			LogTool.error(JsonTool.class, e);
		} catch (Exception e) {
			LogTool.error(JsonTool.class, e);
		}finally{
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
					LogTool.error(JsonTool.class, e);
				}
			}
		}
		
		return content;
	}
	
	public static byte[] read(InputStream in) throws Exception {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		if (in != null) {
			byte[] buffer = new byte[1024];
			int length = 0;
			while ((length = in.read(buffer)) != -1) {
				out.write(buffer, 0, length);
			}
			out.close();
			in.close();
			return out.toByteArray();
		}
		return null;
	}
	
	public static void main(String[] args) throws JsonParseException, JsonMappingException, IOException, ParseException, JAXBException {
		//read json file data to String
		//String file = "employee.txt";
//		String dateFormat = "yyyy-MM-dd HH:mm:ss";
//		String path = JsonUtils.class.getResource("/"+file).getPath();
//		
//		byte[] jsonData = JsonUtils.readFile(path,"gbk").getBytes("gbk");
//		
//		//create ObjectMapper instance
//		ObjectMapper objectMapper = new ObjectMapper();
//		
//		//convert json string to object
//		Employee emp = objectMapper.readValue(jsonData, Employee.class);
//		System.out.println("====================================================");
//		System.out.println("Employee Object\n"+emp);
//		
//		//convert Object to json string
//		RequestCheckDTO checkDTO = null;
//		String checkDTOString = CreateDTOTool_1.create(1,"178_LOCAL201602211",false,1);
//		System.out.println("====================================================");
//		System.out.println("CheckDTO JSON is\n"+checkDTOString);
//		
//		Map String to Object
//		@SuppressWarnings("unused")
//		Employee employee = objectMapper.readValue(stringEmp.toString(), Employee.class);
//		
//		checkDTO = JsonTool.toObject(checkDTOString,RequestCheckDTO.class,dateFormat);
//		System.out.println(ToStringBuilder.reflectionToString(checkDTO.getApply()));
//		
//		System.out.println("====================================================");
//
//        SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss Z yyyy", Locale.US);//MMM dd hh:mm:ss Z yyyy
//        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//        
//        try {
//            System.out.println(formatter.format(sdf.parse(new Date().toString())));
//        } catch (ParseException ex) {
//            ex.printStackTrace();
//        }
        
//        String checkDTOString = "{\"result\":\"2\",\"err_code\":\"\"}";
//        ResponsePayMoneyDTO responsePayMoneyDTO = JsonTool.toObject(checkDTOString,ResponsePayMoneyDTO.class,DateTool.DATE_TIME_MASK);
//		System.out.println(responsePayMoneyDTO);
		
//		RequestPurchaseRecordQueryDTO request = new RequestPurchaseRecordQueryDTO();
//		String json = JsonTool.toJson(request);
//		System.err.println(json);
		
	}
}

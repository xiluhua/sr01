package com.taiping.facility.action;


import java.util.Calendar;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taiping.facility.cache.impl.CacheImpl;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.StringTool;
import com.taiping.jinfu.action.BaseAction;

/**
 * 缓存
 */
@Controller
@RequestMapping(value = "/cache")
public class CacheAction extends BaseAction {

	@Resource
	private CacheImpl cacheImpl;

	@ResponseBody
	@RequestMapping(value = "/refreshLog.action")
	public String refreshLog() throws Exception {

		LogTool.info(this.getClass(), "===========================================================================");
		LogTool.info(this.getClass(), "cache class: log");

		cacheImpl.refreshLogLevel();

		LogTool.info(this.getClass(), "refreshLog: finished!");
		return SUCCESS;
	}

	public static void main(String[] args) {
		String rand = String.valueOf(StringTool.getRandomInRange(1000, 100000));
		String partnerApplyId = String.valueOf(Calendar.getInstance().getTimeInMillis())+rand;
		System.out.println(partnerApplyId);
	}
}
package com.taiping.facility.tool;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

public class StringTool {
	public static boolean isInArray(String str, String[] strArray) {
		boolean result = false;
		for (int i = 0; i < strArray.length; i++) {
			if (strArray[i].equals("")) {
				result = false;
			} else if (str.indexOf(strArray[i].trim())!=-1) {
				result = true;
				break;
			}
		}
		return result;
	}
	 //大写首字母
    public static String up1stLetter(String word){
    	char[] chars=word.toCharArray();
    	if(chars[0]>='a'&&chars[0]<'z') 
    	{chars[0]=(char)(chars[0]-32); 
    	} 
    	String up1srWord=new String(chars); 
    	return up1srWord;
    }
   //小写首字母
    public static String lower1stLetter(String word){
    	char[] chars=word.toCharArray();
    	if(chars[0]>='A'&&chars[0]<'Z') 
    	{chars[0]=(char)(chars[0]+32); 
    	} 
    	String up1srWord=new String(chars); 
    	return up1srWord;
    }
    public static String toString(Object inObj,String dataFormat) {
		String obj = null;
		if (inObj != null) {
			if (inObj.getClass().equals(Date.class)||inObj.getClass().equals(Timestamp.class)) {
				obj = DateTool.getFormatDate(dataFormat, (Timestamp) inObj);
			}
			else{
				obj=inObj.toString();
			}
		} else {
			obj = "";
		}
		return obj;
	}

    /**
	 * 将输入的字串左补0到指定位数
	 * 
	 * @param String str 源字串
	 * @param int totalSize 补齐后的位数 
	 * @return boolean
	 */
	public static String addZero(String str, int totalSize) {
		if (str == null)
			str = "";
		int length = str.length();
		if(totalSize==length){
			return str;
		}
		if(totalSize<length){
			return str.substring(length-totalSize,length-1);
		}		
		for (int i = 0; i < totalSize - length; i++) {
			str = "0" + str;
		}
		return str;
	}

	/**
	 * 返回字符串的副本，忽略前导'0'。
	 * 
	 * @param String str 源字串
	 * @return str
	 */
	public static String trimLeadingZero(String str) {
		if(str == null || str.length() == 0)
		return str;
		
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(0) == '0')
			{
				str = str.substring(1);
			}
			else
			{
				break;
			}
		}
		return str;
	}
	
	public static String nullToEmpty(Object sourceString) {
		if (sourceString == null) {
			return "";
		}
		return sourceString.toString();
	}
	public static Object StringToObj(String s,Class clazz){
		Object obj=null;
		if(s.equals("NULL")){
			obj=null;
		}
		else if(clazz.equals(Integer.class)){
			obj=Integer.parseInt(s);
		}
		else if(clazz.equals(int.class)){
			obj=Integer.parseInt(s);
		}
		else if(clazz.equals(Long.class)){
			obj=Long.parseLong(s);
		}
		else if(clazz.equals(long.class)){
			obj=Long.parseLong(s);
		}
		else if(clazz.equals(Double.class)){
			obj=Double.parseDouble(s);
		}
		else if(clazz.equals(double.class)){
			obj=Double.parseDouble(s);
		}
		else if(clazz.equals(Date.class)){
			try {
				obj=DateTool.getDateTime(s,"yyyy-MM-dd HH:mm:ss:SSS");
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		else if(clazz.equals(String.class)){
			obj=s;
		}
		else{
			//不支持类型
			LogTool.error(StringTool.class,"不支持类型:"+clazz.getName());
		}
		return obj;
	}
	public static String ObjToString(Object obj){
		String  str=null;
		if(obj==null){
			str="";
		}
		else{
			Class clazz=obj.getClass();
			if(clazz.equals(Integer.class)){
				str=obj.toString();
			}
			else if(clazz.equals(int.class)){
				str=obj+"";
			}
			else if(clazz.equals(Long.class)){
				str=obj.toString();
			}
			else if(clazz.equals(long.class)){
				str=obj+"";
			}
			else if(clazz.equals(Double.class)){
				str=obj.toString();
			}
			else if(clazz.equals(double.class)){
				str=obj+"";
			}
			else if(clazz.equals(Date.class)){
				str=DateTool.getFormatDate("yyyy-MM-dd HH:mm:ss:SSS", (Date)obj);
				
			}
			else if(clazz.equals(String.class)){
				str=obj+"";
				
			}
			else if(clazz.getSimpleName().endsWith("Exception")){
				
				str=LogTool.getExceptionStr((Exception)obj);
				
			}
			else{
				//不支持类型
				LogTool.error(StringTool.class,"不支持类型:"+clazz.getName());
				str="";
			}
		}
		return str;
	}
	
	/**
	 * 按大写字母分割字符串
	 * @return
	 */
	public static List<String> splitByUpLetter(String str){
		List<String> list=new ArrayList();
		char[] c=str.toCharArray();
		StringBuffer sb=new StringBuffer();
		for(int i=0;i<c.length;i++){
			if(Character.isUpperCase(c[i])){
				list.add(sb.toString());
				sb=new StringBuffer();
			}
			sb.append(c[i]);
			if(i==c.length-1){
				list.add(sb.toString());
			}
		}
		return list;
	}
	
	public static String getSexFromIdCard(String idCard) {
		int idCardLength = idCard.length();
		String sex = "";
		if (idCardLength == 18)
			sex = idCard.substring(16, 17);
		else if (idCardLength == 15) {
			sex = idCard.substring(14, 15);
		}
		Integer sexInt = Integer.valueOf(Integer.parseInt(sex) % 2);

		if (sexInt.intValue() == 0)
			sex = "2";
		else {
			sex = "1";
		}
		return sex;
	}
	
	public static Date getBirthdayFromIdCard(String idCard) {
		Date birth = null;
		try {
			int idCardLength = idCard.length();
			String bir = "";
			if (idCardLength == 18)
				bir = idCard.substring(6, 10) + "-" + idCard.substring(10, 12)
						+ "-" + idCard.substring(12, 14);
			else if (idCardLength == 15) {
				bir = "19" + idCard.substring(6, 8) + "-"
						+ idCard.substring(8, 10) + "-"
						+ idCard.substring(10, 12);
			}
			birth = DateTool.getDateTime(bir, "yyyy-MM-dd");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return birth;
	}
	
	//由出生日期获得年龄
    public static int getAge(Date birthDay) throws Exception {
        Calendar cal = Calendar.getInstance();

        if (cal.before(birthDay)) {
            throw new IllegalArgumentException(
                    "The birthDay is before Now.It's unbelievable!");
        }
        int yearNow = cal.get(Calendar.YEAR);
        int monthNow = cal.get(Calendar.MONTH);
        int dayOfMonthNow = cal.get(Calendar.DAY_OF_MONTH);
        cal.setTime(birthDay);

        int yearBirth = cal.get(Calendar.YEAR);
        int monthBirth = cal.get(Calendar.MONTH);
        int dayOfMonthBirth = cal.get(Calendar.DAY_OF_MONTH);

        int age = yearNow - yearBirth;

        if (monthNow <= monthBirth) {
            if (monthNow == monthBirth) {
                if (dayOfMonthNow < dayOfMonthBirth) age--;
            }else{
                age--;
            }
        }
        return age;
    }
 // 根据年月日计算年龄,birthTimeString:"1994-11-14"
	public static int getAgeFromBirthTime(String birthTimeString) {
		// 先截取到字符串中的年、月、日
		String strs[] = birthTimeString.trim().split("-");
		int selectYear = Integer.parseInt(strs[0]);
		int selectMonth = Integer.parseInt(strs[1]);
		int selectDay = Integer.parseInt(strs[2]);
		// 得到当前时间的年、月、日
		Calendar cal = Calendar.getInstance();
		int yearNow = cal.get(Calendar.YEAR);
		int monthNow = cal.get(Calendar.MONTH) + 1;
		int dayNow = cal.get(Calendar.DATE);

		// 用当前年月日减去生日年月日
		int yearMinus = yearNow - selectYear;
		int monthMinus = monthNow - selectMonth;
		int dayMinus = dayNow - selectDay;

		int age = yearMinus;// 先大致赋值
		if (yearMinus < 0) {// 选了未来的年份
			age = 0;
		} else if (yearMinus == 0) {// 同年的，要么为1，要么为0
			if (monthMinus < 0) {// 选了未来的月份
				age = 0;
			} else if (monthMinus == 0) {// 同月份的
				if (dayMinus < 0) {// 选了未来的日期
					age = 0;
				} else if (dayMinus >= 0) {
					age = 1;
				}
			} else if (monthMinus > 0) {
				age = 1;
			}
		} else if (yearMinus > 0) {
			if (monthMinus < 0) {// 当前月>生日月
			} else if (monthMinus == 0) {// 同月份的，再根据日期计算年龄
				if (dayMinus < 0) {
				} else if (dayMinus >= 0) {
					age = age + 1;
				}
			} else if (monthMinus > 0) {
				age = age + 1;
			}
		}
		return age;
	}

	// 根据时间戳计算年龄
	public static int getAgeFromBirthTime(long birthTimeLong) {
		//Date date = new Date(birthTimeLong * 1000l);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		String birthTimeString = format.format(birthTimeLong);
		return getAgeFromBirthTime(birthTimeString);
	}
	/**
	 * 获取low-->range(不包括range)范围内的随机数
	 * @param low
	 * @param range
	 * @return
	 */
	public static int getRandomInRange(int low,int range)
	{		
		int key = -999999999;
		Random random = new Random();
		while(key < low)
		{
			key = random.nextInt(range);
		}
		return key;
	}
	
	public static int calculateLength(String address) {
		int sum = 0;
		int chinese = 0;
		int other = 0;
		for (int x = 0; x < address.length(); x++) {
			char ch = address.charAt(x);
			// 判断该字符到底是属于那种类型的
			if (ch >= 0x4E00 && ch <= 0x9FA5) {
				chinese ++;
			}else{
				other++;
			}
		}
		
		sum  = other + chinese*2;
		return sum;
	}
	
	public static void main(String[] args) throws ParseException, Exception {
//		String str="insureApplyDao";
//		List l=StringTool.splitByUpLetter(str);
//		System.out.println(l);
		String string = null;
		System.out.println(StringTool.nullToEmpty(string));
//		System.out.println(StringTool.getAge(DateTool.getDateTime("2016-09-22", "yyyy-MM-dd")));
//		System.out.println(StringTool.getAgeFromBirthTime("2016-09-22"));
//		System.out.println(StringTool.getAgeFromBirthTime("1952-03-18"));
		System.out.println(StringTool.getRandomInRange(100, 1000));
	}
}

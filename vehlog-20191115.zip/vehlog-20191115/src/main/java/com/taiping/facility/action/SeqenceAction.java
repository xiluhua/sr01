package com.taiping.facility.action;




import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.dao.IspSequenceDao;
import com.taiping.jinfu.service.seq.impl.SeqImpl;

@Controller
@RequestMapping(value = "/sequence")
public class SeqenceAction {
	@Resource
	SeqImpl seqImpl;
	@Resource
	IspSequenceDao ispSequenceDao;
	
	/**
	 * @author xilh
	 * @since 20190409
	 * local : http://localhost:8007/seqence/gen3.action?name=SEQ_ISP_TRANS
	 * uat   : http://10.1.118.45:8002/seqence/gen.action?name=SEQ_ISP_YANGLAO_TRANS
	 * formal: http://10.4.233.46seqence/gen.action?name=SEQ_ISP_YANGLAO_TRANS
	 */
	@ResponseBody
	@RequestMapping(value = "gen3.action") 
	public Long gen3(String name) {
		
		LogTool.info(this.getClass(), "===========================================================================");
		LogTool.info(this.getClass(), "seqence name: "+ name);
		try {
			Long seq = seqImpl.getSequnce(name);
			LogTool.info(this.getClass(), "seqence name: "+ name+", seq: "+seq);
			return seq;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0L;
	}
}

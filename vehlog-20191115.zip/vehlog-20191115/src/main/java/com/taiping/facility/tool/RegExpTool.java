package com.taiping.facility.tool;

import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegExpTool 
{		
	public static String numRegex	= "[0-9]";				//验证包含数字
	public static String letterRegex = "[A-Za-z]";			//验证包含字母
	public static String lowerRegex = "[a-z]";				//验证包含小写字母
	public static String upperRegex = "[A-Z]";				//验证包含汉字
	public static String chineseRegex = "[\\u4e00-\\u9fa5]";//验证是否为汉字
	public static String allNumRegex  = "^[0-9]*$";			//验证全是数字
	public static String allLetterRegex = "^[A-Za-z]+$";	//验证全是字母
	public static String allLowerRegex = "^[a-z]+$";		//验证全是小写字母
	public static String allUpperRegex = "^[A-Z]+$";		//验证全是大写字母
	public static String allCineseRegex = "^[\\u4e00-\\u9fa5]+$";//验证全是汉字
	public static String emailRegex = "^([\\w-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([\\w-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$";
	public static String IPRegex = "(25[0-5]|2[0-4]\\d|[0-1]\\d{2}|[1-9]?\\d)";
	public static String urlRegex = "http(s)?://([\\w-]+\\.)+[\\w-]+(/[\\w- ./?%&=]*)?";
	public static String telRegex = "^(\\d{3,4}-)?\\d{6,8}$";
	public static String mobileRegex = "^[0,1]+[3,5,8]+\\d{9}$";
	public static String signRegex = "[\\[\\]~!@#$%^&*()_+}{|\":?.,';=-\\><、。，‘；】【——）（……%￥！◎※§ ]";
	public static String decimalRegex	= "^[0-9]+(.[0-9]{2})?$"; 	//验证输入两位小数
	public static String monthRegex = "^(0?[[1-9]|1[0-2])$";		//验证输入一年的12个月
	public static String dayRegex = "^((0?[1-9])|((1|2)[0-9])|30|31)$";//验证输入一个月的31天	
	public static String dateRegex ="^((((1[6-9]|[2-9]\\d)\\d{2})-(0?[13578]|1[02])-(0?[1-9]|[12]\\d|3[01]))|(((1[6-9]|[2-9]\\d)\\d{2})-(0?[13456789]|1[012])-(0?[1-9]|[12]\\d|30))|(((1[6-9]|[2-9]\\d)\\d{2})-0?2-(0?[1-9]|1\\d|2[0-8]))|(((1[6-9]|[2-9]\\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29-)) (20|21|22|23|[0-1]?\\d):[0-5]?\\d:[0-5]?\\d$";//验证日期格式	
		
	//验证以上所有静态正则-->如果str 符合 regex的正则表达式格式,返回true, 否则返回 false;
	public static boolean vaidate(String str, String regex) {
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(str);
		return matcher.matches();
	}	
	//检查输入的数据中是否含有regx所代表的字符
	public static boolean isContain(String str, String regx) 
	{		
		boolean flag = false;
		str = str.trim();
		Pattern p = Pattern.compile(regx, Pattern.CASE_INSENSITIVE);
		Matcher m = p.matcher(str);			
		flag = m.find();				   
		return flag;
	}	
		
	public static void main(String[] args)
	{
//			// System.out.println(RegExpTool.isContain("fsjfsjfj§s5",RegExpTool.signRegex));
		String str = "上海市环球金融大厦b1层101号";
		System.out.println(str);
		int sum =0;
		int number1 =0;
		int number2 =0;
		int chinese = 0;
		int other = 0;
		for (int i = 0; i < str.length(); i++) {
			String subStr1 = str.substring(i,i+1);
			 sum = i+1;
		}
		// 遍历字符串，得到每一个汉字。
		for (int x = 0; x < str.length(); x++) {
			char ch = str.charAt(x);
			// 判断该字符到底是属于那种类型的
			if (ch >= 0x4E00 && ch <= 0x9FA5) {
				chinese ++;
			}else
				other++;
		}
		// 输出结果。
		number1  = other + chinese*2;
		number2 = chinese+ sum ;
		System.out.println("含有" + chinese + "个汉字");
		System.out.println("含有" + other + "个非汉字");
		System.out.println("     一共" + sum + "字");
		System.out.println("number1 = "+ number1 );
		System.out.println("number2 = "+ number2 );
	}
}

package com.taiping.facility.tool;

import java.io.IOException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.URLEncoder;
import java.util.Enumeration;
import java.util.Map;

import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;

import com.taiping.common.Base64Tool;
import com.taiping.facility.cache.container.CacheContainer;
import com.taiping.jinfu.constant.Env;

public class HttpclientTool {

	public static String localIp = null;
	
	static{
		localIp = getLocalIp();
	}
	/**
	 * post 方法
	 * @param  url
	 * @param params
	 * @return
	 */
	public static String post(String url, Object content, String encode) throws Exception {
		String responseMsg = "";
		byte[] responseBody = null;
		HttpClient httpclient = new HttpClient();
		PostMethod httpPost = new PostMethod(url);
		httpPost.setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, encode);
		httpPost.setRequestHeader("ContentType", "application/x-www-form-urlencoded;charset="+encode);
		// 设置连接超时时间(单位毫秒)
		httpclient.getHttpConnectionManager().getParams().setConnectionTimeout(6000000);
		// 设置读数据超时时间(单位毫秒)    	
		httpclient.getHttpConnectionManager().getParams().setSoTimeout(6000000);
		try {
			httpPost.getParams().setParameter(HttpMethodParams.RETRY_HANDLER,new DefaultHttpMethodRetryHandler(3, false));
			// servlet
			if (content instanceof Map) {
				@SuppressWarnings("unchecked")
				Map<String, String> map = (Map<String, String>)content;
				NameValuePair[] param = new NameValuePair[map.size()];
				
				int index = 0;
				for (Map.Entry<String, String> entry : map.entrySet()) {
					param[index] = new NameValuePair(entry.getKey(),URLEncoder.encode(entry.getValue(), "GBK"));
			    }
				
				httpPost.setRequestBody(param);
			}
			// rest
			else {
				httpPost.setRequestEntity(new StringRequestEntity((String)content,"plain/text", encode));
			}
			
			// post
			int statusCode = httpclient.executeMethod(httpPost);
			System.out.println("statusCode:"+statusCode);
			// success
			if (statusCode == HttpStatus.SC_OK) {
				responseBody = httpPost.getResponseBody();
			}
			// failure
			else {
				responseMsg = Base64Tool.encode(String.valueOf("statusCode:"+statusCode), encode);
			}
		} catch (HttpException e) {
			throw new Exception(e.getMessage());
		} catch (IOException e) {
			throw new Exception(e.getMessage());
		} catch (Exception e) {
			throw new Exception(e.getMessage());
		} finally {
			httpPost.releaseConnection();
		}
	
		if (responseBody != null) {
			responseMsg = new String(responseBody, encode);
		}
		return responseMsg;
	}

	/**
	 * 获取本机IP地址
	 * @return
	 */
	public static String getLocalIp(){
		String localIp = "";
		Enumeration allNetInterfaces = null;
		try {
			allNetInterfaces = NetworkInterface.getNetworkInterfaces();
		} catch (SocketException e) {
			e.printStackTrace();
		}
		InetAddress ip = null;
		while (allNetInterfaces.hasMoreElements()) {
			NetworkInterface netInterface = (NetworkInterface) allNetInterfaces.nextElement();
//			System.out.println(netInterface.getName());
			Enumeration addresses = netInterface.getInetAddresses();
			while (addresses.hasMoreElements()) {
				ip = (InetAddress) addresses.nextElement();
				
				if (ip != null && ip instanceof Inet4Address) {

//					System.out.println("local IP address = " + ip.getHostAddress());
					localIp = ip.getHostAddress();
					if (!localIp.equals("127.0.0.1")) {
						return localIp;
					}
					
				}
			}
		}
		return localIp;
	}
	
	/** 
	* 设置代理 
	* @author xilh
	* @since 20180517 
	*/  
	public static void setProxy(HttpClient client) {  
		// 设置代理  
		//设置代理服务器的ip地址和端口  
		if (Env.isLocal) {
			String proxy = PropertyFileTool.get("internet.proxy");
			String[] arr1 = proxy.split(":");
			String auth  = PropertyFileTool.get("internet.auth");
			String[] arr2 = auth.split(":");
			client.getHostConfiguration().setProxy(arr1[0], Integer.valueOf(arr1[1]));  
			//使用抢先认证  
			client.getParams().setAuthenticationPreemptive(true);
			if (Env.isLocal) {
				client.getState().setProxyCredentials(AuthScope.ANY, new UsernamePasswordCredentials(arr2[0],arr2[1])); 
			}
			return;
		}
		
		String value = CacheContainer.getSysParamValue("internet.proxy", true);
		String[] arr = value.split(":");
		client.getHostConfiguration().setProxy(arr[0], Integer.valueOf(arr[1]));  
	}  
}
package com.taiping.facility.tool;

import com.taiping.jinfu.constant.Ret;

/**
 * 联通撤单返回枚举类
 * @author liuhe
 * @since 20190517
 */
public enum CancelLtResponseEnum {

	SUCCESS(Ret.RETURN_SUCC,"0","成功"),
	PLICY_NO_EXISTS(Ret.C1007,"001","保单不存在"),
	POLICY_STATUS_ERROR(Ret.C1019,"002","保单状态有误"),
	POLICY_CANCEL(Ret.C1014,"003","投保单已撤件"),
	POLICY_PAY(Ret.C1005,"004","保单已缴费"),
	ERROR_OTHER(Ret.C9999,"005","其他错误");
	
	private String resutCode;
	private String exterCode;
	private String desc;
	
	private CancelLtResponseEnum(String resutCode,String exterCode,String desc) {
		this.resutCode = resutCode;
		this.exterCode = exterCode;
		this.desc = desc;
	}
	
	public static String getResponseCode(String exterCode) {
		for(CancelLtResponseEnum response : CancelLtResponseEnum.values()){
	        if(response.getExterCode().equals(exterCode)) {
	        	return response.getResutCode();
	        }
	    }
		return ERROR_OTHER.getResutCode();
	}
	
	public String getResutCode() {
		return resutCode;
	}
	public void setResutCode(String resutCode) {
		this.resutCode = resutCode;
	}
	public String getExterCode() {
		return exterCode;
	}
	public void setExterCoe(String exterCode) {
		this.exterCode = exterCode;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}

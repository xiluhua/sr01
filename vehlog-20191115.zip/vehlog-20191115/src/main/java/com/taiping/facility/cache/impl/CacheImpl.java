package com.taiping.facility.cache.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.taiping.facility.cache.CacheService;
import com.taiping.facility.redis.JedisClient2;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.dao.ImsLogLevelDao;
import com.taiping.jinfu.entity.ImsLogLevel;

@Service
public class CacheImpl implements CacheService{

	@Resource
	private ImsLogLevelDao imsLogLevelDao;
	
	/**
	 * 刷新日志等级
	 */
	public void refreshLogLevel(){
		Map<Object, String> map = imsLogLevelDao.getAllInMap();
		JedisClient2.set(ImsLogLevel.class.getSimpleName(),JsonTool.toJson(map));
		LogTool.init(map);
	}
	
}

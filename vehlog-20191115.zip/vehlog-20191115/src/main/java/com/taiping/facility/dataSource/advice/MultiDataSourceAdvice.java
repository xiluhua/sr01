package com.taiping.facility.dataSource.advice;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;
import org.springframework.aop.MethodBeforeAdvice;
import org.springframework.stereotype.Component;

import com.taiping.facility.dataSource.DataSourceContextHolder;
import com.taiping.facility.dataSource.MultiDataSource;

@Component
public class MultiDataSourceAdvice implements MethodBeforeAdvice,AfterReturningAdvice
{
	@Override
	public void afterReturning(Object returnValue, Method method,
			Object[] args, Object target) throws Throwable {
		// TODO Auto-generated method stub
		DataSourceContextHolder.clearDataSourceType();
	}

	@Override
	public void before(Method method, Object[] args, Object target)
			throws Throwable {
	
		int id = (int)args[0];
		if (id % 2 == 0) {
			DataSourceContextHolder.setDataSourceType(MultiDataSource.dataSource2);
		}else {
			DataSourceContextHolder.setDataSourceType(MultiDataSource.dataSource1);
		}
		System.out.println(MultiDataSourceAdvice.class+": "+id+" : "+DataSourceContextHolder.getDataSourceType());
	}
}

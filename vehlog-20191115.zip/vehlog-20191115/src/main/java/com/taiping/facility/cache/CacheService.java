package com.taiping.facility.cache;

public interface CacheService {
	
	/**
	 * 刷新日志等级
	 */
	public void refreshLogLevel();
	
}

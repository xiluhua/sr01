package com.taiping.facility.model;

import java.io.Serializable;

/**
 *<p>Description : 字典项</p>
 *<p>Date        : Jun 3, 2013</p>
 *<p>Remark      : </p>
 * @version   
 */
public class DictItem implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5127635775002810660L;
	public String code;  //代码 如: m
	public String text;  //内容 如：男
	public String    value; //本系统值   如: 1
	public String coreValue;//核心系统对应值
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getCoreValue() {
		return coreValue;
	}
	public void setCoreValue(String coreValue) {
		this.coreValue = coreValue;
	}

}

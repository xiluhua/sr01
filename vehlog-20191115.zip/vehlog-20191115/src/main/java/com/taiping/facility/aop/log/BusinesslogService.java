///**
// * @(#)BusinesslogService.java
// *       
// * project：taiping-sol-insu-vehicle-BRANCH-20150818
// * 
// * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
// * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
// */
//package com.taiping.facility.aop.log;
//
//import com.taiping.jinfu.core.model.Busi;
//import com.taiping.jinfu.entity.IspApply;
//
///**
// *<p>Description : 业务日志服务</p>
// *<p>Date        : 2015-08-19</p>
// *<p>Remark      : </p>
// * @version
// */
//public interface BusinesslogService {
//	
//	public Long getLogIndexWrite();
//	
//	public Long getLogIndex();
//
//	/**
//	 * 业务日志
//	 * @param apply
//	 * @param businessOperateType
//	 * @param operateStatus
//	 * @param phase:1内层2外层
//	 */
//	public void postBusinessOpelog_1(IspApply apply,String packet,String businessOperateType,Integer operateStatus,int phase);
//	
//	/**
//	 * 业务日志
//	 * @param apply
//	 * @param businessOperateType
//	 * @param operateStatus
//	 * @param phase:1内层2外层
//	 */
//	public void postBusinessOpelog_2(IspApply apply,String packet,String businessOperateType,Integer operateStatus,int phase);
//	
//	/**
//	 * 业务日志
//	 * @param busi
//	 * @param businessOperateType
//	 * @param operateStatus
//	 */
//	public void postBusinessOpelog_1(Busi busi,String packet,String businessOperateType,Integer operateStatus,int phase);
//	/**
//	 * 业务日志
//	 * @param busi
//	 * @param businessOperateType
//	 * @param operateStatus
//	 */
//	public void postBusinessOpelog_2(Busi busi,String packet,String businessOperateType,Integer operateStatus,int phase);
//}
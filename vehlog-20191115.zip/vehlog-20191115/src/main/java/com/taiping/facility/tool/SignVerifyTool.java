package com.taiping.facility.tool;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

public class SignVerifyTool {
	/**
     * 解析xml,返回第一级元素键值对。如果第一级元素有子节点，则此节点的值是子节点的xml数据。
     *
     * @param strxml
     * @return
     * @throws org.jdom.JDOMException
     * @throws IOException
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
	public static Map doXMLParse(String strxml) throws JDOMException, IOException {
        strxml = strxml.replaceFirst("encoding=\".*\"", "encoding=\"UTF-8\"");

        if (null == strxml || "".equals(strxml)) {
            return null;
        }

        Map m = new HashMap();

        InputStream in = new ByteArrayInputStream(strxml.getBytes("UTF-8"));
        SAXBuilder builder = new SAXBuilder();
        Document doc = builder.build(in);
        Element root = doc.getRootElement();
        List list = root.getChildren();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            Element e = (Element) it.next();
            String k = e.getName();
            String v = "";
            List children = e.getChildren();
            if (children.isEmpty()) {
                v = e.getTextNormalize();
            } else {
                v = getChildrenText(children);
            }

            m.put(k, v);
        }

        //关闭流
        in.close();

        return m;
    }
    
    /**
     * 获取子结点的xml
     *
     * @param children
     * @return String
     */
    @SuppressWarnings("rawtypes")
	public static String getChildrenText(List children) {
        StringBuffer sb = new StringBuffer();
        if (!children.isEmpty()) {
            Iterator it = children.iterator();
            while (it.hasNext()) {
                Element e = (Element) it.next();
                String name = e.getName();
                String value = e.getTextNormalize();
                List list = e.getChildren();
                sb.append("<" + name + ">");
                if (!list.isEmpty()) {
                    sb.append(getChildrenText(list));
                }
                sb.append(value);
                sb.append("</" + name + ">");
            }
        }

        return sb.toString();
    }
    
    /**
     * 解析xml,返回第一级元素键值对。如果第一级元素有子节点，则此节点的值是子节点的xml数据。
     *
     * @param strxml
     * @return
     * @throws org.jdom.JDOMException
     * @throws IOException
     */
    @SuppressWarnings("rawtypes")
	public static SortedMap<String,Object> convertMap2SortedMap(String strxml){
        strxml = strxml.replaceFirst("encoding=\".*\"", "encoding=\"UTF-8\"");

        if (null == strxml || "".equals(strxml)) {
            return null;
        }

        SortedMap<String, Object> m = new TreeMap<String, Object>();
        InputStream in = null;
		try {
			in = new ByteArrayInputStream(strxml.getBytes("UTF-8"));
		    SAXBuilder builder = new SAXBuilder();
		    Document doc = builder.build(in);
		    Element root = doc.getRootElement();
		    List list = root.getChildren();
		    Iterator it = list.iterator();
		    while (it.hasNext()) {
		        Element e = (Element) it.next();
		        String k = e.getName();
		        String v = "";
		        List children = e.getChildren();
		        if (children.isEmpty()) {
		            v = e.getTextNormalize();
		        } else {
		            v = getChildrenText(children);
		        }
		
		        m.put(k, v);
		    }
		} catch (Exception e) {
			LogTool.error(SignVerifyTool.class, e);
		} finally {
			if (in != null) {
				//关闭流
				try {
					in.close();
				} catch (IOException e) {
					LogTool.error(SignVerifyTool.class, e);
				}
			}
		}

        return m;
    }
	/**
	 * 	<xml>
			<billId>200631898</billId>
			<channel>1E1FF6B9FE5671584CB4DC1A47E3E6D8</channel>
			<orderTime>2015-08-17 16:25:00</orderTime>
			<partner>1220341801</partner>
			<payAmount>1</payAmount>
			<payBank>wechat</payBank>
			<payResult>1</payResult>
			<payTime>2015-08-17 16:25:00</payTime>
			<payerTradeNo>1234567890</payerTradeNo>
			<tradeNo>200631898</tradeNo>
			<sign>7784F809E3EA5A123861E977D9AF0DEB</sign>
		</xml>
	
	 */
    @SuppressWarnings("rawtypes")
	public static String createSign2(String characterEncoding,
			SortedMap<String, Object> parameters, String api_key) {
		StringBuffer sb = new StringBuffer();
		Set es = parameters.entrySet();
		Iterator it = es.iterator();
		while (it.hasNext()) {
			Map.Entry entry = (Map.Entry) it.next();
			String k = (String) entry.getKey();
			Object v = entry.getValue();
			if (null != v && !"".equals(v) && !"sign".equals(k)
					&& !"key".equals(k)) {
				sb.append(k + "=" + v + "&");
			}
		}
		sb.append("key=" + api_key);
		String sign = MD5Util.MD5Encode(sb.toString(), characterEncoding).toUpperCase();
		return sign;
	}

	/**
	 * 签名校验
	 * 
	 * @return
	 * @throws UnsupportedEncodingException
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static boolean verifyPaySign(SortedMap paras, String key, String sign) {
		String paySign = createSign2("UTF-8", paras, key);
		LogTool.info(SignVerifyTool.class, paySign);
		LogTool.info(SignVerifyTool.class, sign);
		// 电销交互去除验签，sign=8085468D4B8CA07A0E2064F6D48837D8
		if (paySign.equalsIgnoreCase(sign)) {
			return true;
		} else {
			return false;
		}
	}
}

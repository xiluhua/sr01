package com.taiping.facility.tool;

public class KeyTool {

	public static String get(Class<?> clazz,Object columns){
		StringBuilder builder = new StringBuilder();
		builder.append(clazz.getSimpleName());
		builder.append(":");
		builder.append(String.valueOf(columns));
		return builder.toString();
	}
	
	public static String getByVer(Class<?> clazz,Object columns,int version){
		StringBuilder builder = new StringBuilder();
		builder.append(clazz.getSimpleName());
		builder.append("-"+version);
		builder.append(":");
		builder.append(String.valueOf(columns));
		return builder.toString();
	}
	
	
	public  static String getPattern(Class<?> clazz, String partnerApplyId){
		String key = clazz.getSimpleName()+"*"+partnerApplyId;
		return key;
	}

}

package com.taiping.facility.tool;

import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

/**
 * 投保工具类
 * @author amo
 * CreateDate:May 2, 2012
 */
public class InsureTool {
	
	/**
	 * 计算保障终止日期
	 */
	@Deprecated
	public static Date calcExpirationDate(Date validDate, int coverageType,
			int coverageYear, int insuredAge) {
		// 定义局部变量
		Date expirationDate = new Date();  // 保障终止日期
		
		// 计算保障终止日期
		if (coverageType == 1) {	    //终身
			try {
				expirationDate = DateTool.getDate("9999-09-09");
			} catch (ParseException e) {
				LogTool.error(InsureTool.class, e);
			}
		} else if (coverageType == 2) {	//保多少年
			expirationDate = DateTool.getDateAdd(DateTool.getPreviousDay(
					validDate, 1), Calendar.MONTH, coverageYear * 12);
		} else if (coverageType == 3) {	//保至多少岁
			expirationDate = DateTool.getDateAdd(DateTool.getPreviousDay(
					validDate, 1), Calendar.MONTH, (coverageYear - insuredAge) * 12);
		} else if (coverageType == 4) {	//保多少月
			expirationDate = DateTool.getDateAdd(DateTool.getPreviousDay(
					validDate, 1), Calendar.MONTH, coverageYear);
		} else if (coverageType == 5) {	//保多少天
			expirationDate = DateTool.getNextDay(DateTool.getPreviousDay(
					validDate, 1), coverageYear);
		}
		
		// 返回保障终止日期
		return expirationDate;
	}
	
	public static Date calcExpirationDate(Date validDate, Date insuredBirthday,
			int coverageType, int coverageYear) {
		// 定义输入输出参数
		Date expirationDate = new Date();  // 保障终止日期
		
		if (coverageType == 1) {	     // 终身
			try {
				expirationDate = DateTool.getDate("9999-09-09");
			} catch (ParseException e) {
				LogTool.error(InsureTool.class, e);
			}
		} else if (coverageType == 2) {	 // 保多少年
			expirationDate = DateTool.add(DateTool.getPreviousDay(validDate, 1), Calendar.YEAR, coverageYear);
		} else if (coverageType == 3) {  // 保至多少岁
			expirationDate = DateTool.add(DateTool.getPreviousDay(insuredBirthday, 1), Calendar.YEAR, coverageYear + 1);
		} else if (coverageType == 4) {  // 保多少月
			expirationDate = DateTool.getDateAdd(DateTool.getPreviousDay(validDate, 1), Calendar.MONTH, coverageYear);
		} else if (coverageType == 5) {  // 保多少天
			// expirationDate = DateTool.getNextDay(validDate, coverageYear);
			expirationDate = DateTool.getNextDay(DateTool.getPreviousDay(validDate, 1), coverageYear);
		}
		
		return expirationDate;
	}
	
	public static Date calcExpirationDate2(Date validDate, Date insuredBirthday,
			int coverageType, int coverageYear) {
		// 定义输入输出参数
		Date expirationDate = new Date();  // 保障终止日期
		
		if (coverageType == 1) {	     // 终身
			try {
				expirationDate = DateTool.getDate("9999-09-09");
			} catch (ParseException e) {
				LogTool.error(InsureTool.class, e);
			}
		} else if (coverageType == 2) {	 // 保多少年
			expirationDate = DateTool.add(DateTool.getPreviousDay(validDate, 1), Calendar.YEAR, coverageYear);
		} else if (coverageType == 3) {  // 保至多少岁
			expirationDate = DateTool.add(DateTool.getPreviousDay(insuredBirthday, 1), Calendar.YEAR, coverageYear + 1);
		} else if (coverageType == 4) {  // 保多少月
			expirationDate = DateTool.getDateAdd(DateTool.getPreviousDay(validDate, 1), Calendar.MONTH, coverageYear);
		} else if (coverageType == 5) {  // 保多少天
			 expirationDate = DateTool.getNextDay(validDate, coverageYear);
		}
		
		return expirationDate;
	}
	
	
	/*根据身份证 获得生日 年-月-日 */
	public static  Date getBirthdayFromIdCard(String idCard){
		 Date birth = null;
		 
		try{
		     int idCardLength = idCard.length();
		     String bir = "";
		   	 if(idCardLength == 18){
		   		bir = idCard.substring(6,10)+"-"+idCard.substring(10,12)+"-"+idCard.substring(12,14);
		   	 }else  if(idCardLength == 15){
		   		bir = "19"+idCard.substring(6,8)+"-"+idCard.substring(8,10)+"-"+idCard.substring(10,12);
		   	 }
		   	 birth =  DateTool.getDateTime(bir, "yyyy-MM-dd");
		}catch (Exception e) {
			e.printStackTrace();
		}
	   	 return birth;
	}


	/*根据身份证 获得性别 2是女性，1是男性*/
	public static String  getSexFromIdCard(String idCard){
		int idCardLength = idCard.length();
		String sex = "";
	   	 if(idCardLength == 18){
	    	  sex = idCard.substring(16,17);
	   	 }else  if(idCardLength == 15){
	    	  sex = idCard.substring(14,15);
	   	 }
	   	Integer sexInt =Integer.parseInt(sex)%2;
	    //偶数是女性 奇数是男性			     
	   	if(sexInt == 0){                                          
	      sex = "2";
	   	}else{
	   	  sex = "1";
	    }
	    return sex;
	}

	
	
    /*支付宝证件类型映射网销证件类型*/
	public static String getWXIdTypeForAlipay(String alipayIdType){
		String wxIdtype = null;   //1.A.身份证|2.B.军人证|3.C.护照|4.D.出生证|9.E.其他
		
//		支付宝 特有IDTYPE：
//		800	ALI_SOCIAL_SECURITY_CARD	身份证；生日日期必须与身份证号码中的出生年月日信息保持一致
//		801	ALI_STUDENT_CARD	学生证
//		802	ALI_DRIVERS_LICENCE	驾驶证
//		803	ALI_HOUSE_CARD	户口本
//		804	ALI_BIRTH_CARD	出生证
//		17	OLI_GOVTID_PASSPORTID	护照
//		21	OLI_GOVTID_CHINAMIL	军官证
//		999	OLI_OTHER	其他
		
		if(alipayIdType != null && !"".equals(alipayIdType)){  

			if("800".equals(alipayIdType)){
				wxIdtype = "1";
			}else if("17".equals(alipayIdType)){
				wxIdtype = "3";
			}else if(("804").equals(alipayIdType)){
				wxIdtype = "4";
			}else{
				wxIdtype = "9";
			}
		}else{
			wxIdtype = "9";
		}
		
		return wxIdtype;
	}
	
	/**
	 * 获得用户真实IP 防止代理IP
	 * @param request
	 * @return
	 */
	public static String getRequestIPAddr(HttpServletRequest request) {
		// String ip = request.getHeader("x-forwarded-for");
		// if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)){
		// ip = request.getHeader("Proxy-Client-IP");
		// }
		// if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)){
		// ip = request.getHeader("WL-Proxy-Client-IP");
		// }
		// if(ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)){
		// ip = request.getRemoteAddr();
		// }
		// return ip;
		String ipAddress = null;
		// ipAddress = this.getRequest().getRemoteAddr();
		ipAddress = request.getHeader("x-forwarded-for");
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("Proxy-Client-IP");
		}
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ipAddress == null || ipAddress.length() == 0
				|| "unknown".equalsIgnoreCase(ipAddress)) {
			ipAddress = request.getRemoteAddr();
			if (ipAddress.equals("127.0.0.1")) {
				// 根据网卡取本机配置的IP
				InetAddress inet = null;
				try {
					inet = InetAddress.getLocalHost();
				} catch (UnknownHostException e) {
					e.printStackTrace();
				}
				ipAddress = inet.getHostAddress();
			}

		}

		// 对于通过多个代理的情况，第一个IP为客户端真实IP,多个IP按照','分割
		if (ipAddress != null && ipAddress.length() > 15) { // "***.***.***.***".length()
															// = 15
			if (ipAddress.indexOf(",") > 0) {
				ipAddress = ipAddress.substring(0, ipAddress.indexOf(","));
			}
		}
		return ipAddress;
	}
	
	public static String getMyIPAddr() throws UnknownHostException {
		String ip = "";
		try {
			Enumeration<?> e1 = (Enumeration<?>) NetworkInterface
					.getNetworkInterfaces();
			while (e1.hasMoreElements()) {
				NetworkInterface ni = (NetworkInterface) e1.nextElement();
				if (!ni.getName().equals("eth0")) {
					continue;
				} else {
					Enumeration<?> e2 = ni.getInetAddresses();
					while (e2.hasMoreElements()) {
						InetAddress ia = (InetAddress) e2.nextElement();
						if (ia instanceof Inet6Address)
							continue;
						ip = ia.getHostAddress();
					}
					break;
				}
			}
		} catch (SocketException e) {
			e.printStackTrace();
			System.exit(-1);
		}
		return ip;
	}
	
	/**
     * <li>功能描述：时间相减得到天数
     * @param beginDateStr yyyy-MM-dd
     * @param endDateStr yyyy-MM-dd
     * @return
     * long 
     * @author Administrator
     */
    public static long getDaySub(String beginDateStr,String endDateStr)
    {
        long day=0;
        java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd");    
        java.util.Date beginDate;
        java.util.Date endDate;
        try
        {
            beginDate = format.parse(beginDateStr);
            endDate= format.parse(endDateStr);    
            day=(endDate.getTime()-beginDate.getTime())/(24*60*60*1000);    
            //System.out.println("相隔的天数="+day);   
        } catch (ParseException e)
        {
            // TODO 自动生成 catch 块
            e.printStackTrace();
        }   
        return day;
    }
    
}

package com.taiping.facility.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 *<p>Description : 字典类</p>
 *<p>Date        : Jun 3, 2013</p>
 *<p>Remark      : </p>
 * @version  
 */
@JsonIgnoreProperties(ignoreUnknown = true) 
public class DictItems implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -3872869689092575434L;
	/**
	 * 
	 */
	private String dictCode;
	private String dictName;
	private List<DictItem> items=new ArrayList<DictItem>();
	public List<DictItem> getItems() {
		return items;
	}
	public void setItems(List<DictItem> items) {
		this.items = items;
	}
	public void addItem(DictItem item){
		this.items.add(item);
	}
	public DictItem getItemByValue(String value){
		DictItem dicItem=new DictItem();
		for(DictItem item:items){
			if(item.getValue().equalsIgnoreCase(value)){
				dicItem= item;
				break;
			}
		}
		return dicItem;	
	}
	public DictItem getItemByCoreValue(String value){
		DictItem dicItem=new DictItem();
		for(DictItem item:items){
			if(item.getCoreValue()!=null&&item.getCoreValue().equals(value)){
				dicItem= item;
				break;
			}
		}
		return dicItem;	
	}
	
	public DictItem getItemByCode(String code){
		DictItem dicItem=new DictItem();
		for(DictItem item:items){
			if(item.getCode().equals(code)){
				dicItem= item;
				break;
			}
		}
		return dicItem;	
	}
	public String getDictCode() {
		return dictCode;
	}
	public void setDictCode(String dictCode) {
		this.dictCode = dictCode;
	}
	public String getDictName() {
		return dictName;
	}
	public void setDictName(String dictName) {
		this.dictName = dictName;
	}
	
	
}

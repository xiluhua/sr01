package com.taiping.facility.redis;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.jinfu.constant.Env;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisSentinelPool;
import redis.clients.jedis.exceptions.JedisConnectionException;
import redis.clients.jedis.exceptions.JedisDataException;

public class JedisClient2 {
	
	private static int index = 15;
	public static JedisSentinelPool pool = null;
	
	static{
		// 设置访问的库
		index = Integer.valueOf(PropertyFileTool.get("redis.core2.index"));
		Set<String> sentinels = new HashSet<String>();//sentinel各节点地址
        String hostAndPort1 = PropertyFileTool.get("redis.url.core2.1");
        String hostAndPort2 = PropertyFileTool.get("redis.url.core2.2");
        String hostAndPort3 = PropertyFileTool.get("redis.url.core2.3");
        sentinels.add(hostAndPort1);
        sentinels.add(hostAndPort2);
        // UAT 是2台机器，FORMAL 是3台
        if (Env.isFormal) {
        	sentinels.add(hostAndPort3);
		}
        String sentinelName = PropertyFileTool.get("redis.url.core2.username");//用户名
        String password 	= PropertyFileTool.get("redis.url.core2.password");//密码
		
        JedisPoolConfig config = new JedisPoolConfig();
        //设置最大连接总数
        config.setMaxTotal(100);
        //设置最大空闲数
        config.setMaxIdle(30);
        //设置最小空闲数
        config.setMinIdle(8);
        //设置最大等待时间
        config.setMaxWaitMillis(5*1000);
        //在获取连接的时候检查有效性, 默认false
        config.setTestOnBorrow(false);
        //在空闲时检查有效性, 默认false
        config.setTestOnReturn(false);
        //是否启用pool的jmx管理功能, 默认true
        config.setJmxEnabled(true);
        //Idle时进行连接扫描
        config.setTestWhileIdle(true);
        //是否启用后进先出, 默认true
        config.setLifo(true);
        //逐出扫描的时间间隔(毫秒) 如果为负数,则不运行逐出线程, 默认-1
        //config.setTimeBetweenEvictionRunsMillis(-1);
        //每次逐出检查时 逐出的最大数目 如果为负数就是 : 1/abs(n), 默认3
        //config.setNumTestsPerEvictionRun(10);
        //表示一个对象至少停留在idle状态的最短时间，然后才能被idle object evitor扫描并驱逐；这一项只有在timeBetweenEvictionRunsMillis大于0时才有意义
        //config.setMinEvictableIdleTimeMillis(60000);
        //连接耗尽时是否阻塞, false报异常,ture阻塞直到超时, 默认true
        config.setBlockWhenExhausted(true);
        //对象空闲多久后逐出, 当空闲时间>该值 且 空闲连接>最大空闲数 时直接逐出,不再根据MinEvictableIdleTimeMillis判断  (默认逐出策略)
        //config.setSoftMinEvictableIdleTimeMillis(1800000);
        
        pool = new JedisSentinelPool(sentinelName,sentinels,config,password);//连接池
        
		LogTool.debug(JedisClient2.class, "=== JedisClient2 init:"+pool+" ===");
		LogTool.debug(JedisClient2.class, "=== JedisClient2 index:"+index+" ===");
	}
	
	/**
	 * Handle jedisException, write log and return whether the connection is broken.
	 * @author xilh
	 * @since 20180325
	 * {@docRoot https://blog.csdn.net/erica_1230/article/details/72795128}
	 */
	public static boolean handleJedisException(Exception jedisException) {
	    if (jedisException instanceof JedisConnectionException) {
	        LogTool.error(JedisClient2.class, "Redis connection lost.");
	    } else if (jedisException instanceof JedisDataException) {
	        if ((jedisException.getMessage() != null) && (jedisException.getMessage().indexOf("READONLY") != -1)) {
	        	LogTool.error(JedisClient2.class, "Redis connection  are read-only slave.");
	        } else {
	            // dataException, isBroken=false
	            return false;
	        }
	    } else {
	    	LogTool.error(JedisClient2.class, "Jedis exception happen.");
	    }
	    return true;
	}
	
	/**
	 * Return jedis connection to the pool, call different return methods depends on the conectionBroken status.
	 * @author xilh
	 * @since 20180325
	 * {@docRoot https://blog.csdn.net/erica_1230/article/details/72795128}
	 */
	public static void closeResource(Jedis jedis, boolean conectionBroken) {
		if (jedis == null) {
			return;
		}
	    try {
	        if (conectionBroken) {
	            pool.returnBrokenResource(jedis);
	        } else {
	        	pool.returnResource(jedis);
	        }
	    } catch (Exception e) {
	    	LogTool.error(JedisClient2.class, "return back jedis failed, will fore close the jedis.");
	    	pool.returnResource(jedis);
	    }
	}
	
	// -----------------------------------------------------------------------------------------------------
	// ------------------------------------------------ api ------------------------------------------------
	// -----------------------------------------------------------------------------------------------------
	public static byte[] get(byte[] bytes){
		Jedis client = null;
		byte[] value = null;
		boolean conectionBroken = false;
	    try {
	    	LogTool.debug(JedisClient2.class, "redis database index: "+index);
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	value = client.get(bytes);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return value;
	}
	
	public static String get(String bytes){
		Jedis client = null;
		String value = null;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	value = client.get(bytes);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return value;
	}
	
	/**
	 * added by xiluhua
	 * 增加业务幂等性验证
	 */
	public static boolean isExist(String key){
		Jedis client = null;
		boolean isExist = false;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	// 如果数据存在则返回0，不存在返回1
	    	if (client.setnx(key,key) == 0) {
				return true;
			}
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
			return false;
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return isExist;
	}
	
	public static boolean isCachedInited(String bytes){
		Jedis client = null;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	String value = client.get(bytes);
	    	
	    	if (StringUtils.isEmpty(value)) {
	    		LogTool.debug(JedisClient2.class, "isCachedInited："+value);
				return false;
			}else {
				LogTool.debug(JedisClient2.class, "isCachedInited："+true);
			}
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return true;
	}
	
	public static void set(byte[] bytes,byte[] valuebytes){
		Jedis client = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			client.set(bytes,valuebytes);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
	}
	
	public static void set(String key,String value){
		Jedis client = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			client.set(key,value);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
	}
	
	public static void del(String... key){
		Jedis client = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			client.del(key);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
	}
	
	public static long llen(byte[] bytes){
		Jedis client = null;
		long size = 0;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			size = client.llen(bytes);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return size;
	}
	
	public static long llen(String bytes){
		Jedis client = null;
		long size = 0;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			size = client.llen(bytes);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return size;
	}
	
	public static long rpush(byte[] bytes,byte[] bytesValue){
		Jedis client = null;
		long value = 0;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	value = client.rpush(bytes, bytesValue);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return value;
	}
	
	public static long rpush(String key,String string){
		Jedis client = null;
		long value = 0;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	value = client.rpush(key, string);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return value;
	}
	
	public static byte[] lpop(byte[] bytes){
		Jedis client = null;
		byte[] bytesValue = null;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	bytesValue = client.lpop(bytes);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return bytesValue;
	}
	
	public static String lpop(String key){
		Jedis client = null;
		String bytesValue = null;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	bytesValue = client.lpop(key);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return bytesValue;
	}
	
	public static Set<String> keys(String pattern){
		Jedis client = null;
		Set<String> set = null;
		boolean conectionBroken = false;
	    try {
	    	client = pool.getResource();
	    	client.select(index);//选择redis库号---不指定库号，默认存入到0号库
	    	set = client.keys(pattern);
	    } catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return set;
	}
	
	public static Set<String> sdiff(String ... keys){
		Jedis client = null;
		Set<String> set = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			set = client.sdiff(keys);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return set;
	}
	
	/**
	 * @author xilh
	 * @since 20170725
	 * @param key
	 * @param field
	 * @param value
	 * @return
	 */
	public static Long hset(String key,String field,String value){
		Jedis client = null;
		Long bytesValue = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			bytesValue = client.hset(key,field,value);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return bytesValue;
	}
	
	/**
	 * @author xilh
	 * @since 20170725
	 * @param key
	 * @param field
	 * @param value
	 * @return
	 */
	public static Set<String> hkeys(String key){
		Jedis client = null;
		Set<String> set = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			set = client.hkeys(key);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		
		return set;
	}
	
	// -----------------------------------------------------------------------------------------------------
	// ------------------------------------------------ main -----------------------------------------------
	// -----------------------------------------------------------------------------------------------------
	public static void redis_pool(){
		boolean conectionBroken = false;
		Set<String> sentinels = new HashSet<String>();//sentinel各节点地址
        String hostAndPort1 = "10.1.14.19:26379";
        String hostAndPort2 = "10.1.14.18:26379";
        String hostAndPort3 = "10.1.14.17:26379";
        sentinels.add(hostAndPort1);
        sentinels.add(hostAndPort2);
        sentinels.add(hostAndPort3);
        String sentinelName = "mymaster";//用户名
        String password = "taiping123";//密码

        JedisPoolConfig config = new JedisPoolConfig();
        //设置最大连接总数
        config.setMaxTotal(100);
        //设置最大空闲数
        config.setMaxIdle(30);
        //设置最小空闲数
        config.setMinIdle(8);
        
        JedisSentinelPool pool = new JedisSentinelPool(sentinelName,sentinels,config,password);//连接池
		// 在业务操作时，从连接池获取连接
		Jedis client = null;
		try {
		    // 执行指令
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
		    String result = client.set("key-string", "Hello, Redis pool!");
		    System.out.println( String.format("set指令执行结果:%s", result) );
		    String value = client.get("key-string");
		    System.out.println( String.format("get指令执行结果:%s", value) );
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
		    LogTool.error(JedisClient2.class, e);
		} finally {
			try {
		        if (conectionBroken) {
		            pool.returnBrokenResource(client);
		        } else {
		        	pool.returnResource(client);
		        }
		    } catch (Exception e) {
		    	LogTool.error(JedisClient2.class, "return back jedis failed, will fore close the jedis.");
		    	pool.returnResource(client);
		    }
		}

		// 应用关闭时，释放连接池资源
		pool.destroy();
	}
	
	/**
	 * anti-shortmsg attack
	 * @author xilh
	 * @since 20180627
	 * @param key
	 * @param seconds
	 * @param value
	 */
	public static void setex(String key, int seconds, String value){
		Jedis client = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			client.setex(key, seconds, value);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient_outer2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
	}
	
	/**
	 * anti-shortmsg attack
	 * @author xilh
	 * @since 20180627
	 * @param key
	 * @param seconds
	 * @param value
	 */
	public static long ttl(String key){
		Jedis client = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			return client.ttl(key);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient_outer2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return -1;
	}
	
	/**
	 * sequence from redis
	 * @author xilh
	 * @since 20190226
	 * @param key
	 * @param value
	 */
	public static Long incr(String key){
		Long seq = null;
		Jedis client = null;
		boolean conectionBroken = false;
		try {
			client = pool.getResource();
			client.select(index);//选择redis库号---不指定库号，默认存入到0号库
			seq = client.incr(key);
		} catch (Exception e) {
			conectionBroken = handleJedisException(e);
			LogTool.error(JedisClient_outer2.class, e);
		}finally{
			// 业务操作完成，将连接返回给连接池
			closeResource(client, conectionBroken);
		}
		return seq;
	}
	
	public static void set(Map<Object, String> map){
		for (Map.Entry<Object, String> entry : map.entrySet()) {
			JedisClient2.set(entry.getKey().toString(), entry.getValue());
	    }
	}
	
	public static void del(Map<Object, String> map){
		for (Map.Entry<Object, String> entry : map.entrySet()) {
			JedisClient2.del(entry.getKey().toString());
	    }
	}
	
	public static void main(String[] args) {
		JedisClient2.redis_pool();
	}
}

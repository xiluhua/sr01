//package com.taiping.facility.action;
//
//import java.io.IOException;
//import java.util.Date;
//
//import javax.annotation.Resource;
//import javax.servlet.http.HttpServletRequest;
//import javax.servlet.http.HttpServletResponse;
//import javax.xml.ws.Action;
//
//import org.apache.commons.lang3.StringUtils;
//import org.apache.velocity.VelocityContext;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.taiping.dianshang.constant.ConstantTool;
//import com.taiping.dianshang.core.rest.impl.RestImpl_PayNotify;
//import com.taiping.facility.mock.MockService;
//import com.taiping.facility.tool.DateTool;
//import com.taiping.facility.tool.IOTool;
//import com.taiping.facility.tool.LogTool;
//import com.taiping.facility.tool.TemplateToolV1218;
//import com.taiping.jinfu.action.BaseAction;
//import com.taiping.jinfu.constant.Cons;
//import com.taiping.jinfu.core.model.Busi;
//import com.taiping.jinfu.core.service.policyPdfUrl.sub.impl.PolicyPdfUrlCoreImpl_4;
//import com.taiping.jinfu.entity.IpayRegister;
//import com.taiping.jinfu.entity.IpayRegisterTemplateCode;
//import com.taiping.jinfu.entity.IspApply;
//import com.taiping.jinfu.entity.IspPolicy;
//import com.taiping.jinfu.service.validSqlInject.AntiSqlInjectService;
//
//@Controller
//@RequestMapping(value = "/mock")
//public class MockAction extends BaseAction {
//	
//	/**
//	 * 缓存查询，用于查看缓存是否已更新到系统
//	 */
//	private static final long serialVersionUID = 5849260213064898322L;
//
//	@Resource
//	RestImpl_PayNotify restImpl_PayNotify;
//	@Resource
//	AntiSqlInjectService antiSqlInjectService;
//	@Resource
//	MockService mockService;
//	@Resource
//	PolicyPdfUrlCoreImpl_4 policyPdfUrlCoreImpl_4;
//
//	/**
//	 * mack payNofy wothout pay, actually
//	 * localhost: http://localhost:7788/taiping-dianshang-core/mock/payNotify.action?billId=975978&isCheckBillBySelf=1
//	 * uat		: http://10.1.118.45:8002/mock/payNotify.action?billId=670248
//     * uat		: http://baoxian.itaiping.com/mock/payNotify.action?billId=670248&isCheckBillBySelf=1
//	 * @author xilh
//	 * @since 20180325
//	 * @param billId
//	 * @param isCheckBillBySelf "if 'isCheckBillBySelf' is null, the request will send an callBack to the partner client to trigger checkBill business, otherwise it don't"
//	 * @throws IOException 
//	 */
//	@ResponseBody
//	@RequestMapping(value = "/payNotify.action")
//	public void data(HttpServletRequest request, HttpServletResponse response) throws IOException {
//		String flag = SUCCESS;
//		try {
//			String billId = request.getParameter("billId");
//			String isCheckBillBySelf = request.getParameter("isCheckBillBySelf");
//			antiSqlInjectService.verify(billId + "," + isCheckBillBySelf);
//			
//			IpayRegister payRegister = mockService.getPayRegisterForCallback(Long.valueOf(billId));
//			if (payRegister == null) {
//				flag = ERROR+".1";
//				return;
//			}
//			
//			IspApply apply = mockService.getApply(payRegister.getApplyId());
//			if (apply == null) {
//				flag = ERROR+".2";
//				return;
//			}
//			
//			IpayRegisterTemplateCode prtc = mockService.getFirstRegisterTemplateCode4Test(apply.getPartnerId(), apply.getSellChannel());
//			if (prtc == null) {
//				flag = ERROR+".3";
//				return;
//			}
//			
//			LogTool.info(this.getClass(), "===========================================================================");
//			LogTool.info(this.getClass(), "billId:"+ billId);
//			String path = MockAction.class.getResource("/template/pay/payNotify-request.xml").getPath();
//			String requestMsg = IOTool.readFile(path, Cons.UTF8);  //请确认编码方式
//			
//			String date = DateTool.getDateTime(DateTool.DATE_TIME_MASK, new Date());
//			VelocityContext context = new VelocityContext();
//			context.put("billId", billId);
//			context.put("date", date);
//			context.put("premium", payRegister.getPremium());
//			context.put("prtc", prtc);
//			if (!StringUtils.isEmpty(isCheckBillBySelf)) {
//				context.put("isCheckBillBySelf", "iCheckBill");
//			}
//			requestMsg = TemplateToolV1218.fill(context, requestMsg);
//			
//			restImpl_PayNotify.entrance(requestMsg);
//		} catch (Exception e) {
//			LogTool.error(this.getClass(), e);
//		} finally {
//			response.getWriter().write(flag);
//		}
//	}
//	
////	/**
////	 * http://localhost:7788/taiping-dianshang-core/mock/synPolicyPdf.action?policyNo=8C2012206201800000000558
////	 * @author xilh
////	 * @since 20180104
////	 */
////	@Action(value = "synPolicyPdf")
////	public void synPolicyPdf() throws IOException {
////		String flag = SUCCESS;
////		String policyNo = getRequest().getParameter("policyNo");
////		try {
////			IspApply apply = mockService.getApply(policyNo);
////			if (apply == null) {
////				flag = ERROR+".1";
////				return;
////			}
////			
////			IspPolicy policy = mockService.getPolicy(policyNo);
////			if (policy == null) {
////				flag = ERROR+".2";
////				return;
////			}
////			Busi busi = new Busi();
////			busi.setBusiId(apply.getPartnerApplyId());
////			busi.setApply(apply);
////			busi.setPolicy(policy);
////			busi.setServiceCode(ConstantTool.POLICY_PDF_URL);
////			
////			policyPdfUrlCoreImpl_4.handleCore(busi);
////		} catch (Exception e) {
////			LogTool.error(this.getClass(), e);
////		} finally {
////			getResponse().getWriter().write(flag);
////		}
////	}
//	
//}

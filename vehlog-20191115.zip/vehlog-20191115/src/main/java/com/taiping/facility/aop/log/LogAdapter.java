//package com.taiping.facility.aop.log;
//
//import com.taiping.jinfu.core.model.Busi;
//import com.taiping.jinfu.entity.IspApply;
//import com.taiping.jinfu.entity.IspCardApply;
//
//public class LogAdapter {
//
//	public static void convertCardApply2Apply(Busi busi,IspCardApply cardApply){
//		// 日志
//		IspApply apply4log = new IspApply();
//		apply4log.setPartnerApplyId(cardApply.getPartnerApplyId());
//		apply4log.setPartnerId(cardApply.getPartnerId());
//		apply4log.setBaleId(cardApply.getBaleId());
//		apply4log.setBlueId(cardApply.getBlueId());
//		if (null != cardApply.getBuyer()) {
//			apply4log.setHolder(cardApply.getBuyer());
//		}
//		apply4log.setPremium(cardApply.getTotalPrice());
//		apply4log.setApplyId(cardApply.getApplyId());
//		apply4log.setSellChannel(1);
//		busi.setApply(apply4log);
//	}
//	
//}

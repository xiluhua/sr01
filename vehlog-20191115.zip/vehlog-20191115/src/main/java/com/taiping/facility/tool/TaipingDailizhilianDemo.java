package com.taiping.facility.tool;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.params.HttpMethodParams;

/**
 * 太平代理直连JAVA版简易demo
 * @author xc.fujw
 *
 */
public class TaipingDailizhilianDemo {

	////////////////////////////MD5加密程序区/////////////////////////////
	/**
	 * Used building output as Hex
	 */
	private static final char[] DIGITS = { '0', '1', '2', '3', '4', '5', '6',
			'7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
	
	/**
	 * 检查校验MD5值，此方法会将key加到字符串最后
	 * @param text 文本内容
	 * @param sign 分隔符
	 * @param key  银行保险双方约定key值串
	 * @return md5值
	 */
	public static String checkMd5(String text,String key, String sign) {
		StringBuffer sb = new StringBuffer();
		String[] str = text.split(sign);
		//str[str.length-1] = key;		
		for (int i = 0;  i< str.length; i++) {
			str[i] = null==str[i]?"":str[i];
			sb.append(str[i]);
		}
		sb.append(key);
		return md5(sb.toString());
	}
	
	/**
	 * 对字符串进行MD5加密
	 * 
	 * @param text
	 *            明文
	 * 
	 * @return 密文
	 */
	public static String md5(String text) {
		MessageDigest msgDigest = null;
		try {
			msgDigest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(
					"System doesn't support MD5 algorithm.");
		}
		try {
			msgDigest.update(text.getBytes("GBK"));
		} catch (UnsupportedEncodingException e) {
			throw new IllegalStateException(
					"System doesn't support your  EncodingException.");
		}
		byte[] bytes = msgDigest.digest();
		String md5Str = new String(encodeHex(bytes));
		return md5Str;
	}
	
	public static String md5ByUTF8(String text) {
		MessageDigest msgDigest = null;
		try {
			msgDigest = MessageDigest.getInstance("MD5");
		} catch (NoSuchAlgorithmException e) {
			throw new IllegalStateException(
					"System doesn't support MD5 algorithm.");
		}
		try {
			msgDigest.update(text.getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			throw new IllegalStateException(
					"System doesn't support your  EncodingException.");
		}
		byte[] bytes = msgDigest.digest();
		String md5Str = new String(encodeHex(bytes));
		return md5Str;
	}
	public static char[] encodeHex(byte[] data) {
		int l = data.length;
		char[] out = new char[l << 1];
		// two characters form the hex value.
		for (int i = 0, j = 0; i < l; i++) {
			out[j++] = DIGITS[(0xF0 & data[i]) >>> 4];
			out[j++] = DIGITS[0x0F & data[i]];
		}
		return out;
	}
	
	////////////////////////////报送交易报文程序区/////////////////////////////
	// 使用POST方式提交表单数据  
	private static HttpMethod getPostMethod() throws UnsupportedEncodingException {  
	    // 测试地址
//		String url = "http://116.236.245.194/eservice/gp/servlet/PublicGpBatchOnlineServlet";  
//		String url = "http://localhost:8080/eservice/servlet/PublicGpBatchOnlineServlet";  
		String url = "http://10.1.14.43:7001/eservice/gp/servlet/PublicGpBatchOnlineServlet";  
	    
	    PostMethod post = new PostMethod(url);
	    // 投保报文样例
	    String requestXml =
	    	"<?xml version='1.0' encoding='GBK'?>\n" +
	    	"<REQUEST>\n" +
	    	"  <DIST>\n" +
	    	"    <DLBH>D0100600</DLBH>\n" +
	    	"    <TBBXDDH>fjwtest20160713001</TBBXDDH>\n" +
	    	"    <HBSSDDH></HBSSDDH>\n" +
	    	"  </DIST>\n" +
	    	"  <BUSI>\n" +
	    	"    <DZHM></DZHM>\n" +
	    	"    <TBRQ>20160713</TBRQ>\n" +
	    	"    <TBSJ>190615</TBSJ>\n" +
	    	"    <TBKHLX>1</TBKHLX>\n" +
	    	"    <COST_CENTER></COST_CENTER>\n" +
	    	"    <TELLER_INNER></TELLER_INNER>\n" +
	    	"    <INNER_NAME></INNER_NAME>\n" +
	    	"    <TBR>\n" +
	    	"      <TBRXM>wang</TBRXM>\n" +
	    	"      <TBRXB>2</TBRXB>\n" +
	    	"      <TBRSR>19970701</TBRSR>\n" +
	    	"      <TBRZJLX>1</TBRZJLX>\n" +
	    	"      <TBRZJH>150402198401300310</TBRZJH>\n" +
	    	"      <TBRSJH>13621290625</TBRSJH>\n" +
	    	"      <TBRYXDZ></TBRYXDZ>\n" +
	    	"      <TBRADDR></TBRADDR>\n" +
	    	"      <TBRTEL></TBRTEL>\n" +
	    	"    </TBR>\n" +
	    	"    <COMP>\n" +
	    	"      <DWMC>易云游网络技术(北京)有限公司</DWMC>\n" +
	    	"      <LXRMC></LXRMC>\n" +
	    	"      <LXRSJH></LXRSJH>\n" +
	    	"      <LXRDZYJ></LXRDZYJ>\n" +
	    	"    </COMP>\n" +
	    	"    <BBR>\n" +
	    	"      <BBXRXM>wang</BBXRXM>\n" +
	    	"      <BBXRXB>2</BBXRXB>\n" +
	    	"      <BBXRSR>19950101</BBXRSR>\n" +
	    	"      <SYRXM></SYRXM>\n" +
	    	"      <ZJLX>1</ZJLX>\n" +
	    	"      <BBXRZJH>13010119970701920X</BBXRZJH>\n" +
	    	"      <BBXRSJH></BBXRSJH>\n" +
	    	"      <BBXRYXDZ></BBXRYXDZ>\n" +
	    	"      <OCCUP></OCCUP>\n" +
	    	"      <BBXRADDR></BBXRADDR>\n" +
	    	"      <BBXRTEL></BBXRTEL>\n" +
	    	"      <BENE>\n" +
	    	"        <SYRXM></SYRXM>\n" +
	    	"      </BENE>\n" +
	    	"    </BBR>\n" +
	    	"    <TRIP>\n" +
	    	"      <HBH></HBH>\n" +
	    	"      <HBRQ></HBRQ>\n" +
	    	"      <LXMDD></LXMDD>\n" +
	    	"      <FCHBH></FCHBH>\n" +
	    	"      <FCHBRQ></FCHBRQ>\n" +
	    	"      <KPHM></KPHM>\n" +
	    	"      <CFD></CFD>\n" +
	    	"      <CGMD></CGMD>\n" +
	    	"    </TRIP>\n" +
	    	"    <PT>\n" +
	    	"      <XZDM>5</XZDM>\n" +
	    	"      <XZMC></XZMC>\n" +
	    	"      <TBSL>1</TBSL>\n" +
	    	"      <JSBF>100000</JSBF>\n" +
	    	"      <BXJE></BXJE>\n" +
	    	"      <BXZRQSSJ>20161230</BXZRQSSJ>\n" +
	    	"      <BXZRZZSJ>20161230</BXZRZZSJ>\n" +
	    	"      <JHDM>6000</JHDM>\n" +
	    	"      <CZDM>1</CZDM>\n" +
	    	"      <BDZT></BDZT>\n" +
	    	"      <ZJXSDM></ZJXSDM>\n" +
	    	"      <YWY></YWY>\n" +
	    	"    </PT>\n" +
	    	"    <HOUSE>\n" +
	    	"      <FDXM></FDXM>\n" +
	    	"      <FDZJHM></FDZJHM>\n" +
	    	"      <BBXFWZLDZ></BBXFWZLDZ>\n" +
	    	"      <BXQSSJ></BXQSSJ>\n" +
	    	"      <BXZZSJ></BXZZSJ>\n" +
	    	"    </HOUSE>\n" +
	    	"    <LOAN>\n" +
	    	"      <DEBTOR/>\n" +
	    	"      <NO></NO>\n" +
	    	"      <AMOUNT></AMOUNT>\n" +
	    	"      <BGN></BGN>\n" +
	    	"      <END></END>\n" +
	    	"      <ACCT/>\n" +
	    	"      <BANK_NAME></BANK_NAME>\n" +
	    	"    </LOAN>\n" +
	    	"    <PAY>\n" +
	    	"      <PLATTYPE></PLATTYPE>\n" +
	    	"      <TRADENO></TRADENO>\n" +
	    	"      <BUSINESSNAME></BUSINESSNAME>\n" +
	    	"      <BUSINESSID></BUSINESSID>\n" +
	    	"      <CARDBANK></CARDBANK>\n" +
	    	"      <CARDNO></CARDNO>\n" +
	    	"      <EFFECTIVEPERIOD></EFFECTIVEPERIOD>\n" +
	    	"      <CUSTACCOUNT></CUSTACCOUNT>\n" +
	    	"      <SYSTEMNO></SYSTEMNO>\n" +
	    	"      <TRADETYPE></TRADETYPE>\n" +
	    	"      <AMOUNT></AMOUNT>\n" +
	    	"      <OLDSERIALNO></OLDSERIALNO>\n" +
	    	"      <TRADEDATE></TRADEDATE>\n" +
	    	"      <ACCOUNTSTATUS></ACCOUNTSTATUS>\n" +
	    	"      <ACCOUNTCONFIRM></ACCOUNTCONFIRM>\n" +
	    	"      <NOTE></NOTE>\n" +
	    	"    </PAY>\n" +
	    	"  </BUSI>\n" +
	    	"</REQUEST>";
	    	
	    String path = TaipingDailizhilianDemo.class.getResource("/template/test/test-1101-1.xml").getPath();
		System.out.println("path : "+path);
	    requestXml = IOTool.readFile(path, "GBK");
	    System.out.println(requestXml);
	    	/*"<?xml version='1.0' encoding='GBK'?>\n" +
	    	"<PACKAGE>\n" + 
	    	"  <HEAD>\n" + 
	    	"    <DLBH>D0202100</DLBH>\n" + 
	    	"    <SUBJECT>1</SUBJECT>\n" + 
	    	"    <BATCH_NO>test101</BATCH_NO>\n" + 
	    	"    <COUNT>2</COUNT>\n" + 
	    	"  </HEAD>\n" + 
	    	"  <REQUEST>\n" + 
	    	"  <DIST>\n" + 
	    	"    <DLBH>D0202100</DLBH>\n" + 
	    	"    <HBSSDDH>fjw20160510111111</HBSSDDH>\n" + 
	    	"  </DIST>\n" + 
	    	"  <BUSI>\n" + 
	    	"    <DZHM/>\n" + 
	    	"    <TBRQ>20160510</TBRQ>\n" + 
	    	"    <TBSJ>150000</TBSJ>\n" + 
	    	"    <TBKHLX>1</TBKHLX>\n" + 
	    	"    <TBR>\n" + 
	    	"      <TBRXM>刘开放1</TBRXM>\n" + 
	    	"      <TBRSR>19940601</TBRSR>\n" + 
	    	"      <TBRXB>1</TBRXB>\n" + 
	    	"      <TBRZJH>341202199406010211</TBRZJH>\n" + 
	    	"      <TBRZJLX>1</TBRZJLX>\n" + 
	    	"      <TBRSJH>15010806346</TBRSJH>\n" + 
	    	"      <TBRYXDZ>ljjshyx@163.com</TBRYXDZ>\n" + 
	    	"      <TBRADDR>北京市市辖区丰台区新华街七里</TBRADDR>\n" + 
	    	"      <TBRTEL>15010806346</TBRTEL>\n" + 
	    	"    </TBR>\n" + 
	    	"    <COMP>\n" + 
	    	"      <DWMC>sssssssss</DWMC>\n" + 
	    	"      <LXRMC/>\n" + 
	    	"      <LXRSJH/>\n" + 
	    	"      <LXRDZYJ/>\n" + 
	    	"    </COMP>\n" + 
	    	"    <BBR>\n" + 
	    	"      <ZJLX>1</ZJLX>\n" + 
	    	"      <OCCUP>0504029</OCCUP>\n" + 
	    	"      <BENE>\n" + 
	    	"        <SYRXM>法定受益人</SYRXM>\n" + 
	    	"      </BENE>\n" + 
	    	"      <BBXRXM>刘开放1</BBXRXM>\n" + 
	    	"      <BBXRXB>1</BBXRXB>\n" + 
	    	"      <BBXRSR>19940601</BBXRSR>\n" + 
	    	"      <BBXRZJH>341202199406010211</BBXRZJH>\n" + 
	    	"      <BBXRSJH>18601242343</BBXRSJH>\n" + 
	    	"      <BBXRYXDZ>ljjshyx@163.com</BBXRYXDZ>\n" + 
	    	"      <BBXRADDR>北京市市辖区丰台区新华街七里</BBXRADDR>\n" + 
	    	"      <BBXRTEL>18601242343</BBXRTEL>\n" + 
	    	"    </BBR>\n" + 
	    	"    <TRIP>\n" + 
	    	"      <HBH/>\n" + 
	    	"      <HBRQ/>\n" + 
	    	"      <LXMDD/>\n" + 
	    	"    </TRIP>\n" + 
	    	"    <PT>\n" + 
	    	"      <XZDM>1</XZDM>\n" + 
	    	"      <XZMC></XZMC>\n" + 
	    	"      <TBSL>1</TBSL>\n" + 
	    	"      <JSBF>200</JSBF>\n" + 
	    	"      <BXJE/>\n" + 
	    	"      <BXZRQSSJ>20160510</BXZRQSSJ>\n" + 
	    	"      <BXZRZZSJ>20160513</BXZRZZSJ>\n" + 
	    	"      <JHDM>2100</JHDM>\n" + 
	    	"      <CZDM>5</CZDM>\n" + 
	    	"      <BDZT/>\n" + 
	    	"    </PT>\n" + 
	    	"  </BUSI>\n" + 
	    	"</REQUEST>\n" + 
	    	"  <REQUEST>\n" + 
	    	"  <DIST>\n" + 
	    	"    <DLBH>D0202100</DLBH>\n" + 
	    	"    <HBSSDDH>fjw2016051111112</HBSSDDH>\n" + 
	    	"  </DIST>\n" + 
	    	"  <BUSI>\n" + 
	    	"    <DZHM/>\n" + 
	    	"    <TBRQ>20160510</TBRQ>\n" + 
	    	"    <TBSJ>150000</TBSJ>\n" + 
	    	"    <TBKHLX>1</TBKHLX>\n" + 
	    	"    <TBR>\n" + 
	    	"      <TBRXM>刘开放2</TBRXM>\n" + 
	    	"      <TBRSR>19940601</TBRSR>\n" + 
	    	"      <TBRXB>1</TBRXB>\n" + 
	    	"      <TBRZJH>341202199406010211</TBRZJH>\n" + 
	    	"      <TBRZJLX>1</TBRZJLX>\n" + 
	    	"      <TBRSJH>15010806346</TBRSJH>\n" + 
	    	"      <TBRYXDZ>ljjshyx@163.com</TBRYXDZ>\n" + 
	    	"      <TBRADDR>北京市市辖区丰台区新华街七里</TBRADDR>\n" + 
	    	"      <TBRTEL>15010806346</TBRTEL>\n" + 
	    	"    </TBR>\n" + 
	    	"    <COMP>\n" + 
	    	"      <DWMC>sssssssss</DWMC>\n" + 
	    	"      <LXRMC/>\n" + 
	    	"      <LXRSJH/>\n" + 
	    	"      <LXRDZYJ/>\n" + 
	    	"    </COMP>\n" + 
	    	"    <BBR>\n" + 
	    	"      <ZJLX>1</ZJLX>\n" + 
	    	"      <OCCUP>0504029</OCCUP>\n" + 
	    	"      <BENE>\n" + 
	    	"        <SYRXM>法定受益人</SYRXM>\n" + 
	    	"      </BENE>\n" + 
	    	"      <BBXRXM>刘开放2</BBXRXM>\n" + 
	    	"      <BBXRXB>1</BBXRXB>\n" + 
	    	"      <BBXRSR>19940601</BBXRSR>\n" + 
	    	"      <BBXRZJH>341202199406010211</BBXRZJH>\n" + 
	    	"      <BBXRSJH>18601242343</BBXRSJH>\n" + 
	    	"      <BBXRYXDZ>ljjshyx@163.com</BBXRYXDZ>\n" + 
	    	"      <BBXRADDR>北京市市辖区丰台区新华街七里</BBXRADDR>\n" + 
	    	"      <BBXRTEL>18601242343</BBXRTEL>\n" + 
	    	"    </BBR>\n" + 
	    	"    <TRIP>\n" + 
	    	"      <HBH/>\n" + 
	    	"      <HBRQ/>\n" + 
	    	"      <LXMDD/>\n" + 
	    	"    </TRIP>\n" + 
	    	"    <PT>\n" + 
	    	"      <XZDM>1</XZDM>\n" + 
	    	"      <XZMC></XZMC>\n" + 
	    	"      <TBSL>1</TBSL>\n" + 
	    	"      <JSBF>200</JSBF>\n" + 
	    	"      <BXJE/>\n" + 
	    	"      <BXZRQSSJ>20160510</BXZRQSSJ>\n" + 
	    	"      <BXZRZZSJ>20160513</BXZRZZSJ>\n" + 
	    	"      <JHDM>2100</JHDM>\n" + 
	    	"      <CZDM>5</CZDM>\n" + 
	    	"      <BDZT/>\n" + 
	    	"    </PT>\n" + 
	    	"  </BUSI>\n" + 
	    	"</REQUEST>\n" + 
	    	"</PACKAGE>";*/

	    	
//	    NameValuePair message1 = new NameValuePair("dlbh", "A0203100");  //中介代码
	    NameValuePair message1 = new NameValuePair("dlbh", "D0100700");  //中介代码
	    NameValuePair message2 = new NameValuePair("xmlstr", requestXml);  //请求报文
	    
	    String key = "0851guwsdfc4713c76h784f6eoopp7nd";
//	    String key = "995k9s71muc2p87c7x9hg4f6e3xx97cs";
	    String hf_md5 = md5(requestXml + key);//MD5 = 加密(请求报文+key)
	    
	    NameValuePair message3 = new NameValuePair("md5", hf_md5);  //MD5值
	    post.setRequestBody(new NameValuePair[]{message1,message2,message3});  
	    post.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET,"gbk");  //编码GBK
	    return post;  
	}
	
	public static void main(String[] args) throws HttpException, IOException {
		// 
    	HttpClient client = new HttpClient();  
        // 使用POST方式提交数据  
        HttpMethod method = getPostMethod();  
        client.executeMethod(method);  
        // 打印服务器返回的状态  
        System.out.println(method.getStatusLine());  
        // 打印结果页面  
        String response = new String(method.getResponseBodyAsString());  
        // 打印返回的信息  
        System.out.println(response);  
        method.releaseConnection();  
	}
	
}

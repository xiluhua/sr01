package com.taiping.facility.config;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.taiping.facility.cache.impl.CacheImpl;
import com.taiping.facility.redis.JedisClient_outer2;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.PropertyFileTool;
import com.taiping.facility.tool.SerializeTool;
import com.taiping.facility.tool.SpringTool;
import com.taiping.jinfu.constant.Cons;
import com.taiping.jinfu.constant.Env;
import com.taiping.jinfu.entity.IlogBusinessOperateLog;
import com.taiping.jinfu.exception.TpRuntimeException;
import com.taiping.jinfu.log.pool.LogPool;
import com.taiping.jinfu.log.service.impl.LogClearImpl;

public class StartUpListener implements ServletContextListener {
	
	public void contextInitialized(ServletContextEvent event) {
		try {
			ServletContext servletContext 	= event.getServletContext();
			ApplicationContext ctx 			= WebApplicationContextUtils.getWebApplicationContext(servletContext);
			this.deduceEnv(ctx);
			// 1、初始化properties静态变量
			PropertyFileTool.init3(Env.DATABASE);
			
			// 2.初始化sprintTool
			SpringTool.setServletContext(servletContext);
			
			LogTool.info(StartUpListener.class,"===========================================================================");
			LogTool.debug(StartUpListener.class, "localIp:"+Env.localIp);
			
			CacheImpl cacheImpl = SpringTool.getSpringBean(CacheImpl.class);
			cacheImpl.refreshLogLevel();
			
			// 3,初始化日志写文件
			this.startUpClearLogs();
			// new redis
			this.startUp_add_busi();
			
		} catch (Exception e) {
			LogTool.info(StartUpListener.class,"===========================================================================");
			LogTool.info(StartUpListener.class,"======================== inited in failure ===================");
			LogTool.error(this.getClass(), e);
		}
	}

	/**
	 * 推断环境
	 * @author xilh
	 * @since 20190307
	 * @return
	 * @throws IOException
	 */
	private void deduceEnv(ApplicationContext ctx) throws IOException {
		LogTool.info(this.getClass(), "spring.profiles.active: "+Env.ENV);
		if (Env.ENV.equalsIgnoreCase(Cons.PROD) && !Env.isFormal) {
			LogTool.error(this.getClass(), new TpRuntimeException("Product database running in 'UAT' env is not permitted!!!  To fix the error, please set 'spring.profiles.active=dev'."));
			System.exit(0);
		}
		
		String tmp = ctx.getEnvironment().getProperty("db.driver");
		LogTool.info(this.getClass(), "=== deduceEnv from spring.profiles.active ===");
		LogTool.info(this.getClass(), "db.driver: "+tmp);
		
		if (tmp.indexOf(Cons.MYSQL) > -1) {
			Env.DATABASE = Cons.MYSQL;
		}else {
			Env.DATABASE = Cons.ORACLE;
		}
		LogTool.info(this.getClass(), "=== DATABASE: "+Env.DATABASE+" ===");
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * @author xilh
	 * @since 20191115
	 */
	private void startUpClearLogs(){
		new Thread() {
			public void run() {
				LogClearImpl logClearImpl = SpringTool.getSpringBean(LogClearImpl.class);
				logClearImpl.init();
			}
		}.start();
	}
	
	/**
	 * 异步取队列
	 * @author xilh
	 * @since 20191115
	 */
	private void startUp_add_busi(){
		
		int threadNum = 2;
		if (!Env.isFormal) {
			threadNum = 1;
		}
		
		for (int i = 0; i < threadNum; i++) {
			
			new Thread() {
				int max = 1000;
				
				public void run() {
					while(true){
						
						long length = JedisClient_outer2.llen(Cons.QUEUE_DS_BUSI_LOG.getBytes());
						// 所有队列长度总和为零的话，休眠2秒
						if (length == 0 || LogPool.dsBusiOpeLogQ.size() > max) {
							if (LogPool.dsBusiOpeLogQ.size() > max) {
								LogTool.warn(this.getClass(), "--- warning!!! LogPool.dsBusiOpeLogQ.size() > "+max+": "+LogPool.dsBusiOpeLogQ.size()+" ---");
							}
							try {
								int secondmil = 5000;
								if (!Env.isFormal) {
									secondmil = secondmil*1;
								}
								Thread.sleep(secondmil);
								LogTool.warn(this.getClass(), "--- sleeping "+Cons.QUEUE_DS_BUSI_LOG+" ---");
							} catch (Exception e) {
								LogTool.error(this.getClass(), e);
							}
						}else {
							// 对队列长度不为零的，进行处理
							byte[] byteValues = JedisClient_outer2.lpop(Cons.QUEUE_DS_BUSI_LOG.getBytes());
							if (byteValues != null) {
								String json = "";
								try {
									json = (String) SerializeTool.unserialize(byteValues);
									IlogBusinessOperateLog log = JsonTool.toObject(json, IlogBusinessOperateLog.class, Cons.DATE_TIME_MASK_SSS);
									LogPool.dsBusiOpeLogQ.add(log);
								} catch (Exception e) {
									LogTool.error(this.getClass(), e);
									LogTool.error(this.getClass(), json);
								}
							}
						}
						
					}
					// while over
				}
			}.start();
		}
	}
}

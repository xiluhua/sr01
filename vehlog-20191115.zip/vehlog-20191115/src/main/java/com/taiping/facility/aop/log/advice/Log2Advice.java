//package com.taiping.facility.aop.log.advice;
//
//import java.lang.reflect.Method;
//
//import javax.annotation.Resource;
//
//import org.springframework.aop.AfterReturningAdvice;
//import org.springframework.stereotype.Component;
//
//import com.taiping.facility.aop.log.Log2;
//import com.taiping.facility.aop.log.impl.BusinesslogImpl;
//import com.taiping.facility.aop.log.multi.LoggingMulti;
//import com.taiping.facility.tool.LogTool;
//import com.taiping.jinfu.constant.Cons;
//import com.taiping.jinfu.core.model.Busi;
//import com.taiping.jinfu.entity.IspRmi3;
//
///**
// * 
// * @author xilh
// * @since 20190410
// */
//@Component
//public class Log2Advice extends LoggingMulti implements AfterReturningAdvice{
//
//	@Resource
//	BusinesslogImpl businesslogImpl;
//	
//	/**
//	 * 
//	 * @author xilh
//	 * @since 20190410
//	 */
//	@Override
//	public void afterReturning(Object returnValue, Method method, Object[] args, Object target) throws Throwable {
//		LogTool.info(this.getClass(), "isAnnotationPresent(Log2.class): "+method.isAnnotationPresent(Log2.class));
//		LogTool.info(this.getClass(), "class: "+method.getDeclaringClass().getSimpleName()+", method: "+method.getName());
//		
//		Busi busi = (Busi)args[0];
//		String responseXml = (String)args[1];
//		IspRmi3 ispRmi = busi.getRmi();
//
//		if (ispRmi != null) {
//			responseXml = busi.getServiceCode()+"url: "+ ispRmi.getUrl() +System.getProperty("line.separator")+ responseXml;
//		}
//		
//		int operateStatus = 2;// 失败
//		if (busi.getResponseDTO().getBusiness().isSuccess()) {
//			operateStatus = 1;  // 成功
//		}
//		
//		// 存报文
//		businesslogImpl.postBusinessOpelog_2(busi, responseXml, busi.getServiceCode(), operateStatus, 1);
//		
//	}
//
//}

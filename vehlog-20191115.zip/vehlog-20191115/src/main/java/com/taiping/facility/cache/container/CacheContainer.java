package com.taiping.facility.cache.container;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.taiping.facility.redis.JedisClient2;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.JsonTool;
import com.taiping.facility.tool.KeyTool;
import com.taiping.facility.tool.SerializeTool;
import com.taiping.jinfu.entity.ImsSysParamList;
import com.taiping.jinfu.exception.CacheObjectNotFoundException;
import com.taiping.jinfu.exception.SystemParameterNotFoundException;
/**
 * @author xilh
 * @since 20160115
 * 缓存容器
 */
public class CacheContainer {

	public static Map<Object,Map<Object,?>> cacheMap = new HashMap<Object,Map<Object,?>>();
	
	public static Map<Object, Map<Object, ?>> getCacheMap() {
		return cacheMap;
	}
	// 用于判断是否执行过自动导入投保单号
	public static Map<String, Integer> execMap = new HashMap<String, Integer>();
	
	public static void setExecMap(String today){
		String yeday = DateTool.convertDataToString(DateTool.getYesterday(), DateTool.DATE_MASK);
		CacheContainer.execMap.remove(yeday);
		if (CacheContainer.execMap.get(today) == null) {
			CacheContainer.execMap.put(today, 1);
		}else {
			int tmp = CacheContainer.execMap.get(today);
			CacheContainer.execMap.put(today, tmp+1);
		}
	}
	
	public static void setCacheMap(Map<Object, Map<Object, ?>> cacheMap) {
		CacheContainer.cacheMap = cacheMap;
	}
	
	public static void init(Map<Object,Map<Object,?>> cacheMap){
		CacheContainer.cacheMap = cacheMap;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getByIdFromCache(Object id,Class<T> t, boolean isThrow){
		
		String key = KeyTool.get(t, id);
		String val = JedisClient2.get(key);
		if (val == null) {
			if (isThrow) {
				throw new CacheObjectNotFoundException(t.getSimpleName()+" is not inited");
			}
			return null;
		}
		return (T)JsonTool.toObject(val,t);
	}
	
	/**
	 * @author xilh
	 * @since 20180814
	 */
	public static String getSysParamValue(String parameterCode, boolean isThrow){
		
		String key = KeyTool.get(ImsSysParamList.class, parameterCode);
		String value = JedisClient2.get(key);
		if (value != null) {
			ImsSysParamList obj = (ImsSysParamList)JsonTool.toObject(value, ImsSysParamList.class);
			return obj.getParamValue();
		}else {
			if (isThrow) {
				throw new SystemParameterNotFoundException(ImsSysParamList.class.getSimpleName()+" is not available by:"+parameterCode);
			}
			return null;
		}
	}
	
	public static boolean isInSysparamRange(String sysParamCode,Object key){
		String partnerEnumNotForInnerPay = CacheContainer.getSysParamValue(sysParamCode, true);
		List<String> list = Arrays.asList(partnerEnumNotForInnerPay.split(","));
		return list.contains(String.valueOf(key));
	}

	@SuppressWarnings("unchecked")
	public static <T> List<T> getList(Class<T> t){
		String simpleName  = t.getSimpleName();
		String simpleName2 = StringUtils.capitalize(simpleName) + "Dao";
		byte[] bytes = JedisClient2.get(simpleName2.getBytes());
		Map<Object, String> tmp = (Map<Object, String>) SerializeTool.unserialize(bytes);
		List<T> list = JSON.parseArray(tmp.get(simpleName), t);
		return list;
	}
	
	/**
	 * 得到 json 形式的对象
	 * @author xilh
	 * @since 20190121
	 * @return
	 */
	@SuppressWarnings("rawtypes")
	public static String getObjectJson(String str,Class clazz){
		String key = KeyTool.get(clazz, str);
		String value = JedisClient2.get(key);
		if (value != null) {
			return value;
		}
		return null;
	}
	
}

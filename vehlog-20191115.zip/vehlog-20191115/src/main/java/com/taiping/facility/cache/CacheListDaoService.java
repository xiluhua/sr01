package com.taiping.facility.cache;

import java.util.Map;

public interface CacheListDaoService {
	
	public Map<Object,?> getAllInMap();
	
}

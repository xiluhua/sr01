package com.taiping.facility.tool;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * Velocity模板工具
 * @author amo
 * CreateDate:2016-3-12
 */
public class VelocityTool {
	/**
	 * 乘法工具1
	 * @param num1
	 * @param num2
	 * @param pattern
	 * @return
	 */
	public String multiply(String num1, double num2, String pattern) {
		String returnValue = "";
		DecimalFormat df = null;
		if (!StringUtils.isEmpty(pattern)) {
			df = new DecimalFormat(pattern);
		}
		if (num1.equalsIgnoreCase("null")) {
			num1 = "0";
		}
		if (!StringUtils.isEmpty(num1) ) {
			BigDecimal num1Bd = new BigDecimal(num1);
			double value = num1Bd.multiply(new BigDecimal(num2)).doubleValue();
			if (df != null) {
				returnValue = df.format(value);
			} else {
				returnValue = String.valueOf(value);
			}
		} 
		
		return returnValue;
	}
	
	/**
	 * 乘法工具2
	 * @param num1
	 * @param num2
	 * @param pattern
	 * @return
	 */
	public String multiply2(double num1, double num2, String pattern) {
		String returnValue = "";
		DecimalFormat df = null;
		if (!StringUtils.isEmpty(pattern)) {
			df = new DecimalFormat(pattern);
		}
		
		BigDecimal num1Bd = new BigDecimal(num1);
		double value = num1Bd.multiply(new BigDecimal(num2)).doubleValue();
		if (df != null) {
			returnValue = df.format(value);
		} else {
			returnValue = String.valueOf(value);
		}
		
		return returnValue;
	}
	
	/**
	 * 格式化数字
	 * @param numString
	 * @param pattern
	 * @return
	 */
	public String formatNum(String numString, String pattern) {
		DecimalFormat df = null;
		double num = 0.0;
		String returnValue = "";
		
		if (!StringUtils.isEmpty(numString)) {
			num = Double.parseDouble(numString);
		}
		
		if (!StringUtils.isEmpty(pattern)) {
			df = new DecimalFormat(pattern);
			returnValue = df.format(num);
		} else {
			returnValue = String.valueOf(num);
		}
		
		return returnValue;
	}
	/**
	 * 乘法工具
	 * @param num1
	 * @param num2
	 * @param pattern
	 * @return
	 */
	public String divide(double num1, double num2, String pattern) {
		String returnValue = "";
		DecimalFormat df = null;
		if (!StringUtils.isEmpty(pattern)) {
			df = new DecimalFormat(pattern);
		}
		BigDecimal num1Bd = new BigDecimal(num1);
		double value = num1Bd.divide(new BigDecimal(num2),2,RoundingMode.HALF_EVEN).doubleValue();
		if (df != null) {
			returnValue = df.format(value);
		} else {
			returnValue = String.valueOf(value);
		}
		
		return returnValue;
	}
	
	/**
	 * 乘法工具
	 * @param num1
	 * @param num2
	 * @param pattern
	 * @return
	 */
	public String divide2(Integer num1, Integer num2, String pattern) {
		String returnValue = "";
		DecimalFormat df = null;
		if (!StringUtils.isEmpty(pattern)) {
			df = new DecimalFormat(pattern);
		}
		BigDecimal num1Bd = new BigDecimal(num1);
		double value = num1Bd.divide(new BigDecimal(num2),2,RoundingMode.HALF_EVEN).doubleValue();
		if (df != null) {
			returnValue = df.format(value);
		} else {
			returnValue = String.valueOf(value);
		}
		
		return returnValue;
	}
	
	/**
	 * 乘法工具
	 * @param num1
	 * @param num2
	 * @param pattern
	 * @return
	 */
	public String divide(double num1, int num2, String pattern) {
		String returnValue = "";
		DecimalFormat df = null;
		if (!StringUtils.isEmpty(pattern)) {
			df = new DecimalFormat(pattern);
		}
		BigDecimal num1Bd = new BigDecimal(num1);
		double value = num1Bd.divide(new BigDecimal(num2),2,RoundingMode.HALF_EVEN).doubleValue();
		if (df != null) {
			returnValue = df.format(value);
		} else {
			returnValue = String.valueOf(value);
		}
		
		return returnValue;
	}
	
	/**
	 * 格式化日期
	 * @param date 日期
	 * @param pattern 格式
	 * @return
	 */
	public String formatDate(Date date, String pattern) {
		if(date == null   || StringUtils.isBlank(pattern) ){
			return null;
		}
		DateFormat df = new SimpleDateFormat(pattern);
		return df.format(date);
	}
	
	/**
	 * 去掉两边空格 
	 * @param str 格式
	 * @return
	 */
	public String trim(String str) {
		if(StringUtils.isBlank(str)){
			return null;
		}
		return str.trim();
	}
	public static void main(String[] args) {
//		System.out.println(StringUtils.isEmpty(""));
//		System.out.println(StringUtils.isEmpty(null));
//		System.out.println(StringUtils.isEmpty(" "));
//		
//		System.out.println(StringUtils.isBlank(""));
//		System.out.println(StringUtils.isBlank(null));
//		System.out.println(StringUtils.isBlank(" "));
		System.out.println(4.44444*3);
		System.out.println(new VelocityTool().divide(13.33332, 3, "0.00"));
	}
}

///**
// * @(#)BusinesslogImpl.java
// *       
// * project：taiping-sol-insu-vehicle-BRANCH-20150818
// * 
// * Copyright ©2013 - 2014 太平电子商务有限公司.  All rights reserved.
// * ADDRESS: 中国 上海 浦东新区 民生路1399号 9楼
// */
//package com.taiping.facility.aop.log.impl;
//
//import java.util.Date;
//
//import org.apache.commons.lang3.StringUtils;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.taiping.facility.aop.log.BusinesslogService;
//import com.taiping.facility.model.DsIlogBusinessOperateLog;
//import com.taiping.facility.tool.LogTool;
//import com.taiping.facility.tool.PropertyFileTool;
//import com.taiping.jinfu.constant.Cons;
//import com.taiping.jinfu.constant.Env;
//import com.taiping.jinfu.core.model.Busi;
//import com.taiping.jinfu.dao.IspSequenceDao;
//import com.taiping.jinfu.entity.IspApply;
//
///**
// * <p>Description : 业务日志服务类</p>
// * @author xiluhua by 20160119
// *
// */
//@Component
//public class BusinesslogImpl implements BusinesslogService{
//
//	@Autowired 
//	private IspSequenceDao ispSequenceDao;
//	
//	public String getBusinessOperateType_1(String businessOperateType,int phase){
//		int tmp = Math.abs(phase*2 - 1);
//		return businessOperateType+Cons.UNDERLINE+tmp;
//	}
//	
//	public String getBusinessOperateType_2(String businessOperateType,int phase){
//		int tmp = Math.abs(phase*2);
//		return businessOperateType+Cons.UNDERLINE+tmp;
//	}
//	
//	/**
//	 * 业务日志
//	 * @param apply
//	 * @param businessOperateType
//	 * @param operateStatus
//	 */
//	public void postBusinessOpelog_1(IspApply apply,String packet,String businessOperateType,Integer operateStatus,int phase){
//		
//		DsIlogBusinessOperateLog busiOpeLog = new DsIlogBusinessOperateLog();
//		try {
//			if (apply == null) {
//				return;
//			}
//			if (apply.getApplyId() == null) {
//				busiOpeLog.setApplyId(null);
//			}else {
//				busiOpeLog.setApplyId(String.valueOf(apply.getApplyId()));
//			}
//			
//			
//			if (apply.getPayId() == null) {
//				busiOpeLog.setPayId(null);
//			}else {
//				busiOpeLog.setPayId(String.valueOf(apply.getPayId()));
//			}
//			
//			busiOpeLog.setBusinessOperateType(getBusinessOperateType_1(businessOperateType, phase));
//			busiOpeLog.setOperateStatus(operateStatus);
//			busiOpeLog.setAppNo(StringUtils.defaultString(apply.getAppNo()));
//			busiOpeLog.setPremium(apply.getPremium());
//			busiOpeLog.setUserId(StringUtils.defaultString(apply.getUserId()));
//			if (apply.getHolder() != null) {
//				busiOpeLog.setHolderName(StringUtils.defaultString(apply.getHolder().getCustName()));
//				busiOpeLog.setHolderIdno(StringUtils.defaultString(apply.getHolder().getIdNo()));
//			}
//			busiOpeLog.setPartnerId(apply.getPartnerId());
//			busiOpeLog.setPartnerTransCode(StringUtils.defaultString(apply.getPartnerApplyId()));
//			busiOpeLog.setFromIp(Env.localIp);
//			busiOpeLog.setMsgPath(PropertyFileTool.get("log.msg.path"));
//			busiOpeLog.setMsg(StringUtils.defaultString(packet));
//			busiOpeLog.setCreateTime(new Date());
//			LogTool.put(busiOpeLog);
//		} catch (Exception e) {
//			LogTool.error(BusinesslogImpl.class, e);
//		}
//	}
//	
//	/**
//	 * 业务日志
//	 * @param apply
//	 * @param businessOperateType
//	 * @param operateStatus
//	 */
//	public void postBusinessOpelog_2(IspApply apply,String packet,String businessOperateType,Integer operateStatus,int phase){
//
//		DsIlogBusinessOperateLog busiOpeLog = new DsIlogBusinessOperateLog();
//		try {
//			if (apply == null) {
//				return;
//			}
//			if (apply.getApplyId() == null) {
//				busiOpeLog.setApplyId(null);
//			}else {
//				busiOpeLog.setApplyId(String.valueOf(apply.getApplyId()));
//			}
//			
//			
//			if (apply.getPayId() == null) {
//				busiOpeLog.setPayId(null);
//			}else {
//				busiOpeLog.setPayId(String.valueOf(apply.getPayId()));
//			}
//			
//			busiOpeLog.setBusinessOperateType(getBusinessOperateType_2(businessOperateType, phase));
//			busiOpeLog.setOperateStatus(operateStatus);
//			busiOpeLog.setAppNo(StringUtils.defaultString(apply.getAppNo()));
//			busiOpeLog.setPremium(apply.getPremium());
//			busiOpeLog.setUserId(StringUtils.defaultString(apply.getUserId()));
//			if (apply.getHolder() != null) {
//				busiOpeLog.setHolderName(StringUtils.defaultString(apply.getHolder().getCustName()));
//				busiOpeLog.setHolderIdno(StringUtils.defaultString(apply.getHolder().getIdNo()));
//			}
//			busiOpeLog.setPartnerId(apply.getPartnerId());
//			busiOpeLog.setPartnerTransCode(StringUtils.defaultString(apply.getPartnerApplyId()));
//			busiOpeLog.setFromIp(Env.localIp);
//			busiOpeLog.setMsgPath(PropertyFileTool.get("log.msg.path"));
//			busiOpeLog.setMsg(StringUtils.defaultString(packet));
//			busiOpeLog.setCreateTime(new Date());
//			LogTool.put(busiOpeLog);
//		} catch (Exception e) {
//			LogTool.error(BusinesslogImpl.class, e);
//		}
//	}
//	
//	// -----------------------------------------------------------------------
//	/**
//	 * 业务日志
//	 * @param busi
//	 * @param businessOperateType
//	 * @param operateStatus
//	 */
//	public void postBusinessOpelog_1(Busi busi,String packet,String businessOperateType,Integer operateStatus,int phase){
//		IspApply apply = busi.getApply();
//		DsIlogBusinessOperateLog busiOpeLog = new DsIlogBusinessOperateLog();
//		try {
//			if (apply == null) {
//				return;
//			}
//			if (apply.getApplyId() == null) {
//				busiOpeLog.setApplyId(null);
//			}else {
//				busiOpeLog.setApplyId(String.valueOf(apply.getApplyId()));
//			}
//			
//			
//			if (apply.getPayId() == null) {
//				busiOpeLog.setPayId(null);
//			}else {
//				busiOpeLog.setPayId(String.valueOf(apply.getPayId()));
//			}
//			
//			busiOpeLog.setBusinessOperateType(getBusinessOperateType_1(businessOperateType, phase));
//			busiOpeLog.setOperateStatus(operateStatus);
//			busiOpeLog.setAppNo(StringUtils.defaultString(apply.getAppNo()));
//			busiOpeLog.setPremium(apply.getPremium());
//			busiOpeLog.setUserId(StringUtils.defaultString(apply.getUserId()));
//			if (apply.getHolder() != null) {
//				busiOpeLog.setHolderName(StringUtils.defaultString(apply.getHolder().getCustName()));
//				busiOpeLog.setHolderIdno(StringUtils.defaultString(apply.getHolder().getIdNo()));
//			}
//			busiOpeLog.setPartnerId(apply.getPartnerId());
//			busiOpeLog.setPartnerTransCode(StringUtils.defaultString(busi.getBusiId()));
//			busiOpeLog.setFromIp(Env.localIp);
//			busiOpeLog.setMsgPath(PropertyFileTool.get("log.msg.path"));
//			busiOpeLog.setMsg(StringUtils.defaultString(packet));
//			busiOpeLog.setCreateTime(new Date());
//			LogTool.put(busiOpeLog);
//		} catch (Exception e) {
//			LogTool.error(BusinesslogImpl.class, e);
//		}
//	}
//	
//	/**
//	 * 业务日志
//	 * @param busi
//	 * @param businessOperateType
//	 * @param operateStatus
//	 */
//	public void postBusinessOpelog_2(Busi busi,String packet,String businessOperateType,Integer operateStatus,int phase){
//		IspApply apply = busi.getApply();
//		DsIlogBusinessOperateLog busiOpeLog = new DsIlogBusinessOperateLog();
//		try {
//			if (apply == null) {
//				return;
//			}
//			if (apply.getApplyId() == null) {
//				busiOpeLog.setApplyId(null);
//			}else {
//				busiOpeLog.setApplyId(String.valueOf(apply.getApplyId()));
//			}
//			
//			
//			if (apply.getPayId() == null) {
//				busiOpeLog.setPayId(null);
//			}else {
//				busiOpeLog.setPayId(String.valueOf(apply.getPayId()));
//			}
//			
//			busiOpeLog.setBusinessOperateType(getBusinessOperateType_2(businessOperateType, phase));
//			busiOpeLog.setOperateStatus(operateStatus);
//			busiOpeLog.setAppNo(StringUtils.defaultString(apply.getAppNo()));
//			busiOpeLog.setPremium(apply.getPremium());
//			busiOpeLog.setUserId(StringUtils.defaultString(apply.getUserId()));
//			if (apply.getHolder() != null) {
//				busiOpeLog.setHolderName(StringUtils.defaultString(apply.getHolder().getCustName()));
//				busiOpeLog.setHolderIdno(StringUtils.defaultString(apply.getHolder().getIdNo()));
//			}
//			busiOpeLog.setPartnerId(apply.getPartnerId());
//			busiOpeLog.setPartnerTransCode(StringUtils.defaultString(busi.getBusiId()));
//			busiOpeLog.setFromIp(Env.localIp);
//			busiOpeLog.setMsgPath(PropertyFileTool.get("log.msg.path"));
//			busiOpeLog.setMsg(StringUtils.defaultString(packet));
//			busiOpeLog.setCreateTime(new Date());
//			LogTool.put(busiOpeLog);
//		} catch (Exception e) {
//			LogTool.error(BusinesslogImpl.class, e);
//		}
//	}
//	
//	@Override
//	public Long getLogIndex() {
//		Long logIndex = ispSequenceDao.getSequnce(Cons.SEQ_LOG_INDEX);
//		return logIndex;
//	}
//	
//	@Override
//	public Long getLogIndexWrite(){
//		Long logIndex = ispSequenceDao.getSequnceWrite(Cons.SEQ_LOG_INDEX);
//		return logIndex;
//	}
//	
//
////	@Autowired
//	
////	private LogPoolService logPoolService;
////
////	@Override
////	public void postBusinessOpelog(ScIlogBusinessOperateLog businessOperateLog) {
////		logPoolService.put(businessOperateLog);
////	}
////	
////	/**
////	 * @name记录业务操作日志
////	 * @param CxElevQuote quote,not null
////	 * @param String businessOperateType,not null
////	 * @param Long msgId,not null
////	 * @param Long reqOrRet,not null
////	 * @param Integer operateStatus,not null
////	 * @return 
////	 * */
////	@Override
////	public void postBusinessOpelog(IspApply apply,Long businessOperateType,Long msgId,Integer operateStatus){
////		ScIlogBusinessOperateLog businessOperateLog = new ScIlogBusinessOperateLog();
////		
////		if (apply.getApplyId() != null) {
////			businessOperateLog.setApplyId(apply.getApplyId());
////		}
////
////		Integer businessOperateTypeInt = null;
////		if (businessOperateType != null) {
////			businessOperateTypeInt = Integer.valueOf(String.valueOf(businessOperateType));
////		}
////		businessOperateLog.setBusinessOperateType(businessOperateTypeInt);
////		
////		if (apply.getHolder() != null) {
////			businessOperateLog.setHolderIdno(apply.getHolder().getIdNo());
////			businessOperateLog.setHolderName(apply.getHolder().getCustName());
////		}
////
////		businessOperateLog.setMsgId(msgId);
////		businessOperateLog.setOperateNo(apply.getAppNo());
////		businessOperateLog.setOperateStatus(operateStatus);
////		businessOperateLog.setPartnerId(apply.getPartnerId());
////		businessOperateLog.setPartnerTransCode(apply.getPartnerApplyId());
////		businessOperateLog.setPayId(apply.getPayId());
////		businessOperateLog.setIp(HttpclientTool.localIp);
////		businessOperateLog.setPremium(apply.getPremium());
////		
////		if (apply.getUserId() != null) {
////			businessOperateLog.setUserId(apply.getUserId());
////		}
////		businessOperateLog.setCreateTime(new Date());
////		logPoolService.put(businessOperateLog);
////	}
////	
////	/**
////	 * @name记录业务操作日志
////	 * @param CxElevQuote quote,not null
////	 * @param String businessOperateType,not null
////	 * @param Long reqOrRet,not null
////	 * @return 
////	 * */
////	public void postBusinessOpelog(IspApply apply,Long businessOperateType){
////		this.postBusinessOpelog(apply, businessOperateType, null, 0);
////	}
////	
////	@Override
////	public void postMsgLog(String content, Long templateId, Long senderId,Long receiverId, Long logIndex) {
////		
////		ScIlogMsg msgLog = new ScIlogMsg();
////		msgLog.setMsgContent(content);
////		msgLog.setTemplateId(templateId);
////		msgLog.setSenderId(senderId);
////		msgLog.setReceiverId(receiverId);
////		msgLog.setIp(HttpclientTool.localIp);
////		msgLog.setMsgId(logIndex);
////		msgLog.setLogIndex(logIndex);
////		msgLog.setCreateTime(new Date());
////		msgLog.setMsgDocPath(PropertyFileTool.get("log.msg.path"));
////		logPoolService.put(msgLog);
////	}
////	
////	public void postBusinessOpelog(IspApply apply,Integer busiOperateType,int operateStatus,String userId){
////		String opeLogUrl = PropertyFileUtil.get("log.url")+"/businessLog";
////		ScIlogBusinessOperateLog busiOpeLog = new ScIlogBusinessOperateLog();
////		try {
////			busiOpeLog.setApplyId(apply.getApplyId());
////			busiOpeLog.setPayId(apply.getPayId());
////			busiOpeLog.setBusinessType(null);
////			busiOpeLog.setBusinessOperateType(busiOperateType);
////			
////			busiOpeLog.setOperateStatus(operateStatus);
////			busiOpeLog.setOperateNo(apply.getAppNo());
////			
////			busiOpeLog.setPremium(apply.getPremium());
////			
////			if (!StringUtils.isEmpty(apply.getUserId())) {
////				busiOpeLog.setUserId(apply.getUserId());
////			}
////			
////			if (apply.getHolder()!= null) {
////				busiOpeLog.setHolderName(apply.getHolder().getCustName());
////				busiOpeLog.setHolderIdno(apply.getHolder().getIdNo());
////			}
////
////			busiOpeLog.setCardBuyerName(userId);
////			busiOpeLog.setCardBuyerIdno(null);
////			busiOpeLog.setLinkId(null);
////			busiOpeLog.setPartnerId(apply.getPartnerId());
////			busiOpeLog.setPartnerName(null);
////			busiOpeLog.setPartnerTransCode(apply.getPartnerApplyId());
////			busiOpeLog.setPayerId(null);
////			busiOpeLog.setPayerName(null);
////			busiOpeLog.setIp(LogTool.localIp);
////			busiOpeLog.setMsgId(null);
////			logPoolService.put(busiOpeLog);
////		} catch (Exception e) {
////			LogTool.error(BusinesslogImpl.class, e);
////		}
////	}
////
////	public void postBusinessOpelog(IspApply apply,Integer busiOperateType,int operateStatus,Long messageId){
////		ScIlogBusinessOperateLog busiOpeLog = new ScIlogBusinessOperateLog();
////		try {
////			busiOpeLog.setApplyId(apply.getApplyId());
////			busiOpeLog.setPayId(apply.getPayId());
////			busiOpeLog.setBusinessType(null);
////			if (busiOperateType != null) {
////				busiOpeLog.setBusinessOperateType(busiOperateType);
////			}
////			
////			busiOpeLog.setOperateStatus(operateStatus);
////			
////			busiOpeLog.setOperateNo(apply.getAppNo());
////			busiOpeLog.setPremium(apply.getPremium());
////			
////			if (!StringUtils.isEmpty(apply.getUserId())) {
////				busiOpeLog.setUserId(apply.getUserId());
////			}
////			
////			if (apply.getHolder()!= null) {
////				busiOpeLog.setHolderName(apply.getHolder().getCustName());
////				busiOpeLog.setHolderIdno(apply.getHolder().getIdNo());
////			}
////
////			busiOpeLog.setCardBuyerName(null);
////			busiOpeLog.setCardBuyerIdno(null);
////			busiOpeLog.setLinkId(null);
////			busiOpeLog.setPartnerId(apply.getPartnerId());
////			busiOpeLog.setPartnerName(null);
////			busiOpeLog.setPartnerTransCode(apply.getPartnerApplyId());
////			busiOpeLog.setPayerId(null);
////			busiOpeLog.setPayerName(null);
////			busiOpeLog.setIp(LogTool.localIp);
////			busiOpeLog.setMsgId(messageId);
////			logPoolService.put(busiOpeLog);
////		} catch (Exception e) {
////			LogTool.error(BusinesslogImpl.class, e);
////		}
////	}
//	
//}

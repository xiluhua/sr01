package com.taiping.deploy.tool;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.atomic.AtomicInteger;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.io.support.PropertiesLoaderUtils;

import com.taiping.deploy.entity.IspRelease;
import com.taiping.facility.tool.FileStreamTool;
import com.taiping.facility.tool.FileTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.constant.Cons;

/**
 * 发布工具
 * @author xilh
 * @since 20190523
 */
public class DeployTool {
	
	public static void main(String[] args) {
//		String[] ipPorts = { "127.0.0.1:9002" };
//		String settingXml = "C:\\Users\\a\\.m2\\settings-boot03.xml";
		String settingXml = "C:\\Users\\xilh\\.m2\\settings-boot03.xml";
//		String settingXml = "D:\\Apache\\Maven\\apache-maven-3.3.9\\conf\\work\\settings-boot03.xml";

		String[] ipPorts = {
				// local
				// "127.0.0.1:9002"
				// product
				"10.4.3.20:9002",
				// "10.4.233.163:9002",
				// "10.4.233.164:9002"
		};
		System.out.println("=== 开始部署 ===");
		DeployTool.deploy(settingXml, ipPorts);
		System.out.println("=== 结束部署 ===");
	}
	
	// 上传完成结果
	public static AtomicInteger RESULT = new AtomicInteger(0);
	
	/**
	 * 部署
	 * @author xilh
	 * @since 20190528
	 * @param settingXml	maven 配置文件路径
	 * @param ipPorts		ip & port
	 */
	public static void deploy(String settingXml, String[] ipPorts) {
		IspRelease release 	= new IspRelease();
		
		if (StringUtils.isEmpty(settingXml)) {
			LogTool.error(DeployTool.class, "maven 'setting.xml' file path can not be null");
			return;
		}
		
		if (ipPorts == null || ipPorts.length == 0) {
			LogTool.error(DeployTool.class, "发布地址不能为空。举例，10.4.233.163:9002");
			return;
		}
		
		try {
			// 1. 打包
			String path = DeployTool.class.getResource("/application.properties").getPath();
			System.out.println("path: "+path);
			path 		= pkg(settingXml, path);
			// path 		= "D:\\work2019-6\\taiping-jinfu-core-BRA-20190520-xilh\\";
//			path 		= "E:\\workspace-CORE3-B\\taiping-jinfu-core-BRA-20190520-xilh\\";
			// path 		= "D:\\Eclipse\\Workspace\\taiping\\temp\\";
			
			release.setTmpVerFile(path);
			release.setNewVerFile(path);
			release.setNewVer(release.getNewVerFile().getName());
			
			LogTool.info(DeployTool.class, "IspRelease: "+release);
			// 2. 上传到服务器
			upload(ipPorts, release.getNewVerFile());
			
			// 3. 发布
			// 3.1. 将新版本 jar 包复制到发布目录： app 文件夹下
			release.cpToRemoteAppDir(ipPorts);
			
			// 3.2.看以上步骤有没有问题：看发布目录 app 文件夹下是否存在上传的 jar 包
			release.isExistNewJar(ipPorts);
			System.out.println("3.2. everything is ok!");
			
			// 3.3. 得到 old jar 包
			release.setOldVer(ipPorts);
			System.out.println("3.3. oldVer: "+release.getOldVer());
			
			// 3.4. 通过JDBC方式 - 保存到数据库
			// sequence
//			Long seq = DeployTool.getSequence("SEQ_ISP_RELEASE");
//			release.setId(seq);
//			release.setIp(Env.localIp);
//			DeployTool.save(release);
//			System.out.println("3.4. save ok! ");
			
			// 3.5. 启动项目
			release.launch(ipPorts);
			System.out.println("3.5. launch ok! ");
//			
//			// 3.6. 通过JDBC方式 - 更新发布结果到数据库
//			DeployTool.update(release);
//			System.out.println("3.6. update ok! ");
			
			// 4. 删除发布目录： app 文件夹下的 jar
			release.rmJarFromRemoteAppDir();
			
			// 5. 输出发布结果
			if (release.getFailList().size() < 1) {
				System.out.println("success!");
				return;
			}
			System.err.println("fail in: "+release.getFailList());
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 发送至远程服务器
	 * @param ipPorts
	 * @param path
	 * @throws InterruptedException
	 */
	private static void upload(String[] ipPorts, File jar) throws InterruptedException {
		Date time1 	= new Date();
		
		for (int index = 0; index < ipPorts.length; index++) {
			final int no = index;
			new Thread() {
				public void run() {  
					try {  
						String ipPort = ipPorts[no];
                        String url = "http://"+ipPort+"/deploy/upload.action";
                        System.out.println(ipPort+" begin, url   : "+url);
                        String response = DeployTool.uploadFile(jar, url);
            			System.out.println(ipPort+", url response: "+response);
            			int tmp = RESULT.incrementAndGet();
            			System.out.println(ipPort+", result: "+tmp);
					} catch (Exception e) {  
						e.printStackTrace();
					}
				}  
			}.start();
		};  
		
		while (true) {
			int tmp = RESULT.get();
			Thread.sleep(1000);
			// System.out.println("uploading: "+DateTool.convertDataToString(new Date(), DateTool.DATE_TIME_MASK));
			if (tmp == ipPorts.length) {
				break;
			}
		}

		Date time2 	= new Date();
		long inteval = time1.getTime() - time2.getTime();
		LogTool.info(DeployTool.class, "=============================================================");
		LogTool.info(DeployTool.class, inteval + "ms");
	}

	public static File getJarFile(String path) {
		path 			= path+"/target";
		List<File>list  = FileTool.getfilelist(path);
		File jar 		= DeployTool.getJarFile(list);
		return jar;
	}
    
	/**
	 * 得到 jar 包文件
	 * @author xilh
	 * @since 20190528
	 */
	public static File getJarFile(List<File> list) {
		File jar 		= null; 
		for (File file : list) {
			System.out.println("file: "+file.getName());
			if (file.getName().endsWith(".jar")) {
				jar = file;
				break;
			}
		}
		return jar;
	}

	/**
	 * 打包
	 * @author xilh
	 * @since 20190528
	 * @param settingXml
	 * @param path
	 */
	private static String pkg(String settingXml, String path) throws IOException, Exception {
		int endIndex = path.indexOf("/target");
		path = path.substring(0, endIndex)+"";
		System.out.println("path: "+path);
		File dir = new File(path);// 此处是指定路径
		String[] cmd = new String[] { "cmd", "/c", "mvn clean package --settings "+settingXml+" -Dmaven.test.skip=true"};
		System.out.println(cmd[2]);
		Process process = Runtime.getRuntime().exec(cmd, null, dir);
		FileStreamTool.printLines(process.getInputStream(), Cons.GBK);
		process.getOutputStream().close();
		return path;
	}
	
	/**
	 * 上传
	 * @author xilh
	 * @since 20190528
	 * @param file
	 * @param RequestURL
	 */
	public static String uploadFile(File file, String RequestURL) throws IOException {
        String result = null;
        String BOUNDARY = "letv"; // 边界标识 随机生成
        String PREFIX = "--", LINE_END = "\r\n";
        String CONTENT_TYPE = "multipart/form-data"; // 内容类型

        try {
            URL  url = new URL(RequestURL);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(6000);
            conn.setConnectTimeout(6000);
            conn.setDoInput(true); // 允许输入流
            conn.setDoOutput(true); // 允许输出流
            conn.setUseCaches(false); // 不允许使用缓存
            conn.setRequestMethod("POST"); // 请求方式
            conn.setRequestProperty("Charset", "utf-8"); // 设置编码
            conn.setRequestProperty("connection", "keep-alive");
            conn.setRequestProperty("Content-Type", CONTENT_TYPE + ";boundary="+ BOUNDARY);

            if (file != null) {
                /**
                 * 当文件不为空，把文件包装并且上传
                 */
                DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                StringBuffer sb = new StringBuffer();
                sb.append(PREFIX);
                sb.append(BOUNDARY);
                sb.append(LINE_END);
                /**
                 * 这里重点注意： name里面的值为服务器端需要key 只有这个key 才可以得到对应的文件
                 * filename是文件的名字，包含后缀名的 比如:abc.png
                 */
                sb.append("Content-Disposition: form-data; name=\"file\"; filename=\""
                        + file.getName() + "\"" + LINE_END);
                sb.append("Content-Type: application/ctet-stream" + LINE_END);
                sb.append(LINE_END);
                dos.write(sb.toString().getBytes());
                InputStream is = new FileInputStream(file);
                byte[] bytes = new byte[1024 * 1024];
                int len = 0;
                while ((len = is.read(bytes)) != -1) {
                    dos.write(bytes, 0, len);
                }
                is.close();
                dos.write(LINE_END.getBytes());
                byte[] end_data = (PREFIX + BOUNDARY + PREFIX + LINE_END)
                        .getBytes();
                dos.write(end_data);
                dos.flush();
                /**
                 * 获取响应码 200=成功 当响应成功，获取响应的流
                 */
                int res = conn.getResponseCode();
                System.out.println(RequestURL+", response code:" + res);
                InputStream input = conn.getInputStream();
                StringBuffer sb1 = new StringBuffer();
                int ss;
                while ((ss = input.read()) != -1) {
                    sb1.append((char) ss);
                }
                result = sb1.toString();
                result = new String(result.getBytes("iso8859-1"), "utf-8");
                // System.out.println("result : " + result);
            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return result;
    }
	
	/**
	 * 得到数据库连接
	 * @author xilh
	 * @since 20190620
	 */

	public static Connection getConnection() {
		Connection conn = null;
        try{
        	Properties prop 	= PropertiesLoaderUtils.loadAllProperties("application-dev.properties");
        	String JDBC_DRIVER 	= prop.getProperty("db.driver");
        	String DB_URL		= prop.getProperty("db1.jdbc.url");
        	String USER			= prop.getProperty("db.login.name");
        	String PSWD			= prop.getProperty("db.login.password");
            // 注册 JDBC 驱动
            Class.forName(JDBC_DRIVER);
        
            // 打开链接
            System.out.print("get DB connection ... ");
            conn = DriverManager.getConnection(DB_URL,USER,PSWD);
            return conn;
        }catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        }catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }
        return null;
	}
	
	public static void close(ResultSet rs, Statement stmt, PreparedStatement psmt, Connection conn) {
		try {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}
		} catch(SQLException se){
            // 处理 JDBC 错误
            se.printStackTrace();
        } catch(Exception e){
            // 处理 Class.forName 错误
            e.printStackTrace();
        }
	}
	
	/**
     * 插入一条记录
     * @author xilh
     * @since 20190620
     * @param object
     */
    public static void save(Object object) {
    	Connection conn 	= getConnection();
        ResultSet resultSet = null;
        Class<? extends Object> clazz 	= object.getClass();
        // 获取简单类名，数据库表名和类名一致
        String tableName = getTableName(clazz);
        // 获取字段
        PreparedStatement psmt = null;
        Field[] declaredFields = clazz.getDeclaredFields();
        String sql 			= "insert into " + tableName;
        String fieldString 	= "(";
        String valueString 	= "values(";
        // 获取字段的个数
        int length = declaredFields.length;
        try {
            for(int i = 0; i < length; i++) {
            	Field field = declaredFields[i];
                // 私有字段设置允许访问
                field.setAccessible(true);
                // 获取字段值
                Object fieldValue = field.get(object);
                boolean isSkip = isSkip(field, object);
                if (isSkip){
                	continue;
                }
                String typeName = field.getGenericType().getTypeName();
                if(typeName.toLowerCase().contains("date")) {
                    // 如果是日期类型
                    Date date = (Date) fieldValue;
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String format = dateFormat.format(date);
                    fieldValue = format;
                }
                String columnName = getColumnName(field);
                // 拼接字段名
                fieldString += columnName + ",";
                // System.out.println(fieldString);
                // 拼接字段值
                valueString += "'" + fieldValue + "',";
                //System.out.println(valueString);
            }
            fieldString = fieldString.substring(0, fieldString.lastIndexOf(","));
            fieldString = fieldString+")";
            
            valueString = valueString.substring(0, valueString.lastIndexOf(","));
            valueString = valueString+")";
            // 拼接SQL语句
            sql = sql + fieldString + valueString;
            System.out.println("SQL = " + sql);
            // 设置事务手动提交
            conn.setAutoCommit(false);
            psmt = conn.prepareStatement(sql);
            psmt.executeUpdate();
            // 提交事务
            conn.commit();
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            try {
                // 回滚事务
            	conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            e.printStackTrace();
        } finally {
            // 关闭连接
            close(resultSet, null, psmt, conn);
        }
    }

	private static String getTableName(Class<? extends Object> clazz) {
		Table table 		= clazz.getDeclaredAnnotation(Table.class);
        String tableName 	= table.name();
		return tableName;
	}
    
    public static String getColumnName(Field field) {
    	String columnName = null;
        Column column = field.getAnnotation(Column.class); 
        if (column != null) {
        	columnName = column.name();
		}else {
			columnName = field.getName();
		}
        return columnName;
    }
    
    public static boolean isSkip(Field field, Object object) throws IllegalArgumentException, IllegalAccessException {
    	boolean isSkip = false;
    	Object fieldValue = field.get(object);
        if (fieldValue == null) {
        	isSkip = true;
        }
        if (field.isAnnotationPresent(Transient.class)){
        	isSkip = true;
        }
        int modfier = field.getModifiers();
        if (modfier == 25 || modfier == 26){
        	isSkip = true;
        }
        return isSkip;
	}
    
    /**
     * 根据主键修改记录
     * @author xilh
     * @since 20190620
     * @param object
     */
    public static void update(Object object) {
    	Connection conn 		= getConnection();
        PreparedStatement psmt 	= null;
        ResultSet resultSet 	= null;
        try {
        	Class<? extends Object> clazz = object.getClass();
        	// 获取简单类名，数据库表名和类名一致
            String tableName 	= getTableName(clazz);
            // 获取数据库元数据
            DatabaseMetaData databaseMetaData = conn.getMetaData();
            // 获取给定表主键列的描述
            resultSet = databaseMetaData.getPrimaryKeys(null, null, tableName);
            String primaryKey = null;
            if(resultSet.next()) {
                // 获取主键列的名称
                primaryKey = resultSet.getString("COLUMN_NAME");
            }
            
            if(null == primaryKey) {
            	 System.err.println("主键为空！");
            }
            // 获取主键在实体类中的同名字段
            Field declaredField = clazz.getDeclaredField(primaryKey.toLowerCase());
            // 设置私有字段允许访问
            declaredField.setAccessible(true);
            // 获取字段的值
            Object primaryKeyValue = declaredField.get(object);
            // 获取字段
            Field[] declaredFields = clazz.getDeclaredFields();
            // 定义SQL语句
            String sql = "update " + tableName + " set ";
            for(Field field : declaredFields) {
            	String columnName = getColumnName(field);
            	// 主键跳过
            	if(columnName.equals(primaryKey.toLowerCase())) {
            		continue; 
            	}
                // 设置允许访问
                field.setAccessible(true);
                // 获取属性值
                Object fieldValue = field.get(object);
                boolean isSkip = isSkip(field, object);
                if (isSkip){
                	continue;
                }
                sql += columnName + "='";
                // 获取字段类型名称
                String typeName = field.getGenericType().getTypeName();
                // 不是基本数据类型
                if(typeName.toLowerCase().contains("date")) {
                    // 如果是日期类型
                    Date date = (Date) fieldValue;
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    String format = dateFormat.format(date);
                    sql += format + "', ";
                }else {
                    sql += fieldValue + "', ";
                }
            }
            // 删除最后一个逗号
            int lastIndexOf = sql.lastIndexOf(",");
            sql = sql.substring(0, lastIndexOf);
            sql += " where " + primaryKey + "='" + primaryKeyValue + "' ";
            System.out.println("SQL = " + sql);
            // 开启事务
            conn.setAutoCommit(false);
            psmt = conn.prepareStatement(sql);
            psmt.executeUpdate();
            // 提交事务
            conn.commit();
        } catch (SQLException e) {
            try {
                // 事务回滚
                conn.rollback();
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(resultSet, null, psmt, conn);
        }
    }
    
    /**
     * @author xilh
     * @since 20190620
     */
    public static Long getSequence(String sequence) {
    	Connection conn 		= getConnection();
    	PreparedStatement psmt 	= null;
    	ResultSet resultSet 	= null;
    	Long seq 				= null;
    	try {
    		String sql = "SELECT "+sequence+".NEXTVAL FROM dual";
    		System.out.println("SQL = " + sql);
    		// 开启事务
    		conn.setAutoCommit(false);
    		psmt = conn.prepareStatement(sql);
    		resultSet = psmt.executeQuery();
    		if(resultSet.next()) {
    			seq = resultSet.getLong("NEXTVAL");
    		}
    		// 提交事务
    		conn.commit();
    		return seq;
    	} catch (SQLException e) {
    		try {
    			// 事务回滚
    			conn.rollback();
    		} catch (SQLException e1) {
    			e1.printStackTrace();
    		}
    		e.printStackTrace();
    	} catch (Exception e) {
    		e.printStackTrace();
    	} finally {
    		close(resultSet, null, psmt, conn);
    	}
    	return null;
    }
}

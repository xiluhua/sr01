package com.taiping.deploy.entity;

import java.io.Serializable;

/**
 * 发布结果
 * @author xilh
 * @since 20190604
 */
public class IspReleaseResult implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -5127635775002810660L;
	public String ip; 
	public String port; 
	public String result; // 0 成功|其他失败
	
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getPort() {
		return port;
	}
	public void setPort(String port) {
		this.port = port;
	}
	
	public IspReleaseResult(String ip, String result) {
		super();
		this.ip = ip;
		this.result = result;
	}
	public IspReleaseResult() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "IspReleaseResult [ip=" + ip + ", port=" + port + ", result=" + result + "]";
	}
	
}

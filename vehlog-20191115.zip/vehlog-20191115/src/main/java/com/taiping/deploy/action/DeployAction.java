package com.taiping.deploy.action;


import java.io.File;

import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.taiping.boot.Bootup;
import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.action.BaseAction;
import com.taiping.jinfu.constant.Cons;

/**
 * 发布
 * @author xilh
 * @since 20190523
 */
@RestController
@RequestMapping(value = "/deploy")
public class DeployAction extends BaseAction {
	
	/**
	 * local: http://localhost:9002/deploy/upload.action
	 * prod : http://10.4.233.163:9002/deploy/upload.action
	 * @author xilh
	 * @since 20190523
	 */
	@PostMapping("/upload.action")
    @ResponseBody
    public String upload(@RequestParam("file") MultipartFile file) {
		try {
	        if (file.isEmpty()) {
	            return "file is empty!";
	        }
       
        	String fileName = file.getOriginalFilename();
        	AnnotationConfigServletWebServerApplicationContext resourceLoader = new AnnotationConfigServletWebServerApplicationContext();
			org.springframework.core.io.Resource[] resources = ((ResourcePatternResolver) resourceLoader).getResources(Bootup.PATH_APPLICATION_CONTEXT);
			resourceLoader.close();
			String xmlPath = resources[0].getFile().getAbsolutePath();
			String path    = xmlPath.substring(0, xmlPath.indexOf(Cons.PROJECT_NAME));
			LogTool.info(this.getClass(), "path: "+path);
			path = path+"/deploy/";
			
			if (!new File(path).exists()) {
				new File(path).mkdirs();
			}
		    File dest = new File(path + fileName);
		    LogTool.info(this.getClass(), SUCCESS);
			
            file.transferTo(dest);
            return SUCCESS;
        } catch (Exception e) {
        	LogTool.error(this.getClass(), e);
        }
        return FAILURE;
    }

}
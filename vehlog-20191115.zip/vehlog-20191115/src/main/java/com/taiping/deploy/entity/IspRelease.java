package com.taiping.deploy.entity;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.alibaba.fastjson.JSON;
import com.taiping.deploy.tool.DeployTool;
import com.taiping.deploy.tool.RemoteShellTool;
import com.taiping.facility.tool.DateTool;
import com.taiping.facility.tool.FilesUtil;
import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.constant.Cons;
import com.taiping.jinfu.exception.TpRuntimeException;

/**
 * 发布历史
 * @author xilh
 * @since 20190604
 */
@Table(name="ISP_RELEASE")
public class IspRelease implements Serializable{
	public static final String APP_DIR = Cons.PROJECT_NAME+"/app/";
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5127635775002810660L;
	public Long id;
	@Column(name="OLD_VER")
	public String oldVer;  
	@Column(name="NEW_VER")
	public String newVer;
	public String ip; 
	public String memo; 
	@Column(name="RESULT_SUCC")
	public String resultSucc; // 成功结果
	@Column(name="RESULT_FAIL")
	public String resultFail; // 失败结果
	public Date createTime;
	@Transient
	public String newVerDateStr;
	@Transient
	public boolean isSuccess;
	@Transient
	public File tmpVerFile;  
	@Transient
	public File newVerFile; 
	@Transient
	public Map<String,Object> oldVerMap = new HashMap<String,Object>(); 
	@Transient
	public List<IspReleaseResult> succList = new ArrayList<>(); 
	@Transient
	public List<IspReleaseResult> failList = new ArrayList<>(); 

	public File getTmpVerFile() {
		return tmpVerFile;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getOldVer() {
		return oldVer;
	}
	public void setOldVer(String oldVer) {
		this.oldVer = oldVer;
	}
	public String getNewVer() {
		return newVer;
	}
	public void setNewVer(String newVer) {
		this.newVer = newVer;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public File getNewVerFile() {
		return this.newVerFile;
	}
	public void setNewVerFile(File newVerFile) {
		this.newVerFile = newVerFile;
	}
	public String getNewVerDateStr() {
		return newVerDateStr;
	}
	public void setNewVerDateStr(String newVerDateStr) {
		this.newVerDateStr = newVerDateStr;
	}
	/**
	 * set 临时版本
	 * @author xilh
	 * @since 20190604
	 * @param path
	 */
	public void setTmpVerFile(String path) {
		File jar = DeployTool.getJarFile(path);
		this.tmpVerFile = jar;
	}
	public Map<String, Object> getOldVerMap() {
		return oldVerMap;
	}
	public void setOldVerMap(Map<String, Object> oldVerMap) {
		this.oldVerMap = oldVerMap;
	}
	
	/**
	 * set 新版本
	 * @author xilh
	 * @since 20190604
	 * @param path
	 */
	public void setNewVerFile(String path) {
		String now  		= DateTool.convertDataToString(new Date(), DateTool.DATE_MASK2)+"-"+DateTool.convertDataToString(new Date(), DateTool.TIME_PATTERN_MASK_4);
		String newVerPath 	= path+"\\target\\"+Cons.PROJECT_WHOLE_NAME+"-"+now+".jar";
		new FilesUtil().copyFile(this.getTmpVerFile().getAbsolutePath(), newVerPath);
		this.newVerFile 	= new File(newVerPath);
		this.newVerDateStr 	= now;
	}
	
	public void setTmpVerFile(File tmpVerFile) {
		this.tmpVerFile = tmpVerFile;
	}
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public List<IspReleaseResult> getSuccList() {
		return succList;
	}
	public void setSuccList(List<IspReleaseResult> succList) {
		this.succList = succList;
	}
	public List<IspReleaseResult> getFailList() {
		return failList;
	}
	public void setFailList(List<IspReleaseResult> failList) {
		this.failList = failList;
	}
	public String getResultSucc() {
		return resultSucc;
	}
	public void setResultSucc(String resultSucc) {
		this.resultSucc = resultSucc;
	}
	public String getResultFail() {
		return resultFail;
	}
	public void setResultFail(String resultFail) {
		this.resultFail = resultFail;
	}
	@Override
	public String toString() {
		return "IspRelease [id=" + id + ", oldVer=" + oldVer + ", newVer=" + newVer + ", ip=" + ip + ", memo=" + memo
				+ ", resultSucc=" + resultSucc + ", resultFail=" + resultFail + ", createTime=" + createTime
				+ ", newVerDateStr=" + newVerDateStr + ", isSuccess=" + isSuccess + ", tmpVerFile=" + tmpVerFile
				+ ", newVerFile=" + newVerFile + ", succList=" + succList + ", failList=" + failList + "]";
	}
	/**
	 * 将新版本 jar 包复制到发布目录： app 文件夹下
	 * @author xilh
	 * @since 20190620
	 */
	public void cpToRemoteAppDir(String[] ipPorts) {
		String cmd = "cp deploy/"+this.getNewVerFile().getName()+" "+APP_DIR;
		for (String ipPort : ipPorts) {
			String ip = ipPort.split(":")[0];
			RemoteShellTool.execute(ip, cmd);
		}
	}
	
	/**
	 * 看以上步骤有没有问题：看发布目录 app 文件夹下是否存在上传的 jar 包
	 * @author xilh
	 * @since 20190620
	 */
	public void isExistNewJar(String[] ipPorts) {
		String cmd = "cd "+IspRelease.APP_DIR+" && ls "+this.getNewVerFile().getName();
		for (String ipPort : ipPorts) {
			String ip		= ipPort.split(":")[0];
			String result 	= RemoteShellTool.execute(ip, cmd);
			if (result.indexOf("cannot access") > -1 || result.indexOf("No such") > -1) {
				if (result.endsWith("\r\n")) {
					int index = result.lastIndexOf("\r\n");
					result = result.substring(0, index);
				}
				if (result.endsWith("\n")) {
					int index = result.lastIndexOf("\n");
					result = result.substring(0, index);
				}
				String ex = "发布失败："+result;
				LogTool.error(DeployTool.class, "# =========================");
				LogTool.error(DeployTool.class, "# "+ex);
				LogTool.error(DeployTool.class, "# =========================");
				throw new TpRuntimeException(ex);
			}	
		}
	}
	
	/**
	 * 得到 old jar 包
	 * @author xilh
	 * @since 20190620
	 */
	public void setOldVer(String[] ipPorts) {
		String cmd = "cd "+Cons.PROJECT_NAME+"/app/ && ls *.jar|grep -v "+this.getNewVer();
		for (String ipPort : ipPorts) {
			String ip		= ipPort.split(":")[0];
			String oldVer 	= RemoteShellTool.execute(ip, cmd);
			if (oldVer.endsWith("\n")) {
				oldVer = oldVer.substring(0, oldVer.lastIndexOf("\n"));
			}
			LogTool.info(RemoteShellTool.class, ip+", oldVer: "+oldVer);
			this.oldVerMap.put(ip, oldVer);
		}
		this.oldVer = JSON.toJSONString(oldVerMap);
	}
	
	/**
	 * 启动
	 * @author xilh
	 * @since 20190620
	 * @param ipPorts
	 */
	public void launch(String[] ipPorts) {
		for (String ipPort : ipPorts) {
			String ip 		= ipPort.split(":")[0];
			String port 	= ipPort.split(":")[1];
			String cmd 		= "cd "+Cons.PROJECT_NAME+"/bin/ && sh start.sh "+port+" 5 "+this.getNewVerDateStr();
			String result 	= RemoteShellTool.execute(ip, cmd);
			
			LogTool.info(DeployTool.class, ip+", result: "+ result);
			if (result.endsWith("\n")) {
				result = result.substring(0, result.lastIndexOf("\n"));
			}
			if (result.equals(Cons.STR_0)) {
				this.succList.add(new IspReleaseResult(ip, result));
			}else {
				this.failList.add(new IspReleaseResult(ip, result));
			}
		}

		if (this.succList.size() > 0) {
			this.resultSucc = JSON.toJSONString(succList);
		}
		
		if (this.failList.size() > 0) {
			this.resultFail = JSON.toJSONString(failList);
		}
	}

	/**
	 * 删除发布目录： app 文件夹下的 jar
	 * @author xilh
	 * @since 20190620
	 */
	public void rmJarFromRemoteAppDir() {
		String cmd = "cd "+APP_DIR+" && rm ";
		// 4.1. 发布成功，删除 old jar
		if (this.getSuccList() != null && this.getSuccList().size() > 0) {
			for (IspReleaseResult releaseResult : this.getSuccList()) {
				String oldVer = this.getOldVerMap().get(releaseResult.getIp()).toString();
				cmd = cmd + oldVer;
				RemoteShellTool.execute(releaseResult.getIp(), cmd);
			}
			System.out.println("4.1. rm old jar ok! ");
		}
		
		// 4.2. 发布失败，删除 new jar
		if (this.getFailList() != null && this.getFailList().size() > 0) {
			for (IspReleaseResult releaseResult : this.getFailList()) {
				cmd = cmd + this.getNewVer();
				RemoteShellTool.execute(releaseResult.getIp(), cmd);
			}
			System.out.println("4.2. rm new jar ok! ");
		}
	}
	
	public static void main(String[] args) {
//		Connection conn = DeployTool.getConnection();
//		System.out.println(conn);
//		DeployTool.close(null, null, null, conn);
		
		
//		IspRelease release = new IspRelease();
		// sequence
		Long seq = DeployTool.getSequence("SEQ_ISP_RELEASE");
		System.out.println(seq);
		
		// save
//		release.setId(6L);
//		release.setIp(Env.localIp);
//		release.setMemo("测试6");
//		release.setOldVer("taiping-jinfu-core-0.0.1-SNAPSHOT.jar");
//		release.setNewVer("taiping-jinfu-core-20190620-090909.jar");
//		release.setResult(Env.localIp+":0");
//		DeployTool.insert(release);
		
		// update
//		release.setId(6L);
//		release.setResult("23333");
//		DeployTool.update(release);
		
	}
	
}

package com.taiping.deploy.tool;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;

import org.apache.commons.lang3.StringUtils;

import com.taiping.facility.tool.LogTool;

import ch.ethz.ssh2.Connection;
import ch.ethz.ssh2.Session;
import ch.ethz.ssh2.StreamGobbler;

public class RemoteShellTool {
	// rm by xiluhua 20190618
	// private static String ip = "10.4.3.20";
	private static String userName = "weblogic";
	private static String userPwd = "24pwd123!";
	private static Connection connection = null;

	public static Connection getConnection() {
		return connection;
	}

	public static void setConnection(Connection connection) {
		RemoteShellTool.connection = connection;
	}

	public static void closeConnection() {
		connection.close();
	}

	public static Connection login(String ip) {
		setConnection(new Connection(ip));
		try {
			getConnection().connect();// 连接
			// 认证
			if (getConnection().authenticateWithPassword(userName, userPwd)) {
				LogTool.info(RemoteShellTool.class, "登录成功："+ip);
				return getConnection();
			}
		} catch (IOException e) {
			LogTool.error(RemoteShellTool.class, "=== 登录失败===");
			LogTool.error(RemoteShellTool.class, e);
		}
		return getConnection();
	}

	public static String execute(String ip, String cmd) {
		String result = "";
		Connection conn = RemoteShellTool.login(ip);
		try {
			if (conn != null) {
				Session session = conn.openSession();// 打开一个会话
				session.execCommand(cmd);// 执行命令
				result = processStdout(session.getStdout(), "UTF-8");
				// 如果为得到标准输出为空，说明脚本执行出错了
				if (StringUtils.isBlank(result)) {
					LogTool.info(RemoteShellTool.class, "得到标准输出为空,链接conn:" + conn + ",执行的命令：" + cmd);
					result = processStdout(session.getStderr(), "UTF-8");
				} else {
					LogTool.info(RemoteShellTool.class, "执行命令成功,链接conn:" + conn + ",执行的命令：" + cmd);
				}
				session.close();
			}
		} catch (IOException e) {
			LogTool.info(RemoteShellTool.class, "执行命令失败,链接conn:" + conn + ",执行的命令：" + cmd + "  " + e.getMessage());
			LogTool.error(RemoteShellTool.class, e);
		}
		return result;
	}

	private static String processStdout(InputStream in, String charset) {
		InputStream stdout = new StreamGobbler(in);
		StringBuffer buffer = new StringBuffer();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(stdout, charset));
			String line = null;
			while ((line = br.readLine()) != null) {
				buffer.append(line + "\n");
			}
		} catch (UnsupportedEncodingException e) {
			LogTool.info(RemoteShellTool.class, "解析脚本出错");
			LogTool.error(RemoteShellTool.class, e);
		} catch (IOException e) {
			LogTool.info(RemoteShellTool.class, "解析脚本出错");
			LogTool.error(RemoteShellTool.class, e);
		} finally {
			try {
				stdout.close();
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return buffer.toString();
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		String sss = "123,";
		if (sss.endsWith(",")) {
			sss = sss.substring(0, sss.length()-1);
		}
		System.out.println(sss);
		
//		Connection connection = new Connection("10.4.3.20");
//		connection.connect();// 连接
//		connection.authenticateWithPassword("loginuser", "Tpl!f81qsxas");// 认证
//		Session session = connection.openSession();
//		session.waitForCondition(ChannelCondition.CLOSED | ChannelCondition.EOF | ChannelCondition.EXIT_STATUS, 100*1000);
//		 
//		String cmd = "ls -l && ls -l";
//		session.execCommand(cmd);
//
//		InputStream is = new StreamGobbler(session.getStdout());// 获得标准输出流
//		FileStreamTool.printLines(is, Cons.UTF8);
//
//		if (session != null) {
//			session.close();
//		}
//		if (connection != null) {
//			connection.close();
//		}
	}
}

package com.taiping;

import com.taiping.deploy.tool.DeployTool;

/**
 * 发布生产
 * @author xilh
 * @since 20190523
 */
public class Deploy {

	public static void main(String[] args) {
		String settingXml = "C:\\Users\\a\\.m2\\settings-boot03.xml";
//		String settingXml = "D:\\Apache\\Maven\\apache-maven-3.3.9\\conf\\work\\settings-boot03.xml";

		String[] ipPorts = {
				// local
				// "127.0.0.1:9112"
				// uat
//				"10.0.113.19:9114"
				// product
				 "10.0.113.24:9114",
				 "10.0.113.25:9114",
		};
		System.out.println("=== 开始部署 ===");
		DeployTool.deploy(settingXml, ipPorts);
		System.out.println("=== 结束部署 ===");
	}

}

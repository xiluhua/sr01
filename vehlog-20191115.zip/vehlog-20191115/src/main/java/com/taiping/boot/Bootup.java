package com.taiping.boot;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.lang.annotation.ElementType;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.velocity.VelocityContext;
import org.springframework.boot.web.servlet.context.AnnotationConfigServletWebServerApplicationContext;
import org.springframework.context.annotation.ClassPathBeanDefinitionScanner;
import org.springframework.context.support.GenericApplicationContext;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;

import com.taiping.SpringBootJinfuVehicleLogApplication;
import com.taiping.facility.aop.log.Log1;
import com.taiping.facility.aop.log.Log2;
import com.taiping.facility.aop.log.Log3;
import com.taiping.facility.aop.log.Log4;
import com.taiping.facility.dataSource.MultiDataSource;
import com.taiping.facility.tool.FilesUtil;
import com.taiping.facility.tool.IOTool;
import com.taiping.facility.tool.LogTool;
import com.taiping.facility.tool.TemplateToolV1218;
import com.taiping.jinfu.constant.Cons;
import com.taiping.jinfu.constant.Env;

/**
 * 启动
 * @author xilh
 * @since 20190409
 * @param args
 * @return
 */
public class Bootup {
	
	static boolean isFirst										= true;
	public final static String utf8 				 			= "utf-8";
	public final static String APPLICATION_CONTEXT_XML 			= "applicationContext.xml";
	public final static String APPLICATION_CONTEXT_XML_ORIGIN 	= "applicationContextOrigin.xml";
	public final static String PATH							 	= "file:///home/weblogic/"+Cons.PROJECT_NAME+"/conf/";
	public final static String PATH_APPLICATION_CONTEXT		 	= PATH + APPLICATION_CONTEXT_XML;
	private final static String POINTCUT_SPACE 					= "<!--POINTCUT SPACE-->";     
	private final static String ADVISER_SPACE  					= "<!--ADVISER SPACE-->"; 
	private final static String POINTCUT  = "<aop:pointcut id=\"$!{advice-ref}PointCut$!{index}\"  expression=\"execution(* $!{pkg}.*(..))\" />"; 
	private final static String ADVISER   = "<aop:advisor  pointcut-ref=\"$!{advice-ref}PointCut${index}\" advice-ref=\"$!{advice-ref}\" order=\"$!{order}\" />"; 
	
	/**
	 * 启动前
	 * @author xilh
	 * @since 20190409
	 * @param args
	 * @return
	 */
	public String[] aopConfig(String[] args) {
		if (args == null || args.length == 0) {
			try {
				AopConfig[] arr = new AopConfig[] { 
						new AopConfig(MultiDataSource.class, 1), 
						new AopConfig(Log1.class, 2),
						new AopConfig(Log2.class, 2), 
						new AopConfig(Log3.class, 3),
						new AopConfig(Log4.class, 3),
				};
				
				String[]  pkgs     = new String[] { "com.taiping" };
				boolean flag = this.createAopConfigByAnnotation(Arrays.asList(arr), pkgs);
				if ( !flag ) {
					return new String[]{"2"};
				}
				args = new String[]{"1"};

			} catch (Exception e) {
				LogTool.error(SpringBootJinfuVehicleLogApplication.class, e);
				return new String[]{"2"};
			}
		}
		return args;
	}
	
	/**
	 * 启动前
	 * @author xilh
	 * @since 20190409
	 * @param args
	 * @return
	 */
	public String[] envAndAopConfig(String[] args) {
		Thread thread = Thread.currentThread();
		System.out.println(thread.getName());
		// 环境
		Env.ENV = Cons.DEV;
		if (args.length > 0 && args[0].toLowerCase().indexOf(Cons.PROD) > -1) {
			Env.ENV = Cons.PROD;
		}
		
		try {
			// LOCAL
			if (args == null || args.length == 0) {
				LogTool.debug(this.getClass(), "LOCAL ...");
				Resource resource = new DefaultResourceLoader().getResource("application-dev.properties");
				String path  	  = resource.getFile().getAbsolutePath();
				String content	  = IOTool.readFile(path, Cons.UTF8);
				content			  = content.replace("172.31.20.236", "10.0.113.19");
				IOTool.writeIntoTxt(path, content, false, Cons.UTF8);
				content	  = IOTool.readFile(path, Cons.UTF8);
				
				if (thread.getName().equals("main")) {
					return args;
				}
			}
		
			// UAT or PROD
			if (args.length == 1) {
				LogTool.debug(this.getClass(), "UAT or PROD ...");
			}
		
			AopConfig[] arr = new AopConfig[] { 
					new AopConfig(MultiDataSource.class, 1), 
					new AopConfig(Log1.class, 2),
					new AopConfig(Log2.class, 2), 
					new AopConfig(Log3.class, 3),
					new AopConfig(Log4.class, 3),
			};
			
			String[] pkgs	= new String[] { "com.taiping" };
			boolean flag	= this.createAopConfigByAnnotation(Arrays.asList(arr), pkgs);
			if (!flag) {
				System.exit(1);
			}
			
		} catch (Exception e) {
			LogTool.error(SpringBootJinfuVehicleLogApplication.class, e);
			System.exit(1);
		}
		return args;
	}
	
	public boolean createAopConfigByAnnotation(List<AopConfig> aopConfigs, String ... pkgs) throws UnsupportedEncodingException, Exception {
		Set<String> candidateBeans				= new HashSet<>();      
		Map<String, AopBean> aopBeans			= new HashMap<>();
		GenericApplicationContext context 		= new GenericApplicationContext();
		ClassPathBeanDefinitionScanner scanner  = new ClassPathBeanDefinitionScanner(context);
		boolean flag 			= true;
		StringBuilder builder1 	= new StringBuilder("");
		StringBuilder builder2 	= new StringBuilder("");
		System.out.println("----------------------------------------------------------------------------------------------");
		System.out.println("----------------------------------- CREATE AOP CONFIG BEGIN! ---------------------------------");
		System.out.println("----------------------------------------------------------------------------------------------");
		
		try {
			for (int i = 0; i < pkgs.length; i++) {
				int beanCount = scanner.scan(pkgs[i]);
				System.out.println("beanCount: "+beanCount);
				String[] beans = context.getBeanDefinitionNames();
				candidateBeans.addAll(Arrays.asList(beans));
			}
			
			for (AopConfig aopConfig : aopConfigs) {
				aopBeans.putAll(this.loadBeanClassesAnnoted(context, candidateBeans, aopConfig));
			}
			
			System.out.println("anno beanCount: "+aopBeans.size());
			if (aopBeans.size() == 0) {
				return true;
			}
			
			builder1 = this.buildPointcut(aopBeans);
			builder2 = this.buildAdvisor(aopBeans);
			
			// System.out.println(builder1.toString());
			// System.out.println(builder2.toString());
		} catch (Exception e) {
			flag = false;
			e.printStackTrace();
		} finally {
			context = null;
			scanner = null;
			
			// read
			InputStream in = getClass().getClassLoader().getResourceAsStream(APPLICATION_CONTEXT_XML_ORIGIN);
			String content = new String(FilesUtil.read(in), utf8);
			
			// rewrite
			AnnotationConfigServletWebServerApplicationContext resourceLoader = new AnnotationConfigServletWebServerApplicationContext();
			Resource[] resources = ((ResourcePatternResolver) resourceLoader).getResources(PATH_APPLICATION_CONTEXT);
			resourceLoader.close();
			String xmlPath = resources[0].getFile().getAbsolutePath();
			System.out.println(APPLICATION_CONTEXT_XML+" path: "+xmlPath);
			
			// add by xiluhua 20190507
			String temp = xmlPath.replace(APPLICATION_CONTEXT_XML, "");
			if (!new File(temp).exists()) {
				new File(temp).mkdirs();
			}
			if (new File(xmlPath).exists()) {
				new File(xmlPath).delete();
			}
			
			content = content.replaceAll(POINTCUT_SPACE, builder1.toString());
			content = content.replaceAll(ADVISER_SPACE,  builder2.toString());
			IOTool.writeIntoTxt(xmlPath, content, false, utf8);
			content = IOTool.readFile(xmlPath, utf8);
			
			System.out.println("*********************************************************************************************");
			System.out.println("******************************** CREATE AOP CONFIG SUCCESS! *********************************");
			System.out.println(content);
			System.out.println("*********************************************************************************************");
		}
		return flag;
	}
	
	/**
     * 复制单个文件 从classpath中读取文件复制
     * @param path  不能以/开头   指向文件不能是目录
     * @param newpath   指向文件不能是目录
     */
    public static void copyFileFromJar(String path,String newpath) {
        try {
            //创建新文件
            makeFile(newpath);
            //获取文件流
            InputStream in = Bootup.class.getClassLoader().getResourceAsStream(path);
            //将流写入新文件
            write2File(in, newpath);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	/**
     * 复制path目录下所有文件  
     * @param path  文件目录 不能以/开头
     * @param newpath 新文件目录
     */
    public static void BatCopyFileFromJar(String path,String newpath) {
        ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        try {
            //获取所有匹配的文件
            Resource[] resources = resolver.getResources(path+"/*");
            //打印有多少文件
            LogTool.info(Bootup.class, "*****************"+resources.length);
            for(int i=0;i<resources.length;i++) {
                Resource resource=resources[i];

                try {
                    //以jar运行时，resource.getFile().isFile() 无法获取文件类型，会报异常，抓取异常后直接生成新的文件即可；以非jar运行时，需要判断文件类型，避免如果是目录会复制错误，将目录写成文件。
                    if(resource.getFile().isFile()) {
                        makeFile(newpath+"/"+resource.getFilename());
                        InputStream stream = resource.getInputStream();
                        write2File(stream, newpath+"/"+resource.getFilename()); 
                    }
                }catch (Exception e) {
                    LogTool.info(Bootup.class ,"-------------"+e.getMessage());
                    makeFile(newpath+"/"+resource.getFilename());
                    InputStream stream = resource.getInputStream();
                    write2File(stream, newpath+"/"+resource.getFilename());
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 创建文件
     * @param path  全路径 指向文件
     * @return
     */
    public static boolean makeFile(String path) {  
        File file = new File(path);  
        if(file.exists()) {  
        	LogTool.info(Bootup.class, "文件已存在！");  
            return false;  
        }  
        if (path.endsWith(File.separator)) {  
           LogTool.info(Bootup.class, "不能为目录！");  
            return false;  
        }  
        if(!file.getParentFile().exists()) {   
            if(!file.getParentFile().mkdirs()) {  
               LogTool.info(Bootup.class, "创建目标文件所在目录失败！");  
                return false;  
            }  
        }  
        try {  
            if (file.createNewFile()) {  
               LogTool.info(Bootup.class, "创建文件" + path + "成功！");  
                return true;  
            } else {  
               LogTool.info(Bootup.class, "创建文件" + path + "失败！");  
                return false;  
            }  
        } catch (IOException e) {  
            e.printStackTrace();  
           LogTool.info(Bootup.class, "创建文件" + path + "失败！" + e.getMessage());  
            return false;  
        }  
    }  
    
    
    /**
     * 输入流写入文件
     * 
     * @param is
     *            输入流
     * @param filePath
     *            文件保存目录路径
     * @throws IOException
     */
    public static void write2File(InputStream is, String filePath) throws IOException {
        OutputStream os = new FileOutputStream(filePath);
        int len = 8192;
        byte[] buffer = new byte[len];
        while ((len = is.read(buffer, 0, len)) != -1) {
            os.write(buffer, 0, len);
        }
        os.close();
        is.close();
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    ////////////////////////////////////////////////////////////
	private StringBuilder buildPointcut(Map<String, AopBean> aopBeans) throws ClassNotFoundException {
		StringBuilder builder = new StringBuilder();
		
		int i = 0;
		for (Map.Entry<String, AopBean> entry : aopBeans.entrySet()) {
			AopBean aopBean = entry.getValue();
			String pointcut = this.fill(POINTCUT, aopBean, (i+1));
			builder.append(pointcut);
			builder.append(System.getProperty("line.separator"));
			i++;
		}
		
		return builder;
	}

	private StringBuilder buildAdvisor(Map<String, AopBean> aopBeans) throws ClassNotFoundException {
		StringBuilder builder = new StringBuilder();
		int i = 0;
		for (Map.Entry<String, AopBean> entry : aopBeans.entrySet()) {
			AopBean aopBean = entry.getValue();
			String advisor = this.fill(ADVISER, aopBean, (i+1));
			builder.append(advisor);
			builder.append(System.getProperty("line.separator"));
			i++;
		}
		return builder;
	}

	private Map<String, AopBean> loadBeanClassesAnnoted(GenericApplicationContext context, Set<String> beans, AopConfig aopConfig) throws ClassNotFoundException {
		Map<String, AopBean> map1 = this.loadBeanClassesAnnotedClass(context, beans, aopConfig);
		Map<String, AopBean> map2 = this.loadBeanClassesAnnotedMethod(context, beans, aopConfig, map1);
		map1.putAll(map2);
		return map1;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, AopBean> loadBeanClassesAnnotedClass(GenericApplicationContext context, Set<String> beans, AopConfig aopConfig) throws ClassNotFoundException {
		Map<String, AopBean> map  = new HashMap<>();
		Class anno = aopConfig.getAnno();
		for (String bean : beans) {
			String clazz = context.getBeanDefinition(bean).getBeanClassName();
			if (Class.forName(clazz).isAnnotationPresent(anno)) 
			{
				AopBean aopBean = new AopBean();
				aopBean.setAopConfig(aopConfig);
				aopBean.setAnno(anno);				
				aopBean.setBeanDefinition(context.getBeanDefinition(bean));
				aopBean.setElementType(ElementType.TYPE);
				String key = bean+":"+anno.getSimpleName()+":"+aopBean.getElementType();
				map.put(key, aopBean);
			}
		}
		return map;
	}
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private Map<String, AopBean> loadBeanClassesAnnotedMethod(GenericApplicationContext context, Set<String> beans, AopConfig aopConfig, Map<String, AopBean> classMap) throws ClassNotFoundException {
		Map<String, AopBean> map  = new HashMap<>();
		Class anno = aopConfig.getAnno();
		for (String bean : beans) {
			String clazz = context.getBeanDefinition(bean).getBeanClassName();
			Method[] methods = Class.forName(clazz).getDeclaredMethods();
			for (Method method : methods) {
				if (method.isAnnotationPresent(anno)) 
				{
					AopBean aopBean = new AopBean();
					aopBean.setAopConfig(aopConfig);
					aopBean.setAnno(anno);				
					aopBean.setBeanDefinition(context.getBeanDefinition(bean));
					aopBean.setElementType(ElementType.METHOD);
					aopBean.setMethod(method);
					// 已经注解 class 则忽略 method
					String key1 = bean+":"+anno.getSimpleName()+":"+ElementType.TYPE;
					String key2 = bean+":"+anno.getSimpleName()+":"+aopBean.getElementType()+":"+method.getName();
					if ( classMap != null && classMap.get(key1) != null) {
						break;
					}
					map.put(key2, aopBean);
				}
			}
		}
		return map;
	}
	
	private String fill(String template, AopBean aopBean, int index) {
		String pkg = null;
		if (aopBean.getMethod() != null) {
			pkg = aopBean.getBeanDefinition().getBeanClassName()+"."+aopBean.getMethod().getName();
		} else {
			pkg = aopBean.getBeanDefinition().getBeanClassName();
		}
		
		VelocityContext context = new VelocityContext();
		context.put("advice-ref", aopBean.getAopConfig().getAdviceRef());
		context.put("index", index);
		context.put("pkg", pkg);
		context.put("order", aopBean.getAopConfig().getOrder());
		String result = TemplateToolV1218.fill(context, template);
		
		if (aopBean.getMethod() != null) {
			result = result.replace(".*", "");
		}
		
		if (index != 1 ) {
			result = "\t\t"+result;
		}
		return result;
	}
}

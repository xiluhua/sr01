package com.taiping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.ImportResource;

import com.taiping.boot.Bootup;
import com.taiping.facility.tool.LogTool;
import com.taiping.jinfu.constant.Cons;
import com.taiping.jinfu.constant.Env;

/**
 * @ImportResource: file:///home/weblogic/${Cons.PROJECT_NAME}/conf/applicationContext.xml
 * @author xilh
 * @since 20190228
 */
@ImportResource(value = {Bootup.PATH_APPLICATION_CONTEXT})
@SpringBootApplication
public class SpringBootJinfuVehicleLogApplication {
	
	public static void main(String[] args) {
		
		new Bootup().envAndAopConfig(args);
		
		ConfigurableApplicationContext ctx = SpringApplication.run(SpringBootJinfuVehicleLogApplication.class, args);
		
		String url = ctx.getEnvironment().getProperty(Cons.DB_JDBC_URL);
		LogTool.info(SpringBootJinfuVehicleLogApplication.class, "# ==============================");
		LogTool.info(SpringBootJinfuVehicleLogApplication.class, "# It is running ...             ");
		LogTool.info(SpringBootJinfuVehicleLogApplication.class, "# Env     : "+Env.ENV);
		LogTool.info(SpringBootJinfuVehicleLogApplication.class, "# Database: "+Env.DATABASE);
		LogTool.info(SpringBootJinfuVehicleLogApplication.class, "# DB_URL  : "+url);
		LogTool.info(SpringBootJinfuVehicleLogApplication.class, "# ==============================");
	}
	
}

